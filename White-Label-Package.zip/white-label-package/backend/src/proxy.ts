import { NextResponse, type NextRequest } from 'next/server';
import { createServerClient } from '@supabase/ssr';

// Next.js 16 "proxy" (formerly middleware). Refreshes the Supabase session cookie
// and sends signed-out visitors on /member or /admin to the sign-in page.
// Pages still check access themselves; this is the first gate, not the only one.
export async function proxy(req: NextRequest) {
  let res = NextResponse.next({ request: req });
  const sb = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll: () => req.cookies.getAll(),
      setAll: (list) => {
        for (const { name, value } of list) req.cookies.set(name, value);
        res = NextResponse.next({ request: req });
        for (const { name, value, options } of list) res.cookies.set(name, value, options);
      },
    },
  });
  const { data } = await sb.auth.getUser();
  if (!data.user) {
    const login = req.nextUrl.clone();
    login.pathname = '/login';
    login.search = `?next=${encodeURIComponent(req.nextUrl.pathname + req.nextUrl.search)}`;
    return NextResponse.redirect(login);
  }
  res.headers.set('Cache-Control', 'private, no-store');
  return res;
}

export const config = { matcher: ['/member/:path*', '/admin/:path*'] };
