import { NextResponse, type NextRequest } from 'next/server';
import crypto from 'node:crypto';
import { env } from '@/lib/env';
import { buildReport } from '@/lib/reportData';
import { rateLimit } from '@/lib/ratelimit';

// The quarterly licensee report for the licensor's fleet console (product/licensor).
// Off unless LICENSOR_REPORT_TOKEN is set. Counts and totals only; no personal data.
//   GET /api/licensor/report?quarter=2026-Q3   Authorization: Bearer <LICENSOR_REPORT_TOKEN>
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const same = (a: string, b: string) => {
  const x = crypto.createHash('sha256').update(a).digest(), y = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(x, y);
};

export async function GET(req: NextRequest) {
  const token = env().LICENSOR_REPORT_TOKEN;
  if (!token) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
  if (!rateLimit(`licensor:${ip}`, 30, 60 * 60_000).ok) return NextResponse.json({ error: 'Too many requests' }, { status: 429 });
  const auth = req.headers.get('authorization') || '';
  if (!auth.startsWith('Bearer ') || !same(auth.slice(7).trim(), token)) return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  const q = req.nextUrl.searchParams.get('quarter') || undefined;
  if (q && !/^\d{4}-Q[1-4]$/.test(q)) return NextResponse.json({ error: 'Use quarter=YYYY-Q1..Q4' }, { status: 400 });
  try {
    return NextResponse.json(await buildReport(q), { headers: { 'Cache-Control': 'no-store' } });
  } catch {
    return NextResponse.json({ error: 'Report unavailable' }, { status: 503 });
  }
}
