import type { NextRequest } from 'next/server';
import { preflight } from '@/lib/http';
import { handleLead } from '@/lib/leadRoute';
import { auditSchema } from '@/lib/validation';
import { auditResultEmail, sendMail } from '@/lib/email';
import { rateLimit } from '@/lib/ratelimit';

// Set links.auditWebhook in the site's assets/config.js to https://<APP_URL>/api/audit
export const runtime = 'nodejs';
export const OPTIONS = preflight;

export function POST(req: NextRequest) {
  return handleLead(req, 'audit', auditSchema, (d) => {
    const { email, company, marketingConsent, page, website: _hp, ...rest } = d;
    return { kind: 'audit', email, company, marketingConsent, page, payload: rest };
  }, async (d) => {
    // The visitor added their email to receive the result: send it (at most twice a day per address,
    // so the form can't be used to flood someone else's inbox).
    if (!d.email) return;
    const to = d.email.trim().toLowerCase();
    if (!rateLimit(`audit-mail:${to}`, 2, 24 * 60 * 60_000).ok) return;
    const r = await sendMail({ to, ...auditResultEmail(d) });
    if (!r.ok) console.error('[audit] result email failed:', r.error);
  });
}
