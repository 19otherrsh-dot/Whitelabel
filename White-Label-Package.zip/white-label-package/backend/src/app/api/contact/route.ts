import type { NextRequest } from 'next/server';
import { preflight } from '@/lib/http';
import { handleLead } from '@/lib/leadRoute';
import { contactSchema } from '@/lib/validation';
import { sendMail } from '@/lib/email';
import { env } from '@/lib/env';

// Set links.contactWebhook in the site's assets/config.js to https://<APP_URL>/api/contact
export const runtime = 'nodejs';
export const OPTIONS = preflight;

export function POST(req: NextRequest) {
  return handleLead(req, 'contact', contactSchema,
    (d) => ({ kind: 'contact', email: d.email, name: d.name, company: d.company, marketingConsent: d.marketingConsent, page: d.page,
      payload: { topic: d.topic, message: d.message } }),
    async (d) => {
      // Forward to the inbox, with Reply-To set to the visitor so a reply goes straight back.
      await sendMail({
        to: env().SUPPORT_EMAIL,
        replyTo: d.email,
        subject: `${d.topic || 'Enquiry'} from ${d.name}${d.company ? `, ${d.company}` : ''}`,
        text: `${d.message}\n\n${d.name}${d.company ? `, ${d.company}` : ''}\n${d.email}\nSent from ${d.page || 'the contact page'}`,
      });
    });
}
