import type Stripe from 'stripe';
import { NextResponse, type NextRequest } from 'next/server';
import { env } from '@/lib/env';
import { stripe } from '@/lib/stripe';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { fulfilCheckout, handleDispute, handleRefund, releaseCheckout } from '@/lib/fulfil';
import { fulfilRenewal, refundRenewal } from '@/lib/renewal';

// Stripe → this endpoint. Point a webhook at https://<APP_URL>/api/stripe/webhook with these events:
//   checkout.session.completed, checkout.session.async_payment_succeeded,
//   checkout.session.async_payment_failed, checkout.session.expired,
//   charge.refunded, charge.dispute.created
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  const sig = req.headers.get('stripe-signature');
  if (!sig) return NextResponse.json({ error: 'missing signature' }, { status: 400 });
  const raw = await req.text();

  let event: Stripe.Event;
  try {
    event = stripe().webhooks.constructEvent(raw, sig, env().STRIPE_WEBHOOK_SECRET);
  } catch {
    return NextResponse.json({ error: 'bad signature' }, { status: 400 });
  }

  const sb = supabaseAdmin();
  // Idempotency: Stripe retries and can deliver an event more than once.
  const { data: seen } = await sb.from('stripe_events').select('processed_at').eq('id', event.id).maybeSingle();
  if (seen?.processed_at) return NextResponse.json({ received: true, duplicate: true });
  if (!seen) await sb.from('stripe_events').insert({ id: event.id, type: event.type });

  try {
    let outcome: string = 'ignored';
    switch (event.type) {
      case 'checkout.session.completed':
      case 'checkout.session.async_payment_succeeded':
        outcome = event.data.object.metadata?.type === 'renewal' ? await fulfilRenewal(event.data.object) : await fulfilCheckout(event.data.object);
        break;
      case 'checkout.session.async_payment_failed':
      case 'checkout.session.expired':
        await releaseCheckout(event.data.object);
        outcome = 'released';
        break;
      case 'charge.refunded':
        outcome = (await refundRenewal(event.data.object)) ? 'renewal-refund' : (await handleRefund(event.data.object), 'refund');
        break;
      case 'charge.dispute.created':
        await handleDispute(event.data.object);
        outcome = 'dispute';
        break;
    }
    await sb.from('stripe_events').update({ processed_at: new Date().toISOString(), error: null }).eq('id', event.id);
    return NextResponse.json({ received: true, outcome });
  } catch (err) {
    const message = (err as Error).message;
    console.error('[stripe-webhook]', event.type, event.id, message);
    await sb.from('stripe_events').update({ error: message.slice(0, 2000) }).eq('id', event.id);
    // 500 makes Stripe retry with backoff for up to three days.
    return NextResponse.json({ error: 'processing failed' }, { status: 500 });
  }
}
