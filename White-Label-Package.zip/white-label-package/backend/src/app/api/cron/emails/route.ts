import { NextResponse, type NextRequest } from 'next/server';
import crypto from 'node:crypto';
import { env } from '@/lib/env';
import { runSchedule } from '@/lib/scheduleRun';

// Sends the scheduled emails that are due (reminders, recordings, support and library notices).
// Call it every 15 minutes, at least hourly:
//   Vercel Cron (vercel.json; Vercel sends "Authorization: Bearer <CRON_SECRET>"), Supabase pg_cron + pg_net,
//   or any scheduler that can send a GET with that header. Off until CRON_SECRET is set.
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

const same = (a: string, b: string) => crypto.timingSafeEqual(crypto.createHash('sha256').update(a).digest(), crypto.createHash('sha256').update(b).digest());

export async function GET(req: NextRequest) {
  const secret = env().CRON_SECRET;
  if (!secret) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  const auth = req.headers.get('authorization') || '';
  if (!auth.startsWith('Bearer ') || !same(auth.slice(7).trim(), secret)) return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  try {
    return NextResponse.json(await runSchedule(), { headers: { 'Cache-Control': 'no-store' } });
  } catch (e) {
    console.error('[cron/emails]', (e as Error).message);
    return NextResponse.json({ error: 'Run failed' }, { status: 500 });
  }
}
