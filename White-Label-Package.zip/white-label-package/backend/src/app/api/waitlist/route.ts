import type { NextRequest } from 'next/server';
import { preflight } from '@/lib/http';
import { handleLead } from '@/lib/leadRoute';
import { waitlistSchema } from '@/lib/validation';

// Waitlist and free-training sign-ups: POST { kind: "waitlist" | "training", email, name?, company?, marketingConsent? }
export const runtime = 'nodejs';
export const OPTIONS = preflight;

export function POST(req: NextRequest) {
  return handleLead(req, 'waitlist', waitlistSchema,
    (d) => ({ kind: d.kind, email: d.email, name: d.name, company: d.company, marketingConsent: d.marketingConsent, page: d.page, payload: {} }));
}
