import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabase/admin';

// Uptime check: 200 when the app and database answer. Reveals nothing else.
export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const { error } = await supabaseAdmin().from('cohorts').select('id', { head: true, count: 'exact' }).limit(1);
    if (error) throw error;
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false }, { status: 503 });
  }
}
