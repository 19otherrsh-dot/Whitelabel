'use server';
import { redirect } from 'next/navigation';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { attemptByToken, validToken } from '@/lib/examData';
import { EXAM, autoMarks, cleanAnswers, examState } from '@/lib/exam';
import { rateLimit } from '@/lib/ratelimit';
import { sendMail } from '@/lib/email';
import { env } from '@/lib/env';

const page = (token: string, q = '') => `/exam/${token}${q}`;

async function attemptFor(form: FormData) {
  const token = String(form.get('token') ?? '');
  if (!validToken(token)) redirect('/exam/invalid');
  if (!rateLimit(`exam:${token}`, 120, 60 * 60_000).ok) redirect(page(token, '?error=busy'));
  const a = await attemptByToken(token);
  if (!a) redirect('/exam/invalid');
  return { token, a: a! };
}

/** Start the clock. Starting twice keeps the first start time. */
export async function startExam(form: FormData) {
  const { token, a } = await attemptFor(form);
  const state = examState(a);
  if (state !== 'ready') redirect(page(token));
  const now = new Date();
  await supabaseAdmin().from('exam_attempts')
    .update({ started_at: now.toISOString(), deadline: new Date(now.getTime() + EXAM.minutes * 60_000).toISOString() })
    .eq('id', a.id).is('started_at', null);
  redirect(page(token));
}

/**
 * Save answers ("save" keeps going; "submit" hands in). After the deadline (plus a short grace)
 * nothing more is accepted and the last saved answers are handed in.
 */
export async function saveExam(form: FormData) {
  const { token, a } = await attemptFor(form);
  const sb = supabaseAdmin();
  const state = examState(a);
  if (state === 'submitted' || state === 'expired' || state === 'ready') redirect(page(token));
  const now = new Date();
  if (state === 'time_up') {
    await finish(a.id, a.answers ?? {}, a.instructors?.name, now);
    redirect(page(token, '?late=1'));
  }
  const raw: Record<string, unknown> = {};
  for (const q of EXAM.questions) raw[q.n] = form.get(`q${q.n}`);
  const answers = { ...(a.answers ?? {}), ...cleanAnswers(raw) };
  // A cleared short answer clears the saved one too.
  for (const q of EXAM.questions) if (q.type === 'short' && form.has(`q${q.n}`) && !String(form.get(`q${q.n}`) ?? '').trim()) delete answers[q.n];
  if (form.get('intent') === 'submit') {
    await finish(a.id, answers, a.instructors?.name, now);
    redirect(page(token));
  }
  await sb.from('exam_attempts').update({ answers }).eq('id', a.id).is('submitted_at', null);
  redirect(page(token, `?saved=${now.getTime()}`));
}

async function finish(id: string, answers: Record<string, string>, name: string | undefined, now: Date) {
  const sb = supabaseAdmin();
  await sb.from('exam_attempts').update({ answers, marks: autoMarks(answers), submitted_at: now.toISOString() }).eq('id', id).is('submitted_at', null);
  const e = env();
  await sendMail({ to: e.SUPPORT_EMAIL, subject: `[Certification] Exam handed in${name ? ` · ${name}` : ''}`, text: `Mark the short answers: ${e.APP_URL}/admin/instructors/exam/${id}` });
}

