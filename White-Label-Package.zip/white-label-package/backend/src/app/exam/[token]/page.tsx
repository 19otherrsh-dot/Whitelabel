import type { Metadata } from 'next';
import { Shell } from '@/components/Shell';
import { Inline } from '@/components/Inline';
import { attemptByToken } from '@/lib/examData';
import { EXAM, examState, publicExam } from '@/lib/exam';
import { env } from '@/lib/env';
import { startExam, saveExam } from './actions';
import { Deadline } from '@/components/Deadline';

export const metadata: Metadata = { title: 'Instructor certification exam', robots: { index: false, follow: false } };
export const dynamic = 'force-dynamic';

export default async function Exam({ params, searchParams }: { params: Promise<{ token: string }>; searchParams: Promise<Record<string, string | undefined>> }) {
  const [{ token }, sp] = await Promise.all([params, searchParams]);
  const a = await attemptByToken(token);
  const e = env();
  if (!a) {
    return <Shell narrow><h1>Exam link not found</h1><div className="card">This link isn’t valid. Check you copied the whole link from the email, or ask <a href={`mailto:${e.SUPPORT_EMAIL}`}>{e.SUPPORT_EMAIL}</a> for a new one.</div></Shell>;
  }
  const state = examState(a);
  const name = a.instructors?.name?.split(' ')[0];

  if (state === 'expired') {
    return <Shell narrow><h1>This exam link has expired</h1><div className="card">Ask <a href={`mailto:${e.SUPPORT_EMAIL}`}>{e.SUPPORT_EMAIL}</a> for a new invitation.</div></Shell>;
  }
  if (state === 'submitted' || state === 'time_up') {
    return (
      <Shell narrow>
        <h1>Exam handed in</h1>
        <div className="card">
          {sp.late && <p>Time was up, so your last saved answers were handed in.</p>}
          <p>Thanks{name ? `, ${name}` : ''}. Multiple-choice questions are marked automatically; an assessor marks the short answers against the key and accepts equivalent wording.</p>
          <p style={{ margin: 0 }}>{a.result === 'pending' ? 'You’ll get your result by email, usually within 5 business days.' : a.result === 'pass' ? <><span className="pill ok">Passed</span> {a.score} of {EXAM.questions.length}.</> : <><span className="pill bad">Not passed this time</span> {a.score} of {EXAM.questions.length}. Your assessor will email what to review before a retake.</>}</p>
        </div>
      </Shell>
    );
  }
  if (state === 'ready') {
    return (
      <Shell narrow>
        <h1>Instructor certification exam</h1>
        <div className="card stack">
          <p>Hi{name ? ` ${name}` : ''}. This is Part 2 of instructor certification: {EXAM.questions.length} questions, {EXAM.minutes} minutes.</p>
          <ul>
            <li>Kit documentation is allowed (<code>README.md</code>, <code>docs/</code>, the curriculum). The answer key is not, and the work must be your own.</li>
            <li>Pass: {EXAM.passScore} of {EXAM.questions.length} ({EXAM.passPercent}%) <b>and</b> every ★ safety question correct.</li>
            <li>The clock starts when you press Start and doesn’t stop if you close the page. Use <b>Save</b> as you go; when time is up, your last saved answers are handed in.</li>
            <li>Short answers are marked by an assessor, who accepts equivalent wording.</li>
          </ul>
          <form action={startExam}><input type="hidden" name="token" value={token} /><button className="btn buy" type="submit">Start the exam ({EXAM.minutes} minutes)</button></form>
          <p className="small muted" style={{ margin: 0 }}>This link is personal to you. Please don’t share it.</p>
        </div>
      </Shell>
    );
  }

  // In progress
  return (
    <Shell>
      <h1>Instructor certification exam</h1>
      <div className="notice" role="status" style={{ position: 'sticky', top: 64, zIndex: 4 }}>
        Hand in by <Deadline iso={a.deadline!} />. {sp.saved ? 'Saved. ' : ''}{sp.error === 'busy' ? 'Too many saves in a short time; wait a moment. ' : ''}Save every few questions.
      </div>
      <form action={saveExam} className="stack">
        <input type="hidden" name="token" value={token} />
        {publicExam().map((q) => {
          const v = a.answers?.[q.n] ?? '';
          return (
            <fieldset key={q.n} className="q">
              <legend>{q.n}. {q.safety && <span title="Safety question" aria-label="Safety question">★ </span>}<Inline text={q.text} /></legend>
              {q.type === 'short'
                ? <><label className="sr" htmlFor={`q${q.n}`}>Your answer to question {q.n}</label><textarea id={`q${q.n}`} name={`q${q.n}`} rows={3} maxLength={4000} defaultValue={v} /></>
                : q.options!.map((o, j) => <label key={j}><input type="radio" name={`q${q.n}`} value={j} defaultChecked={v === String(j)} /> <span><Inline text={o} /></span></label>)}
            </fieldset>
          );
        })}
        <div className="row" style={{ position: 'sticky', bottom: 0, background: 'var(--bg)', padding: '12px 0' }}>
          <button className="btn" type="submit" name="intent" value="save">Save</button>
          <button className="btn buy" type="submit" name="intent" value="submit">Hand in</button>
          <span className="small muted">Hand in is final.</span>
        </div>
      </form>
    </Shell>
  );
}
