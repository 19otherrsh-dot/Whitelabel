import type { Metadata } from 'next';
import { Shell, Notice, memberNav } from '@/components/Shell';
import { requireUser, isAdmin } from '@/lib/auth';
import { loadMember } from '@/lib/memberData';
import { env } from '@/lib/env';
import { money, likeExact, seatName } from '@/lib/rules';
import { loadCourse } from '@/lib/courseData';
import { shareUsage, markSetupDone } from './actions';
import { supabaseAdmin } from '@/lib/supabase/admin';

export const metadata: Metadata = { title: 'Your member area' };
export const dynamic = 'force-dynamic';

const when = (iso: string, tz: string) =>
  new Date(iso).toLocaleString('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', timeZone: tz, timeZoneName: 'short' });
const day = (iso: string) => new Date(iso).toLocaleDateString('en-US', { dateStyle: 'long' });

export default async function Member({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { sb, user } = await requireUser('/member');
  const { member, enrollment, ent } = await loadMember(sb, user.id);
  const e = env();
  const admin = await isAdmin(user.id);
  const nav = admin ? [...memberNav, { href: '/admin', label: 'Admin' }] : memberNav;

  if (!enrollment || !ent.active) {
    return (
      <Shell nav={nav} current="/member" signedIn>
        <h1>Welcome{member?.full_name ? `, ${member.full_name.split(' ')[0]}` : ''}</h1>
        <Notice error={sp.notice === 'not-admin' ? 'That area is for staff only.' : undefined} />
        <div className="card">
          <p>{enrollment ? 'This seat is no longer active, so sessions and downloads are closed.' : 'We can’t find a seat for this email address.'}</p>
          <p className="muted small">Signed in as {user.email}. If you paid with a different address, sign out and use that one, or write to <a href={`mailto:${e.SUPPORT_EMAIL}`}>{e.SUPPORT_EMAIL}</a>.</p>
          <a className="btn" href={`${e.SITE_URL}/pricing.html`}>See seats and pricing</a>
        </div>
      </Shell>
    );
  }

  const tz = enrollment.cohorts?.time_zone || 'UTC';
  const selfPaced = !!enrollment.cohorts?.self_paced;
  const [{ data: sessions }, { data: latest }, { data: attended }, { count: audits }, course] = await Promise.all([
    sb.from('cohort_sessions').select('id, position, title, starts_at, ends_at, join_url, replay_url').eq('cohort_id', enrollment.cohort_id).order('position'),
    sb.from('releases').select('version, notes, published_at, size_bytes').eq('is_latest', true).maybeSingle(),
    sb.from('attendance').select('session_id, attended').eq('member_id', user.id),
    supabaseAdmin().from('leads').select('id', { count: 'exact', head: true }).eq('kind', 'audit').ilike('email', likeExact((user.email ?? '').toLowerCase())),
    loadCourse(sb, user.id),
  ]);
  const cs = course.status;
  const went = new Set((attended ?? []).filter((a) => a.attended).map((a) => a.session_id));
  const now = Date.now();
  const nextSession = (sessions ?? []).find((s) => Date.parse(s.ends_at) > now);

  return (
    <Shell nav={nav} current="/member" signedIn>
      <p className="muted small">{enrollment.cohorts?.name} · {seatName(enrollment.seat, selfPaced)}</p>
      <h1>Welcome{member?.full_name ? `, ${member.full_name.split(' ')[0]}` : ''}</h1>
      <Notice ok={sp.ok} error={sp.error} />

      <div className="grid">
        {selfPaced
          ? <div className="card stat"><b>{cs.modulesComplete} of {cs.modules.length}</b><span>Course modules complete</span></div>
          : <div className="card stat"><b>{nextSession ? when(nextSession.starts_at, tz) : 'All done'}</b><span>{nextSession ? `Next: ${nextSession.title}` : 'Every session has run. Replays are below.'}</span></div>}
        <div className="card stat"><b>{ent.library ? (enrollment.library_until ? day(enrollment.library_until) : 'Active') : 'Ended'}</b><span>Library access and updates</span></div>
        <div className="card stat"><b>{ent.support ? (enrollment.support_until ? day(enrollment.support_until) : 'Active') : 'Ended'}</b><span>Support</span></div>
      </div>

      <h2>The course</h2>
      <div className="card">
        <p>{selfPaced ? 'Six modules of short lessons, each with a quiz and an assignment we review.' : 'Short lessons for every session, to prepare, catch up or rewatch, with a quiz and an assignment per module.'} {cs.lessonsDone ? `You’ve watched ${cs.lessonsDone} of ${cs.lessonsTotal} lessons.` : ''}</p>
        <progress className="bar" max={cs.lessonsTotal} value={cs.lessonsDone} aria-label={`${cs.lessonsDone} of ${cs.lessonsTotal} lessons watched`} style={{ marginBottom: 14 }} />
        <a className="btn" href={cs.complete ? '/member/course/certificate' : cs.next ? `/member/course/${cs.next}` : '/member/course'}>{cs.complete ? 'Your certificate' : cs.lessonsDone ? `Continue with Module ${cs.next}` : 'Start Module 1'}</a>{' '}
        <a className="small" href="/member/course">All modules</a>
      </div>

      <h2>Your workspace kit</h2>
      <div className="card">
        {latest ? (
          <>
            <p><b>Version {latest.version}</b> <span className="muted small">· {day(latest.published_at)}{latest.size_bytes ? ` · ${(latest.size_bytes / 1e6).toFixed(1)} MB` : ''}</span></p>
            {latest.notes && <p className="small" style={{ whiteSpace: 'pre-wrap' }}>{latest.notes}</p>}
            {ent.library
              ? <a className="btn buy" href="/member/download">Download the kit</a>
              : <p className="muted">Library access has ended. The files you already downloaded are yours to keep. <a href="/member/renew">Renew access to new releases</a>.</p>}
          </>
        ) : <p className="muted">{selfPaced ? 'The kit will appear here shortly.' : 'The kit will appear here before Session 1.'}</p>}
        <h3 style={{ marginTop: 20 }}>{selfPaced ? 'Getting started (Module 1 walks you through it)' : 'Before Session 1'}</h3>
        <ol className="steps">
          <li>Download the kit, unzip it somewhere you keep work files, and double-click <b>Install on Mac</b> or <b>Install on Windows</b>.</li>
          {!!audits && <li>You took the free audit with this email: <a href="/member/audit-answers">download your answers</a> and put the file in the workspace’s <code>data/imports/</code> folder. The interview starts from them instead of asking again.</li>}
          <li>Start Claude in the folder (<code>bin/wf start</code>) and say “run the onboarding interview” (15 to 45 minutes). It writes your knowledge base.</li>
          <li>Open the department library (<code>bin/wf library</code>) and pick a starter for your first department.</li>
          <li>Open the console (<code>bin/wf serve</code>) and check the map shows your business.</li>
        </ol>
        {enrollment.setup_done_at
          ? <form action={markSetupDone} className="row" style={{ marginTop: 6 }}><span className="pill ok">Setup done</span><input type="hidden" name="undo" value="1" /><button className="linkbtn small" type="submit">Not quite? Undo</button></form>
          : <form action={markSetupDone} style={{ marginTop: 6 }}><button className="btn sm" type="submit">I’ve finished these steps (bin/wf doctor shows no problems)</button></form>}
        <p className="small muted">Stuck on any step? <a href="/member/support">Ask for help</a>. That’s what the support window is for.</p>
      </div>

      {!selfPaced && (<>

      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'baseline' }}>
        <h2>Live sessions</h2>
        <a className="btn sm" href="/member/calendar.ics">Add all to calendar</a>
      </div>
      <div className="card tablewrap">
        <table>
          <thead><tr><th>#</th><th>Session</th><th>When</th><th>Link</th><th>Attended</th></tr></thead>
          <tbody>
            {(sessions ?? []).map((s) => {
              const live = now >= Date.parse(s.starts_at) - 60 * 60_000 && now <= Date.parse(s.ends_at);
              const past = now > Date.parse(s.ends_at);
              return (
                <tr key={s.id}>
                  <td>{s.position}</td>
                  <td>{s.title}</td>
                  <td>{when(s.starts_at, tz)}</td>
                  <td>
                    {past
                      ? (s.replay_url ? <a href={s.replay_url} rel="noopener">Recording</a> : <span className="muted">Recording soon</span>)
                      : s.join_url ? <a className={live ? 'btn buy sm' : undefined} href={s.join_url} rel="noopener">{live ? 'Join now' : 'Join link'}</a> : <span className="muted">Link coming</span>}
                  </td>
                  <td>{past ? (went.has(s.id) ? <span className="pill ok">Yes</span> : <span className="pill">Not recorded</span>) : ''}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <p className="small muted" style={{ marginTop: 12 }}>The build guarantee needs live attendance at all six sessions. If a session shows “Not recorded” but you were there, <a href="/member/support">tell us</a>.</p>
      </div>
      </>)}

      {e.COMMUNITY_URL && (
        <>
          <h2>Community</h2>
          <div className="card"><p>SOPs, recordings, documentation and the other members.</p><a className="btn" href={e.COMMUNITY_URL} rel="noopener">Open the community</a></div>
        </>
      )}

      <h2>Help improve the kit</h2>
      <div className="card">
        <p>Your workspace can write a summary of how often each kit skill ran, failed or had work rejected: counts only, with no names, content, recipients or the names of skills you built. Sharing it is optional and shows us which skills to improve first.</p>
        <ol className="steps small">
          <li>In your workspace, run <code>bin/wf learn --export</code>.</li>
          <li>Open the file it names in <code>output/learning/</code> if you’d like to see exactly what’s in it.</li>
          <li>Upload it here. It’s stored without your name or email.</li>
        </ol>
        <form action={shareUsage} className="row">
          <label className="sr" htmlFor="usage-report">Usage summary file</label>
          <input id="usage-report" name="report" type="file" accept="application/json,.json" required />
          <button className="btn sm" type="submit">Share summary</button>
        </form>
      </div>

      <h2>Your seat</h2>
      <div className="card small">
        <p>Paid {money(enrollment.amount_paid, enrollment.currency)} on {day(enrollment.created_at)} · signed in as {user.email}</p>
        <p style={{ margin: 0 }}> <a href="/member/renew">Library access and renewal</a> · <a href="/member/guarantee">{selfPaced ? 'Refunds' : 'Refunds and the build guarantee'}</a> · <a href={`${e.SITE_URL}/terms.html`}>Terms</a> · <a href={`${e.SITE_URL}/privacy.html`}>Privacy</a></p>
      </div>
    </Shell>
  );
}
