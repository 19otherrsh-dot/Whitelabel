'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { requireUser } from '@/lib/auth';
import { loadMember } from '@/lib/memberData';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { LESSON_IDS, gradeQuiz, moduleByNumber } from '@/lib/course';
import { rateLimit } from '@/lib/ratelimit';
import { sendMail } from '@/lib/email';
import { env } from '@/lib/env';

const back = (path: string, k: 'ok' | 'error', msg: string, extra = '') => redirect(`${path}?${k}=${encodeURIComponent(msg)}${extra}`);

/** Every course action needs a signed-in member with an active seat. */
async function activeMember(path: string) {
  const { sb, user } = await requireUser(path);
  const { enrollment, ent } = await loadMember(sb, user.id);
  if (!enrollment || !ent.active) back('/member', 'error', 'The course is open to members with an active seat.');
  return { sb, user };
}

function moduleFrom(form: FormData) {
  const n = Number(form.get('module'));
  const m = Number.isInteger(n) ? moduleByNumber(n) : null;
  if (!m) back('/member/course', 'error', 'We couldn’t find that module.');
  return m!;
}

/** Mark a lesson as watched, or undo it. */
export async function toggleLesson(form: FormData) {
  const m = moduleFrom(form);
  const path = `/member/course/${m.n}`;
  const { sb, user } = await activeMember(path);
  const lesson = String(form.get('lesson') ?? '');
  if (!LESSON_IDS.has(lesson) || !m.lessons.some((l) => l.id === lesson)) back(path, 'error', 'We couldn’t find that lesson.');
  // Written with the member's own client: row-level security checks it's theirs and the seat is active.
  const { error } = form.get('undo') === '1'
    ? await sb.from('course_progress').delete().eq('member_id', user.id).eq('lesson_id', lesson)
    : await sb.from('course_progress').upsert({ member_id: user.id, lesson_id: lesson }, { onConflict: 'member_id,lesson_id' });
  if (error) back(path, 'error', 'That didn’t save. Please try again.');
  revalidatePath(path);
  redirect(`${path}#l-${lesson.replace('.', '-')}`);
}

/** Grade a quiz on the server and keep the attempt. */
export async function submitQuiz(form: FormData) {
  const m = moduleFrom(form);
  const path = `/member/course/${m.n}`;
  const { user } = await activeMember(path);
  if (!rateLimit(`quiz:${user.id}`, 20, 60 * 60_000).ok) back(path, 'error', 'That’s a lot of attempts in an hour. Take a break and rewatch the lessons first.', '#quiz');
  const answers: Record<string, number> = {};
  for (const q of m.quiz) {
    const v = form.get(`q-${q.id}`);
    if (typeof v === 'string' && /^\d+$/.test(v)) answers[q.id] = Number(v);
  }
  if (Object.keys(answers).length < m.quiz.length) back(path, 'error', 'Answer every question, then check your answers.', '#quiz');
  const r = gradeQuiz(m, answers);
  const { data, error } = await supabaseAdmin().from('quiz_attempts').insert({ member_id: user.id, module: m.n, answers, score: r.score, total: r.total, passed: r.passed }).select('id').single();
  if (error) back(path, 'error', 'That didn’t save. Please try again.', '#quiz');
  revalidatePath(path);
  redirect(`${path}?attempt=${(data as { id: string }).id}#quiz`);
}

const submissionSchema = z.object({
  body: z.string().trim().min(20, 'Paste your command output and notes (at least a couple of lines).').max(20000, 'That’s longer than we can take here. Put long files in a shared folder and link it.'),
  link: z.union([z.literal(''), z.string().trim().url('That link doesn’t look right.').startsWith('https://', 'Links must start with https://')]),
});

/** Send a module's assignment for review. */
export async function submitAssignment(form: FormData) {
  const m = moduleFrom(form);
  const path = `/member/course/${m.n}`;
  const { user } = await activeMember(path);
  if (!rateLimit(`submit:${user.id}`, 10, 24 * 60 * 60_000).ok) back(path, 'error', 'You’ve sent several submissions today. We’ll review what you’ve sent first.', '#assignment');
  const parsed = submissionSchema.safeParse({ body: form.get('body') ?? '', link: form.get('link') ?? '' });
  if (!parsed.success) back(path, 'error', parsed.error.issues[0].message, '#assignment');
  const d = parsed.data!;
  // Rough guard against pasting secrets: refuse anything that looks like a live key.
  if (/\b(sk_live_|sk-ant-|xox[bp]-|ghp_|AKIA[0-9A-Z]{12})/.test(d.body)) back(path, 'error', 'That looks like it contains an API key or token. Remove it (and rotate the key in that tool), then send again.', '#assignment');
  const sb = supabaseAdmin();
  const { error } = await sb.from('course_submissions').insert({ member_id: user.id, module: m.n, body: d.body, link: d.link || null });
  if (error) back(path, 'error', 'That didn’t send. Please try again.', '#assignment');
  await sendMail({ to: env().SUPPORT_EMAIL, subject: `[Course] Module ${m.n} submission · ${user.email}`, text: `Review it in the admin area: ${env().APP_URL}/admin/course` });
  revalidatePath(path);
  back(path, 'ok', 'Sent. A reviewer will reply within 5 business days with Complete or exactly what’s missing.', '#assignment');
}

const nameSchema = z.string().trim().min(2, 'Enter the name to print on the certificate.').max(80, 'That name is too long for the certificate.');

/** Issue the certificate of completion, once every module is complete. */
export async function claimCertificate(form: FormData) {
  const path = '/member/course/certificate';
  const { sb, user } = await activeMember(path);
  const { loadCourse, issueCertificate } = await import('@/lib/courseData');
  const { status } = await loadCourse(sb, user.id);
  if (!status.complete) back(path, 'error', 'The certificate is ready once all six modules are complete.');
  const name = nameSchema.safeParse(form.get('name') ?? '');
  if (!name.success) back(path, 'error', name.error.issues[0].message);
  const cert = await issueCertificate(user.id, name.data!);
  if (!cert) back(path, 'error', 'That didn’t work. Please try again.');
  revalidatePath(path);
  back(path, 'ok', 'Congratulations. Your certificate is ready.');
}
