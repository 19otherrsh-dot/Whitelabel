import type { Metadata } from 'next';
import { Shell, Notice, memberNav } from '@/components/Shell';
import { PrintButton } from '@/components/PrintButton';
import { requireUser } from '@/lib/auth';
import { loadMember } from '@/lib/memberData';
import { loadCourse } from '@/lib/courseData';
import { env } from '@/lib/env';
import { claimCertificate } from '../actions';

export const metadata: Metadata = { title: 'Certificate of completion' };
export const dynamic = 'force-dynamic';

export default async function CertificatePage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { sb, user } = await requireUser('/member/course/certificate');
  const { member, enrollment, ent } = await loadMember(sb, user.id);
  const e = env();
  if (!enrollment || !ent.active) {
    return <Shell nav={memberNav} current="/member/course" signedIn><h1>Certificate</h1><div className="card">The course is open to members with an active seat.</div></Shell>;
  }
  const { status, certificate } = await loadCourse(sb, user.id);
  const verify = certificate ? `${e.APP_URL}/certificate/${certificate.code}` : '';
  return (
    <Shell nav={memberNav} current="/member/course" signedIn>
      <p className="small muted noprint"><a href="/member/course">The course</a></p>
      <Notice ok={sp.ok} error={sp.error} />
      {certificate && !certificate.revoked_at ? (
        <>
          <div className="cert">
            <p className="small muted" style={{ letterSpacing: '.12em', textTransform: 'uppercase' }}>Certificate of completion</p>
            <h1>{certificate.name}</h1>
            <p>has completed <b>{e.COURSE_NAME}</b>: six modules, every quiz passed and every assignment reviewed and accepted.</p>
            <p className="muted">Issued by {e.BRAND_NAME} on {new Date(certificate.issued_at).toLocaleDateString('en-US', { dateStyle: 'long' })}</p>
            <p className="small">Verify at {verify}<br /><span className="code">{certificate.code}</span></p>
          </div>
          <div className="row noprint" style={{ marginTop: 16 }}>
            <PrintButton />
            <span className="small muted">Anyone with the verification link can see your name, the course and the date. Share it only if you want to.</span>
          </div>
        </>
      ) : certificate?.revoked_at ? (
        <div className="card">This certificate was withdrawn. Write to <a href={`mailto:${e.SUPPORT_EMAIL}`}>{e.SUPPORT_EMAIL}</a> if you think that’s a mistake.</div>
      ) : status.complete ? (
        <form action={claimCertificate} className="card stack">
          <h1 style={{ marginTop: 0 }}>You’ve done it</h1>
          <p>All six modules are complete. Check the name you want printed on your certificate.</p>
          <label>Name on the certificate<input name="name" required minLength={2} maxLength={80} defaultValue={member?.full_name ?? ''} autoComplete="name" /></label>
          <button className="btn buy" type="submit">Create my certificate</button>
        </form>
      ) : (
        <div className="card">
          <h1 style={{ marginTop: 0 }}>Certificate of completion</h1>
          <p>It’s ready once all six modules are complete: every quiz passed and every assignment marked Complete. You’ve completed {status.modulesComplete} of {status.modules.length}.</p>
          <a className="btn" href={status.next ? `/member/course/${status.next}` : '/member/course'}>{status.next ? `Continue with Module ${status.next}` : 'Back to the course'}</a>
        </div>
      )}
    </Shell>
  );
}
