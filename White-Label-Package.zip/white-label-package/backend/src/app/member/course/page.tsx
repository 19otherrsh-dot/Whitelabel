import type { Metadata } from 'next';
import { Shell, Notice, memberNav } from '@/components/Shell';
import { requireUser } from '@/lib/auth';
import { loadMember } from '@/lib/memberData';
import { loadCourse } from '@/lib/courseData';
import { MODULES } from '@/lib/course';
import { Inline } from '@/components/Inline';

export const metadata: Metadata = { title: 'The course' };
export const dynamic = 'force-dynamic';

const subLabel = { none: 'Not sent', submitted: 'Waiting for review', not_yet: 'Not yet: see the note', complete: 'Complete' } as const;
const subPill = { none: '', submitted: 'warn', not_yet: 'bad', complete: 'ok' } as const;

export default async function Course({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { sb, user } = await requireUser('/member/course');
  const { enrollment, ent } = await loadMember(sb, user.id);
  if (!enrollment || !ent.active) {
    return <Shell nav={memberNav} current="/member/course" signedIn><h1>The course</h1><div className="card">The course is open to members with an active seat. <a href="/member">Back to your member area</a>.</div></Shell>;
  }
  const { status, certificate } = await loadCourse(sb, user.id);
  const selfPaced = !!enrollment.cohorts?.self_paced;

  return (
    <Shell nav={memberNav} current="/member/course" signedIn>
      <h1>The course</h1>
      <Notice ok={sp.ok} error={sp.error} />
      <p className="lead">{selfPaced
        ? 'Six modules at your own pace. Each has short lessons, a five-question quiz and an assignment we review.'
        : 'The same method as the live sessions, in short lessons you can watch before or after each session, or to catch up.'}</p>

      <div className="grid">
        <div className="card stat"><b>{status.modulesComplete} of {status.modules.length}</b><span>Modules complete</span></div>
        <div className="card stat"><b>{status.lessonsDone} of {status.lessonsTotal}</b><span>Lessons watched</span></div>
        <div className="card stat"><b>{status.complete ? 'Earned' : 'Not yet'}</b><span>Certificate of completion</span></div>
      </div>
      <progress className="bar" max={status.lessonsTotal} value={status.lessonsDone} aria-label={`${status.lessonsDone} of ${status.lessonsTotal} lessons watched`} style={{ margin: '4px 0 24px' }} />

      {status.complete && (
        <div className="notice ok" role="status">You’ve completed the course. <a href="/member/course/certificate">{certificate ? 'View your certificate' : 'Get your certificate'}</a>.</div>
      )}

      <div className="card tablewrap">
        <table>
          <thead><tr><th>Module</th><th>Lessons</th><th>Quiz</th><th>Assignment</th><th></th></tr></thead>
          <tbody>
            {MODULES.map((m) => {
              const s = status.modules.find((x) => x.n === m.n)!;
              return (
                <tr key={m.n}>
                  <td><b>{m.n}. {m.title}</b>{m.length ? <div className="small muted">{m.length}</div> : null}</td>
                  <td>{s.lessonsDone}/{s.lessonsTotal}</td>
                  <td>{s.quiz.passed ? <span className="pill ok">Passed</span> : s.quiz.attempts ? <span className="pill warn">Best {s.quiz.best}/{s.quiz.total}</span> : <span className="muted">Not taken</span>}</td>
                  <td>{s.submission === 'none' ? <span className="muted">{subLabel.none}</span> : <span className={`pill ${subPill[s.submission]}`}>{subLabel[s.submission]}</span>}</td>
                  <td><a className={status.next === m.n ? 'btn sm buy' : 'btn sm'} href={`/member/course/${m.n}`}>{s.complete ? 'Review' : s.started ? 'Continue' : status.next === m.n ? 'Start' : 'Open'}</a></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <h2>How completion works</h2>
      <div className="card small">
        <ol className="steps">
          <li>Watch each module’s lessons and follow along in your own workspace.</li>
          <li>Pass the module quiz: 4 of 5 correct. Retakes are allowed.</li>
          <li>Send the assignment. A reviewer marks it Complete, or tells you exactly what’s missing, within 5 business days.</li>
          <li>When all six modules are complete, your certificate of completion is ready here.</li>
        </ol>
        <p className="muted" style={{ margin: 0 }}>Never include passwords, keys, tokens or other people’s personal data in a submission. <Inline text="Paste command output as text where you can (for example `bin/wf runs --days 7`)." /></p>
      </div>
    </Shell>
  );
}
