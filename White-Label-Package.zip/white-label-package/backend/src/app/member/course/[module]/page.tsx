import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { Shell, Notice, memberNav } from '@/components/Shell';
import { Inline } from '@/components/Inline';
import { requireUser } from '@/lib/auth';
import { loadMember } from '@/lib/memberData';
import { loadCourse } from '@/lib/courseData';
import { MODULES, moduleByNumber, publicQuiz } from '@/lib/course';
import { toggleLesson, submitQuiz, submitAssignment } from '../actions';

export const dynamic = 'force-dynamic';
export async function generateMetadata({ params }: { params: Promise<{ module: string }> }): Promise<Metadata> {
  const m = moduleByNumber(Number((await params).module));
  return { title: m ? `Module ${m.n} · ${m.title}` : 'Course' };
}

const day = (iso: string) => new Date(iso).toLocaleDateString('en-US', { dateStyle: 'medium' });

export default async function ModulePage({ params, searchParams }: { params: Promise<{ module: string }>; searchParams: Promise<Record<string, string | undefined>> }) {
  const [{ module: raw }, sp] = await Promise.all([params, searchParams]);
  const m = moduleByNumber(Number(raw));
  if (!m || !/^\d+$/.test(raw)) notFound();
  const path = `/member/course/${m.n}`;
  const { sb, user } = await requireUser(path);
  const { enrollment, ent } = await loadMember(sb, user.id);
  if (!enrollment || !ent.active) {
    return <Shell nav={memberNav} current="/member/course" signedIn><h1>The course</h1><div className="card">The course is open to members with an active seat. <a href="/member">Back to your member area</a>.</div></Shell>;
  }
  const { state, status, media } = await loadCourse(sb, user.id);
  const s = status.modules.find((x) => x.n === m.n)!;
  const attempts = state.attempts.filter((a) => a.module === m.n);
  const shown = sp.attempt ? attempts.find((a) => a.id === sp.attempt) : undefined;
  const passedAttempt = attempts.find((a) => a.passed);
  const wrong = new Set(shown ? m.quiz.filter((q) => shown.answers[q.id] !== q.answer).map((q) => q.id) : []);
  const reveal = !!passedAttempt;                      // correct answers are shown once the quiz is passed
  const subs = state.submissions.filter((x) => x.module === m.n);
  const prev = MODULES.find((x) => x.n === m.n - 1), next = MODULES.find((x) => x.n === m.n + 1);

  return (
    <Shell nav={memberNav} current="/member/course" signedIn>
      <p className="small muted"><a href="/member/course">The course</a> · Module {m.n} of {MODULES.length}</p>
      <h1>{m.title}</h1>
      <Notice ok={sp.ok} error={sp.error} />
      {m.outcome && <p className="lead"><b>By the end:</b> <Inline text={m.outcome} /></p>}
      <progress className="bar" max={s.lessonsTotal} value={s.lessonsDone} aria-label={`${s.lessonsDone} of ${s.lessonsTotal} lessons watched`} style={{ marginBottom: 20 }} />

      <h2>Lessons</h2>
      <div className="card">
        {m.lessons.map((l) => {
          const done = state.done.has(l.id);
          const v = media.get(l.id);
          return (
            <section className="lesson" key={l.id} id={`l-${l.id.replace('.', '-')}`} aria-labelledby={`h-${l.id.replace('.', '-')}`}>
              <div className="row" style={{ justifyContent: 'space-between', alignItems: 'baseline' }}>
                <h3 id={`h-${l.id.replace('.', '-')}`}>{l.id} {l.title}</h3>
                <span className="small muted">{l.minutes} min{done ? ' · ' : ''}{done && <span className="pill ok">Watched</span>}</span>
              </div>
              {l.summary && <p className="small" style={{ margin: 0 }}><Inline text={l.summary} /></p>}
              {(l.say || l.show || l.commands) && (
                <dl>
                  {l.say && <><dt>Covers</dt><dd><Inline text={l.say} /></dd></>}
                  {l.show && <><dt>You’ll see</dt><dd><Inline text={l.show} /></dd></>}
                  {l.commands && <><dt>Commands</dt><dd><Inline text={l.commands} /></dd></>}
                </dl>
              )}
              <div className="row">
                {v?.video_url ? <a className="btn sm buy" href={v.video_url} rel="noopener" target="_blank">Watch the video<span className="sr"> (opens in a new tab)</span></a> : <span className="small muted">Video coming soon. Follow the steps above in your workspace meanwhile.</span>}
                {v?.transcript_url && <a className="small" href={v.transcript_url} rel="noopener">Transcript</a>}
                <form action={toggleLesson}>
                  <input type="hidden" name="module" value={m.n} /><input type="hidden" name="lesson" value={l.id} />
                  {done ? <><input type="hidden" name="undo" value="1" /><button className="linkbtn small" type="submit">Mark as not watched</button></> : <button className="btn sm" type="submit">Mark as watched</button>}
                </form>
              </div>
            </section>
          );
        })}
      </div>

      <h2 id="quiz">Quiz</h2>
      {shown && (
        <div className={`notice ${shown.passed ? 'ok' : 'err'}`} role="status">
          {shown.passed ? `Passed: ${shown.score} of ${shown.total}.` : `${shown.score} of ${shown.total}. You need ${Math.ceil(0.8 * shown.total)} to pass. The questions marked below are worth another look; rewatch the lessons and try again.`}
        </div>
      )}
      {!shown && s.quiz.passed && <div className="notice ok">You’ve passed this quiz. You can take it again any time.</div>}
      <form action={submitQuiz} className="card">
        <input type="hidden" name="module" value={m.n} />
        {publicQuiz(m).map((q, i) => (
          <fieldset key={q.id} className={`q${wrong.has(q.id) ? ' wrong' : ''}`}>
            <legend>{i + 1}. <Inline text={q.text} />{wrong.has(q.id) && <span className="sr"> (answered incorrectly)</span>}</legend>
            {q.options.map((o, j) => (
              <label key={j}><input type="radio" name={`q-${q.id}`} value={j} required defaultChecked={shown ? shown.answers[q.id] === j : false} /> <span><Inline text={o} /></span></label>
            ))}
            {reveal && <div className="key small">Answer: <Inline text={m.quiz[i].options[m.quiz[i].answer]} /></div>}
          </fieldset>
        ))}
        <button className="btn buy" type="submit">Check my answers</button>
      </form>

      <h2 id="assignment">{m.assignment?.label ?? 'Assignment'}</h2>
      <div className="card stack">
        {m.assignment && <p><Inline text={m.assignment.text} /></p>}
        {m.check && <p className="small"><b>Marked complete when:</b> <Inline text={m.check} /></p>}
        {subs.length > 0 && (
          <div className="tablewrap">
            <table>
              <thead><tr><th>Sent</th><th>Status</th><th>Reviewer’s note</th></tr></thead>
              <tbody>
                {subs.map((x) => (
                  <tr key={x.id}>
                    <td>{day(x.created_at)}</td>
                    <td>{x.status === 'complete' ? <span className="pill ok">Complete</span> : x.status === 'not_yet' ? <span className="pill bad">Not yet</span> : <span className="pill warn">Waiting for review</span>}</td>
                    <td style={{ whiteSpace: 'pre-wrap' }}>{x.reviewer_note ?? ''}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {s.submission === 'complete' ? <p className="small muted" style={{ margin: 0 }}>This assignment is complete. You can still send an update if you’d like feedback on changes.</p> : null}
        <form action={submitAssignment} className="stack">
          <input type="hidden" name="module" value={m.n} />
          <label>Your work <span className="hint">Paste command output as text, plus a line or two on anything you want us to look at. No passwords, keys or other people’s data.</span>
            <textarea name="body" rows={8} required minLength={20} maxLength={20000} />
          </label>
          <label>Link (optional) <span className="hint">A screen recording or shared folder, starting with https://. Make sure we can open it.</span>
            <input type="url" name="link" inputMode="url" placeholder="https://" pattern="https://.*" />
          </label>
          <button className="btn" type="submit">Send for review</button>
        </form>
      </div>

      <nav className="row" aria-label="Modules" style={{ justifyContent: 'space-between', marginTop: 24 }}>
        {prev ? <a href={`/member/course/${prev.n}`}>← Module {prev.n}: {prev.title}</a> : <span />}
        {next ? <a href={`/member/course/${next.n}`}>Module {next.n}: {next.title} →</a> : <a href="/member/course">Back to the course</a>}
      </nav>
    </Shell>
  );
}
