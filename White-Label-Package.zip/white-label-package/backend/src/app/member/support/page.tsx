import type { Metadata } from 'next';
import { Shell, Notice, memberNav } from '@/components/Shell';
import { requireUser } from '@/lib/auth';
import { loadMember } from '@/lib/memberData';
import { openSupport } from '../actions';

export const metadata: Metadata = { title: 'Support' };
export const dynamic = 'force-dynamic';

const pill = { open: 'warn', waiting: 'ok', closed: '' } as const;
const label = { open: 'With us', waiting: 'Replied', closed: 'Closed' } as const;

export default async function Support({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { sb, user } = await requireUser('/member/support');
  const { ent, enrollment } = await loadMember(sb, user.id);
  const { data: reqs } = await sb.from('support_requests').select('id, subject, body, status, admin_reply, created_at').eq('member_id', user.id).order('created_at', { ascending: false });

  return (
    <Shell nav={memberNav} current="/member/support" signedIn>
      <h1>Support</h1>
      <Notice ok={sp.ok} error={sp.error} />
      {ent.support ? (
        <form action={openSupport} className="stack card">
          <label>Subject<input type="text" name="subject" maxLength={160} required /></label>
          <label>What’s happening? <span className="hint">What you tried, what you expected, and any error message. Never paste passwords or API keys.</span>
            <textarea name="body" maxLength={8000} required />
          </label>
          <button className="btn buy" type="submit">Send</button>
        </form>
      ) : (
        <div className="card"><p>{enrollment ? 'The support window for this seat has ended.' : 'Support is for members with a seat.'}</p></div>
      )}
      <h2>Your requests</h2>
      {(reqs ?? []).length === 0 ? <p className="muted">None yet.</p> : (reqs ?? []).map((r) => (
        <div className="card" key={r.id}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <b>{r.subject}</b><span className={`pill ${pill[r.status as keyof typeof pill]}`}>{label[r.status as keyof typeof label]}</span>
          </div>
          <p className="small muted">{new Date(r.created_at).toLocaleString('en-US')}</p>
          <p style={{ whiteSpace: 'pre-wrap' }}>{r.body}</p>
          {r.admin_reply && <div className="notice ok" style={{ whiteSpace: 'pre-wrap', marginBottom: 0 }}><b>Our reply</b><br />{r.admin_reply}</div>}
        </div>
      ))}
    </Shell>
  );
}
