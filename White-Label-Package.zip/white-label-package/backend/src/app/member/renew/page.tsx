import type { Metadata } from 'next';
import { Shell, Notice, memberNav } from '@/components/Shell';
import { requireUser } from '@/lib/auth';
import { renewalOffer } from '@/lib/renewal';
import { money } from '@/lib/rules';
import { env } from '@/lib/env';
import { beginRenewal } from '../actions';

export const metadata: Metadata = { title: 'Renew library access' };
export const dynamic = 'force-dynamic';

const day = (iso: string) => new Date(iso).toLocaleDateString('en-US', { dateStyle: 'long' });

export default async function Renew({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { user } = await requireUser('/member/renew');
  const offer = await renewalOffer(user.id);
  const ended = offer?.libraryUntil ? Date.parse(offer.libraryUntil) <= Date.now() : false;
  return (
    <Shell nav={memberNav} current="/member" signedIn narrow>
      <h1>Library access and updates</h1>
      <Notice error={sp.error} />
      {!offer ? (
        <div className="card"><p>Renewals aren’t open for your seat yet. Write to <a href={`mailto:${env().SUPPORT_EMAIL}`}>{env().SUPPORT_EMAIL}</a> and we’ll help.</p></div>
      ) : (
        <div className="card stack">
          <p>{offer.libraryUntil ? (ended ? <>Your access ended on <b>{day(offer.libraryUntil)}</b>.</> : <>Your access runs until <b>{day(offer.libraryUntil)}</b>.</>) : 'Your access has no end date.'} Everything you’ve already downloaded is yours either way.</p>
          <p>Renewing adds <b>{offer.months} months</b> of new kit releases and updates{offer.libraryUntil && !ended ? ', on top of the time you have left' : ', starting today'}.</p>
          <form action={beginRenewal}><button className="btn buy" type="submit">Renew for {money(offer.price, offer.currency)}</button></form>
          <p className="small muted" style={{ margin: 0 }}>One payment through Stripe; no subscription. Terms: <a href={`${env().SITE_URL}/terms.html`}>terms of sale</a>.</p>
        </div>
      )}
    </Shell>
  );
}
