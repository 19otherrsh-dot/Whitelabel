import { NextResponse, type NextRequest } from 'next/server';
import { supabaseServer } from '@/lib/supabase/server';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { loadMember } from '@/lib/memberData';
import { rateLimit } from '@/lib/ratelimit';

// Hands out a 2-minute signed link to the kit zip after checking the member's library access.
export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const sb = await supabaseServer();
  const { data } = await sb.auth.getUser();
  const user = data.user;
  if (!user) return NextResponse.redirect(new URL('/login?next=/member', req.nextUrl.origin));
  const { ent } = await loadMember(sb, user.id);
  if (!ent.library) return NextResponse.redirect(new URL('/member?error=' + encodeURIComponent('Library access has ended for this seat.'), req.nextUrl.origin));
  if (!rateLimit(`dl:${user.id}`, 20, 60 * 60_000).ok) return NextResponse.redirect(new URL('/member?error=' + encodeURIComponent('Too many downloads in the last hour. Please try again later.'), req.nextUrl.origin));

  const version = req.nextUrl.searchParams.get('v');
  const q = sb.from('releases').select('id, version, storage_path');
  const { data: rel } = version ? await q.eq('version', version).maybeSingle() : await q.eq('is_latest', true).maybeSingle();
  if (!rel) return NextResponse.redirect(new URL('/member?error=' + encodeURIComponent('No kit release is available yet.'), req.nextUrl.origin));

  const admin = supabaseAdmin();
  const { data: signed, error } = await admin.storage.from('kit').createSignedUrl(rel.storage_path, 120, { download: `workforce-kit-${rel.version}.zip` });
  if (error || !signed) return NextResponse.redirect(new URL('/member?error=' + encodeURIComponent('The download is unavailable right now. Please try again shortly.'), req.nextUrl.origin));
  await admin.from('downloads').insert({ member_id: user.id, release_id: rel.id });
  return NextResponse.redirect(signed.signedUrl, { status: 303 });
}
