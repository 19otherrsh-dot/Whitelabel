'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { requireUser } from '@/lib/auth';
import { loadMember } from '@/lib/memberData';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { claimEligibility } from '@/lib/rules';
import { claimSchema, supportSchema } from '@/lib/validation';
import { rateLimit } from '@/lib/ratelimit';
import { sendMail } from '@/lib/email';
import { env } from '@/lib/env';
import { MAX_USAGE_BYTES, parseUsageFile } from '@/lib/usage';
import type { UsageReport } from '@/lib/validation';

const back = (path: string, k: 'ok' | 'error', msg: string) => redirect(`${path}?${k}=${encodeURIComponent(msg)}`);

export async function openSupport(form: FormData) {
  const { sb, user } = await requireUser('/member/support');
  const { ent } = await loadMember(sb, user.id);
  if (!ent.support) back('/member/support', 'error', 'The support window for this seat has ended.');
  if (!rateLimit(`support:${user.id}`, 6, 60 * 60_000).ok) back('/member/support', 'error', 'You’ve sent several requests in the last hour. We’ll get to them; please wait before sending more.');
  const parsed = supportSchema.safeParse({ subject: form.get('subject'), body: form.get('body') });
  if (!parsed.success) back('/member/support', 'error', parsed.error.issues[0].message);
  const d = parsed.data!;
  // Inserted with the member's own client: the RLS policy checks it is theirs and the seat is active.
  const { error } = await sb.from('support_requests').insert({ member_id: user.id, subject: d.subject, body: d.body });
  if (error) back('/member/support', 'error', 'That didn’t send. Please try again.');
  await sendMail({ to: env().SUPPORT_EMAIL, replyTo: user.email ?? undefined, subject: `[Support] ${d.subject}`, text: `${d.body}\n\nFrom ${user.email}\nReply in the admin area: ${env().APP_URL}/admin/support` });
  revalidatePath('/member/support');
  back('/member/support', 'ok', 'Thanks. We’ve got your request and will reply by email.');
}

/** Start a paid renewal of library access. */
export async function beginRenewal() {
  const { user } = await requireUser('/member/renew');
  if (!rateLimit(`renew:${user.id}`, 5, 30 * 60_000).ok) back('/member/renew', 'error', 'Too many attempts. Please wait a few minutes.');
  const { startRenewal } = await import('@/lib/renewal');
  const r = await startRenewal(user.id, user.email ?? '');
  if (!r.ok) back('/member/renew', 'error', r.message);
  redirect((r as { url: string }).url);
}

/** The member confirms their setup is done (kit installed, interview started, doctor clean). */
export async function markSetupDone(form: FormData) {
  const { sb, user } = await requireUser('/member');
  const { enrollment, ent } = await loadMember(sb, user.id);
  if (!enrollment || !ent.active) back('/member', 'error', 'We can’t find an active seat for this account.');
  const undo = form.get('undo') === '1';
  const { error } = await supabaseAdmin().from('enrollments').update({ setup_done_at: undo ? null : new Date().toISOString() }).eq('id', enrollment!.id).eq('member_id', user.id);
  if (error) back('/member', 'error', 'That didn’t save. Please try again.');
  revalidatePath('/member');
  back('/member', 'ok', undo ? 'Marked as not done yet.' : 'Great, you’re set up. See you in Session 1.');
}

/** A member shares the anonymous usage summary from their workspace. Stored without any link to them. */
export async function shareUsage(form: FormData) {
  const { sb, user } = await requireUser('/member');
  const { enrollment } = await loadMember(sb, user.id);
  if (!enrollment) back('/member', 'error', 'We can’t find a seat for this account.');
  if (!rateLimit(`usage:${user.id}`, 3, 24 * 60 * 60_000).ok) back('/member', 'error', 'Thanks, you’ve shared a few already today.');
  const file = form.get('report');
  if (!(file instanceof File) || file.size === 0) back('/member', 'error', 'Choose the file from output/learning/ in your workspace.');
  if ((file as File).size > MAX_USAGE_BYTES) back('/member', 'error', 'That file is larger than a usage summary should be.');
  const parsed = parseUsageFile(await (file as File).text());
  if (!parsed.ok) back('/member', 'error', parsed.reason);
  const r = (parsed as { ok: true; report: UsageReport }).report;
  const { error } = await supabaseAdmin().from('usage_reports').insert({
    kit_version: r.kitVersion ?? null,
    business_type: r.businessType ?? null,
    team_size: r.teamSize == null ? null : String(r.teamSize),
    generated_at: r.generated ?? null,
    skills: r.skills,
  });
  if (error) back('/member', 'error', 'That didn’t upload. Please try again.');
  back('/member', 'ok', 'Thank you. Your summary was saved without your name or email, and helps us improve the skills everyone uses.');
}

export async function fileClaim(form: FormData) {
  const { sb, user } = await requireUser('/member/guarantee');
  const { enrollment } = await loadMember(sb, user.id);
  if (!enrollment) back('/member/guarantee', 'error', 'We can’t find a seat for this account.');
  const parsed = claimSchema.safeParse({ kind: form.get('kind'), reason: form.get('reason'), checklist: form.get('checklist') ?? '', evidenceUrl: form.get('evidenceUrl') ?? '' });
  if (!parsed.success) back('/member/guarantee', 'error', parsed.error.issues[0].message);
  const d = parsed.data!;

  const [{ data: sessions }, { data: att }] = await Promise.all([
    sb.from('cohort_sessions').select('id, position, starts_at, ends_at').eq('cohort_id', enrollment!.cohort_id),
    sb.from('attendance').select('session_id, attended').eq('member_id', user.id),
  ]);
  const attendedIds = new Set((att ?? []).filter((a) => a.attended).map((a) => a.session_id));
  const positions = (sessions ?? []).filter((s) => attendedIds.has(s.id)).map((s) => s.position);
  const c = enrollment!.cohorts;
  const selfPaced = c?.self_paced ? { refundDays: c.refund_days ?? 14, modulesUsed: await (await import('@/lib/courseData')).modulesUsed(user.id) } : undefined;
  const elig = claimEligibility(d.kind, enrollment!, sessions ?? [], positions, new Date(), selfPaced);
  if (!elig.ok) back('/member/guarantee', 'error', elig.reason);

  // Written with the service role (members can't insert claims directly), after the checks above.
  const { error } = await supabaseAdmin().from('guarantee_claims').insert({
    enrollment_id: enrollment!.id,
    member_id: user.id,
    kind: d.kind,
    reason: d.reason,
    evidence: { checklist: d.checklist, url: d.evidenceUrl, attended: positions },
  });
  if (error) back('/member/guarantee', 'error', error.code === '23505' ? 'You already have a request open. We’ll be in touch.' : 'That didn’t send. Please try again.');
  await sendMail({ to: env().SUPPORT_EMAIL, subject: `[Refund request] ${d.kind === 'cooling_off' ? 'Cooling-off' : 'Build guarantee'} · ${user.email}`, text: `${d.reason}\n\nReview: ${env().APP_URL}/admin/claims` });
  revalidatePath('/member/guarantee');
  back('/member/guarantee', 'ok', 'Request received. We’ll confirm within two working days.');
}
