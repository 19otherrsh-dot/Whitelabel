import type { Metadata } from 'next';
import { Shell, Notice, memberNav } from '@/components/Shell';
import { requireUser } from '@/lib/auth';
import { loadMember } from '@/lib/memberData';
import { claimEligibility } from '@/lib/rules';
import { env } from '@/lib/env';
import { fileClaim } from '../actions';
import { modulesUsed } from '@/lib/courseData';

export const metadata: Metadata = { title: 'Refunds and the build guarantee' };
export const dynamic = 'force-dynamic';

export default async function Guarantee({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { sb, user } = await requireUser('/member/guarantee');
  const { enrollment } = await loadMember(sb, user.id);
  const e = env();
  if (!enrollment) {
    return <Shell nav={memberNav} current="/member/guarantee" signedIn><h1>Refunds</h1><div className="card">We can’t find a seat for this account.</div></Shell>;
  }
  const [{ data: sessions }, { data: att }, { data: claims }] = await Promise.all([
    sb.from('cohort_sessions').select('id, position, starts_at, ends_at').eq('cohort_id', enrollment.cohort_id),
    sb.from('attendance').select('session_id, attended').eq('member_id', user.id),
    sb.from('guarantee_claims').select('id, kind, status, admin_note, created_at').eq('member_id', user.id).order('created_at', { ascending: false }),
  ]);
  const ids = new Set((att ?? []).filter((a) => a.attended).map((a) => a.session_id));
  const positions = (sessions ?? []).filter((s) => ids.has(s.id)).map((s) => s.position);
  const selfPaced = enrollment.cohorts?.self_paced ? { refundDays: enrollment.cohorts.refund_days ?? 14, modulesUsed: await modulesUsed(user.id) } : undefined;
  const cooling = claimEligibility('cooling_off', enrollment, sessions ?? [], positions, new Date(), selfPaced);
  const build = claimEligibility('build_guarantee', enrollment, sessions ?? [], positions, new Date(), selfPaced);
  const open = (claims ?? []).some((c) => c.status === 'open');
  const available = [cooling, build].filter((x) => x.ok);

  return (
    <Shell nav={memberNav} current="/member/guarantee" signedIn>
      <h1>{selfPaced ? 'Refunds' : 'Refunds and the build guarantee'}</h1>
      <Notice ok={sp.ok} error={sp.error} />
      {selfPaced ? (
        <div className="card"><h3>Money-back window</h3><p className="small">Full refund within {selfPaced.refundDays} days of purchase, as long as no more than two modules are complete (a module counts once its quiz is passed or its assignment accepted). You’ve used {selfPaced.modulesUsed}.</p>
          <p className="small">{cooling.ok ? <span className="pill ok">Available now</span> : <span className="muted">{cooling.reason}</span>}</p></div>
      ) : (
      <div className="grid">
        <div className="card"><h3>Cooling-off</h3><p className="small">Full refund, no questions, within 3 days of purchase and before Session 1.</p>
          <p className="small">{cooling.ok ? <span className="pill ok">Available now</span> : <span className="muted">{cooling.reason}</span>}</p></div>
        <div className="card"><h3>Build guarantee</h3><p className="small">Attend all six sessions live and complete the setup steps. If you don’t leave with a working department, ask within 7 days after Session 6.</p>
          <p className="small">{build.ok ? <span className="pill ok">Available now</span> : <span className="muted">{build.reason}</span>}</p></div>
      </div>
      )}
      <p className="small muted">Full conditions: <a href={`${e.SITE_URL}/refunds.html`}>refunds and guarantee</a>. These are in addition to your legal rights.</p>

      {enrollment.status !== 'active' ? null : open ? (
        <div className="notice">You have a request open. We’ll confirm within two working days.</div>
      ) : available.length ? (
        <form action={fileClaim} className="stack card">
          <h2 style={{ marginTop: 0 }}>Ask for a refund</h2>
          <fieldset style={{ border: 0, padding: 0, margin: 0, display: 'grid', gap: 8 }}>
            <legend className="small" style={{ fontWeight: 600, marginBottom: 6 }}>Which applies?</legend>
            {cooling.ok && <label className="check"><input type="radio" name="kind" value="cooling_off" defaultChecked /> {selfPaced ? 'Money-back window (changed my mind)' : 'Cooling-off (changed my mind)'}</label>}
            {build.ok && <label className="check"><input type="radio" name="kind" value="build_guarantee" defaultChecked={!cooling.ok} /> Build guarantee (no working department)</label>}
          </fieldset>
          <label>What happened? <span className="hint">For the build guarantee, tell us which department you built and where it stopped working.</span><textarea name="reason" required maxLength={8000} /></label>
          {build.ok && <label>Setup steps completed <span className="hint">Kit installed, interview done, tools connected or replaced by files.</span><textarea name="checklist" maxLength={2000} style={{ minHeight: 80 }} /></label>}
          {build.ok && <label>Link to evidence (optional) <span className="hint">For example a shared folder with your run log.</span><input type="url" name="evidenceUrl" maxLength={500} /></label>}
          <button className="btn" type="submit">Send refund request</button>
        </form>
      ) : (
        <div className="card"><p style={{ margin: 0 }}>Neither window is open right now. If something outside your control is blocking you, <a href="/member/support">tell us</a> and we’ll work out an alternative with you.</p></div>
      )}

      {(claims ?? []).length > 0 && (
        <>
          <h2>Your requests</h2>
          {(claims ?? []).map((c) => (
            <div className="card small" key={c.id}>
              <b>{c.kind === 'cooling_off' ? (selfPaced ? 'Money-back window' : 'Cooling-off') : 'Build guarantee'}</b> · {new Date(c.created_at).toLocaleDateString('en-US', { dateStyle: 'medium' })} · <span className="pill">{c.status}</span>
              {c.admin_note && <p style={{ margin: '8px 0 0' }}>{c.admin_note}</p>}
            </div>
          ))}
        </>
      )}
    </Shell>
  );
}
