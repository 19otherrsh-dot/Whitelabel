import { NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase/server';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { auditAnswersFile } from '@/lib/auditAnswers';
import { likeExact } from '@/lib/rules';

export const dynamic = 'force-dynamic';

// The member's own free-audit answers, as a file for the onboarding interview to start from
// (they put it in their workspace's data/imports/ folder). Only the signed-in member's own email.
export async function GET() {
  const sb = await supabaseServer();
  const { data } = await sb.auth.getUser();
  const email = data.user?.email?.toLowerCase();
  if (!email) return new NextResponse('Not found', { status: 404 });
  const { data: lead } = await supabaseAdmin().from('leads').select('company, payload, created_at').eq('kind', 'audit').ilike('email', likeExact(email)).order('created_at', { ascending: false }).limit(1).maybeSingle();
  if (!lead) return new NextResponse('Not found', { status: 404 });
  return new NextResponse(JSON.stringify(auditAnswersFile(lead), null, 2), { headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Disposition': 'attachment; filename="audit-answers.json"',
    'Cache-Control': 'private, no-store',
  } });
}
