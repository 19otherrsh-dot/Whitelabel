import { NextResponse, type NextRequest } from 'next/server';
import { supabaseServer } from '@/lib/supabase/server';
import { loadMember } from '@/lib/memberData';
import { buildIcs } from '@/lib/ics';
import { env } from '@/lib/env';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const sb = await supabaseServer();
  const { data } = await sb.auth.getUser();
  if (!data.user) return NextResponse.redirect(new URL('/login?next=/member', req.nextUrl.origin));
  const { enrollment, ent } = await loadMember(sb, data.user.id);
  if (!enrollment || !ent.sessions) return NextResponse.redirect(new URL('/member', req.nextUrl.origin));
  const { data: sessions } = await sb.from('cohort_sessions').select('id, title, starts_at, ends_at, join_url').eq('cohort_id', enrollment.cohort_id).order('position');
  const e = env();
  const ics = buildIcs(`${e.BRAND_NAME} · ${enrollment.cohorts?.name ?? 'Cohort'}`, (sessions ?? []).map((s) => ({
    uid: `${s.id}@cohort`,
    title: `${e.BRAND_NAME}: ${s.title}`,
    start: s.starts_at,
    end: s.ends_at,
    url: s.join_url,
    description: `Join link and replays: ${e.APP_URL}/member`,
  })));
  return new NextResponse(ics, { headers: { 'Content-Type': 'text/calendar; charset=utf-8', 'Content-Disposition': 'attachment; filename="sessions.ics"', 'Cache-Control': 'private, no-store' } });
}
