'use server';
import { redirect } from 'next/navigation';
import { headers } from 'next/headers';
import { env } from '@/lib/env';
import { saveLead } from '@/lib/leads';
import { rateLimit } from '@/lib/ratelimit';
import { waitlistSchema } from '@/lib/validation';
import { sendMail } from '@/lib/email';
import { createHash } from 'node:crypto';

export async function join(form: FormData) {
  const kind = form.get('kind') === 'training' ? 'training' : 'waitlist';
  const back = (q: string) => redirect(`/join?kind=${kind}&${q}`);
  if (String(form.get('website') ?? '')) back('done=1');   // honeypot
  const parsed = waitlistSchema.safeParse({
    kind, email: form.get('email'), name: form.get('name') ?? '', company: form.get('company') ?? '',
    marketingConsent: form.get('marketing') === 'on', page: `/join?kind=${kind}`,
  });
  if (!parsed.success) back(`error=${encodeURIComponent(parsed.error.issues[0].message)}`);
  const d = parsed.data!;
  const h = await headers();
  const ip = (h.get('x-forwarded-for') ?? '').split(',')[0].trim() || 'unknown';
  if (!rateLimit(`join:${ip}`, 10, 10 * 60_000).ok) back('error=' + encodeURIComponent('Too many sign-ups from here. Please try again in a few minutes.'));

  const e = env();
  await saveLead({ kind, email: d.email, name: d.name, company: d.company, marketingConsent: d.marketingConsent, page: d.page, payload: {},
    ipHash: createHash('sha256').update(e.IP_HASH_SALT + '|' + ip).digest('hex').slice(0, 32) });

  if (kind === 'training') {
    const when = e.TRAINING_START ? new Date(e.TRAINING_START).toLocaleString('en-US', { dateStyle: 'full', timeStyle: 'short', timeZone: e.TRAINING_TIME_ZONE, timeZoneName: 'short' }) : 'the date on our website';
    await sendMail({ to: d.email, subject: `You're registered: free live training`, text: `Hi${d.name ? ` ${d.name.split(' ')[0]}` : ''},

You're registered for the free live training on ${when}.

${e.TRAINING_JOIN_URL ? `Join here: ${e.TRAINING_JOIN_URL}` : `We'll email you the joining link before it starts.`}

${e.BRAND_NAME}` });
  } else {
    await sendMail({ to: d.email, subject: `You're on the waitlist`, text: `Hi${d.name ? ` ${d.name.split(' ')[0]}` : ''},

Thanks for joining the waitlist. We'll email you when the next cohort opens, before seats go on sale publicly.

${e.BRAND_NAME}` });
  }
  back('done=1');
}
