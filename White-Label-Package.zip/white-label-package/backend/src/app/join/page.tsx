import type { Metadata } from 'next';
import { Shell } from '@/components/Shell';
import { env } from '@/lib/env';
import { join } from './actions';

export const metadata: Metadata = { title: 'Sign up' };

// Hosted sign-up forms the static site can link to:
//   links.waitlist             → https://<APP_URL>/join?kind=waitlist
//   links.trainingRegistration → https://<APP_URL>/join?kind=training
export default async function Join({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const e = env();
  const training = sp.kind === 'training';
  const when = training && e.TRAINING_START ? new Date(e.TRAINING_START).toLocaleString('en-US', { dateStyle: 'full', timeStyle: 'short', timeZone: e.TRAINING_TIME_ZONE, timeZoneName: 'short' }) : null;

  if (sp.done) {
    return (
      <Shell narrow>
        <h1>{training ? 'You’re registered' : 'You’re on the list'}</h1>
        <p className="lead">{training ? 'Check your inbox for the confirmation.' : 'We’ll email you when the next cohort opens.'}</p>
        <a className="btn" href={e.SITE_URL}>Back to the site</a>
      </Shell>
    );
  }
  return (
    <Shell narrow>
      <h1>{training ? 'Free live training' : 'Join the waitlist'}</h1>
      <p className="lead">{training ? (when ? `${when}. Register and we’ll send you the link.` : 'Register and we’ll send you the link.') : 'Hear first when the next cohort opens.'}</p>
      {sp.error && <div className="notice err" role="alert">{sp.error}</div>}
      <form action={join} className="stack card">
        <input type="hidden" name="kind" value={training ? 'training' : 'waitlist'} />
        <div aria-hidden="true" style={{ position: 'absolute', left: -9999, width: 1, height: 1, overflow: 'hidden' }}><label>Leave this empty<input type="text" name="website" tabIndex={-1} autoComplete="off" /></label></div>
        <label>Name <span className="hint">Optional</span><input type="text" name="name" autoComplete="name" maxLength={120} /></label>
        <label>Email<input type="email" name="email" autoComplete="email" required maxLength={254} /></label>
        <label className="check"><input type="checkbox" name="marketing" /> <span>Also send me occasional emails about new cohorts and resources. Unsubscribe any time.</span></label>
        <button className="btn buy" type="submit">{training ? 'Register' : 'Join the waitlist'}</button>
        <p className="small muted" style={{ margin: 0 }}>We use your email for this sign-up as described in our <a href={`${e.SITE_URL}/privacy.html`}>privacy notice</a>.</p>
      </form>
    </Shell>
  );
}
