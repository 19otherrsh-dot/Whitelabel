import type { Metadata } from 'next';
import { Shell } from '@/components/Shell';
import { env } from '@/lib/env';
import { releaseHold } from '@/lib/checkout';

export const metadata: Metadata = { title: 'Checkout cancelled' };
export const dynamic = 'force-dynamic';

export default async function Cancelled({ searchParams }: { searchParams: Promise<{ hold?: string }> }) {
  const { hold } = await searchParams;
  if (hold) await releaseHold(hold);
  const e = env();
  return (
    <Shell narrow>
      <h1>No payment was taken</h1>
      <p className="lead">You left the payment page, so we’ve released the seat we were holding for you.</p>
      <div className="row">
        <a className="btn buy" href={`${e.SITE_URL}/pricing.html`}>Back to pricing</a>
        <a className="btn" href={`${e.SITE_URL}/contact.html`}>Ask a question</a>
      </div>
    </Shell>
  );
}
