'use server';
import { redirect } from 'next/navigation';
import { headers } from 'next/headers';
import { z } from 'zod';
import { cohortBySlug } from '@/lib/data';
import { startCheckout } from '@/lib/checkout';
import { rateLimit } from '@/lib/ratelimit';
import { isSeat } from '@/lib/rules';

export async function beginCheckout(form: FormData) {
  const seat = String(form.get('seat') ?? '');
  const cohort = String(form.get('cohort') ?? '');
  const email = String(form.get('email') ?? '').trim();
  const back = `/checkout?seat=${encodeURIComponent(seat)}&cohort=${encodeURIComponent(cohort)}`;
  if (!isSeat(seat) || !/^[a-z0-9-]{2,60}$/.test(cohort)) redirect('/checkout?error=unknown');
  if (email && !z.email().safeParse(email).success) redirect(`${back}&error=email`);

  const h = await headers();
  const ip = (h.get('x-forwarded-for') ?? '').split(',')[0].trim() || 'unknown';
  // Each attempt holds a seat for 35 minutes, so cap attempts per visitor.
  if (!rateLimit(`checkout:${ip}`, 5, 30 * 60_000).ok) redirect(`${back}&error=busy`);

  const c = await cohortBySlug(cohort);
  if (!c) redirect('/checkout?error=unknown');
  const r = await startCheckout(c, seat, email || undefined);
  if (!r.ok) redirect(`${back}&error=${r.reason}`);
  redirect(r.url);
}
