import type { Metadata } from 'next';
import { Shell } from '@/components/Shell';
import { env } from '@/lib/env';
import { availability, cohortBySlug, sessionsFor } from '@/lib/data';
import { isSeat, money, saleState, seatName } from '@/lib/rules';
import { beginCheckout } from './actions';

export const metadata: Metadata = { title: 'Checkout' };
export const dynamic = 'force-dynamic';

const errors: Record<string, string> = {
  unknown: "We couldn't find that seat. Please go back and choose again.",
  email: 'That email address doesn’t look right.',
  busy: 'Too many attempts. Please wait a few minutes and try again.',
  closed: 'Enrollment for this cohort is closed.',
  past_deadline: 'Enrollment for this cohort has closed.',
  sold_out: 'Those seats are all taken right now. Someone may still be checking out, so try again in half an hour, or join the waitlist.',
  error: 'Checkout is unavailable right now. Please try again in a few minutes.',
};

export default async function Checkout({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const e = env();
  const c = await cohortBySlug(sp.cohort || e.DEFAULT_COHORT);
  const seat = c?.self_paced ? 'founding' : isSeat(sp.seat) ? sp.seat : 'founding';   // self-paced has one price
  if (!c) {
    return <Shell narrow><h1>Checkout</h1><div className="notice err">This cohort isn’t available. <a href={`${e.SITE_URL}/pricing.html`}>Back to pricing</a></div></Shell>;
  }
  const [left, sessions] = await Promise.all([availability(c, seat), sessionsFor(c.id)]);
  const state = saleState(c, seat, left);
  const price = money(seat === 'vip' ? c.price_vip : c.price_founding, c.currency);
  const first = sessions[0] ? new Date(sessions[0].starts_at) : null;
  const err = sp.error ? errors[sp.error] ?? errors.error : null;

  return (
    <Shell narrow>
      <p className="muted small">{c.name}</p>
      <h1>{seatName(seat, c.self_paced)} · {price}</h1>
      {err && <div className="notice err" role="alert">{err}</div>}
      <div className="card">
        {c.self_paced ? (
          <>
            <ul>
              <li>Six modules of short video lessons, at your own pace, with a quiz and an assignment each</li>
              <li>Every assignment reviewed by our team, and a certificate of completion</li>
              <li>The workspace kit, with {c.library_months} months of library updates</li>
              <li>{c.support_days} days of written support</li>
            </ul>
            <p className="small muted">{c.refund_days ?? 14}-day money-back window while no more than two modules are complete. <a href={`${e.SITE_URL}/refunds.html`}>Read the conditions</a>.</p>
          </>
        ) : (<>
        <ul>
          <li>Six live build sessions{first ? `, starting ${first.toLocaleDateString('en-US', { dateStyle: 'long', timeZone: c.time_zone || 'UTC' })}` : ''}</li>
          <li>The workspace kit, with {c.library_months} months of library updates</li>
          <li>{c.support_days} days of support after demo day</li>
          {seat === 'vip' && <li>Three private 1-on-1 build sessions with the lead instructor</li>}
        </ul>
        <p className="small muted">3-day cooling-off and the build guarantee apply. <a href={`${e.SITE_URL}/refunds.html`}>Read the conditions</a>.</p>
        </>)}
      </div>
      {state.ok ? (
        <form action={beginCheckout} className="stack card">
          <input type="hidden" name="seat" value={seat} />
          <input type="hidden" name="cohort" value={c.slug} />
          <label>Email for your member account <span className="hint">Optional here; you can enter it on the payment page.</span>
            <input type="email" name="email" autoComplete="email" inputMode="email" />
          </label>
          <button className="btn buy" type="submit">Continue to secure payment</button>
          <p className="small muted" style={{ margin: 0 }}>Your seat is held for 30 minutes while you pay. {left <= 10 ? `${left} ${left === 1 ? 'seat' : 'seats'} left.` : ''}</p>
        </form>
      ) : (
        <div className="card">
          <p>{errors[state.reason]}</p>
          <a className="btn" href={`${e.SITE_URL}/pricing.html`}>Back to pricing</a>
        </div>
      )}
    </Shell>
  );
}
