import type { Metadata, Viewport } from 'next';
import './globals.css';

const brand = process.env.BRAND_NAME || 'Your Brand';

export const metadata: Metadata = {
  title: { default: brand, template: `%s · ${brand}` },
  description: `${brand} member area`,
  robots: { index: false, follow: false },   // checkout, member and admin pages are never indexed
  icons: { icon: '/favicon.svg' },
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#F4F4F5' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a className="skip" href="#main">Skip to content</a>
        {children}
      </body>
    </html>
  );
}
