import type { Metadata } from 'next';
import { Shell } from '@/components/Shell';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { env } from '@/lib/env';

export const metadata: Metadata = { title: 'Verify a certificate', robots: { index: false, follow: false } };
export const dynamic = 'force-dynamic';

/** Public check that a certificate of completion is genuine. Shows only the name, course and date. */
export default async function Verify({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  const e = env();
  const clean = String(code).toUpperCase();
  const ok = /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(clean);
  const { data } = ok ? await supabaseAdmin().from('course_certificates').select('name, issued_at, revoked_at').eq('code', clean).maybeSingle() : { data: null };
  return (
    <Shell narrow>
      <h1>Certificate check</h1>
      {data && !data.revoked_at ? (
        <div className="card">
          <p><span className="pill ok">Valid</span></p>
          <p><b>{data.name}</b> completed <b>{e.COURSE_NAME}</b> with {e.BRAND_NAME} on {new Date(data.issued_at).toLocaleDateString('en-US', { dateStyle: 'long' })}.</p>
          <p className="small muted" style={{ margin: 0 }}>Code {clean}</p>
        </div>
      ) : (
        <div className="card">
          <p><span className="pill bad">{data ? 'Withdrawn' : 'Not found'}</span></p>
          <p style={{ margin: 0 }}>{data ? 'This certificate has been withdrawn.' : 'We can’t find a certificate with that code. Check it was typed exactly as printed.'}</p>
        </div>
      )}
    </Shell>
  );
}
