import { Shell } from '@/components/Shell';

export default function NotFound() {
  return (
    <Shell narrow>
      <h1>Page not found</h1>
      <p className="lead">That page doesn’t exist or has moved.</p>
      <a className="btn" href="/member">Go to your member area</a>
    </Shell>
  );
}
