'use server';
import { redirect } from 'next/navigation';
import { headers } from 'next/headers';
import { z } from 'zod';
import { env } from '@/lib/env';
import { supabaseServer } from '@/lib/supabase/server';
import { rateLimit } from '@/lib/ratelimit';
import { safeNext } from '@/lib/rules';

export async function requestLink(form: FormData) {
  const email = String(form.get('email') ?? '').trim().toLowerCase();
  const next = safeNext(String(form.get('next') ?? ''));
  const q = (k: string) => `/login?${k}&next=${encodeURIComponent(next)}`;
  if (!z.email().safeParse(email).success) redirect(q('error=email'));

  const h = await headers();
  const ip = (h.get('x-forwarded-for') ?? '').split(',')[0].trim() || 'unknown';
  if (!rateLimit(`login:${ip}`, 8, 15 * 60_000).ok || !rateLimit(`login:${email}`, 4, 15 * 60_000).ok) redirect(q('error=busy'));

  const sb = await supabaseServer();
  // shouldCreateUser: false — only people with a seat (created at checkout) can sign in.
  const { error } = await sb.auth.signInWithOtp({
    email,
    options: { shouldCreateUser: false, emailRedirectTo: `${env().APP_URL}/auth/callback?next=${encodeURIComponent(next)}` },
  });
  if (error && !/signups not allowed|not found|otp_disabled/i.test(error.message)) console.warn('[login]', error.message);
  // Same answer whether or not the address has a seat, so the form can't be used to check who's enrolled.
  redirect(q('sent=1'));
}
