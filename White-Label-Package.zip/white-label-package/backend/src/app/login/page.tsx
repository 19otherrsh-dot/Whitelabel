import type { Metadata } from 'next';
import { Shell } from '@/components/Shell';
import { safeNext } from '@/lib/rules';
import { requestLink } from './actions';

export const metadata: Metadata = { title: 'Sign in' };

const errors: Record<string, string> = {
  email: 'Please enter the email address you booked with.',
  busy: 'Too many attempts. Please wait a few minutes and try again.',
  link: 'That sign-in link has expired or was already used. Request a new one below.',
};

export default async function Login({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const next = safeNext(sp.next);
  return (
    <Shell narrow>
      <h1>Sign in</h1>
      <p className="lead">We’ll email you a one-time link. No password needed.</p>
      {sp.error && <div className="notice err" role="alert">{errors[sp.error] ?? errors.link}</div>}
      {sp.sent ? (
        <div className="notice ok" role="status">
          If that address has a seat, a sign-in link is on its way. It expires in an hour. Check spam if you don’t see it in a minute or two.
        </div>
      ) : null}
      <form action={requestLink} className="stack card">
        <input type="hidden" name="next" value={next} />
        <label>Email
          <input type="email" name="email" autoComplete="email" inputMode="email" required />
        </label>
        <button className="btn buy" type="submit">Email me a sign-in link</button>
      </form>
      <p className="small muted">Bought a seat but can’t sign in? Use the address you paid with, or reply to your welcome email.</p>
    </Shell>
  );
}
