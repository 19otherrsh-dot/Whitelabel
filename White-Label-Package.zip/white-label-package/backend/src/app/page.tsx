import { redirect } from 'next/navigation';

// The public site is the static marketing site. This app's root goes to the member area.
export default function Home() {
  redirect('/member');
}
