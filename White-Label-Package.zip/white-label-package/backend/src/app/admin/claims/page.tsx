import type { Metadata } from 'next';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { money } from '@/lib/rules';
import { decideClaim } from '../actions';

export const metadata: Metadata = { title: 'Refund requests' };
export const dynamic = 'force-dynamic';

type Claim = { id: string; kind: string; reason: string; status: string; admin_note: string | null; created_at: string; evidence: { checklist?: string; url?: string; attended?: number[] };
  members: { email: string; full_name: string | null } | null; enrollments: { amount_paid: number; currency: string; created_at: string; seat: string } | null };

export default async function Claims({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const { data } = await supabaseAdmin().from('guarantee_claims')
    .select('id, kind, reason, status, admin_note, created_at, evidence, members(email, full_name), enrollments(amount_paid, currency, created_at, seat)')
    .order('created_at', { ascending: false }).limit(200);
  const claims = (data ?? []) as unknown as Claim[];
  const open = claims.filter((c) => c.status === 'open');
  const done = claims.filter((c) => c.status !== 'open');

  return (
    <Shell nav={adminNav} current="/admin/claims" signedIn>
      <h1>Refund requests</h1>
      <Notice ok={sp.ok} error={sp.error} />
      <p className="muted">The public promise is a reply within two working days. Approving issues a full refund through Stripe; access ends when Stripe confirms it.</p>
      {open.length === 0 && <div className="card muted">Nothing waiting.</div>}
      {open.map((c) => (
        <div className="card" key={c.id}>
          <div className="row" style={{ justifyContent: 'space-between' }}>
            <b>{c.kind === 'cooling_off' ? 'Cooling-off' : 'Build guarantee'} · {c.members?.full_name || c.members?.email}</b>
            <span className="small muted">{new Date(c.created_at).toLocaleString('en-US')}</span>
          </div>
          <p className="small muted">{c.members?.email} · {c.enrollments?.seat} seat · paid {c.enrollments ? money(c.enrollments.amount_paid, c.enrollments.currency) : '—'} on {c.enrollments ? new Date(c.enrollments.created_at).toLocaleDateString('en-US') : '—'}</p>
          <p style={{ whiteSpace: 'pre-wrap' }}>{c.reason}</p>
          {c.kind === 'build_guarantee' && (
            <div className="small" style={{ background: 'var(--bg)', padding: 12, borderRadius: 10, marginBottom: 12 }}>
              <div><b>Sessions attended (recorded):</b> {(c.evidence.attended ?? []).join(', ') || 'none'}</div>
              {c.evidence.checklist && <div style={{ whiteSpace: 'pre-wrap' }}><b>Setup steps:</b> {c.evidence.checklist}</div>}
              {c.evidence.url && <div><b>Evidence:</b> <a href={c.evidence.url} rel="noopener noreferrer">{c.evidence.url}</a></div>}
            </div>
          )}
          <form action={decideClaim} className="stack">
            <input type="hidden" name="claim" value={c.id} />
            <label>Note to the member <span className="hint">Required when declining. Sent by email and shown in their member area.</span><textarea name="note" style={{ minHeight: 70 }} /></label>
            <div className="row">
              <button className="btn buy" name="decision" value="approve" type="submit">Approve and refund in full</button>
              <button className="btn danger" name="decision" value="decline" type="submit">Decline</button>
            </div>
          </form>
        </div>
      ))}
      {done.length > 0 && (
        <>
          <h2>Decided</h2>
          <div className="card tablewrap"><table><thead><tr><th>When</th><th>Member</th><th>Type</th><th>Outcome</th><th>Note</th></tr></thead><tbody>
            {done.map((c) => <tr key={c.id}><td className="small">{new Date(c.created_at).toLocaleDateString('en-US')}</td><td>{c.members?.email}</td><td>{c.kind.replace('_', '-')}</td><td><span className={`pill ${c.status === 'declined' ? 'bad' : 'ok'}`}>{c.status}</span></td><td className="small">{c.admin_note}</td></tr>)}
          </tbody></table></div>
        </>
      )}
    </Shell>
  );
}
