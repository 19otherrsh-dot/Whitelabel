'use server';
import { redirect } from 'next/navigation';
import { z } from 'zod';
import { requireAdmin } from '@/lib/auth';
import { erasePerson } from '@/lib/privacy';
import { logAdmin } from '@/lib/data';

export async function erase(form: FormData) {
  const { user } = await requireAdmin();
  const email = String(form.get('email') ?? '').trim().toLowerCase();
  if (!z.email().safeParse(email).success) redirect('/admin/privacy?error=' + encodeURIComponent('Enter a valid email.'));
  const r = await erasePerson(email);
  // The log records that an erasure happened, not the address.
  await logAdmin(user.id, 'privacy_erase', null, { leads: r.leads, member: r.member, instructor: r.instructor });
  redirect('/admin/privacy?ok=' + encodeURIComponent(`Erased: ${r.leads} lead record(s)${r.member ? ', the member account (anonymised) and their course work' : ''}${r.instructor ? ', the instructor record and exam attempts' : ''}.`));
}
