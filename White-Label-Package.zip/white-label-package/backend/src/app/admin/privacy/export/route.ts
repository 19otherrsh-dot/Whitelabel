import { NextResponse, type NextRequest } from 'next/server';
import { supabaseServer } from '@/lib/supabase/server';
import { isAdmin } from '@/lib/auth';
import { findPerson } from '@/lib/privacy';
import { logAdmin } from '@/lib/data';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const sb = await supabaseServer();
  const { data } = await sb.auth.getUser();
  if (!data.user || !(await isAdmin(data.user.id))) return new NextResponse('Not found', { status: 404 });
  const email = (req.nextUrl.searchParams.get('email') ?? '').trim().toLowerCase();
  if (!email) return new NextResponse('Missing email', { status: 400 });
  const p = await findPerson(email);
  await logAdmin(data.user.id, 'privacy_export', null, { found: !!p.member || p.leads.length > 0 });
  return new NextResponse(JSON.stringify({ exportedAt: new Date().toISOString(), ...p }, null, 2), {
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': 'attachment; filename="personal-data-export.json"', 'Cache-Control': 'private, no-store' },
  });
}
