import type { Metadata } from 'next';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { findPerson } from '@/lib/privacy';
import { erase } from './actions';

export const metadata: Metadata = { title: 'Privacy requests' };
export const dynamic = 'force-dynamic';

export default async function Privacy({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const email = (sp.email ?? '').trim().toLowerCase();
  const p = email ? await findPerson(email) : null;

  return (
    <Shell nav={adminNav} current="/admin/privacy" signedIn>
      <h1>Privacy requests</h1>
      <Notice ok={sp.ok} error={sp.error} />
      <p className="muted">Find everything held about an email address, export it for an access request, or erase it. Answer requests within one month.</p>
      <form className="row card" style={{ marginBottom: 16 }}>
        <label style={{ flex: 1 }}>Email<input type="email" name="email" defaultValue={email} required /></label>
        <button className="btn" type="submit">Find</button>
      </form>
      {p && (
        <div className="card">
          <h2 style={{ marginTop: 0 }}>{p.email}</h2>
          <table><tbody>
            <tr><th>Leads (audit, contact, waitlist, training)</th><td>{p.leads.length}</td></tr>
            <tr><th>Member account</th><td>{p.member ? 'Yes' : 'No'}</td></tr>
            <tr><th>Enrollments (purchase records)</th><td>{p.enrollments.length}</td></tr>
            <tr><th>Support requests</th><td>{p.support.length}</td></tr>
            <tr><th>Refund requests</th><td>{p.claims.length}</td></tr>
            <tr><th>Attendance records / downloads</th><td>{p.attendance.length} / {p.downloads.length}</td></tr>
            <tr><th>Course: lessons / quiz attempts / submissions / certificate</th><td>{p.course.progress.length} / {p.course.quizzes.length} / {p.course.submissions.length} / {p.course.certificates.length}</td></tr>
            <tr><th>Instructor record / exam attempts</th><td>{p.instructor ? 'Yes' : 'No'} / {p.exams.length}</td></tr>
          </tbody></table>
          <div className="row" style={{ marginTop: 16 }}>
            <a className="btn" href={`/admin/privacy/export?email=${encodeURIComponent(p.email)}`}>Export (JSON)</a>
            {(p.leads.length > 0 || p.member) && (
              <form action={erase}>
                <input type="hidden" name="email" value={p.email} />
                <button className="btn danger" type="submit">Erase</button>
              </form>
            )}
          </div>
          <p className="small muted" style={{ marginTop: 12 }}>Erasing deletes leads, support requests, attendance and the download log; anonymises the member record and blocks sign-in. Purchase and refund records are kept (anonymised) where tax or dispute law requires. Also remove the person from Stripe (if no records are needed), the email tool, the community and any CRM you forward leads to.</p>
        </div>
      )}
    </Shell>
  );
}
