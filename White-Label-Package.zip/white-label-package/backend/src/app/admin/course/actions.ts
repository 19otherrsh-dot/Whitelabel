'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { logAdmin } from '@/lib/data';
import { sendMail } from '@/lib/email';
import { env } from '@/lib/env';
import { moduleByNumber } from '@/lib/course';

const go = (k: 'ok' | 'error', msg: string): never => redirect(`/admin/course?${k}=${encodeURIComponent(msg)}`);
const uuid = (v: FormDataEntryValue | null) => { const s = String(v ?? ''); if (!/^[0-9a-f-]{36}$/i.test(s)) go('error', 'Not found.'); return s; };

/** Mark a module submission Complete or Not yet, and tell the member. */
export async function reviewSubmission(form: FormData) {
  const { user } = await requireAdmin();
  const sb = supabaseAdmin();
  const id = uuid(form.get('submission'));
  const decision = String(form.get('decision'));
  const note = String(form.get('note') ?? '').trim().slice(0, 4000);
  if (decision !== 'complete' && decision !== 'not_yet') go('error', 'Choose Complete or Not yet.');
  if (decision === 'not_yet' && note.length < 10) go('error', 'Say exactly what’s missing, so the member can fix it.');
  const { data: sub } = await sb.from('course_submissions').select('id, module, member_id, status, members(email, full_name)').eq('id', id).maybeSingle();
  if (!sub) go('error', 'Submission not found.');
  await sb.from('course_submissions').update({ status: decision, reviewer_note: note || null, reviewed_by: user.id, reviewed_at: new Date().toISOString() }).eq('id', id);
  await logAdmin(user.id, 'review_submission', id, { decision });
  const m = sub!.members as unknown as { email: string; full_name: string | null } | null;
  const mod = moduleByNumber(sub!.module as number);
  const e = env();
  if (m?.email) {
    const first = m.full_name?.split(' ')[0] ?? 'there';
    const link = `${e.APP_URL}/member/course/${sub!.module}#assignment`;
    await sendMail({
      to: m.email,
      subject: decision === 'complete' ? `Module ${sub!.module} is complete` : `Module ${sub!.module}: one more step`,
      text: decision === 'complete'
        ? `Hi ${first},\n\nYour Module ${sub!.module} work (${mod?.title ?? ''}) is marked Complete.${note ? `\n\nFrom your reviewer:\n${note}` : ''}\n\n${link}\n\n${e.BRAND_NAME}`
        : `Hi ${first},\n\nThanks for sending your Module ${sub!.module} work. It isn't complete yet. Here's exactly what's missing:\n\n${note}\n\nFix it and send it again from the module page:\n${link}\n\nReply to this email if anything's unclear.\n\n${e.BRAND_NAME}`,
    });
  }
  revalidatePath('/admin/course');
  go('ok', `Marked ${decision === 'complete' ? 'Complete' : 'Not yet'}${m?.email ? ` and emailed ${m.email}` : ''}.`);
}

/** Save video and transcript links for one module's lessons. */
export async function saveCourseMedia(form: FormData) {
  const { user } = await requireAdmin();
  const m = moduleByNumber(Number(form.get('module')));
  if (!m) go('error', 'Module not found.');
  const rows: { lesson_id: string; video_url: string | null; transcript_url: string | null; updated_at: string }[] = [];
  for (const l of m!.lessons) {
    const v = String(form.get(`video-${l.id}`) ?? '').trim();
    const t = String(form.get(`transcript-${l.id}`) ?? '').trim();
    for (const u of [v, t]) if (u && !/^https:\/\/[^\s]+$/.test(u)) go('error', `Lesson ${l.id}: links must start with https://`);
    rows.push({ lesson_id: l.id, video_url: v || null, transcript_url: t || null, updated_at: new Date().toISOString() });
  }
  const { error } = await supabaseAdmin().from('course_media').upsert(rows, { onConflict: 'lesson_id' });
  if (error) go('error', 'That didn’t save.');
  await logAdmin(user.id, 'save_course_media', String(m!.n), { lessons: rows.filter((r) => r.video_url).length });
  revalidatePath('/admin/course');
  go('ok', `Module ${m!.n} links saved.`);
}

/** Withdraw (or restore) a certificate, e.g. after a refund or a breach of the terms. */
export async function setCertificateRevoked(form: FormData) {
  const { user } = await requireAdmin();
  const id = uuid(form.get('certificate'));
  const revoke = form.get('revoke') === '1';
  await supabaseAdmin().from('course_certificates').update({ revoked_at: revoke ? new Date().toISOString() : null }).eq('id', id);
  await logAdmin(user.id, revoke ? 'revoke_certificate' : 'restore_certificate', id);
  revalidatePath('/admin/course');
  go('ok', revoke ? 'Certificate withdrawn. The verification page now says so.' : 'Certificate restored.');
}
