import type { Metadata } from 'next';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { Inline } from '@/components/Inline';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { MODULES } from '@/lib/course';
import { env } from '@/lib/env';
import { reviewSubmission, saveCourseMedia, setCertificateRevoked } from './actions';

export const metadata: Metadata = { title: 'Course' };
export const dynamic = 'force-dynamic';

type Sub = { id: string; module: number; body: string; link: string | null; status: string; reviewer_note: string | null; created_at: string; reviewed_at: string | null; members: { email: string; full_name: string | null } | null };
const day = (iso: string) => new Date(iso).toLocaleDateString('en-US', { dateStyle: 'medium' });

export default async function AdminCourse({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const sb = supabaseAdmin();
  const [waiting, reviewed, attempts, progress, media, certs] = await Promise.all([
    sb.from('course_submissions').select('id, module, body, link, status, reviewer_note, created_at, reviewed_at, members(email, full_name)').eq('status', 'submitted').order('created_at').limit(100),
    sb.from('course_submissions').select('id, module, body, link, status, reviewer_note, created_at, reviewed_at, members(email, full_name)').neq('status', 'submitted').order('reviewed_at', { ascending: false }).limit(30),
    sb.from('quiz_attempts').select('member_id, module, passed'),
    sb.from('course_progress').select('member_id, lesson_id'),
    sb.from('course_media').select('lesson_id, video_url, transcript_url'),
    sb.from('course_certificates').select('id, name, code, issued_at, revoked_at, members(email)').order('issued_at', { ascending: false }).limit(100),
  ]);
  const queue = (waiting.data ?? []) as unknown as Sub[];
  const done = (reviewed.data ?? []) as unknown as Sub[];
  const mediaBy = new Map((media.data ?? []).map((m) => [m.lesson_id as string, m as { video_url: string | null; transcript_url: string | null }]));
  const lessonModule = new Map(MODULES.flatMap((m) => m.lessons.map((l) => [l.id, m.n] as const)));
  const stats = MODULES.map((m) => {
    const tries = (attempts.data ?? []).filter((a) => a.module === m.n);
    const started = new Set((progress.data ?? []).filter((p) => lessonModule.get(p.lesson_id as string) === m.n).map((p) => p.member_id));
    tries.forEach((t) => started.add(t.member_id));
    const passers = new Set(tries.filter((t) => t.passed).map((t) => t.member_id));
    const takers = new Set(tries.map((t) => t.member_id));
    return { n: m.n, title: m.title, started: started.size, takers: takers.size, passed: passers.size, attempts: tries.length, videos: m.lessons.filter((l) => mediaBy.get(l.id)?.video_url).length, lessons: m.lessons.length };
  });
  const e = env();

  return (
    <Shell nav={adminNav} current="/admin/course" signedIn>
      <h1>Course</h1>
      <Notice ok={sp.ok} error={sp.error} />
      <p className="muted">Lessons and quizzes come from <code>delivery/self-paced/</code> (rebuild with <code>node scripts/build-course.mjs</code>). Mark submissions against <code>submission-guide.md</code>: one line of evidence per check.</p>

      <h2>Waiting for review ({queue.length})</h2>
      {queue.length === 0 && <div className="card muted">Nothing waiting.</div>}
      {queue.map((s) => {
        const mod = MODULES.find((m) => m.n === s.module);
        return (
          <div className="card stack" key={s.id}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <b>Module {s.module}{mod ? ` · ${mod.title}` : ''}</b>
              <span className="small muted">{s.members?.full_name ? `${s.members.full_name} · ` : ''}{s.members?.email} · sent {day(s.created_at)}</span>
            </div>
            {mod?.check && <p className="small" style={{ margin: 0 }}><b>Complete when:</b> <Inline text={mod.check} /></p>}
            <pre style={{ whiteSpace: 'pre-wrap', background: 'var(--bg)', padding: 12, borderRadius: 10, margin: 0, maxHeight: 360, overflow: 'auto', fontSize: 13 }}>{s.body}</pre>
            {s.link && <p className="small" style={{ margin: 0 }}>Link: <a href={s.link} rel="noopener noreferrer" target="_blank">{s.link}</a></p>}
            <form action={reviewSubmission} className="stack">
              <input type="hidden" name="submission" value={s.id} />
              <label>Note to the member <span className="hint">Required for Not yet: exactly what’s missing. If you see a key or someone’s personal data, mark Not yet and explain how to remove it.</span><textarea name="note" rows={3} maxLength={4000} /></label>
              <div className="row">
                <button className="btn buy sm" type="submit" name="decision" value="complete">Complete</button>
                <button className="btn sm" type="submit" name="decision" value="not_yet">Not yet</button>
              </div>
            </form>
          </div>
        );
      })}

      <h2>Progress by module</h2>
      <div className="card tablewrap">
        <table>
          <thead><tr><th>Module</th><th>Members started</th><th>Took the quiz</th><th>Passed</th><th>Attempts</th><th>Videos linked</th></tr></thead>
          <tbody>{stats.map((s) => <tr key={s.n}><td>{s.n}. {s.title}</td><td>{s.started}</td><td>{s.takers}</td><td>{s.passed}</td><td>{s.attempts}</td><td>{s.videos}/{s.lessons}</td></tr>)}</tbody>
        </table>
        <p className="small muted" style={{ margin: '10px 0 0' }}>A quiz many people take but few pass usually means a lesson needs a clearer step, not a harder quiz.</p>
      </div>

      <h2>Recently reviewed</h2>
      <div className="card tablewrap">
        {done.length === 0 ? <p className="muted" style={{ margin: 0 }}>None yet.</p> : (
          <table>
            <thead><tr><th>Member</th><th>Module</th><th>Result</th><th>Note</th><th>Reviewed</th></tr></thead>
            <tbody>{done.map((s) => <tr key={s.id}><td>{s.members?.email}</td><td>{s.module}</td><td>{s.status === 'complete' ? <span className="pill ok">Complete</span> : <span className="pill bad">Not yet</span>}</td><td style={{ whiteSpace: 'pre-wrap' }}>{s.reviewer_note}</td><td>{s.reviewed_at ? day(s.reviewed_at) : ''}</td></tr>)}</tbody>
          </table>
        )}
      </div>

      <h2>Lesson videos</h2>
      <p className="small muted">Paste the link to each lesson’s video and transcript (your video host or course platform; unlisted or members-only). Lessons without a video show their outline and “video coming soon”.</p>
      {MODULES.map((m) => (
        <details className="card" key={m.n}>
          <summary><b>Module {m.n} · {m.title}</b> <span className="small muted">({m.lessons.filter((l) => mediaBy.get(l.id)?.video_url).length}/{m.lessons.length} videos)</span></summary>
          <form action={saveCourseMedia} className="stack" style={{ marginTop: 12 }}>
            <input type="hidden" name="module" value={m.n} />
            {m.lessons.map((l) => (
              <fieldset key={l.id} style={{ border: 0, padding: 0, margin: 0, display: 'grid', gap: 6 }}>
                <legend className="small" style={{ fontWeight: 600 }}>{l.id} {l.title} ({l.minutes} min)</legend>
                <label className="small">Video link<input type="url" name={`video-${l.id}`} defaultValue={mediaBy.get(l.id)?.video_url ?? ''} placeholder="https://" /></label>
                <label className="small">Transcript link (optional)<input type="url" name={`transcript-${l.id}`} defaultValue={mediaBy.get(l.id)?.transcript_url ?? ''} placeholder="https://" /></label>
              </fieldset>
            ))}
            <button className="btn sm" type="submit">Save Module {m.n} links</button>
          </form>
        </details>
      ))}

      <h2>Certificates</h2>
      <div className="card tablewrap">
        {(certs.data ?? []).length === 0 ? <p className="muted" style={{ margin: 0 }}>None issued yet.</p> : (
          <table>
            <thead><tr><th>Name</th><th>Email</th><th>Issued</th><th>Code</th><th></th></tr></thead>
            <tbody>{(certs.data ?? []).map((c) => (
              <tr key={c.id as string}>
                <td>{c.name as string}</td><td>{(c.members as unknown as { email: string } | null)?.email}</td><td>{day(c.issued_at as string)}</td>
                <td><a href={`${e.APP_URL}/certificate/${c.code}`}><code>{c.code as string}</code></a>{c.revoked_at ? <> <span className="pill bad">Withdrawn</span></> : null}</td>
                <td><form action={setCertificateRevoked}><input type="hidden" name="certificate" value={c.id as string} /><input type="hidden" name="revoke" value={c.revoked_at ? '0' : '1'} /><button className="linkbtn small" type="submit">{c.revoked_at ? 'Restore' : 'Withdraw'}</button></form></td>
              </tr>
            ))}</tbody>
          </table>
        )}
      </div>
    </Shell>
  );
}
