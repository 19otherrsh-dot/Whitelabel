import type { Metadata } from 'next';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { previewDue } from '@/lib/scheduleRun';
import { env } from '@/lib/env';
import { runEmailsNow } from '../actions';

export const metadata: Metadata = { title: 'Scheduled emails' };
export const dynamic = 'force-dynamic';

const KINDS: Record<string, string> = {
  prep: 'Prep, a week before Session 1', eve: 'Day before Session 1', reminder: 'Session starting in 2 hours', recording: 'Recording and homework',
  'support-call': 'Support call in 2 days', 'follow-up': '30 days after demo day', 'support-ending': 'Support ends in 10 days',
  'library-ending': 'Library ends in 30 days (renewal)', 'library-ended': 'Library has ended', 'training-reminder': 'Free training reminder', 'training-replay': 'Free training replay',
};

export default async function Emails({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const [{ data: log }, due] = await Promise.all([
    supabaseAdmin().from('email_log').select('key, kind, sent_at, ok, error').order('sent_at', { ascending: false }).limit(200),
    previewDue().catch(() => null),
  ]);
  const on = !!env().CRON_SECRET;
  const d = (s: string) => new Date(s).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' });

  return (
    <Shell nav={adminNav} current="/admin/emails" signedIn>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Scheduled emails</h1>
        <form action={runEmailsNow}><button className="btn sm" type="submit">Send what’s due now</button></form>
      </div>
      <Notice ok={sp.ok} error={sp.error} />
      <p className="muted small">
        Reminders before each session, recordings and homework when you add a recording link, support-call reminders, the 30-day check-in, and support and library notices (with the renewal link). Each goes once, inside its time window.
        {on ? ' The scheduler is on: it should call /api/cron/emails every 15 minutes.' : ' The scheduler is off: set CRON_SECRET and schedule /api/cron/emails (see supabase/cron-emails.example.sql). Until then, use the button.'}
      </p>
      <h2>Due right now</h2>
      <div className="card tablewrap">
        {due === null ? <p className="muted">Couldn’t work this out (check the database connection).</p> : due.length === 0 ? <p className="muted">Nothing is due.</p> : (
          <table><thead><tr><th>Email</th><th>To</th><th>Subject</th></tr></thead><tbody>
            {due.slice(0, 100).map((m) => <tr key={m.key}><td className="small">{KINDS[m.kind] ?? m.kind}</td><td className="small">{m.to}</td><td>{m.subject}</td></tr>)}
          </tbody></table>
        )}
      </div>
      <h2>Sent</h2>
      <div className="card tablewrap">
        {(log ?? []).length === 0 ? <p className="muted">Nothing sent yet.</p> : (
          <table><thead><tr><th>When</th><th>Email</th><th>Result</th></tr></thead><tbody>
            {(log ?? []).map((r) => <tr key={r.key}><td className="small">{d(r.sent_at)}</td><td className="small">{KINDS[r.kind] ?? r.kind}</td>
              <td>{r.ok === true ? <span className="pill ok">Sent</span> : r.ok === false ? <span className="pill bad" title={r.error ?? ''}>Failed, will retry</span> : <span className="pill">Sending</span>}</td></tr>)}
          </tbody></table>
        )}
      </div>
    </Shell>
  );
}
