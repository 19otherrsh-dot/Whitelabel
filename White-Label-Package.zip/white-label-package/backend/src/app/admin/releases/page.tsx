import type { Metadata } from 'next';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { ReleaseUploader } from '@/components/ReleaseUploader';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { makeLatest } from '../actions';

export const metadata: Metadata = { title: 'Kit releases' };
export const dynamic = 'force-dynamic';

export default async function Releases({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const sb = supabaseAdmin();
  const [{ data: rels }, { data: dls }] = await Promise.all([
    sb.from('releases').select('id, version, notes, size_bytes, sha256, is_latest, published_at').order('published_at', { ascending: false }),
    sb.from('downloads').select('release_id'),
  ]);
  const counts = new Map<string, number>();
  for (const d of dls ?? []) counts.set(d.release_id, (counts.get(d.release_id) ?? 0) + 1);

  return (
    <Shell nav={adminNav} current="/admin/releases" signedIn>
      <h1>Kit releases</h1>
      <Notice ok={sp.ok} error={sp.error} />
      <p className="muted">Build the zip with <code>node build/release.mjs</code>, then upload it here. Members with library access download the version marked current; members update an installed kit with <code>wf update --from members can update an installed kit with <code>wf update</code>.lt;zipmembers can update an installed kit with <code>wf update</code>.gt;</code>.</p>
      <ReleaseUploader />
      <div className="card tablewrap">
        <table>
          <thead><tr><th>Version</th><th>Published</th><th>Size</th><th>Downloads</th><th>SHA-256</th><th></th></tr></thead>
          <tbody>
            {(rels ?? []).map((r) => (
              <tr key={r.id}>
                <td><b>{r.version}</b>{r.is_latest && <> <span className="pill ok">Current</span></>}</td>
                <td className="small">{new Date(r.published_at).toLocaleDateString('en-US', { dateStyle: 'medium' })}</td>
                <td className="small">{r.size_bytes ? `${(r.size_bytes / 1e6).toFixed(1)} MB` : <span className="pill warn">Not uploaded</span>}</td>
                <td>{counts.get(r.id) ?? 0}</td>
                <td><code className="small">{r.sha256 ? `${r.sha256.slice(0, 12)}…` : '—'}</code></td>
                <td>{!r.is_latest && r.size_bytes ? <form action={makeLatest}><input type="hidden" name="release" value={r.id} /><button className="btn sm" type="submit">Make current</button></form> : null}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {(rels ?? []).length === 0 && <p className="muted">No releases yet.</p>}
      </div>
    </Shell>
  );
}
