import type { Metadata } from 'next';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { money } from '@/lib/rules';
import { extendAccess, resendWelcome, setEnrollmentStatus } from '../actions';

export const metadata: Metadata = { title: 'Members' };
export const dynamic = 'force-dynamic';

type Row = { id: string; member_id: string; seat: string; status: string; amount_paid: number; currency: string; created_at: string; library_until: string | null; support_until: string | null; setup_done_at: string | null;
  members: { email: string; full_name: string | null } | null; cohorts: { name: string } | null };

export default async function Members({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const q = (sp.q ?? '').trim().toLowerCase();
  const { data } = await supabaseAdmin().from('enrollments')
    .select('id, member_id, seat, status, amount_paid, currency, created_at, library_until, support_until, setup_done_at, members(email, full_name), cohorts(name)')
    .order('created_at', { ascending: false }).limit(500);
  const { data: dls } = await supabaseAdmin().from('downloads').select('member_id, created_at').order('created_at', { ascending: true }).limit(5000);
  const firstDl = new Map<string, string>(); for (const x of dls ?? []) if (!firstDl.has(x.member_id)) firstDl.set(x.member_id, x.created_at);
  const rows = ((data ?? []) as unknown as Row[]).filter((r) => !q || r.members?.email.includes(q) || (r.members?.full_name ?? '').toLowerCase().includes(q));
  const d = (s: string | null) => (s ? new Date(s).toLocaleDateString('en-US', { dateStyle: 'medium' }) : '—');

  return (
    <Shell nav={adminNav} current="/admin/members" signedIn>
      <h1>Members</h1>
      <Notice ok={sp.ok} error={sp.error} />
      <form className="row" style={{ marginBottom: 16 }}>
        <input type="text" name="q" defaultValue={sp.q} placeholder="Search name or email" style={{ maxWidth: 320 }} />
        <button className="btn sm" type="submit">Search</button>
      </form>
      <div className="card tablewrap">
        <table>
          <thead><tr><th>Member</th><th>Seat</th><th>Paid</th><th>Library / support until</th><th>Setup</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td><b>{r.members?.full_name || '—'}</b><br /><span className="small">{r.members?.email}</span><br /><span className="small muted">{r.cohorts?.name} · {d(r.created_at)}</span></td>
                <td>{r.seat === 'vip' ? 'VIP' : 'Founding'}</td>
                <td>{money(r.amount_paid, r.currency)}</td>
                <td className="small">{d(r.library_until)}<br />{d(r.support_until)}</td>
                <td className="small">{firstDl.has(r.member_id) ? <>Kit downloaded {d(firstDl.get(r.member_id)!)}</> : <span className="muted">Kit not downloaded</span>}<br />{r.setup_done_at ? <span className="pill ok">Setup done {d(r.setup_done_at)}</span> : <span className="muted">Setup not confirmed</span>}</td>
                <td><span className={`pill ${r.status === 'active' ? 'ok' : r.status === 'refunded' ? 'bad' : ''}`}>{r.status}</span></td>
                <td>
                  <div className="row">
                    <form action={resendWelcome}><input type="hidden" name="enrollment" value={r.id} /><button className="btn sm" type="submit">Resend welcome</button></form>
                    {r.status === 'active'
                      ? <form action={setEnrollmentStatus}><input type="hidden" name="enrollment" value={r.id} /><input type="hidden" name="status" value="revoked" /><button className="btn sm danger" type="submit">Revoke</button></form>
                      : r.status !== 'refunded' && <form action={setEnrollmentStatus}><input type="hidden" name="enrollment" value={r.id} /><input type="hidden" name="status" value="active" /><button className="btn sm" type="submit">Reactivate</button></form>}
                  </div>
                  <form action={extendAccess} className="row" style={{ marginTop: 8 }}>
                    <input type="hidden" name="enrollment" value={r.id} />
                    <select name="field" aria-label="Which access" style={{ width: 'auto', padding: '6px 8px' }}><option value="library_until">Library</option><option value="support_until">Support</option></select>
                    <input type="number" name="months" min={1} max={36} defaultValue={12} aria-label="Months" style={{ width: 70, padding: '6px 8px' }} />
                    <button className="btn sm" type="submit">Extend</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length === 0 && <p className="muted">No members yet.</p>}
      </div>
      <p className="small muted">Refunds go through Stripe (or the Refunds tab), which ends access automatically. Revoke is for other cases, such as a seat transferred to someone else.</p>
    </Shell>
  );
}
