import type { Metadata } from 'next';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { deleteSupportCall, saveAttendance, saveCohort, saveSession, saveSupportCall } from '../actions';
import { HAVE_READY, HOMEWORK } from '@/lib/schedule';

export const metadata: Metadata = { title: 'Cohorts' };
export const dynamic = 'force-dynamic';

type Cohort = { id: string; slug: string; name: string; seats: number; vip_seats: number; price_founding: number; price_vip: number; currency: string; enrollment_closes: string | null; time_zone: string; support_days: number; library_months: number; is_open: boolean; price_renewal: number | null; renewal_months: number; self_paced?: boolean; refund_days?: number };
type Session = { id: string; position: number; title: string; starts_at: string; ends_at: string; join_url: string | null; replay_url: string | null; have_ready?: string | null; homework?: string | null };
type Call = { id: string; starts_at: string; ends_at: string; join_url: string | null };

/** ISO with the cohort's UTC offset, e.g. 2026-09-21T10:00-04:00, so editing shows local times. */
function localIso(iso: string, tz: string): string {
  const d = new Date(iso);
  const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZoneName: 'longOffset' }).formatToParts(d).map((p) => [p.type, p.value]));
  const off = String(parts.timeZoneName).replace('GMT', '') || '+00:00';
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}${off}`;
}

export default async function Cohorts({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const sb = supabaseAdmin();
  const { data: list } = await sb.from('cohorts').select('*').order('created_at', { ascending: false });
  const cohorts = (list ?? []) as Cohort[];
  const c = cohorts.find((x) => x.slug === sp.c) ?? (sp.c === 'new' ? null : cohorts[0] ?? null);
  const [{ data: sess }, { data: enr }, { data: callRows }] = c ? await Promise.all([
    sb.from('cohort_sessions').select('*').eq('cohort_id', c.id).order('position'),
    sb.from('enrollments').select('member_id, members(email, full_name)').eq('cohort_id', c.id).eq('status', 'active'),
    sb.from('support_calls').select('id, starts_at, ends_at, join_url').eq('cohort_id', c.id).order('starts_at'),
  ]) : [{ data: [] }, { data: [] }, { data: [] }];
  const calls = (callRows ?? []) as Call[];
  const sessions = (sess ?? []) as Session[];
  const { data: att } = sessions.length
    ? await sb.from('attendance').select('session_id, member_id, attended').in('session_id', sessions.map((s) => s.id))
    : { data: [] as { session_id: string; member_id: string; attended: boolean }[] };
  const members = (enr ?? []) as unknown as { member_id: string; members: { email: string; full_name: string | null } | null }[];
  const present = new Set((att ?? []).filter((a) => a.attended).map((a) => `${a.session_id}:${a.member_id}`));
  const tz = c?.time_zone ?? 'America/New_York';
  const nextPos = (sessions.at(-1)?.position ?? 0) + 1;

  return (
    <Shell nav={adminNav} current="/admin/cohorts" signedIn>
      <h1>Cohorts</h1>
      <Notice ok={sp.ok} error={sp.error} />
      <nav className="row" aria-label="Cohorts" style={{ marginBottom: 16 }}>
        {cohorts.map((x) => <a key={x.id} className={`btn sm ${c?.id === x.id ? 'buy' : ''}`} href={`/admin/cohorts?c=${x.slug}`}>{x.name}</a>)}
        <a className={`btn sm ${!c ? 'buy' : ''}`} href="/admin/cohorts?c=new">+ New cohort</a>
      </nav>

      <form action={saveCohort} className="card stack">
        <h2 style={{ marginTop: 0 }}>{c ? 'Settings' : 'New cohort'}</h2>
        <div className="grid">
          <label>Name<input type="text" name="name" defaultValue={c?.name} required /></label>
          <label>Slug <span className="hint">Used in checkout links: /checkout?cohort=…</span><input type="text" name="slug" defaultValue={c?.slug} required pattern="[a-z0-9-]{2,60}" readOnly={!!c} /></label>
          <label>Total places<input type="number" name="seats" defaultValue={c?.seats ?? 50} min={0} required /></label>
          <label>Of which VIP<input type="number" name="vip_seats" defaultValue={c?.vip_seats ?? 5} min={0} required /></label>
          <label>Founding price <span className="hint">e.g. 1497</span><input type="number" step="0.01" name="price_founding" defaultValue={c ? c.price_founding / 100 : 1497} min={0} required /></label>
          <label>VIP price<input type="number" step="0.01" name="price_vip" defaultValue={c ? c.price_vip / 100 : 5000} min={0} required /></label>
          <label>Currency<input type="text" name="currency" defaultValue={(c?.currency ?? 'usd').toUpperCase()} maxLength={3} required /></label>
          <label>Time zone<input type="text" name="time_zone" defaultValue={tz} required /></label>
          <label>Enrollment closes <span className="hint">e.g. 2026-09-21T10:00-04:00</span><input type="text" name="enrollment_closes" defaultValue={c?.enrollment_closes ? localIso(c.enrollment_closes, tz) : ''} /></label>
          <label>Support days after demo day<input type="number" name="support_days" defaultValue={c?.support_days ?? 90} min={0} required /></label>
          <label>Library months<input type="number" name="library_months" defaultValue={c?.library_months ?? 12} min={0} required /></label>
          <label>Renewal price <span className="hint">empty = no paid renewal</span><input type="number" step="0.01" name="price_renewal" defaultValue={c?.price_renewal != null ? c.price_renewal / 100 : ''} min={0} /></label>
          <label>Each renewal adds (months)<input type="number" name="renewal_months" defaultValue={c?.renewal_months ?? 12} min={1} max={36} required /></label>
        </div>
        <label className="check"><input type="checkbox" name="is_open" defaultChecked={c?.is_open ?? true} /> Selling (checkout is open)</label>
        <label className="check"><input type="checkbox" name="self_paced" defaultChecked={c?.self_paced ?? false} /> Self-paced course (no live sessions; the founding price is the course price; no build guarantee)</label>
        <label style={{ maxWidth: 320 }}>Self-paced money-back days <span className="hint">while no more than two modules are complete</span><input type="number" name="refund_days" defaultValue={c?.refund_days ?? 14} min={0} max={60} /></label>
        <p className="small muted" style={{ margin: 0 }}>Prices here are what Stripe charges. Keep the site’s <code>assets/config.js</code> prices and dates in step.</p>
        <button className="btn buy" type="submit">Save cohort</button>
      </form>

      {c && (
        <>
          <h2>Sessions</h2>
          <p className="small muted">Times are written with their UTC offset so there’s no doubt, e.g. <code>{localIso(new Date().toISOString(), tz)}</code>. Members see them in {tz}.</p>
          {[...sessions, { id: '', position: nextPos, title: '', starts_at: '', ends_at: '', join_url: null, replay_url: null }].map((s) => (
            <form action={saveSession} className="card stack" key={s.id || 'new'}>
              <input type="hidden" name="cohort" value={c.id} /><input type="hidden" name="slug" value={c.slug} />
              <div className="grid">
                <label>#<input type="number" name="position" defaultValue={s.position} min={1} required /></label>
                <label style={{ gridColumn: 'span 2' }}>Title<input type="text" name="title" defaultValue={s.title} placeholder={s.id ? '' : 'Add a session'} required /></label>
                <label>Starts<input type="text" name="starts_at" defaultValue={s.starts_at ? localIso(s.starts_at, tz) : ''} required /></label>
                <label>Ends<input type="text" name="ends_at" defaultValue={s.ends_at ? localIso(s.ends_at, tz) : ''} required /></label>
                <label>Join link<input type="url" name="join_url" defaultValue={s.join_url ?? ''} placeholder="https://" /></label>
                <label>Recording <span className="hint">adding it emails members the link and homework</span><input type="url" name="replay_url" defaultValue={s.replay_url ?? ''} placeholder="https://" /></label>
              </div>
              <details>
                <summary className="small">Reminder and homework text</summary>
                <div className="grid" style={{ marginTop: 8 }}>
                  <label>Have ready <span className="hint">in the 2-hour reminder</span><textarea name="have_ready" rows={2} maxLength={2000} defaultValue={s.have_ready ?? ''} placeholder={HAVE_READY[s.position] ?? ''} /></label>
                  <label>Homework <span className="hint">in the recording email</span><textarea name="homework" rows={4} maxLength={2000} defaultValue={s.homework ?? ''} placeholder={HOMEWORK[s.position] ?? ''} /></label>
                </div>
              </details>
              <button className="btn sm" type="submit">{s.id ? `Save session ${s.position}` : 'Add session'}</button>
            </form>
          ))}

          <h2>Support calls</h2>
          <p className="small muted">The fortnightly calls after demo day. Members get a reminder two days before each.</p>
          <div className="card">
            {calls.length === 0 ? <p className="muted">None yet.</p> : (
              <table><thead><tr><th>When ({tz})</th><th>Link</th><th></th></tr></thead><tbody>
                {calls.map((k) => (
                  <tr key={k.id}><td>{localIso(k.starts_at, tz)}</td><td className="small">{k.join_url ?? '—'}</td>
                    <td><form action={deleteSupportCall}><input type="hidden" name="call" value={k.id} /><input type="hidden" name="slug" value={c.slug} /><button className="btn sm danger" type="submit">Remove</button></form></td></tr>
                ))}
              </tbody></table>
            )}
            <form action={saveSupportCall} className="grid" style={{ marginTop: 12, alignItems: 'end' }}>
              <input type="hidden" name="cohort" value={c.id} /><input type="hidden" name="slug" value={c.slug} />
              <label>Starts<input type="text" name="starts_at" placeholder={localIso(new Date().toISOString(), tz)} required /></label>
              <label>Minutes<input type="number" name="minutes" defaultValue={60} min={15} max={480} /></label>
              <label>Join link<input type="url" name="join_url" placeholder="https://" /></label>
              <button className="btn sm" type="submit">Add support call</button>
            </form>
          </div>

          <h2>Attendance</h2>
          <p className="small muted">The build guarantee depends on live attendance. Tick who joined each session (check the meeting tool’s attendance report).</p>
          {members.length === 0 ? <div className="card muted">No active members yet.</div> : sessions.map((s) => (
            <form action={saveAttendance} className="card" key={s.id}>
              <input type="hidden" name="session" value={s.id} /><input type="hidden" name="slug" value={c.slug} />
              <b>Session {s.position}: {s.title}</b>
              <div className="grid" style={{ margin: '12px 0', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 6 }}>
                {members.map((m) => (
                  <label className="check small" key={m.member_id}>
                    <input type="hidden" name="everyone" value={m.member_id} />
                    <input type="checkbox" name="present" value={m.member_id} defaultChecked={present.has(`${s.id}:${m.member_id}`)} /> {m.members?.full_name || m.members?.email}
                  </label>
                ))}
              </div>
              <button className="btn sm" type="submit">Save attendance</button>
            </form>
          ))}
        </>
      )}
    </Shell>
  );
}
