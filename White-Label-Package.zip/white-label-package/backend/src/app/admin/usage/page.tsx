import type { Metadata } from 'next';
import { Shell, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { aggregateUsage, type UsageRow } from '@/lib/usage';

export const metadata: Metadata = { title: 'Skill usage' };
export const dynamic = 'force-dynamic';

const pct = (n: number) => `${(n * 100).toFixed(n > 0 && n < 0.1 ? 1 : 0)}%`;

export default async function AdminUsage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const days = ['30', '90', '365'].includes(sp.days ?? '') ? Number(sp.days) : 90;
  const since = new Date(Date.now() - days * 864e5).toISOString();
  const { data } = await supabaseAdmin().from('usage_reports').select('received_at, kit_version, skills').gte('received_at', since).order('received_at', { ascending: false }).limit(2000);
  const rows = (data ?? []) as UsageRow[];
  const totals = aggregateUsage(rows);
  const versions = [...new Set(rows.map((r) => r.kit_version).filter(Boolean))];

  return (
    <Shell nav={adminNav} current="/admin/usage" signedIn>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Skill usage</h1>
        <nav className="row small" aria-label="Period">
          {[30, 90, 365].map((d) => <a key={d} className="btn sm" href={`/admin/usage?days=${d}`} aria-current={d === days ? 'page' : undefined}>{d} days</a>)}
        </nav>
      </div>
      <p className="muted small">Anonymous summaries members chose to share (<code>bin/wf learn --export</code>). Counts only; no member is identifiable. Sorted by rejection rate, then failure rate: the top rows are the skills to improve first.</p>
      <div className="grid">
        <div className="card stat"><b>{rows.length}</b><span>Summaries in the last {days} days</span></div>
        <div className="card stat"><b>{totals.length}</b><span>Skills with runs</span></div>
        <div className="card stat"><b>{versions.length ? versions.slice(0, 3).join(', ') : '—'}</b><span>Kit versions seen</span></div>
      </div>
      {totals.length === 0 ? <div className="card muted">No summaries yet. Members can share one from their member area.</div> : (
        <div className="card tablewrap">
          <table>
            <thead><tr><th>Skill</th><th>Workspaces</th><th>Runs</th><th>Failed</th><th>Rejected</th><th>Lessons taught</th></tr></thead>
            <tbody>
              {totals.map((t) => (
                <tr key={t.skill}>
                  <td>{t.skill === 'custom' ? <span className="muted">Owners’ own skills (pooled)</span> : <code>{t.skill}</code>}</td>
                  <td>{t.workspaces}</td>
                  <td>{t.runs}</td>
                  <td>{t.failed} <span className="muted small">({pct(t.failRate)})</span></td>
                  <td>{t.rejected} <span className="muted small">({pct(t.rejectRate)})</span></td>
                  <td>{t.lessons}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Shell>
  );
}
