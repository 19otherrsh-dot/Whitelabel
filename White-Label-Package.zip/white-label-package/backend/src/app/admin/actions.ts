'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { stripe } from '@/lib/stripe';
import { logAdmin } from '@/lib/data';
import { signInLink } from '@/lib/members';
import { sendMail, welcomeEmail } from '@/lib/email';
import { cohortSchema, releaseSchema } from '@/lib/validation';

const go = (path: string, k: 'ok' | 'error', msg: string): never => redirect(`${path}${path.includes('?') ? '&' : '?'}${k}=${encodeURIComponent(msg)}`);
const id = (v: FormDataEntryValue | null) => { const s = String(v ?? ''); if (!/^[0-9a-f-]{36}$/i.test(s)) throw new Error('bad id'); return s; };

// ---------- members ----------
export async function resendWelcome(form: FormData) {
  const { user } = await requireAdmin();
  const sb = supabaseAdmin();
  const enrollmentId = id(form.get('enrollment'));
  const { data: en } = await sb.from('enrollments').select('id, seat, member_id, cohorts(name), members(email, full_name)').eq('id', enrollmentId).maybeSingle();
  const m = en?.members as unknown as { email: string; full_name: string | null } | null;
  const c = en?.cohorts as unknown as { name: string } | null;
  if (!en || !m) go('/admin/members', 'error', 'Enrollment not found.');
  const link = await signInLink(m!.email);
  const r = await sendMail({ to: m!.email, ...welcomeEmail({ name: m!.full_name, cohort: c?.name ?? 'the cohort', seat: en!.seat, loginUrl: link }) });
  await logAdmin(user.id, 'resend_welcome', enrollmentId, { ok: r.ok });
  go('/admin/members', r.ok ? 'ok' : 'error', r.ok ? `Welcome email sent to ${m!.email}.` : `Email failed: ${r.error}`);
}

export async function setEnrollmentStatus(form: FormData) {
  const { user } = await requireAdmin();
  const enrollmentId = id(form.get('enrollment'));
  const status = String(form.get('status'));
  if (!['active', 'revoked', 'transferred'].includes(status)) go('/admin/members', 'error', 'Unknown status.');
  await supabaseAdmin().from('enrollments').update({ status }).eq('id', enrollmentId);
  await logAdmin(user.id, 'set_status', enrollmentId, { status });
  revalidatePath('/admin/members');
  go('/admin/members', 'ok', `Seat marked ${status}.`);
}

export async function extendAccess(form: FormData) {
  const { user } = await requireAdmin();
  const enrollmentId = id(form.get('enrollment'));
  const field = String(form.get('field'));
  const months = Number(form.get('months'));
  if (!['library_until', 'support_until'].includes(field) || !Number.isInteger(months) || months < 1 || months > 36) go('/admin/members', 'error', 'Choose 1 to 36 months.');
  const sb = supabaseAdmin();
  const { data: en } = await sb.from('enrollments').select(field).eq('id', enrollmentId).maybeSingle();
  const current = (en as Record<string, string | null> | null)?.[field];
  const base = current && Date.parse(current) > Date.now() ? new Date(current) : new Date();
  base.setUTCMonth(base.getUTCMonth() + months);
  await sb.from('enrollments').update({ [field]: base.toISOString() }).eq('id', enrollmentId);
  await logAdmin(user.id, 'extend', enrollmentId, { field, months });
  go('/admin/members', 'ok', 'Access extended.');
}

// ---------- refunds ----------
export async function decideClaim(form: FormData) {
  const { user } = await requireAdmin();
  const sb = supabaseAdmin();
  const claimId = id(form.get('claim'));
  const decision = String(form.get('decision'));
  const note = String(form.get('note') ?? '').trim().slice(0, 2000);
  const { data: claim } = await sb.from('guarantee_claims').select('id, status, enrollment_id, member_id, enrollments(stripe_payment_intent, amount_paid), members(email)').eq('id', claimId).maybeSingle();
  if (!claim || claim.status !== 'open') go('/admin/claims', 'error', 'That request is no longer open.');
  const en = claim!.enrollments as unknown as { stripe_payment_intent: string | null; amount_paid: number } | null;
  const email = (claim!.members as unknown as { email: string } | null)?.email;

  if (decision === 'decline') {
    if (note.length < 10) go('/admin/claims', 'error', 'Add a note explaining the decision (the member sees it).');
    await sb.from('guarantee_claims').update({ status: 'declined', admin_note: note, decided_at: new Date().toISOString() }).eq('id', claimId);
    await logAdmin(user.id, 'claim_declined', claimId, {});
    if (email) await sendMail({ to: email, subject: 'About your refund request', text: `Hi,\n\nWe've reviewed your request and can't approve it this time.\n\n${note}\n\nIf you think we've got something wrong, just reply to this email.` });
    go('/admin/claims', 'ok', 'Declined and the member was emailed.');
  }
  if (decision !== 'approve') go('/admin/claims', 'error', 'Unknown decision.');
  if (!en?.stripe_payment_intent) go('/admin/claims', 'error', 'No Stripe payment on this seat. Refund it by hand, then mark the seat refunded.');
  try {
    const refund = await stripe().refunds.create(
      { payment_intent: en!.stripe_payment_intent!, reason: 'requested_by_customer', metadata: { claim_id: claimId } },
      { idempotencyKey: `claim-${claimId}` },
    );
    await sb.from('guarantee_claims').update({ status: 'approved', admin_note: note || null, stripe_refund: refund.id, decided_at: new Date().toISOString() }).eq('id', claimId);
    await logAdmin(user.id, 'claim_approved', claimId, { refund: refund.id });
  } catch (err) {
    go('/admin/claims', 'error', `Stripe refused the refund: ${(err as Error).message}`);
  }
  // The charge.refunded webhook ends access and emails the member.
  go('/admin/claims', 'ok', 'Refund issued. Access ends when Stripe confirms it.');
}

// ---------- support ----------
export async function replySupport(form: FormData) {
  const { user } = await requireAdmin();
  const sb = supabaseAdmin();
  const reqId = id(form.get('request'));
  const reply = String(form.get('reply') ?? '').trim();
  const close = form.get('close') === 'on';
  if (!reply && !close) go('/admin/support', 'error', 'Write a reply or tick close.');
  const { data: r } = await sb.from('support_requests').select('subject, members(email)').eq('id', reqId).maybeSingle();
  await sb.from('support_requests').update({ ...(reply ? { admin_reply: reply.slice(0, 8000) } : {}), status: close ? 'closed' : 'waiting' }).eq('id', reqId);
  const email = (r?.members as unknown as { email: string } | null)?.email;
  if (reply && email) await sendMail({ to: email, subject: `Re: ${r!.subject}`, text: `${reply}\n\nYou can see the whole thread in your member area.` });
  await logAdmin(user.id, 'support_reply', reqId, { close });
  go('/admin/support', 'ok', close ? 'Closed.' : 'Reply sent.');
}

// ---------- cohorts & sessions ----------
export async function saveCohort(form: FormData) {
  const { user } = await requireAdmin();
  const raw = Object.fromEntries(form.entries());
  const parsed = cohortSchema.safeParse({ ...raw, is_open: raw.is_open ?? '', self_paced: raw.self_paced ?? '' });
  if (!parsed.success) go('/admin/cohorts', 'error', `${String(parsed.error.issues[0].path[0])}: ${parsed.error.issues[0].message}`);
  const d = parsed.data!;
  if (d.self_paced && d.vip_seats > 0) go('/admin/cohorts', 'error', 'A self-paced course has one price: set VIP seats to 0.');
  if (d.vip_seats > d.seats) go('/admin/cohorts', 'error', 'VIP seats are part of the total, so they can’t exceed it.');
  const closes = d.enrollment_closes ? new Date(d.enrollment_closes) : null;
  if (closes && Number.isNaN(closes.getTime())) go('/admin/cohorts', 'error', 'Enrollment close: use a date like 2026-09-21T10:00-04:00');
  const row = {
    slug: d.slug, name: d.name, seats: d.seats, vip_seats: d.vip_seats,
    price_founding: Math.round(d.price_founding * 100), price_vip: Math.round(d.price_vip * 100),
    currency: d.currency, enrollment_closes: closes?.toISOString() ?? null,
    support_days: d.support_days, library_months: d.library_months, is_open: d.is_open,
    price_renewal: d.price_renewal == null ? null : Math.round(d.price_renewal * 100), renewal_months: d.renewal_months,
    self_paced: d.self_paced, refund_days: d.refund_days,
    time_zone: String(raw.time_zone || 'America/New_York'),
  };
  try { new Intl.DateTimeFormat('en-US', { timeZone: row.time_zone }); } catch { go('/admin/cohorts', 'error', 'Time zone: use an IANA name like America/New_York'); }
  const { error } = await supabaseAdmin().from('cohorts').upsert(row, { onConflict: 'slug' });
  if (error) go('/admin/cohorts', 'error', error.message);
  await logAdmin(user.id, 'save_cohort', d.slug, row);
  revalidatePath('/admin/cohorts');
  go(`/admin/cohorts?c=${d.slug}`, 'ok', 'Cohort saved.');
}

export async function saveSession(form: FormData) {
  const { user } = await requireAdmin();
  const cohortId = id(form.get('cohort'));
  const slug = String(form.get('slug') ?? '');
  const position = Number(form.get('position'));
  const title = String(form.get('title') ?? '').trim();
  const starts = new Date(String(form.get('starts_at') ?? ''));
  const ends = new Date(String(form.get('ends_at') ?? ''));
  const url = (k: string) => { const v = String(form.get(k) ?? '').trim(); if (v && !/^https:\/\//.test(v)) go(`/admin/cohorts?c=${slug}`, 'error', `${k}: links must start with https://`); return v || null; };
  if (!Number.isInteger(position) || position < 1 || !title || Number.isNaN(starts.getTime()) || Number.isNaN(ends.getTime()) || ends <= starts) {
    go(`/admin/cohorts?c=${slug}`, 'error', 'Session needs a number, a title, and a start before its end (e.g. 2026-09-21T10:00-04:00).');
  }
  const longText = (k: string) => String(form.get(k) ?? '').trim().slice(0, 2000) || null;
  const { error } = await supabaseAdmin().from('cohort_sessions').upsert({ cohort_id: cohortId, position, title, starts_at: starts.toISOString(), ends_at: ends.toISOString(), join_url: url('join_url'), replay_url: url('replay_url'), have_ready: longText('have_ready'), homework: longText('homework') }, { onConflict: 'cohort_id,position' });
  if (error) go(`/admin/cohorts?c=${slug}`, 'error', error.message);
  await logAdmin(user.id, 'save_session', cohortId, { position });
  go(`/admin/cohorts?c=${slug}`, 'ok', `Session ${position} saved.`);
}

export async function saveAttendance(form: FormData) {
  const { user } = await requireAdmin();
  const sessionId = id(form.get('session'));
  const slug = String(form.get('slug') ?? '');
  const everyone = form.getAll('everyone').map((v) => id(v));
  const present = new Set(form.getAll('present').map((v) => id(v)));
  const rows = everyone.map((m) => ({ session_id: sessionId, member_id: m, attended: present.has(m), recorded_by: user.id, recorded_at: new Date().toISOString() }));
  if (rows.length) {
    const { error } = await supabaseAdmin().from('attendance').upsert(rows, { onConflict: 'session_id,member_id' });
    if (error) go(`/admin/cohorts?c=${slug}`, 'error', error.message);
  }
  await logAdmin(user.id, 'attendance', sessionId, { present: present.size, total: everyone.length });
  go(`/admin/cohorts?c=${slug}`, 'ok', `Attendance saved (${present.size} of ${everyone.length}).`);
}

export async function saveSupportCall(form: FormData) {
  const { user } = await requireAdmin();
  const cohortId = id(form.get('cohort'));
  const slug = String(form.get('slug') ?? '');
  const starts = new Date(String(form.get('starts_at') ?? ''));
  const minutes = Number(form.get('minutes') || 60);
  const join = String(form.get('join_url') ?? '').trim();
  if (Number.isNaN(starts.getTime()) || !(minutes > 0 && minutes <= 480)) go(`/admin/cohorts?c=${slug}`, 'error', 'Support call needs a start like 2027-02-05T10:00-05:00 and a length in minutes.');
  if (join && !/^https:\/\//.test(join)) go(`/admin/cohorts?c=${slug}`, 'error', 'Join link must start with https://');
  const { error } = await supabaseAdmin().from('support_calls').insert({ cohort_id: cohortId, starts_at: starts.toISOString(), ends_at: new Date(starts.getTime() + minutes * 60_000).toISOString(), join_url: join || null });
  if (error) go(`/admin/cohorts?c=${slug}`, 'error', error.message);
  await logAdmin(user.id, 'add_support_call', cohortId, { starts: starts.toISOString() });
  go(`/admin/cohorts?c=${slug}`, 'ok', 'Support call added. Members get a reminder two days before.');
}

export async function deleteSupportCall(form: FormData) {
  const { user } = await requireAdmin();
  const callId = id(form.get('call'));
  const slug = String(form.get('slug') ?? '');
  await supabaseAdmin().from('support_calls').delete().eq('id', callId);
  await logAdmin(user.id, 'delete_support_call', callId, {});
  go(`/admin/cohorts?c=${slug}`, 'ok', 'Support call removed.');
}

// ---------- scheduled emails ----------
export async function runEmailsNow() {
  const { user } = await requireAdmin();
  const { runSchedule } = await import('@/lib/scheduleRun');
  const r = await runSchedule();
  await logAdmin(user.id, 'run_emails', null, r);
  go('/admin/emails', r.failed ? 'error' : 'ok', `${r.sent} sent${r.failed ? `, ${r.failed} failed (they'll be retried)` : ''}${r.skipped ? `, ${r.skipped} left for the next run` : ''}.`);
}

// ---------- releases ----------
export async function prepareRelease(version: string, notes: string): Promise<{ ok: true; id: string; path: string; token: string } | { ok: false; error: string }> {
  const { user } = await requireAdmin();
  const parsed = releaseSchema.safeParse({ version, notes });
  if (!parsed.success) return { ok: false, error: parsed.error.issues[0].message };
  const sb = supabaseAdmin();
  const path = `releases/${parsed.data.version}/workforce-kit-${parsed.data.version}.zip`;
  const { data: existing } = await sb.from('releases').select('id').eq('version', parsed.data.version).maybeSingle();
  if (existing) return { ok: false, error: `Version ${parsed.data.version} already exists. Use a new version number.` };
  const { data: signed, error } = await sb.storage.from('kit').createSignedUploadUrl(path);
  if (error || !signed) return { ok: false, error: error?.message ?? 'Could not create an upload link.' };
  const { data: row, error: insErr } = await sb.from('releases').insert({ version: parsed.data.version, notes: parsed.data.notes || null, storage_path: path }).select('id').single();
  if (insErr) return { ok: false, error: insErr.message };
  await logAdmin(user.id, 'release_prepared', parsed.data.version, {});
  return { ok: true, id: row.id as string, path, token: signed.token };
}

export async function finishRelease(releaseId: string, size: number, sha256: string, makeLatest: boolean): Promise<{ ok: boolean; error?: string }> {
  const { user } = await requireAdmin();
  if (!/^[0-9a-f-]{36}$/i.test(releaseId) || !/^[0-9a-f]{64}$/.test(sha256)) return { ok: false, error: 'Bad upload details.' };
  const sb = supabaseAdmin();
  await sb.from('releases').update({ size_bytes: size, sha256 }).eq('id', releaseId);
  if (makeLatest) {
    await sb.from('releases').update({ is_latest: false }).eq('is_latest', true);
    await sb.from('releases').update({ is_latest: true }).eq('id', releaseId);
  }
  await logAdmin(user.id, 'release_finished', releaseId, { size, makeLatest });
  revalidatePath('/admin/releases');
  return { ok: true };
}

export async function makeLatest(form: FormData) {
  const { user } = await requireAdmin();
  const releaseId = id(form.get('release'));
  const sb = supabaseAdmin();
  await sb.from('releases').update({ is_latest: false }).eq('is_latest', true);
  await sb.from('releases').update({ is_latest: true }).eq('id', releaseId);
  await logAdmin(user.id, 'release_latest', releaseId, {});
  go('/admin/releases', 'ok', 'Members now download this version.');
}
