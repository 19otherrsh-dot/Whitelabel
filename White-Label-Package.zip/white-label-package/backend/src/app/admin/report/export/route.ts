import { NextResponse, type NextRequest } from 'next/server';
import { supabaseServer } from '@/lib/supabase/server';
import { isAdmin } from '@/lib/auth';
import { buildReport } from '@/lib/reportData';

export const dynamic = 'force-dynamic';

// The quarterly licensee report as a JSON file, for sending to the licensor (Schedule 4).
export async function GET(req: NextRequest) {
  const sb = await supabaseServer();
  const { data } = await sb.auth.getUser();
  if (!data.user || !(await isAdmin(data.user.id))) return new NextResponse('Not found', { status: 404 });
  const q = req.nextUrl.searchParams.get('quarter') || undefined;
  if (q && !/^\d{4}-Q[1-4]$/.test(q)) return new NextResponse('Use quarter=YYYY-Q1..Q4', { status: 400 });
  const r = await buildReport(q);
  return new NextResponse(JSON.stringify(r, null, 2), { headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Disposition': `attachment; filename="licensee-report-${r.period.label}.json"`,
    'Cache-Control': 'private, no-store',
  } });
}
