import type { Metadata } from 'next';
import { Shell, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { buildReport } from '@/lib/reportData';
import { quarter } from '@/lib/report';
import { money } from '@/lib/rules';
import { env } from '@/lib/env';

export const metadata: Metadata = { title: 'Quarterly report' };
export const dynamic = 'force-dynamic';

const day = (iso: string | null) => (iso ? new Date(iso).toLocaleDateString('en-US', { dateStyle: 'medium' }) : '–');

export default async function AdminReport({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const q = sp.quarter && /^\d{4}-Q[1-4]$/.test(sp.quarter) ? sp.quarter : undefined;
  const r = await buildReport(q);
  const cur = quarter();
  const prev = (() => { const [y, n] = r.period.label!.split('-Q').map(Number); return n === 1 ? `${y - 1}-Q4` : `${y}-Q${n - 1}`; })();
  const next = (() => { const [y, n] = r.period.label!.split('-Q').map(Number); return n === 4 ? `${y + 1}-Q1` : `${y}-Q${n + 1}`; })();
  const shared = !!env().LICENSOR_REPORT_TOKEN;

  return (
    <Shell nav={adminNav} current="/admin/report" signedIn>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Quarterly report · {r.period.label}</h1>
        <nav className="row" aria-label="Quarter">
          <a className="btn sm" href={`/admin/report?quarter=${prev}`}>← {prev}</a>
          {r.period.label !== cur.label && <a className="btn sm" href={`/admin/report?quarter=${next}`}>{next} →</a>}
          <a className="btn sm" href={`/admin/report/export?quarter=${r.period.label}`}>Download JSON</a>
        </nav>
      </div>
      <p className="muted small">The figures your licence agreement asks for each quarter (Schedule 4), computed from this site’s records: counts and totals only, no personal data. {shared ? 'Your licensor’s console can read this report automatically (LICENSOR_REPORT_TOKEN is set).' : 'Send the JSON file to your licensor, or set LICENSOR_REPORT_TOKEN to let their console read it.'}</p>

      <div className="grid">
        <div className="card stat"><b>{r.seatsSold.founding + r.seatsSold.vip}</b><span>Seats sold ({r.seatsSold.vip} VIP)</span></div>
        <div className="card stat"><b>{r.seatsRefunded.total}</b><span>Refunded ({r.seatsRefunded.coolingOff} cooling-off, {r.seatsRefunded.guarantee} guarantee, {r.seatsRefunded.other} other)</span></div>
        {Object.entries(r.revenue).map(([c, v]) => <div className="card stat" key={c}><b>{money(v.net, c)}</b><span>Net revenue ({money(v.gross, c)} gross)</span></div>)}
        <div className="card stat"><b>{r.kitVersion ?? '–'}</b><span>Kit version members download</span></div>
      </div>

      <h2>Cohorts</h2>
      <div className="card tablewrap">
        <table>
          <thead><tr><th>Cohort</th><th>Dates</th><th>Seats (VIP)</th><th>Refunded</th><th>Sessions run</th><th>Average attendance</th></tr></thead>
          <tbody>
            {r.cohorts.map((c) => (
              <tr key={c.slug}>
                <td>{c.name}{c.inPeriod ? '' : <span className="muted small"> (no sessions this quarter)</span>}</td>
                <td>{day(c.firstSession)} – {day(c.lastSession)}</td>
                <td>{c.activeSeats.founding + c.activeSeats.vip} / {c.seats} ({c.activeSeats.vip})</td>
                <td>{c.refunded}</td>
                <td>{c.sessionsRun}</td>
                <td>{c.averageAttendance == null ? '–' : `${Math.round(c.averageAttendance * 100)}%`}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2>Demand and support</h2>
      <div className="card tablewrap">
        <table>
          <thead><tr><th>Audits</th><th>Contact</th><th>Waitlist</th><th>Training</th><th>Support opened</th><th>Support open now</th><th>Refund requests open</th><th>Kit downloads</th></tr></thead>
          <tbody><tr><td>{r.leads.audit ?? 0}</td><td>{r.leads.contact ?? 0}</td><td>{r.leads.waitlist ?? 0}</td><td>{r.leads.training ?? 0}</td><td>{r.support.opened}</td><td>{r.support.open}</td><td>{r.refundRequests.open}</td><td>{r.kitDownloads}</td></tr></tbody>
        </table>
      </div>
      <p className="small muted">Not recorded here, so add these to the report yourself: {r.notTrackedHere.join('; ')}.</p>
    </Shell>
  );
}
