import type { Metadata } from 'next';
import { Shell, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';

export const metadata: Metadata = { title: 'Leads' };
export const dynamic = 'force-dynamic';

const KINDS = ['audit', 'contact', 'waitlist', 'training'] as const;

export default async function Leads({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const kind = KINDS.includes(sp.kind as never) ? sp.kind! : '';
  let q = supabaseAdmin().from('leads').select('id, kind, email, name, company, marketing_consent, payload, source_page, created_at').order('created_at', { ascending: false }).limit(300);
  if (kind) q = q.eq('kind', kind);
  const { data } = await q;

  const summary = (k: string, p: Record<string, unknown>) => {
    if (k === 'audit') return [p.businessType, p.teamSize, Array.isArray(p.departments) ? `${p.departments.length} depts` : '', typeof p.estimate === 'number' ? `est. ${Math.round(p.estimate).toLocaleString('en-US')}` : ''].filter(Boolean).join(' · ');
    if (k === 'contact') return `${p.topic ? `${p.topic}: ` : ''}${String(p.message ?? '').slice(0, 140)}`;
    return '';
  };

  return (
    <Shell nav={adminNav} current="/admin/leads" signedIn>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Leads</h1>
        <a className="btn sm" href={`/admin/leads/export${kind ? `?kind=${kind}` : ''}`}>Export CSV</a>
      </div>
      <nav className="row" aria-label="Filter" style={{ marginBottom: 16 }}>
        <a className={`btn sm ${!kind ? 'buy' : ''}`} href="/admin/leads">All</a>
        {KINDS.map((k) => <a key={k} className={`btn sm ${kind === k ? 'buy' : ''}`} href={`/admin/leads?kind=${k}`}>{k}</a>)}
      </nav>
      <div className="card tablewrap">
        <table>
          <thead><tr><th>When</th><th>Type</th><th>Who</th><th>Details</th><th>Marketing</th></tr></thead>
          <tbody>
            {(data ?? []).map((l) => (
              <tr key={l.id}>
                <td className="small">{new Date(l.created_at).toLocaleString('en-US')}</td>
                <td><span className="pill">{l.kind}</span></td>
                <td>{l.name || l.company || '—'}<br /><span className="small">{l.email}</span></td>
                <td className="small">{summary(l.kind, l.payload as Record<string, unknown>)}</td>
                <td>{l.marketing_consent ? <span className="pill ok">Opted in</span> : <span className="muted small">No</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {(data ?? []).length === 0 && <p className="muted">Nothing yet.</p>}
      </div>
      <p className="small muted">Only add people to marketing lists if they opted in. Contact and audit emails without opt-in can be used to reply, not to market.</p>
    </Shell>
  );
}
