import { NextResponse, type NextRequest } from 'next/server';
import { supabaseServer } from '@/lib/supabase/server';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { isAdmin } from '@/lib/auth';
import { logAdmin } from '@/lib/data';
import { toCsv } from '@/lib/rules';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const sb = await supabaseServer();
  const { data } = await sb.auth.getUser();
  if (!data.user || !(await isAdmin(data.user.id))) return new NextResponse('Not found', { status: 404 });
  const kind = req.nextUrl.searchParams.get('kind');
  let q = supabaseAdmin().from('leads').select('created_at, kind, email, name, company, marketing_consent, source_page, payload').order('created_at', { ascending: false }).limit(50_000);
  if (kind && ['audit', 'contact', 'waitlist', 'training'].includes(kind)) q = q.eq('kind', kind);
  const { data: rows } = await q;
  await logAdmin(data.user.id, 'export_leads', kind ?? 'all', { rows: rows?.length ?? 0 });
  const csv = toCsv((rows ?? []) as Record<string, unknown>[], ['created_at', 'kind', 'email', 'name', 'company', 'marketing_consent', 'source_page', 'payload']);
  return new NextResponse('﻿' + csv, { headers: {
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': `attachment; filename="leads-${kind ?? 'all'}-${new Date().toISOString().slice(0, 10)}.csv"`,
    'Cache-Control': 'private, no-store',
  } });
}
