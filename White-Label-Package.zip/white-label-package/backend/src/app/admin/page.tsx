import type { Metadata } from 'next';
import { Shell, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { money, seatsLeftFor, type Seat } from '@/lib/rules';

export const metadata: Metadata = { title: 'Admin' };
export const dynamic = 'force-dynamic';

export default async function Admin() {
  await requireAdmin();
  const sb = supabaseAdmin();
  const since = (d: number) => new Date(Date.now() - d * 86_400_000).toISOString();
  const [{ data: cohorts }, { data: enr }, { data: leads7 }, { data: leads30 }, { count: claims }, { count: support }, { data: log }, { data: failed }] = await Promise.all([
    sb.from('cohorts').select('id, slug, name, seats, vip_seats, currency, is_open, enrollment_closes').order('created_at', { ascending: false }),
    sb.from('enrollments').select('cohort_id, seat, status, amount_paid, currency'),
    sb.from('leads').select('kind').gte('created_at', since(7)),
    sb.from('leads').select('kind, marketing_consent').gte('created_at', since(30)),
    sb.from('guarantee_claims').select('id', { count: 'exact', head: true }).eq('status', 'open'),
    sb.from('support_requests').select('id', { count: 'exact', head: true }).eq('status', 'open'),
    sb.from('admin_log').select('action, target, created_at').in('action', ['duplicate_purchase', 'oversold', 'dispute_opened', 'checkout_missing_data', 'welcome_email_failed', 'partial_refund']).order('created_at', { ascending: false }).limit(10),
    sb.from('stripe_events').select('id, type, error, received_at').not('error', 'is', null).is('processed_at', null).order('received_at', { ascending: false }).limit(10),
  ]);
  const count = (rows: { kind: string }[] | null, k: string) => (rows ?? []).filter((r) => r.kind === k).length;
  const consent30 = (leads30 ?? []).filter((l) => l.marketing_consent).length;

  return (
    <Shell nav={adminNav} current="/admin" signedIn>
      <h1>Dashboard</h1>
      <div className="grid">
        <div className="card stat"><b>{claims ?? 0}</b><span>Refund requests waiting</span></div>
        <div className="card stat"><b>{support ?? 0}</b><span>Support requests waiting</span></div>
        <div className="card stat"><b>{count(leads7, 'audit')}</b><span>Audits in the last 7 days</span></div>
        <div className="card stat"><b>{count(leads7, 'waitlist') + count(leads7, 'training')}</b><span>Waitlist and training sign-ups, 7 days</span></div>
      </div>

      {(cohorts ?? []).map((c) => {
        const rows = (enr ?? []).filter((e) => e.cohort_id === c.id);
        const active = rows.filter((e) => e.status === 'active');
        const taken: Record<Seat, number> = { founding: active.filter((e) => e.seat === 'founding').length, vip: active.filter((e) => e.seat === 'vip').length };
        const revenue = active.reduce((s, e) => s + e.amount_paid, 0);
        const refunded = rows.filter((e) => e.status === 'refunded').length;
        return (
          <div className="card" key={c.id}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <h2 style={{ margin: 0 }}>{c.name}</h2>
              <span className={`pill ${c.is_open ? 'ok' : ''}`}>{c.is_open ? 'Selling' : 'Closed'}</span>
            </div>
            <div className="grid" style={{ marginTop: 14 }}>
              <div className="stat"><b>{taken.founding + taken.vip} / {c.seats}</b><span>Seats sold ({taken.vip} VIP of {c.vip_seats})</span></div>
              <div className="stat"><b>{seatsLeftFor(c, 'founding', taken)}</b><span>Places left ({seatsLeftFor(c, 'vip', taken)} of them can be VIP)</span></div>
              <div className="stat"><b>{money(revenue, c.currency)}</b><span>Collected, net of {refunded} refund{refunded === 1 ? '' : 's'}</span></div>
            </div>
          </div>
        );
      })}

      <h2>Last 30 days</h2>
      <div className="card tablewrap">
        <table><thead><tr><th>Audits</th><th>Contact</th><th>Waitlist</th><th>Training</th><th>Opted in to marketing</th></tr></thead>
          <tbody><tr><td>{count(leads30, 'audit')}</td><td>{count(leads30, 'contact')}</td><td>{count(leads30, 'waitlist')}</td><td>{count(leads30, 'training')}</td><td>{consent30}</td></tr></tbody></table>
      </div>

      {((log ?? []).length > 0 || (failed ?? []).length > 0) && <h2>Needs attention</h2>}
      {(failed ?? []).length > 0 && (
        <div className="card tablewrap"><p className="small muted">Stripe events that failed and are being retried. Persistent failures usually mean a setting is wrong.</p>
          <table><thead><tr><th>Event</th><th>Type</th><th>Error</th></tr></thead><tbody>
            {(failed ?? []).map((f) => <tr key={f.id}><td><code>{f.id}</code></td><td>{f.type}</td><td className="small">{f.error}</td></tr>)}
          </tbody></table></div>
      )}
      {(log ?? []).length > 0 && (
        <div className="card tablewrap"><table><thead><tr><th>When</th><th>What</th><th>Reference</th></tr></thead><tbody>
          {(log ?? []).map((l, i) => <tr key={i}><td>{new Date(l.created_at).toLocaleString('en-US')}</td><td>{l.action.replace(/_/g, ' ')}</td><td><code className="small">{l.target}</code></td></tr>)}
        </tbody></table></div>
      )}
    </Shell>
  );
}
