import type { Metadata } from 'next';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { replySupport } from '../actions';

export const metadata: Metadata = { title: 'Support' };
export const dynamic = 'force-dynamic';

type Req = { id: string; subject: string; body: string; status: string; admin_reply: string | null; created_at: string; members: { email: string; full_name: string | null } | null };

export default async function AdminSupport({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const show = sp.show === 'all' ? 'all' : 'open';
  let q = supabaseAdmin().from('support_requests').select('id, subject, body, status, admin_reply, created_at, members(email, full_name)').order('created_at', { ascending: show === 'open' }).limit(200);
  if (show === 'open') q = q.neq('status', 'closed');
  const { data } = await q;
  const reqs = (data ?? []) as unknown as Req[];

  return (
    <Shell nav={adminNav} current="/admin/support" signedIn>
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h1>Support</h1>
        <a className="btn sm" href={show === 'open' ? '/admin/support?show=all' : '/admin/support'}>{show === 'open' ? 'Show closed too' : 'Open only'}</a>
      </div>
      <Notice ok={sp.ok} error={sp.error} />
      {reqs.length === 0 && <div className="card muted">Nothing waiting.</div>}
      {reqs.map((r) => (
        <div className="card" key={r.id}>
          <div className="row" style={{ justifyContent: 'space-between' }}><b>{r.subject}</b><span className="pill">{r.status}</span></div>
          <p className="small muted">{r.members?.full_name || ''} {r.members?.email} · {new Date(r.created_at).toLocaleString('en-US')}</p>
          <p style={{ whiteSpace: 'pre-wrap' }}>{r.body}</p>
          {r.admin_reply && <div className="notice small" style={{ whiteSpace: 'pre-wrap' }}><b>Last reply</b><br />{r.admin_reply}</div>}
          {r.status !== 'closed' && (
            <form action={replySupport} className="stack">
              <input type="hidden" name="request" value={r.id} />
              <label>Reply <span className="hint">Emailed to the member and shown in their member area.</span><textarea name="reply" style={{ minHeight: 90 }} /></label>
              <label className="check"><input type="checkbox" name="close" /> Close this request</label>
              <button className="btn buy" type="submit">Send</button>
            </form>
          )}
        </div>
      ))}
    </Shell>
  );
}
