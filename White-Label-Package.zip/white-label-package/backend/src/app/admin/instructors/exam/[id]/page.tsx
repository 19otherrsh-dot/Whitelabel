import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { Inline } from '@/components/Inline';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { EXAM, examResult } from '@/lib/exam';
import type { Attempt } from '@/lib/examData';
import { gradeExam } from '../../actions';

export const metadata: Metadata = { title: 'Mark an exam' };
export const dynamic = 'force-dynamic';

export default async function MarkExam({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<Record<string, string | undefined>> }) {
  const [{ id }, sp] = await Promise.all([params, searchParams]);
  await requireAdmin();
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const { data } = await supabaseAdmin().from('exam_attempts').select('*, instructors(name, email)').eq('id', id).maybeSingle();
  if (!data) notFound();
  const a = data as Attempt;
  const answers = a.answers ?? {};
  const marks = a.marks ?? {};
  const r = examResult(answers, marks);
  const minutes = a.started_at && a.submitted_at ? Math.round((Date.parse(a.submitted_at) - Date.parse(a.started_at)) / 60_000) : null;

  return (
    <Shell nav={adminNav} current="/admin/instructors" signedIn>
      <p className="small muted"><a href="/admin/instructors">Instructors</a></p>
      <h1>Written exam · {a.instructors?.name}</h1>
      <Notice ok={sp.ok} error={sp.error} />
      {!a.submitted_at ? <div className="card">Not handed in yet.</div> : (
        <>
          <p className="muted">{a.instructors?.email} · handed in {new Date(a.submitted_at).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })}{minutes != null ? ` after ${minutes} minutes` : ''}{a.kit_version ? ` · kit ${a.kit_version}` : ''}</p>
          <div className="grid">
            <div className="card stat"><b>{r.score} / {r.total}</b><span>Marked correct so far (pass {EXAM.passScore})</span></div>
            <div className="card stat"><b>{r.ungraded.length}</b><span>Short answers to mark</span></div>
            <div className="card stat"><b>{a.result === 'pending' ? 'Pending' : a.result === 'pass' ? 'Passed' : 'Not passed'}</b><span>Result</span></div>
          </div>
          <p className="small">Accept equivalent wording. A blank answer is wrong. ★ safety questions must all be correct to pass, whatever the score.</p>
          <form action={gradeExam} className="stack">
            <input type="hidden" name="attempt" value={a.id} />
            {EXAM.questions.map((q) => {
              const ans = answers[q.n];
              const auto = q.type !== 'short';
              const m = marks[q.n];
              return (
                <fieldset key={q.n} className={`q${m === false ? ' wrong' : ''}`}>
                  <legend>{q.n}. {q.safety ? '★ ' : ''}<Inline text={q.text} /></legend>
                  <p className="small" style={{ margin: '0 0 6px' }}><b>Answer:</b> {ans == null || ans === '' ? <span className="muted">(blank)</span> : auto ? <Inline text={q.options![Number(ans)]} /> : <span style={{ whiteSpace: 'pre-wrap' }}>{ans}</span>}</p>
                  <div className="key"><b>Key:</b> <Inline text={q.key} /></div>
                  {auto || !ans ? (
                    <p className="small" style={{ margin: '8px 0 0' }}>{auto ? 'Marked automatically: ' : ''}{(m ?? false) ? <span className="pill ok">Correct</span> : <span className="pill bad">Wrong</span>}</p>
                  ) : (
                    <div className="row" role="radiogroup" aria-label={`Mark question ${q.n}`} style={{ marginTop: 8 }}>
                      <label><input type="radio" name={`m${q.n}`} value="1" defaultChecked={m === true} required /> Correct</label>
                      <label><input type="radio" name={`m${q.n}`} value="0" defaultChecked={m === false} /> Wrong</label>
                    </div>
                  )}
                </fieldset>
              );
            })}
            <label>Feedback for the candidate (optional) <span className="hint">Sent with the result. If they didn’t pass, say what to review.</span><textarea name="feedback" rows={3} maxLength={4000} /></label>
            <button className="btn buy" type="submit">{a.result === 'pending' ? 'Save marks and send the result' : 'Update marks and resend the result'}</button>
          </form>
        </>
      )}
    </Shell>
  );
}
