'use server';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { logAdmin } from '@/lib/data';
import { sendMail } from '@/lib/email';
import { env } from '@/lib/env';
import { newToken } from '@/lib/examData';
import { EXAM, LINK_DAYS, examResult } from '@/lib/exam';
import { PARTS, LEVEL_LABEL, LEVEL_RANK, levelMet, renewBy, type Level, type Parts } from '@/lib/certification';

const go = (path: string, k: 'ok' | 'error', msg: string): never => redirect(`${path}?${k}=${encodeURIComponent(msg)}`);
const uuid = (v: FormDataEntryValue | null, path = '/admin/instructors') => { const s = String(v ?? ''); if (!/^[0-9a-f-]{36}$/i.test(s)) go(path, 'error', 'Not found.'); return s; };

const personSchema = z.object({ email: z.email('Enter a valid email.').transform((s) => s.toLowerCase()), name: z.string().trim().min(2, 'Enter their name.').max(120) });

export async function addInstructor(form: FormData) {
  const { user } = await requireAdmin();
  const p = personSchema.safeParse({ email: String(form.get('email') ?? '').trim(), name: form.get('name') ?? '' });
  if (!p.success) go('/admin/instructors', 'error', p.error.issues[0].message);
  const { error } = await supabaseAdmin().from('instructors').insert({ email: p.data!.email, name: p.data!.name });
  if (error) go('/admin/instructors', 'error', error.code === '23505' ? 'There’s already a record for that email.' : 'That didn’t save.');
  await logAdmin(user.id, 'add_instructor', p.data!.email);
  revalidatePath('/admin/instructors');
  go('/admin/instructors', 'ok', `${p.data!.name} added. Invite them to the written exam when they’re ready.`);
}

/** Send a private exam link (valid 14 days; the 45-minute clock starts when they press Start). */
export async function inviteToExam(form: FormData) {
  const { user } = await requireAdmin();
  const sb = supabaseAdmin();
  const id = uuid(form.get('instructor'));
  const { data: who } = await sb.from('instructors').select('id, name, email').eq('id', id).maybeSingle();
  if (!who) go('/admin/instructors', 'error', 'Instructor not found.');
  const { data: open } = await sb.from('exam_attempts').select('id').eq('instructor_id', id).is('submitted_at', null).gt('expires_at', new Date().toISOString());
  if ((open ?? []).length) go('/admin/instructors', 'error', 'They already have an unused exam link. Cancel it first to send a new one.');
  const { data: rel } = await sb.from('releases').select('version').eq('is_latest', true).maybeSingle();
  const { token, hash } = newToken();
  const expires = new Date(Date.now() + LINK_DAYS * 86_400_000);
  const { error } = await sb.from('exam_attempts').insert({ instructor_id: id, token_hash: hash, kit_version: rel?.version ?? null, created_by: user.id, expires_at: expires.toISOString() });
  if (error) go('/admin/instructors', 'error', 'That didn’t save.');
  const e = env();
  const link = `${e.APP_URL}/exam/${token}`;
  const r = await sendMail({
    to: who!.email as string,
    subject: `Your instructor certification exam`,
    text: `Hi ${(who!.name as string).split(' ')[0]},\n\nHere's your private link to the written exam (Part 2 of instructor certification):\n\n${link}\n\n${EXAM.questions.length} questions, ${EXAM.minutes} minutes, kit documentation allowed. The clock starts when you press Start, so open it when you have ${EXAM.minutes} quiet minutes. Pass: ${EXAM.passScore} of ${EXAM.questions.length} and every safety question correct.\n\nThe link works until ${expires.toLocaleDateString('en-US', { dateStyle: 'long' })}. Please don't share it.\n\n${e.BRAND_NAME}`,
  });
  await logAdmin(user.id, 'invite_exam', id, { emailed: r.ok });
  revalidatePath('/admin/instructors');
  go('/admin/instructors', r.ok ? 'ok' : 'error', r.ok ? `Exam link sent to ${who!.email}.` : `The link was made but the email failed (${r.error}). Cancel it and try again.`);
}

export async function cancelAttempt(form: FormData) {
  const { user } = await requireAdmin();
  const id = uuid(form.get('attempt'));
  await supabaseAdmin().from('exam_attempts').update({ expires_at: new Date().toISOString() }).eq('id', id).is('started_at', null);
  await logAdmin(user.id, 'cancel_exam', id);
  revalidatePath('/admin/instructors');
  go('/admin/instructors', 'ok', 'Unused link cancelled.');
}

/** Mark the short answers, work out the result, record Part 2 and email the candidate. */
export async function gradeExam(form: FormData) {
  const { user } = await requireAdmin();
  const sb = supabaseAdmin();
  const id = uuid(form.get('attempt'));
  const path = `/admin/instructors/exam/${id}`;
  const { data: a } = await sb.from('exam_attempts').select('*, instructors(id, name, email, parts)').eq('id', id).maybeSingle();
  if (!a || !a.submitted_at) go(path, 'error', 'This exam hasn’t been handed in yet.');
  const answers = (a!.answers ?? {}) as Record<string, string>;
  const marks: Record<string, boolean> = { ...((a!.marks ?? {}) as Record<string, boolean>) };
  for (const q of EXAM.questions) {
    if (q.type !== 'short' || !answers[q.n]) continue;
    const v = form.get(`m${q.n}`);
    if (v === '1') marks[q.n] = true; else if (v === '0') marks[q.n] = false;
  }
  const r = examResult(answers, marks);
  if (r.result === 'pending') go(path, 'error', `Mark every answered question first (still to mark: ${r.ungraded.join(', ')}).`);
  const now = new Date().toISOString();
  await sb.from('exam_attempts').update({ marks, score: r.score, safety_ok: r.safetyOk, result: r.result, graded_by: user.id, graded_at: now }).eq('id', id);
  const who = a!.instructors as unknown as { id: string; name: string; email: string; parts: Parts };
  const feedback = String(form.get('feedback') ?? '').trim().slice(0, 4000);
  if (r.result === 'pass') {
    const { data: admin } = await sb.from('members').select('email').eq('id', user.id).maybeSingle();
    const parts: Parts = { ...(who.parts ?? {}), part2: { passed_on: now.slice(0, 10), assessor: (admin?.email as string) ?? 'admin', score: `${r.score}/${r.total}`, notes: 'Marked online' } };
    await sb.from('instructors').update({ parts }).eq('id', who.id);
  }
  const e = env();
  await sendMail({
    to: who.email,
    subject: r.result === 'pass' ? 'You passed the certification exam' : 'Your certification exam result',
    text: r.result === 'pass'
      ? `Hi ${who.name.split(' ')[0]},\n\nYou passed the written exam: ${r.score} of ${r.total}, with every safety question correct.${feedback ? `\n\nFrom your assessor:\n${feedback}` : ''}\n\n${e.BRAND_NAME}`
      : `Hi ${who.name.split(' ')[0]},\n\nThanks for taking the written exam. You scored ${r.score} of ${r.total}${r.safetyOk ? '' : ', and at least one safety question needs another look'}. The pass is ${EXAM.passScore} of ${r.total} with every safety question correct.${feedback ? `\n\nWhat to review:\n${feedback}` : ''}\n\nWe'll send a new link when you're ready to retake it.\n\n${e.BRAND_NAME}`,
  });
  await logAdmin(user.id, 'grade_exam', id, { result: r.result, score: r.score });
  revalidatePath('/admin/instructors');
  go('/admin/instructors', 'ok', `${who.name}: ${r.result === 'pass' ? 'passed' : 'not passed'} (${r.score}/${r.total}${r.safetyOk ? '' : ', a safety question missed'}). Result emailed.`);
}

const dateOrEmpty = z.union([z.literal(''), z.iso.date()]);

/** Update one instructor's record: parts passed, level, status. */
export async function saveInstructor(form: FormData) {
  const { user } = await requireAdmin();
  const sb = supabaseAdmin();
  const id = uuid(form.get('instructor'));
  const { data: cur } = await sb.from('instructors').select('*').eq('id', id).maybeSingle();
  if (!cur) go('/admin/instructors', 'error', 'Instructor not found.');
  const parts: Parts = {};
  for (const p of PARTS) {
    const passed = String(form.get(`${p.key}-date`) ?? '').trim();
    if (!dateOrEmpty.safeParse(passed).success) go('/admin/instructors', 'error', `${p.label}: use a date like 2027-02-01.`);
    const rec = { passed_on: passed || null, assessor: String(form.get(`${p.key}-assessor`) ?? '').trim().slice(0, 120) || null, score: String(form.get(`${p.key}-score`) ?? '').trim().slice(0, 60) || null, notes: String(form.get(`${p.key}-notes`) ?? '').trim().slice(0, 1000) || null };
    if (rec.passed_on && !rec.assessor) go('/admin/instructors', 'error', `${p.label}: record who assessed it.`);
    if (rec.passed_on || rec.assessor || rec.score || rec.notes) parts[p.key] = rec;
  }
  const level = String(form.get('level')) as Level;
  if (!(level in LEVEL_RANK)) go('/admin/instructors', 'error', 'Unknown level.');
  const met = levelMet(parts);
  if (LEVEL_RANK[level] > LEVEL_RANK[met]) go('/admin/instructors', 'error', `The record shows the requirements for ${LEVEL_LABEL[met]}, not ${LEVEL_LABEL[level]}. Record the parts passed first.`);
  const status = String(form.get('status'));
  if (!['in_progress', 'certified', 'suspended', 'lapsed'].includes(status)) go('/admin/instructors', 'error', 'Unknown status.');
  if (status === 'certified' && level === 'candidate') go('/admin/instructors', 'error', 'A candidate can’t be marked certified. Set the level first.');
  const major = String(form.get('kit_major') ?? '').trim();
  const promoted = status === 'certified' && (cur!.status !== 'certified' || cur!.level !== level);
  const certifiedAt = promoted ? new Date().toISOString() : (cur!.certified_at as string | null);
  const { error } = await sb.from('instructors').update({
    parts, level, status, kit_major: /^\d+$/.test(major) ? Number(major) : null,
    certified_at: certifiedAt, renew_by: certifiedAt ? (promoted ? renewBy(certifiedAt) : cur!.renew_by) : null,
    notes: String(form.get('notes') ?? '').trim().slice(0, 4000) || null,
  }).eq('id', id);
  if (error) go('/admin/instructors', 'error', 'That didn’t save.');
  await logAdmin(user.id, 'save_instructor', id, { level, status });
  revalidatePath('/admin/instructors');
  go('/admin/instructors', 'ok', `${cur!.name} saved${promoted ? `: certified ${LEVEL_LABEL[level]}, renew by ${new Date(renewBy(certifiedAt!)).toLocaleDateString('en-US', { dateStyle: 'medium' })}` : ''}.`);
}

/** Record that a certified instructor taught or assisted a cohort this year: renews for 12 months. */
export async function renewInstructor(form: FormData) {
  const { user } = await requireAdmin();
  const id = uuid(form.get('instructor'));
  const now = new Date().toISOString();
  await supabaseAdmin().from('instructors').update({ renew_by: renewBy(now), status: 'certified' }).eq('id', id).neq('level', 'candidate');
  await logAdmin(user.id, 'renew_instructor', id);
  revalidatePath('/admin/instructors');
  go('/admin/instructors', 'ok', 'Renewed for 12 months.');
}
