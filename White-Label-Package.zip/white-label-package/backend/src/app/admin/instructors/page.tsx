import type { Metadata } from 'next';
import { Shell, Notice, adminNav } from '@/components/Shell';
import { requireAdmin } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { PARTS, LEVEL_LABEL, levelMet, standing, type Level, type Parts, type Standing } from '@/lib/certification';
import { examState } from '@/lib/exam';
import { addInstructor, inviteToExam, cancelAttempt, saveInstructor, renewInstructor } from './actions';

export const metadata: Metadata = { title: 'Instructors' };
export const dynamic = 'force-dynamic';

type Rec = { id: string; email: string; name: string; level: Level; status: string; kit_major: number | null; parts: Parts; certified_at: string | null; renew_by: string | null; notes: string | null };
type Att = { id: string; instructor_id: string; created_at: string; expires_at: string; started_at: string | null; deadline: string | null; submitted_at: string | null; score: number | null; result: string; kit_version: string | null };
const day = (iso: string | null) => (iso ? new Date(iso).toLocaleDateString('en-US', { dateStyle: 'medium' }) : '');
const standingPill: Record<Standing, [string, string]> = {
  in_progress: ['', 'In progress'], certified: ['ok', 'Certified'], due: ['warn', 'Renewal due'], lapsed: ['bad', 'Lapsed'], suspended: ['bad', 'Suspended'], update_needed: ['warn', 'Update module needed'],
};

export default async function Instructors({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  await requireAdmin();
  const sb = supabaseAdmin();
  const [{ data: people }, { data: attempts }, { data: rel }] = await Promise.all([
    sb.from('instructors').select('*').order('created_at', { ascending: false }),
    sb.from('exam_attempts').select('id, instructor_id, created_at, expires_at, started_at, deadline, submitted_at, score, result, kit_version').order('created_at', { ascending: false }),
    sb.from('releases').select('version').eq('is_latest', true).maybeSingle(),
  ]);
  const recs = (people ?? []) as Rec[];
  const atts = (attempts ?? []) as Att[];
  const major = rel?.version ? Number(String(rel.version).split('.')[0]) : null;
  const toMark = atts.filter((a) => a.submitted_at && a.result === 'pending');

  return (
    <Shell nav={adminNav} current="/admin/instructors" signedIn>
      <h1>Instructors</h1>
      <Notice ok={sp.ok} error={sp.error} />
      <p className="muted">Certification follows <code>delivery/instructor/certification.md</code>. Part 2 (the written exam) runs online here; record the other parts as the assessor signs them off. These records are what the licensee report lists.</p>

      {toMark.length > 0 && (
        <div className="notice" role="status">{toMark.length} exam{toMark.length > 1 ? 's' : ''} handed in and waiting to be marked: {toMark.map((a, i) => <span key={a.id}>{i ? ', ' : ''}<a href={`/admin/instructors/exam/${a.id}`}>{recs.find((r) => r.id === a.instructor_id)?.name ?? 'candidate'}</a></span>)}</div>
      )}

      <div className="card tablewrap">
        {recs.length === 0 ? <p className="muted" style={{ margin: 0 }}>No instructors yet. Add your first below.</p> : (
          <table>
            <thead><tr><th>Name</th><th>Level</th><th>Standing</th><th>Parts passed</th><th>Written exam</th><th>Renew by</th></tr></thead>
            <tbody>{recs.map((r) => {
              const st = standing(r, major);
              const last = atts.find((a) => a.instructor_id === r.id);
              const lastState = last ? examState(last) : null;
              return (
                <tr key={r.id}>
                  <td><b>{r.name}</b><div className="small muted">{r.email}</div></td>
                  <td>{LEVEL_LABEL[r.level]}</td>
                  <td><span className={`pill ${standingPill[st][0]}`}>{standingPill[st][1]}</span></td>
                  <td className="small">{PARTS.filter((p) => r.parts?.[p.key]?.passed_on).map((p) => p.label.split(' · ')[0]).join(', ') || <span className="muted">None yet</span>}</td>
                  <td className="small">{!last ? <span className="muted">Not invited</span>
                    : last.submitted_at ? (last.result === 'pending' ? <a href={`/admin/instructors/exam/${last.id}`}>Mark it</a> : <a href={`/admin/instructors/exam/${last.id}`}>{last.result === 'pass' ? 'Passed' : 'Not passed'} {last.score}/30</a>)
                    : lastState === 'in_progress' ? 'In progress' : lastState === 'expired' ? 'Link expired' : `Invited ${day(last.created_at)}`}</td>
                  <td className="small">{day(r.renew_by)}</td>
                </tr>
              );
            })}</tbody>
          </table>
        )}
      </div>

      <h2>Add an instructor or TA</h2>
      <form action={addInstructor} className="card row" style={{ alignItems: 'flex-end' }}>
        <label style={{ flex: 1, minWidth: 180 }}>Name<input name="name" required maxLength={120} autoComplete="off" /></label>
        <label style={{ flex: 1, minWidth: 220 }}>Email<input name="email" type="email" required autoComplete="off" /></label>
        <button className="btn" type="submit">Add</button>
      </form>

      {recs.map((r) => {
        const met = levelMet(r.parts ?? {});
        const mine = atts.filter((a) => a.instructor_id === r.id);
        const open = mine.find((a) => !a.started_at && !a.submitted_at && Date.parse(a.expires_at) > Date.now());
        return (
          <details className="card" key={r.id} id={`i-${r.id}`}>
            <summary><b>{r.name}</b> <span className="small muted">· {LEVEL_LABEL[r.level]} · record shows the requirements for {LEVEL_LABEL[met]}</span></summary>
            <div className="row" style={{ margin: '12px 0' }}>
              {open
                ? <form action={cancelAttempt}><input type="hidden" name="attempt" value={open.id} /><span className="small">Exam link sent {day(open.created_at)}, unused. </span><button className="linkbtn small" type="submit">Cancel the link</button></form>
                : <form action={inviteToExam}><input type="hidden" name="instructor" value={r.id} /><button className="btn sm" type="submit">{mine.length ? 'Send a new exam link (retake)' : 'Invite to the written exam'}</button></form>}
              {r.level !== 'candidate' && <form action={renewInstructor}><input type="hidden" name="instructor" value={r.id} /><button className="btn sm" type="submit">Taught or assisted a cohort: renew 12 months</button></form>}
            </div>
            {mine.length > 0 && (
              <p className="small">Exam attempts: {mine.map((a, i) => <span key={a.id}>{i ? ' · ' : ''}{day(a.created_at)} {a.submitted_at ? <a href={`/admin/instructors/exam/${a.id}`}>{a.result === 'pending' ? 'to mark' : `${a.result} ${a.score}/30`}</a> : examState(a)}{a.kit_version ? ` (kit ${a.kit_version})` : ''}</span>)}</p>
            )}
            <form action={saveInstructor} className="stack">
              <input type="hidden" name="instructor" value={r.id} />
              <div className="tablewrap">
                <table>
                  <thead><tr><th>Part</th><th>Passed on</th><th>Assessor</th><th>Score</th><th>Evidence / notes</th></tr></thead>
                  <tbody>{PARTS.map((p) => {
                    const v = r.parts?.[p.key] ?? {};
                    return (
                      <tr key={p.key}>
                        <td className="small"><b>{p.label}</b><div className="muted">{p.pass}</div></td>
                        <td><label className="sr" htmlFor={`${r.id}-${p.key}-date`}>{p.label} passed on</label><input id={`${r.id}-${p.key}-date`} type="date" name={`${p.key}-date`} defaultValue={v.passed_on ?? ''} /></td>
                        <td><label className="sr" htmlFor={`${r.id}-${p.key}-assessor`}>{p.label} assessor</label><input id={`${r.id}-${p.key}-assessor`} name={`${p.key}-assessor`} defaultValue={v.assessor ?? ''} maxLength={120} /></td>
                        <td><label className="sr" htmlFor={`${r.id}-${p.key}-score`}>{p.label} score</label><input id={`${r.id}-${p.key}-score`} name={`${p.key}-score`} defaultValue={v.score ?? ''} maxLength={60} style={{ width: 90 }} /></td>
                        <td><label className="sr" htmlFor={`${r.id}-${p.key}-notes`}>{p.label} notes</label><input id={`${r.id}-${p.key}-notes`} name={`${p.key}-notes`} defaultValue={v.notes ?? ''} maxLength={1000} /></td>
                      </tr>
                    );
                  })}</tbody>
                </table>
              </div>
              <div className="row">
                <label>Level<select name="level" defaultValue={r.level}>{(['candidate', 'associate', 'lead', 'trainer'] as Level[]).map((l) => <option key={l} value={l}>{LEVEL_LABEL[l]}</option>)}</select></label>
                <label>Status<select name="status" defaultValue={r.status}><option value="in_progress">In progress</option><option value="certified">Certified</option><option value="suspended">Suspended</option><option value="lapsed">Lapsed</option></select></label>
                <label>Kit major version<input name="kit_major" inputMode="numeric" pattern="[0-9]*" defaultValue={r.kit_major ?? (major ?? '')} style={{ width: 90 }} /></label>
              </div>
              <label>Notes<textarea name="notes" rows={2} maxLength={4000} defaultValue={r.notes ?? ''} /></label>
              <button className="btn sm" type="submit">Save record</button>
              {r.certified_at && <p className="small muted" style={{ margin: 0 }}>Certified {day(r.certified_at)} · renew by {day(r.renew_by)}</p>}
            </form>
          </details>
        );
      })}
    </Shell>
  );
}
