import Link from 'next/link';

const brand = process.env.BRAND_NAME || 'Your Brand';
const site = process.env.SITE_URL || '/';

type Item = { href: string; label: string };

export function Shell({ nav = [], current, signedIn = false, narrow = false, children }: {
  nav?: Item[]; current?: string; signedIn?: boolean; narrow?: boolean; children: React.ReactNode;
}) {
  return (
    <>
      <header className="top">
        <a className="brand" href={site}><span className="mark" aria-hidden="true" />{brand}</a>
        <nav aria-label="Main">
          {nav.map((n) => (
            <Link key={n.href} href={n.href} aria-current={current === n.href ? 'page' : undefined}>{n.label}</Link>
          ))}
          {signedIn && (
            <form action="/logout" method="post"><button className="linkbtn" type="submit">Sign out</button></form>
          )}
        </nav>
      </header>
      <main id="main" className={narrow ? 'narrow' : undefined}>{children}</main>
      <footer className="foot">© {new Date().getFullYear()} {brand}</footer>
    </>
  );
}

export function Notice({ ok, error }: { ok?: string | string[]; error?: string | string[] }) {
  const o = Array.isArray(ok) ? ok[0] : ok;
  const e = Array.isArray(error) ? error[0] : error;
  if (e) return <div className="notice err" role="alert">{e}</div>;
  if (o) return <div className="notice ok" role="status">{o}</div>;
  return null;
}

export const memberNav: Item[] = [
  { href: '/member', label: 'Overview' },
  { href: '/member/course', label: 'Course' },
  { href: '/member/support', label: 'Support' },
  { href: '/member/guarantee', label: 'Refunds' },
];

export const adminNav: Item[] = [
  { href: '/admin', label: 'Dashboard' },
  { href: '/admin/members', label: 'Members' },
  { href: '/admin/leads', label: 'Leads' },
  { href: '/admin/claims', label: 'Refunds' },
  { href: '/admin/support', label: 'Support' },
  { href: '/admin/emails', label: 'Emails' },
  { href: '/admin/cohorts', label: 'Cohorts' },
  { href: '/admin/course', label: 'Course' },
  { href: '/admin/instructors', label: 'Instructors' },
  { href: '/admin/releases', label: 'Releases' },
  { href: '/admin/usage', label: 'Usage' },
  { href: '/admin/report', label: 'Report' },
  { href: '/admin/privacy', label: 'Privacy' },
];
