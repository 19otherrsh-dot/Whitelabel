'use client';
import { useEffect, useState } from 'react';

/** The hand-in time in the candidate's own time zone, with the minutes left. Server render shows UTC. */
export function Deadline({ iso }: { iso: string }) {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => { setNow(Date.now()); const t = setInterval(() => setNow(Date.now()), 15_000); return () => clearInterval(t); }, []);
  const at = new Date(iso);
  if (now === null) return <b>{at.toISOString().slice(11, 16)} UTC</b>;
  const left = Math.max(0, Math.ceil((at.getTime() - now) / 60_000));
  return <><b>{at.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}</b> ({left} minute{left === 1 ? '' : 's'} left)</>;
}
