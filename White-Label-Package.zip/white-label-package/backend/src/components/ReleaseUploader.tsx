'use client';
import { useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase/browser';
import { finishRelease, prepareRelease } from '@/app/admin/actions';

// Uploads the kit zip straight from the browser to private storage using a
// one-time signed upload URL, so large files never pass through the app server.
export function ReleaseUploader() {
  const [status, setStatus] = useState<{ kind: 'ok' | 'err' | 'busy'; text: string } | null>(null);

  async function onSubmit(ev: React.FormEvent<HTMLFormElement>) {
    ev.preventDefault();
    const f = new FormData(ev.currentTarget);
    const file = f.get('file');
    if (!(file instanceof File) || !file.size) return setStatus({ kind: 'err', text: 'Choose the kit zip first.' });
    if (!/\.zip$/i.test(file.name)) return setStatus({ kind: 'err', text: 'The kit must be a .zip file (product/dist/workforce-kit-<version>.zip).' });
    setStatus({ kind: 'busy', text: 'Checking the file…' });
    const digest = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());
    const sha = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');

    const prep = await prepareRelease(String(f.get('version') ?? ''), String(f.get('notes') ?? ''));
    if (!prep.ok) return setStatus({ kind: 'err', text: prep.error });
    setStatus({ kind: 'busy', text: `Uploading ${(file.size / 1e6).toFixed(1)} MB…` });
    const { error } = await supabaseBrowser().storage.from('kit').uploadToSignedUrl(prep.path, prep.token, file, { contentType: 'application/zip' });
    if (error) return setStatus({ kind: 'err', text: `Upload failed: ${error.message}. The release row was created; upload again with a new version number.` });
    const done = await finishRelease(prep.id, file.size, sha, f.get('latest') === 'on');
    if (!done.ok) return setStatus({ kind: 'err', text: done.error ?? 'Could not finish the release.' });
    setStatus({ kind: 'ok', text: 'Release uploaded. Reload to see it in the list.' });
    (ev.target as HTMLFormElement).reset();
  }

  return (
    <form onSubmit={onSubmit} className="card stack">
      <h2 style={{ marginTop: 0 }}>Upload a new kit release</h2>
      <div className="grid">
        <label>Version <span className="hint">Matches the zip, e.g. 1.0.1</span><input type="text" name="version" required pattern="[0-9]+\.[0-9]+\.[0-9]+([\-.][0-9A-Za-z.]+)?" /></label>
        <label>Kit zip<input type="file" name="file" accept=".zip,application/zip" required /></label>
      </div>
      <label>What changed <span className="hint">Shown to members above the download button.</span><textarea name="notes" style={{ minHeight: 80 }} /></label>
      <label className="check"><input type="checkbox" name="latest" defaultChecked /> Make this the version members download</label>
      <button className="btn buy" type="submit" disabled={status?.kind === 'busy'}>Upload release</button>
      {status && <div className={`notice ${status.kind === 'ok' ? 'ok' : status.kind === 'err' ? 'err' : ''}`} role="status" style={{ margin: 0 }}>{status.text}</div>}
    </form>
  );
}
