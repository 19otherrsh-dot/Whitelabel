'use client';
/** Opens the browser's print dialog (save as PDF from there). */
export function PrintButton({ label = 'Print or save as PDF' }: { label?: string }) {
  return <button className="btn" type="button" onClick={() => window.print()}>{label}</button>;
}
