import { inlineParts } from '@/lib/inline';

/** A line from the course or exam Markdown, with `code`, **bold** and *italic* kept. */
export function Inline({ text }: { text: string | null | undefined }) {
  if (!text) return null;
  return (
    <>
      {inlineParts(text).map((p, i) => (p.t === 'code' ? <code key={i}>{p.v}</code> : p.t === 'b' ? <b key={i}>{p.v}</b> : p.t === 'i' ? <i key={i}>{p.v}</i> : <span key={i}>{p.v}</span>))}
    </>
  );
}
