import 'server-only';
import { supabaseAdmin } from './supabase/admin';
import { env } from './env';
import { licenseeReport, quarter, type ReportInput } from './report';

/** Load what the report needs (only the columns it counts) and build it for a quarter. */
export async function buildReport(q?: string) {
  const sb = supabaseAdmin();
  const [cohorts, sessions, enrollments, claims, attendance, support, leads, downloads, release, usage] = await Promise.all([
    sb.from('cohorts').select('id, slug, name, seats, vip_seats, currency, is_open'),
    sb.from('cohort_sessions').select('id, cohort_id, starts_at'),
    sb.from('enrollments').select('cohort_id, seat, status, amount_paid, currency, created_at, updated_at'),
    sb.from('guarantee_claims').select('kind, status, created_at, decided_at'),
    sb.from('attendance').select('session_id, attended'),
    sb.from('support_requests').select('status, created_at'),
    sb.from('leads').select('kind, created_at'),
    sb.from('downloads').select('created_at'),
    sb.from('releases').select('version').eq('is_latest', true).maybeSingle(),
    sb.from('usage_reports').select('received_at'),
  ]);
  const failed = [cohorts, sessions, enrollments, claims, attendance, support, leads, downloads, usage].find((r) => r.error);
  if (failed?.error) throw new Error(failed.error.message);
  const input: ReportInput = {
    cohorts: cohorts.data ?? [], sessions: sessions.data ?? [], enrollments: (enrollments.data ?? []) as ReportInput['enrollments'],
    claims: (claims.data ?? []) as ReportInput['claims'], attendance: attendance.data ?? [], support: support.data ?? [],
    leads: leads.data ?? [], downloads: downloads.data ?? [], release: release.data ?? null, usageReports: usage.data ?? [],
  };
  return licenseeReport(input, quarter(q), { brand: env().BRAND_NAME });
}
