import 'server-only';
import { env } from './env';
import { escapeHtml } from './html';

// Transactional email through Resend's HTTP API (no SDK needed).
// With no RESEND_API_KEY set, emails are written to the server log instead,
// which is what you want in development.

export interface Mail {
  to: string;
  subject: string;
  text: string;
  html?: string;
  replyTo?: string;
}

export async function sendMail(m: Mail): Promise<{ ok: boolean; id?: string; error?: string }> {
  const e = env();
  if (!e.RESEND_API_KEY) {
    console.info(`[email:dev] to=${m.to} subject="${m.subject}"\n${m.text}`);
    return { ok: true, id: 'dev' };
  }
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${e.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: e.EMAIL_FROM,
        to: [m.to],
        subject: m.subject,
        text: m.text,
        html: m.html ?? layout(m.subject, m.text),
        reply_to: m.replyTo ?? e.SUPPORT_EMAIL,
      }),
    });
    const body = (await r.json().catch(() => ({}))) as { id?: string; message?: string };
    if (!r.ok) return { ok: false, error: body.message ?? `HTTP ${r.status}` };
    return { ok: true, id: body.id };
  } catch (err) {
    return { ok: false, error: (err as Error).message };
  }
}

/** Minimal, accessible HTML wrapper: the plain text, with links made clickable. */
export function layout(title: string, text: string): string {
  const brand = escapeHtml(env().BRAND_NAME);
  const body = escapeHtml(text)
    .replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" style="color:#087A45">$1</a>')
    .split(/\n{2,}/).map((p) => `<p style="margin:0 0 16px">${p.replace(/\n/g, '<br>')}</p>`).join('');
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(title)}</title></head>
<body style="margin:0;background:#F4F4F5;font:16px/1.6 -apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;color:#161618">
<div style="max-width:560px;margin:0 auto;padding:32px 20px"><div style="font-weight:700;margin-bottom:24px">${brand}</div>
<div style="background:#fff;border:1px solid rgba(20,20,24,.1);border-radius:14px;padding:28px">${body}</div>
<p style="font-size:13px;color:#6E6E76;margin-top:20px">${brand} · Sent because of an action on your account.</p></div></body></html>`;
}

export function welcomeEmail(opts: { name?: string | null; cohort: string; seat: string; loginUrl: string }) {
  const e = env();
  const hi = opts.name ? `Hi ${opts.name.split(' ')[0]},` : 'Hi,';
  return {
    subject: `You're in: ${opts.cohort}`,
    text: `${hi}

Your ${opts.seat === 'vip' ? 'VIP' : 'Founding'} seat in ${opts.cohort} is confirmed. Thank you.

Sign in to your member area to see the session dates and join links, download the workspace kit, and start the setup checklist before Session 1:
${opts.loginUrl}

That link signs you in once and expires after an hour. You can always request a new one at ${e.APP_URL}/login using this email address.

Questions? Reply to this email or write to ${e.SUPPORT_EMAIL}.

${e.BRAND_NAME}`,
  };
}

export function refundEmail(opts: { cohort: string; amount: string }) {
  const e = env();
  return {
    subject: `Your refund for ${opts.cohort}`,
    text: `Hi,

We've refunded ${opts.amount} to your original payment method. Depending on your bank it can take 5 to 10 working days to appear.

Your access to sessions, recordings, the community and library updates has ended. Anything you created about your own business is yours to keep.

If you have any questions, write to ${e.SUPPORT_EMAIL}.

${e.BRAND_NAME}`,
  };
}

/** The free audit's result, sent when the visitor asked for it by adding their email. */
export function auditResultEmail(a: { company?: string; businessType?: string; teamSize?: string; departments?: string[]; tools?: string[]; estimate?: number; jobs?: number; runToday?: number; start?: string[] }) {
  const e = env();
  const site = e.SITE_URL.replace(/\/$/, '');
  const share = `${site}/audit.html#r=${encodeURIComponent([a.businessType ?? '', a.teamSize ?? '', (a.departments ?? []).join('+'), (a.tools ?? []).join('+'), (a.company ?? '').slice(0, 60)].join(','))}`;
  const money = (n: number) => `$${Math.round(n).toLocaleString('en-US')}`;
  const lines = [
    'Hi,',
    `Here is your AI workforce audit${a.company ? ` for ${a.company}` : ''}, as you asked.`,
    a.estimate != null
      ? `Estimate: about ${money(a.estimate)} a year of work${a.jobs ? ` across ${a.jobs} jobs` : ''}${a.runToday ? `, ${a.runToday} of which could run with the tools you already have` : ''}. This is an estimate from your answers and our published method (${site}/methodology.html), not a promise. Your result depends on your business and how you use it.`
      : '',
    a.start?.length ? `Where we'd start:\n${a.start.slice(0, 5).map((s) => `- ${s}`).join('\n')}` : '',
    `See your full result and map again (it keeps your answers, never your email):\n${share}`,
    e.BOOKING_URL ? `Want to talk it through? Book a call: ${e.BOOKING_URL}` : `Questions? Just reply to this email.`,
    `${e.BRAND_NAME}`,
    `You're getting this because you asked for your result on ${site}. We won't send marketing unless you ticked the box.`,
  ].filter(Boolean);
  return { subject: 'Your AI workforce audit result', text: lines.join('\n\n') };
}
