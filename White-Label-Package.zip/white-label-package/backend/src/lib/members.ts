import 'server-only';
import { env } from './env';
import { supabaseAdmin } from './supabase/admin';
import { likeExact } from './rules';

/** Find the auth user for an email, creating it (already confirmed) if needed. */
export async function ensureUser(email: string, fullName?: string | null): Promise<string> {
  const sb = supabaseAdmin();
  const lower = email.trim().toLowerCase();
  const { data: m } = await sb.from('members').select('id').ilike('email', likeExact(lower)).maybeSingle();
  if (m?.id) return m.id as string;

  const created = await sb.auth.admin.createUser({ email: lower, email_confirm: true, user_metadata: fullName ? { full_name: fullName } : {} });
  let id = created.data.user?.id;
  if (!id) {
    // Already registered (e.g. a previous attempt created the user but not the member row). Look it up.
    for (let page = 1; page <= 50 && !id; page++) {
      const { data, error } = await sb.auth.admin.listUsers({ page, perPage: 1000 });
      if (error) throw new Error(`listUsers: ${error.message}`);
      id = data.users.find((u) => u.email?.toLowerCase() === lower)?.id;
      if (data.users.length < 1000) break;
    }
  }
  if (!id) throw new Error(`could not create or find user for ${lower}: ${created.error?.message ?? 'unknown'}`);
  const { error } = await sb.from('members').upsert({ id, email: lower, full_name: fullName ?? null }, { onConflict: 'id' });
  if (error) throw new Error(`member upsert: ${error.message}`);
  return id;
}

/**
 * A one-time sign-in link that lands on /auth/confirm (server-side token check,
 * works on any device, no PKCE cookie needed).
 */
export async function signInLink(email: string, next = '/member'): Promise<string> {
  const e = env();
  const { data, error } = await supabaseAdmin().auth.admin.generateLink({ type: 'magiclink', email });
  if (error || !data.properties?.hashed_token) throw new Error(`generateLink: ${error?.message ?? 'no token'}`);
  const q = new URLSearchParams({ token_hash: data.properties.hashed_token, type: 'magiclink', next });
  return `${e.APP_URL}/auth/confirm?${q}`;
}
