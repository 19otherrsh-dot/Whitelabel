import 'server-only';
import type { SupabaseClient } from '@supabase/supabase-js';
import { randomBytes } from 'node:crypto';
import { supabaseAdmin } from './supabase/admin';
import { certificateCode, courseStatus } from './course';

export interface Submission { id: string; module: number; body: string; link: string | null; status: 'submitted' | 'complete' | 'not_yet'; reviewer_note: string | null; created_at: string; reviewed_at: string | null }
export interface Attempt { id: string; module: number; score: number; total: number; passed: boolean; answers: Record<string, number>; created_at: string }
export interface Media { lesson_id: string; video_url: string | null; transcript_url: string | null }
export interface Certificate { id: string; name: string; code: string; issued_at: string; revoked_at: string | null }

/** One member's course progress, read with their own client so row-level security applies. */
export async function loadCourse(sb: SupabaseClient, memberId: string) {
  const [progress, attempts, submissions, media, cert] = await Promise.all([
    sb.from('course_progress').select('lesson_id, done_at').eq('member_id', memberId),
    sb.from('quiz_attempts').select('id, module, score, total, passed, answers, created_at').eq('member_id', memberId).order('created_at', { ascending: false }),
    sb.from('course_submissions').select('id, module, body, link, status, reviewer_note, created_at, reviewed_at').eq('member_id', memberId).order('created_at', { ascending: false }),
    sb.from('course_media').select('lesson_id, video_url, transcript_url'),
    sb.from('course_certificates').select('id, name, code, issued_at, revoked_at').eq('member_id', memberId).maybeSingle(),
  ]);
  const state: { done: Set<string>; attempts: Attempt[]; submissions: Submission[] } = {
    done: new Set((progress.data ?? []).map((r) => r.lesson_id as string)),
    attempts: (attempts.data ?? []) as Attempt[],
    submissions: (submissions.data ?? []) as Submission[],
  };
  const mediaBy = new Map(((media.data ?? []) as Media[]).map((m) => [m.lesson_id, m]));
  return { state, status: courseStatus(state), media: mediaBy, certificate: (cert.data as Certificate | null) ?? null };
}

/** Issue the certificate once the course is complete (idempotent: one per member). */
export async function issueCertificate(memberId: string, name: string): Promise<Certificate | null> {
  const sb = supabaseAdmin();
  const { data: have } = await sb.from('course_certificates').select('id, name, code, issued_at, revoked_at').eq('member_id', memberId).maybeSingle();
  if (have) return have as Certificate;
  for (let i = 0; i < 3; i++) {
    const code = certificateCode((n) => randomBytes(n));
    const { error } = await sb.from('course_certificates').insert({ member_id: memberId, name, code });
    if (!error) break;
    if (error.code !== '23505') return null;
  }
  const { data } = await sb.from('course_certificates').select('id, name, code, issued_at, revoked_at').eq('member_id', memberId).maybeSingle();
  return (data as Certificate) ?? null;
}

/** Modules used, for the self-paced money-back window (server-side, any member). */
export async function modulesUsed(memberId: string): Promise<number> {
  const sb = supabaseAdmin();
  const [a, s] = await Promise.all([
    sb.from('quiz_attempts').select('module, passed, score, total, created_at').eq('member_id', memberId),
    sb.from('course_submissions').select('module, status, created_at').eq('member_id', memberId),
  ]);
  return courseStatus({ done: new Set(), attempts: (a.data ?? []) as never, submissions: (s.data ?? []) as never }).modulesUsed;
}
