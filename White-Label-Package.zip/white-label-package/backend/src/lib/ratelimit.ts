// Fixed-window rate limiter. In-memory, so it limits per server instance:
// enough to stop a single script hammering a form. For multi-region or
// serverless scale, swap `store` for a shared store (Upstash Redis, or a
// Supabase table) with the same interface.

export interface Store {
  incr(key: string, windowMs: number, now: number): number;
}

export class MemoryStore implements Store {
  private hits = new Map<string, { count: number; reset: number }>();
  incr(key: string, windowMs: number, now: number): number {
    const cur = this.hits.get(key);
    if (!cur || cur.reset <= now) {
      this.hits.set(key, { count: 1, reset: now + windowMs });
      if (this.hits.size > 50_000) this.sweep(now);
      return 1;
    }
    cur.count += 1;
    return cur.count;
  }
  private sweep(now: number) {
    for (const [k, v] of this.hits) if (v.reset <= now) this.hits.delete(k);
  }
}

const shared = new MemoryStore();

export function rateLimit(key: string, limit: number, windowMs: number, store: Store = shared, now = Date.now()) {
  const count = store.incr(key, windowMs, now);
  return { ok: count <= limit, remaining: Math.max(0, limit - count) };
}
