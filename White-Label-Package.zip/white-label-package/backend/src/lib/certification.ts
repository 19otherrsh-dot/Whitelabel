// Instructor certification records (delivery/instructor/certification.md). Pure functions, no I/O.
import { addMonths } from './rules';

export const PARTS = [
  { key: 'part1', label: 'Part 1 · Build it yourself', for: 'associate', pass: 'Own department passes the demo-day rubric (B1–B6)' },
  { key: 'part2', label: 'Part 2 · Written exam', for: 'associate', pass: '80% and every ★ safety question correct (marked online)' },
  { key: 'part3', label: 'Part 3 · Support and troubleshooting', for: 'associate', pass: 'P1 handled correctly and 4 of 5 tickets resolved' },
  { key: 'part4', label: 'Part 4 · Teach-back', for: 'lead', pass: 'At least 3 on every criterion, average 3.5+' },
  { key: 'part5', label: 'Part 5 · Marking', for: 'lead', pass: 'Matches the reference marking on all three demos' },
  { key: 'shadowing', label: 'Shadowing', for: 'lead', pass: 'TA for a full cohort, co-taught two sessions incl. demo day; signed off' },
  { key: 'trainer', label: 'Trainer approval', for: 'trainer', pass: 'Lead + two cohorts taught + licensor approval' },
] as const;
export type PartKey = (typeof PARTS)[number]['key'];
export type Level = 'candidate' | 'associate' | 'lead' | 'trainer';
export interface PartRecord { passed_on?: string | null; assessor?: string | null; score?: string | null; notes?: string | null }
export type Parts = Partial<Record<PartKey, PartRecord>>;

const passed = (p: Parts, k: PartKey) => !!p[k]?.passed_on;

/** The highest level whose requirements the record shows as met. */
export function levelMet(p: Parts): Level {
  const associate = passed(p, 'part1') && passed(p, 'part2') && passed(p, 'part3');
  if (!associate) return 'candidate';
  const lead = passed(p, 'part4') && passed(p, 'part5') && passed(p, 'shadowing');
  if (!lead) return 'associate';
  return passed(p, 'trainer') ? 'trainer' : 'lead';
}

export const LEVEL_RANK: Record<Level, number> = { candidate: 0, associate: 1, lead: 2, trainer: 3 };
export const LEVEL_LABEL: Record<Level, string> = { candidate: 'Candidate', associate: 'Associate', lead: 'Lead Instructor', trainer: 'Trainer' };

/** Every 12 months an instructor teaches or assists a cohort, or repeats Part 1. */
export function renewBy(certifiedAt: string): string {
  return addMonths(new Date(certifiedAt), 12).toISOString();
}

export type Standing = 'in_progress' | 'certified' | 'due' | 'lapsed' | 'suspended' | 'update_needed';

/**
 * Where a record stands today. A new kit major version needs the update module within 60 days;
 * past renew_by the certification has lapsed until renewed.
 */
export function standing(r: { status: string; level: Level; renew_by: string | null; kit_major: number | null }, currentMajor: number | null, now = new Date()): Standing {
  if (r.status === 'suspended') return 'suspended';
  if (r.level === 'candidate' || r.status === 'in_progress') return 'in_progress';
  if (r.renew_by && now.getTime() > Date.parse(r.renew_by)) return 'lapsed';
  if (currentMajor != null && r.kit_major != null && r.kit_major < currentMajor) return 'update_needed';
  if (r.renew_by && now.getTime() > Date.parse(r.renew_by) - 60 * 86_400_000) return 'due';
  return 'certified';
}
