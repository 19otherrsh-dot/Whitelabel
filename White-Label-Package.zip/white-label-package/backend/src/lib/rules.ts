// Business rules as pure functions. No I/O, so every rule is unit tested
// (tests/rules.test.ts) and the same code runs in route handlers and pages.
//
// Keep these in step with the public pages: refunds.html (cooling-off and the
// build guarantee) and pricing.html (seats, library and support periods).

export type Seat = 'founding' | 'vip';
export const SEATS: readonly Seat[] = ['founding', 'vip'] as const;

export interface CohortLike {
  seats: number;
  vip_seats: number;
  is_open: boolean;
  enrollment_closes: string | null;
  time_zone?: string;
  support_days: number;
  library_months: number;
}

export interface SessionLike {
  position: number;
  starts_at: string;
  ends_at: string;
}

export interface EnrollmentLike {
  status: 'active' | 'refunded' | 'revoked' | 'transferred';
  created_at: string;
  library_until: string | null;
  support_until: string | null;
}

const DAY = 86_400_000;

export function isSeat(v: unknown): v is Seat {
  return v === 'founding' || v === 'vip';
}

export type SeatCounts = Record<Seat, number>;

/**
 * Seats left for one seat type. `taken` counts paid seats plus live checkout holds.
 * VIP places sit inside the total (pricing: "5 VIP places within the 50 cohort seats"):
 * founding can use any free place; VIP is also capped at vip_seats.
 * Keep in step with seats_left() in the SQL migration.
 */
export function seatsLeftFor(c: Pick<CohortLike, 'seats' | 'vip_seats'>, seat: Seat, taken: SeatCounts): number {
  const total = c.seats - taken.founding - taken.vip;
  const left = seat === 'vip' ? Math.min(total, c.vip_seats - taken.vip) : total;
  return Math.max(0, left);
}

export function capacityFor(c: CohortLike, seat: Seat): number {
  return seat === 'vip' ? Math.min(c.vip_seats, c.seats) : c.seats;
}

export type SaleState = { ok: true } | { ok: false; reason: 'closed' | 'past_deadline' | 'sold_out' };

/** Can this seat type be sold right now? */
export function saleState(c: CohortLike, seat: Seat, left: number, now = new Date()): SaleState {
  if (!c.is_open) return { ok: false, reason: 'closed' };
  if (c.enrollment_closes && now.getTime() >= Date.parse(c.enrollment_closes)) return { ok: false, reason: 'past_deadline' };
  if (capacityFor(c, seat) <= 0 || left <= 0) return { ok: false, reason: 'sold_out' };
  return { ok: true };
}

/** Add calendar months in UTC, clamping to the month's last day (31 Jan + 1 month = 28/29 Feb). */
export function addMonths(d: Date, months: number): Date {
  const y = d.getUTCFullYear(), m = d.getUTCMonth() + months, day = d.getUTCDate();
  const last = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  return new Date(Date.UTC(y, m, Math.min(day, last), d.getUTCHours(), d.getUTCMinutes(), d.getUTCSeconds()));
}

/**
 * Access periods granted at purchase.
 * Library access runs `library_months` from purchase or from the first session, whichever is later
 * (so early buyers don't lose months before the cohort starts).
 * Support runs `support_days` after the last session (demo day).
 */
export function accessPeriods(c: CohortLike, sessions: SessionLike[], purchasedAt: Date) {
  const sorted = [...sessions].sort((a, b) => a.position - b.position);
  const first = sorted[0] ? new Date(sorted[0].starts_at) : purchasedAt;
  const last = sorted.at(-1) ? new Date(sorted.at(-1)!.ends_at) : purchasedAt;
  const libraryStart = first > purchasedAt ? first : purchasedAt;
  return {
    library_until: addMonths(libraryStart, c.library_months).toISOString(),
    support_until: new Date(Math.max(last.getTime(), purchasedAt.getTime()) + c.support_days * DAY).toISOString(),
  };
}

export interface Entitlements {
  active: boolean;
  library: boolean;     // can download the kit and updates
  support: boolean;     // can open support requests
  sessions: boolean;    // can see session links
}

export function entitlements(e: EnrollmentLike | null | undefined, now = new Date()): Entitlements {
  if (!e || e.status !== 'active') return { active: false, library: false, support: false, sessions: false };
  const t = now.getTime();
  return {
    active: true,
    library: !e.library_until || t < Date.parse(e.library_until),
    support: !e.support_until || t < Date.parse(e.support_until),
    sessions: true,
  };
}

export type ClaimKind = 'cooling_off' | 'build_guarantee';
export type Eligibility =
  | { ok: true; kind: ClaimKind }
  | { ok: false; kind: ClaimKind; reason: string };

/**
 * Cooling-off: within 3 days of purchase AND before Session 1 starts.
 * Build guarantee: from the start of Session 6 until 7 days after it ends,
 * and the member attended every live session. (Completing the setup steps and
 * the "working department" test are judged by a person, from the evidence.)
 */
export function claimEligibility(
  kind: ClaimKind,
  e: EnrollmentLike,
  sessions: SessionLike[],
  attendedPositions: number[],
  now = new Date(),
  selfPaced?: SelfPacedTerms,
): Eligibility {
  if (e.status !== 'active') return { ok: false, kind, reason: 'This seat is no longer active.' };
  if (selfPaced) return selfPacedEligibility(kind, e, selfPaced, now);
  const sorted = [...sessions].sort((a, b) => a.position - b.position);
  const t = now.getTime();
  if (kind === 'cooling_off') {
    const bought = Date.parse(e.created_at);
    if (t > bought + 3 * DAY) return { ok: false, kind, reason: 'The 3-day cooling-off period has ended.' };
    if (sorted[0] && t >= Date.parse(sorted[0].starts_at)) return { ok: false, kind, reason: 'Session 1 has already started.' };
    return { ok: true, kind };
  }
  const last = sorted.at(-1);
  if (!last) return { ok: false, kind, reason: 'The cohort has no sessions yet.' };
  if (t < Date.parse(last.starts_at)) return { ok: false, kind, reason: 'The build guarantee opens at Session 6 (demo day).' };
  if (t > Date.parse(last.ends_at) + 7 * DAY) return { ok: false, kind, reason: 'The 7-day window after Session 6 has ended.' };
  const attended = new Set(attendedPositions);
  const missed = sorted.filter((s) => !attended.has(s.position)).map((s) => s.position);
  if (missed.length) return { ok: false, kind, reason: `Our records show you missed session${missed.length > 1 ? 's' : ''} ${missed.join(', ')}. If that's wrong, open a support request.` };
  return { ok: true, kind };
}

/** The self-paced course has no live sessions, so no build guarantee: a plain money-back window instead. */
export interface SelfPacedTerms { refundDays: number; modulesUsed: number; maxModules?: number }

export function selfPacedEligibility(kind: ClaimKind, e: EnrollmentLike, t: SelfPacedTerms, now = new Date()): Eligibility {
  if (kind === 'build_guarantee') return { ok: false, kind, reason: 'The build guarantee is for live cohorts. The self-paced course has a money-back window instead.' };
  const max = t.maxModules ?? 2;
  if (now.getTime() > Date.parse(e.created_at) + t.refundDays * DAY) return { ok: false, kind, reason: `The ${t.refundDays}-day money-back window has ended.` };
  if (t.modulesUsed > max) return { ok: false, kind, reason: `More than ${max} modules are already complete.` };
  return { ok: true, kind };
}

export function seatName(seat: string, selfPaced?: boolean | null): string {
  if (selfPaced) return 'Self-paced course';
  return seat === 'vip' ? 'VIP seat' : 'Founding seat';
}

/** Format minor units for display. */
export function money(minor: number, currency: string, locale = 'en-US'): string {
  return new Intl.NumberFormat(locale, { style: 'currency', currency: currency.toUpperCase(), maximumFractionDigits: minor % 100 ? 2 : 0 }).format(minor / 100);
}

/** CSV with every cell quoted; neutralises spreadsheet formula injection. */
export function toCsv(rows: Record<string, unknown>[], columns?: string[]): string {
  const cols = columns ?? Array.from(rows.reduce((s, r) => { Object.keys(r).forEach((k) => s.add(k)); return s; }, new Set<string>()));
  const cell = (v: unknown) => {
    let s = v == null ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
    return '"' + s.replace(/"/g, '""') + '"';
  };
  return [cols.map(cell).join(','), ...rows.map((r) => cols.map((c) => cell(r[c])).join(','))].join('\r\n') + '\r\n';
}

/** Only allow same-app relative paths as post-login destinations. */
export function safeNext(next: string | null | undefined, fallback = '/member'): string {
  if (!next || typeof next !== 'string') return fallback;
  if (!next.startsWith('/') || next.startsWith('//') || next.startsWith('/\\')) return fallback;
  return next;
}

/** A pattern for SQL ILIKE that matches the text exactly (case-insensitive): escapes % _ and \\. */
export const likeExact = (s: string) => s.replace(/[\\%_]/g, (c) => '\\' + c);

/**
 * Library access after a paid renewal: the months are added to whatever is left, or to today if access
 * has already ended, so renewing early never loses time and renewing late never back-dates.
 */
export function renewedUntil(current: string | null, months: number, now = new Date()): string {
  const base = current && Date.parse(current) > now.getTime() ? new Date(current) : now;
  return addMonths(base, months).toISOString();
}
