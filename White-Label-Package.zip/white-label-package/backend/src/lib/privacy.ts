import 'server-only';
import { supabaseAdmin } from './supabase/admin';
import { likeExact } from './rules';

/** Everything held about one email address, for access requests (GDPR Art. 15) and erasure. */
export async function findPerson(email: string) {
  const sb = supabaseAdmin();
  const e = email.trim().toLowerCase();
  const [{ data: leads }, { data: member }, { data: instructor }] = await Promise.all([
    sb.from('leads').select('*').ilike('email', likeExact(e)),
    sb.from('members').select('*').ilike('email', likeExact(e)).maybeSingle(),
    sb.from('instructors').select('*').ilike('email', likeExact(e)).maybeSingle(),
  ]);
  let enrollments: unknown[] = [], support: unknown[] = [], claims: unknown[] = [], attendance: unknown[] = [], downloads: unknown[] = [];
  let course: { progress: unknown[]; quizzes: unknown[]; submissions: unknown[]; certificates: unknown[] } = { progress: [], quizzes: [], submissions: [], certificates: [] };
  let exams: unknown[] = [];
  if (instructor) {
    const { data } = await sb.from('exam_attempts').select('id, kit_version, created_at, started_at, submitted_at, answers, marks, score, result, graded_at').eq('instructor_id', instructor.id as string);
    exams = data ?? [];
  }
  if (member) {
    const id = member.id as string;
    const r = await Promise.all([
      sb.from('enrollments').select('*').eq('member_id', id),
      sb.from('support_requests').select('*').eq('member_id', id),
      sb.from('guarantee_claims').select('*').eq('member_id', id),
      sb.from('attendance').select('*').eq('member_id', id),
      sb.from('downloads').select('*').eq('member_id', id),
      sb.from('course_progress').select('*').eq('member_id', id),
      sb.from('quiz_attempts').select('*').eq('member_id', id),
      sb.from('course_submissions').select('*').eq('member_id', id),
      sb.from('course_certificates').select('*').eq('member_id', id),
    ]);
    [enrollments, support, claims, attendance, downloads] = r.slice(0, 5).map((x) => x.data ?? []);
    const [progress, quizzes, submissions, certificates] = r.slice(5).map((x) => x.data ?? []);
    course = { progress, quizzes, submissions, certificates };
  }
  return { email: e, leads: leads ?? [], member: member ?? null, enrollments, support, claims, attendance, downloads, course, instructor: instructor ?? null, exams };
}

/**
 * Erase a person: delete their leads, support requests, attendance, download log, course work and any
 * instructor record; anonymise the
 * member record and block sign-in. Purchase records (enrollments) and refund decisions are kept,
 * linked to the anonymised record, because tax and dispute law usually require them.
 */
export async function erasePerson(email: string): Promise<{ leads: number; member: boolean; instructor: boolean }> {
  const sb = supabaseAdmin();
  const p = await findPerson(email);
  if (p.leads.length) await sb.from('leads').delete().ilike('email', likeExact(p.email));
  // Instructor records and their exam attempts (attempts go with the record).
  if (p.instructor) { await sb.from('exam_attempts').delete().eq('instructor_id', p.instructor.id as string); await sb.from('instructors').delete().eq('id', p.instructor.id as string); }
  let member = false;
  if (p.member) {
    const id = p.member.id as string;
    await sb.from('support_requests').delete().eq('member_id', id);
    await sb.from('attendance').delete().eq('member_id', id);
    await sb.from('downloads').delete().eq('member_id', id);
    for (const t of ['course_progress', 'quiz_attempts', 'course_submissions', 'course_certificates']) await sb.from(t).delete().eq('member_id', id);
    const anon = `erased-${id.slice(0, 8)}@invalid.example`;
    await sb.from('members').update({ email: anon, full_name: null, company: null }).eq('id', id);
    await sb.from('enrollments').update({ stripe_customer: null }).eq('member_id', id);
    await sb.from('guarantee_claims').update({ reason: '[erased]', evidence: {} }).eq('member_id', id);
    await sb.auth.admin.updateUserById(id, { email: anon, user_metadata: {}, ban_duration: '876000h' });
    member = true;
  }
  return { leads: p.leads.length, member, instructor: !!p.instructor };
}
