// Safe to use anywhere (no course answers in here).
export type InlinePart = { t: 'text' | 'code' | 'b' | 'i'; v: string };

/** Render a line from the Markdown sources: `code`, **bold** and *italic* only; everything else is text. */
export function inlineParts(text: string): InlinePart[] {
  const out: InlinePart[] = [];
  const re = /`([^`]+)`|\*\*([^*]+)\*\*|\*([^*\s][^*]*?)\*/g;
  let last = 0;
  for (const m of text.matchAll(re)) {
    if (m.index! > last) out.push({ t: 'text', v: text.slice(last, m.index) });
    out.push(m[1] != null ? { t: 'code', v: m[1] } : m[2] != null ? { t: 'b', v: m[2] } : { t: 'i', v: m[3] });
    last = m.index! + m[0].length;
  }
  if (last < text.length) out.push({ t: 'text', v: text.slice(last) });
  return out;
}
