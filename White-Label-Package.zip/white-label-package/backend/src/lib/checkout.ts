import 'server-only';
import type Stripe from 'stripe';
import { env } from './env';
import { stripe } from './stripe';
import { supabaseAdmin } from './supabase/admin';
import { availability, type Cohort } from './data';
import { saleState, seatName, type Seat } from './rules';
import { invoiceParams } from './renewal';

const HOLD_MINUTES = 35;     // a little longer than Stripe's 30-minute session, so a paid session always has its hold
const SESSION_MINUTES = 30;  // Stripe's minimum expiry

export type StartResult = { ok: true; url: string } | { ok: false; reason: 'closed' | 'past_deadline' | 'sold_out' | 'error'; message: string };

const messages = {
  closed: 'Enrollment for this cohort is closed.',
  past_deadline: 'Enrollment for this cohort has closed.',
  sold_out: 'Those seats are all taken right now. Someone may still be checking out, so try again in half an hour, or join the waitlist.',
  error: 'Checkout is unavailable right now. Please try again in a few minutes.',
} as const;

/** Reserve a seat for 35 minutes and open a Stripe Checkout session for it. */
export async function startCheckout(c: Cohort, seat: Seat, email?: string): Promise<StartResult> {
  const left = await availability(c, seat);
  const state = saleState(c, seat, left);
  if (!state.ok) return { ok: false, reason: state.reason, message: messages[state.reason] };

  const sb = supabaseAdmin();
  const { data: holdId, error: holdErr } = await sb.rpc('take_hold', { c: c.id, s: seat });
  if (holdErr) { console.error('[checkout] hold failed', holdErr.message); return { ok: false, reason: 'error', message: messages.error }; }
  if (!holdId) return { ok: false, reason: 'sold_out', message: messages.sold_out };
  await sb.from('checkout_holds').update({ expires_at: new Date(Date.now() + HOLD_MINUTES * 60_000).toISOString() }).eq('id', holdId);

  const e = env();
  const price = seat === 'vip' ? c.price_vip : c.price_founding;
  const params: Stripe.Checkout.SessionCreateParams = {
    mode: 'payment',
    client_reference_id: holdId as string,
    customer_email: email || undefined,
    customer_creation: 'always',
    billing_address_collection: 'auto',
    allow_promotion_codes: true,
    expires_at: Math.floor(Date.now() / 1000) + SESSION_MINUTES * 60,
    line_items: [{
      quantity: 1,
      price_data: {
        currency: c.currency,
        unit_amount: price,
        product_data: {
          name: `${c.name} · ${seatName(seat, c.self_paced)}`,
          description: 'Six live build sessions, the workspace kit, library updates and support.',
        },
        ...(e.STRIPE_AUTOMATIC_TAX === 'true' ? { tax_behavior: 'exclusive' as const } : {}),
      },
    }],
    metadata: { cohort_id: c.id, cohort_slug: c.slug, seat, hold_id: holdId as string },
    payment_intent_data: { metadata: { cohort_id: c.id, seat, hold_id: holdId as string } },
    custom_text: {
      submit: { message: `By paying you agree to the Terms (${e.SITE_URL}/terms.html) and the Refund policy (${e.SITE_URL}/refunds.html).` },
    },
    success_url: `${e.SITE_URL}/thank-you.html?for=${seat}`,
    cancel_url: `${e.APP_URL}/checkout/cancelled?hold=${holdId}`,
    ...(e.STRIPE_AUTOMATIC_TAX === 'true' ? { automatic_tax: { enabled: true } } : {}),
    ...invoiceParams(`${c.name} · ${seatName(seat, c.self_paced)}`),
  };

  try {
    const session = await stripe().checkout.sessions.create(params, { idempotencyKey: `hold-${holdId}` });
    await sb.from('checkout_holds').update({ stripe_checkout_session: session.id }).eq('id', holdId);
    return { ok: true, url: session.url! };
  } catch (err) {
    console.error('[checkout] stripe error', (err as Error).message);
    await sb.from('checkout_holds').delete().eq('id', holdId);
    return { ok: false, reason: 'error', message: messages.error };
  }
}

/** Buyer clicked "back" on Stripe: release the seat now rather than in 35 minutes. */
export async function releaseHold(holdId: string) {
  if (!/^[0-9a-f-]{36}$/i.test(holdId)) return;
  const sb = supabaseAdmin();
  const { data } = await sb.from('checkout_holds').select('stripe_checkout_session').eq('id', holdId).maybeSingle();
  if (!data) return;
  if (data.stripe_checkout_session) {
    try {
      const s = await stripe().checkout.sessions.retrieve(data.stripe_checkout_session);
      if (s.status === 'complete') return;          // paid after all: keep the hold, the webhook fulfils it
      if (s.status === 'open') await stripe().checkout.sessions.expire(s.id);
    } catch { /* already expired */ }
  }
  await sb.from('checkout_holds').delete().eq('id', holdId);
}
