import { z } from 'zod';

// Input schemas for every public endpoint. Field names match what the static
// site sends (assets/audit.js, assets/site.js contact form, waitlist/training forms).

const text = (max: number) => z.string().trim().max(max);
const optText = (max: number) => text(max).optional().default('');

/** Honeypot: real people leave the hidden "website" field empty. */
const honeypot = { website: z.string().max(0).optional().default('') };

export const contactSchema = z.object({
  name: text(120).min(1, 'Please add your name'),
  email: z.email('Please add a valid email').max(254),
  company: optText(160),
  topic: optText(80),
  message: text(5000).min(10, 'Please add a little more detail'),
  consent: z.literal('yes', 'Please tick the box so we can reply to you'), // consent to be contacted about this enquiry
  marketingConsent: z.boolean().optional().default(false),
  page: optText(300),
  sentAt: optText(40),
  ...honeypot,
});

export const waitlistSchema = z.object({
  kind: z.enum(['waitlist', 'training']).default('waitlist'),
  name: optText(120),
  email: z.email('Please add a valid email').max(254),
  company: optText(160),
  marketingConsent: z.boolean().optional().default(false),
  page: optText(300),
  ...honeypot,
});

// Matches the JSON assets/audit.js posts when links.auditWebhook is set.
const shortList = z.array(z.string().trim().max(120)).max(200).optional().default([]);
export const auditSchema = z.object({
  company: optText(160),
  email: z.union([z.email().max(254), z.literal('')]).optional().default(''),
  marketingConsent: z.boolean().optional().default(false),
  businessType: optText(60),
  teamSize: optText(60),
  departments: shortList,
  tools: shortList,
  estimate: z.number().finite().min(0).max(1e9).optional(),
  jobs: z.number().int().min(0).max(10000).optional(),
  departmentsCount: z.number().int().min(0).max(100).optional(),
  runToday: z.number().int().min(0).max(10000).optional(),
  start: shortList,
  at: optText(40),
  page: optText(300),
  ...honeypot,
});

export const supportSchema = z.object({
  subject: text(160).min(3, 'Add a short subject'),
  body: text(8000).min(10, 'Tell us a little more'),
});

export const claimSchema = z.object({
  kind: z.enum(['cooling_off', 'build_guarantee']),
  reason: text(8000).min(10, 'Tell us briefly what happened'),
  checklist: z.string().trim().max(2000).optional().default(''),
  evidenceUrl: z.union([z.url().max(500), z.literal('')]).optional().default(''),
});

export const cohortSchema = z.object({
  slug: z.string().regex(/^[a-z0-9-]{2,60}$/, 'Lowercase letters, numbers and dashes'),
  name: text(120).min(2),
  seats: z.coerce.number().int().min(0).max(10000),
  vip_seats: z.coerce.number().int().min(0).max(10000),
  price_founding: z.coerce.number().min(0),   // entered in major units, stored in minor
  price_vip: z.coerce.number().min(0),
  currency: z.string().regex(/^[a-zA-Z]{3}$/).transform((s) => s.toLowerCase()),
  enrollment_closes: z.string().optional().default(''),
  support_days: z.coerce.number().int().min(0).max(3650),
  library_months: z.coerce.number().int().min(0).max(120),
  is_open: z.union([z.literal('on'), z.literal('')]).optional().transform((v) => v === 'on'),
  price_renewal: z.union([z.literal(''), z.coerce.number().min(0)]).optional().default('').transform((v) => (v === '' ? null : v)),   // empty = renewals off
  renewal_months: z.coerce.number().int().min(1).max(36).optional().default(12),
  self_paced: z.union([z.literal('on'), z.literal('')]).optional().transform((v) => v === 'on'),
  refund_days: z.coerce.number().int().min(0).max(60).optional().default(14),
});

export const releaseSchema = z.object({
  version: z.string().regex(/^[0-9]+\.[0-9]+\.[0-9]+([-.][0-9A-Za-z.]+)?$/, 'Use a version like 1.2.0'),
  notes: optText(4000),
});

/** Turn a zod error into { field: message } for forms. */
export function fieldErrors(err: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const i of err.issues) {
    const k = String(i.path[0] ?? 'form');
    if (!out[k]) out[k] = i.message;
  }
  return out;
}

// ---------- anonymous usage summary (bin/wf learn --export) ----------
// Exactly the shape the kit writes, and nothing else: unknown keys are refused, skill names must look
// like kit skill names, and every value is a count. That keeps names, content and recipients out.
const count = z.number().int().min(0).max(10_000_000);
const safeLabel = (max: number) => z.string().max(max).regex(/^[A-Za-z0-9 .,&/+-]*$/, 'Unexpected characters');
export const usageSkillSchema = z.strictObject({
  runs: count, done: count, failed: count, skipped: count, queued: count,
  draft: count.optional(), rejected: count.optional(), lessons: count.optional(),
});
export const usageReportSchema = z.strictObject({
  kitVersion: safeLabel(40).nullable().optional(),
  businessType: safeLabel(60).nullable().optional(),
  teamSize: z.union([safeLabel(20), z.number().int().min(0).max(1_000_000)]).nullable().optional(),
  generated: z.iso.datetime().optional(),
  skills: z.record(z.string().regex(/^[a-z0-9][a-z0-9-]{0,63}$/, 'Unexpected skill name'), usageSkillSchema)
    .refine((o) => Object.keys(o).length > 0, 'The summary has no runs in it yet')
    .refine((o) => Object.keys(o).length <= 400, 'Too many skills'),
});
export type UsageReport = z.infer<typeof usageReportSchema>;
