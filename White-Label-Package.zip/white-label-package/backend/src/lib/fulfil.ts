import 'server-only';
import type Stripe from 'stripe';
import { env } from './env';
import { supabaseAdmin } from './supabase/admin';
import { cohortById, logAdmin, sessionsFor, takenSeats } from './data';
import { accessPeriods, isSeat, money } from './rules';
import { ensureUser, signInLink } from './members';
import { refundEmail, sendMail, welcomeEmail } from './email';

/**
 * Turn a paid Checkout session into a member with an active enrollment, then
 * send the welcome email. Safe to run more than once for the same session.
 */
export async function fulfilCheckout(s: Stripe.Checkout.Session): Promise<'fulfilled' | 'already' | 'unpaid' | 'flagged'> {
  if (s.payment_status !== 'paid' && s.payment_status !== 'no_payment_required') return 'unpaid';
  const sb = supabaseAdmin();

  const { data: existing } = await sb.from('enrollments').select('id').eq('stripe_checkout_session', s.id).maybeSingle();
  if (existing) return 'already';

  const cohortId = s.metadata?.cohort_id;
  const seat = s.metadata?.seat;
  const email = (s.customer_details?.email ?? s.customer_email ?? '').trim().toLowerCase() || null;
  if (!cohortId || !isSeat(seat) || !email) {
    await logAdmin(null, 'checkout_missing_data', s.id, { cohortId, seat, email: !!email });
    await alertSupport(`Paid checkout ${s.id} is missing data (cohort, seat or email). Fulfil it by hand.`);
    return 'flagged';
  }
  const c = await cohortById(cohortId);
  if (!c) throw new Error(`cohort ${cohortId} not found`);

  const name = s.customer_details?.name ?? null;
  const memberId = await ensureUser(email, name);

  const { data: prior } = await sb.from('enrollments').select('id, seat, status').eq('member_id', memberId).eq('cohort_id', c.id).maybeSingle();
  if (prior && prior.status === 'active') {
    // Bought twice (or bought VIP after founding). Don't guess: keep the money safe and ask a person.
    await logAdmin(null, 'duplicate_purchase', s.id, { memberId, priorSeat: prior.seat, newSeat: seat, amount: s.amount_total });
    await alertSupport(`${email} paid again for ${c.name} (${seat}) while already holding a ${prior.seat} seat. Checkout ${s.id}. Upgrade or refund the difference in Stripe.`);
    await sb.from('checkout_holds').delete().eq('stripe_checkout_session', s.id);
    return 'flagged';
  }

  const sessions = await sessionsFor(c.id);
  const periods = accessPeriods(c, sessions, new Date((s.created ?? Date.now() / 1000) * 1000));
  const row = {
    member_id: memberId,
    cohort_id: c.id,
    seat,
    status: 'active' as const,
    amount_paid: s.amount_total ?? 0,
    currency: s.currency ?? c.currency,
    stripe_checkout_session: s.id,
    stripe_payment_intent: typeof s.payment_intent === 'string' ? s.payment_intent : s.payment_intent?.id ?? null,
    stripe_customer: typeof s.customer === 'string' ? s.customer : s.customer?.id ?? null,
    ...periods,
  };
  const { error } = prior
    ? await sb.from('enrollments').update(row).eq('id', prior.id)          // re-buying after a refund
    : await sb.from('enrollments').insert(row);
  if (error) {
    if (error.code === '23505') return 'already';                           // a parallel delivery won the race
    throw new Error(`enrollment insert: ${error.message}`);
  }
  await sb.from('checkout_holds').delete().eq('stripe_checkout_session', s.id);

  const taken = await takenSeats(c.id);
  if (taken.founding + taken.vip > c.seats || taken.vip > c.vip_seats) {
    await logAdmin(null, 'oversold', c.id, taken);
    await alertSupport(`${c.name} is over capacity after checkout ${s.id} (${taken.founding} founding, ${taken.vip} VIP). Review in the admin area.`);
  }

  const link = await signInLink(email);
  const mail = welcomeEmail({ name, cohort: c.name, seat, loginUrl: link });
  const sent = await sendMail({ to: email, ...mail });
  if (!sent.ok) await logAdmin(null, 'welcome_email_failed', memberId, { error: sent.error });
  return 'fulfilled';
}

export async function releaseCheckout(s: Stripe.Checkout.Session) {
  await supabaseAdmin().from('checkout_holds').delete().eq('stripe_checkout_session', s.id);
}

/** A full refund ends access. Partial refunds are logged and left for a person. */
export async function handleRefund(ch: Stripe.Charge) {
  const pi = typeof ch.payment_intent === 'string' ? ch.payment_intent : ch.payment_intent?.id;
  if (!pi) return;
  const sb = supabaseAdmin();
  const { data: en } = await sb.from('enrollments').select('id, member_id, cohort_id, status').eq('stripe_payment_intent', pi).maybeSingle();
  if (!en) return;
  if (!ch.refunded) {
    await logAdmin(null, 'partial_refund', en.id, { amount_refunded: ch.amount_refunded, amount: ch.amount });
    return;
  }
  if (en.status === 'refunded') return;
  await sb.from('enrollments').update({ status: 'refunded' }).eq('id', en.id);
  await sb.from('guarantee_claims').update({ status: 'refunded', decided_at: new Date().toISOString() }).eq('enrollment_id', en.id).in('status', ['open', 'approved']);
  await logAdmin(null, 'refunded', en.id, { amount: ch.amount_refunded });
  const { data: m } = await sb.from('members').select('email').eq('id', en.member_id).maybeSingle();
  const c = await cohortById(en.cohort_id);
  if (m?.email && c) await sendMail({ to: m.email, ...refundEmail({ cohort: c.name, amount: money(ch.amount_refunded, ch.currency) }) });
}

export async function handleDispute(d: Stripe.Dispute) {
  const pi = typeof d.payment_intent === 'string' ? d.payment_intent : d.payment_intent?.id;
  const { data: en } = pi
    ? await supabaseAdmin().from('enrollments').select('id').eq('stripe_payment_intent', pi).maybeSingle()
    : { data: null };
  await logAdmin(null, 'dispute_opened', en?.id ?? pi ?? d.id, { reason: d.reason, amount: d.amount });
  await alertSupport(`A payment dispute was opened (${d.reason}, ${money(d.amount, d.currency)}). Respond in Stripe before the deadline. Dispute ${d.id}.`);
}

async function alertSupport(text: string) {
  const e = env();
  await sendMail({ to: e.SUPPORT_EMAIL, subject: `[${e.BRAND_NAME}] Needs attention`, text });
}
