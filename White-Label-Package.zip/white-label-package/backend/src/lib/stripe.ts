import 'server-only';
import Stripe from 'stripe';
import { env } from './env';

let client: Stripe | null = null;

export function stripe(): Stripe {
  if (client) return client;
  client = new Stripe(env().STRIPE_SECRET_KEY, {
    appInfo: { name: 'cohort-backend', version: '1.0.0' },
    maxNetworkRetries: 2,
  });
  return client;
}
