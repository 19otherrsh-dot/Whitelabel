import 'server-only';
import { supabaseAdmin } from './supabase/admin';
import { env } from './env';

export interface LeadInput {
  kind: 'audit' | 'contact' | 'waitlist' | 'training';
  email?: string;
  name?: string;
  company?: string;
  marketingConsent?: boolean;
  page?: string;
  payload: Record<string, unknown>;
  ipHash: string;
}

/** Store a lead and, if configured, forward it to the buyer's CRM webhook. */
export async function saveLead(l: LeadInput) {
  const { error } = await supabaseAdmin().from('leads').insert({
    kind: l.kind,
    email: l.email ? l.email.trim().toLowerCase() : null,
    name: l.name || null,
    company: l.company || null,
    marketing_consent: !!l.marketingConsent,
    source_page: l.page || null,
    payload: l.payload,
    ip_hash: l.ipHash,
  });
  if (error) throw new Error(`lead insert failed: ${error.message}`);

  const hook = env().LEAD_FORWARD_WEBHOOK;
  if (hook) {
    // Fire and forget, with a short timeout: a slow CRM must not slow the visitor down.
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 4000);
    fetch(hook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind: l.kind, email: l.email, name: l.name, company: l.company, marketingConsent: !!l.marketingConsent, page: l.page, ...l.payload }),
      signal: ctrl.signal,
    }).catch((e) => console.warn('[leads] forward failed:', (e as Error).message)).finally(() => clearTimeout(t));
  }
}
