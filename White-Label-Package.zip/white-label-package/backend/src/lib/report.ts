// The licensee report: the figures the licence agreement's Schedule 4 asks for, computed from this
// deployment's own records. Counts and totals only: it never contains a member's name, email,
// message, payment details or any per-person row, as clause 7.1 of the agreement requires.

export type ReportInput = {
  cohorts: { id: string; slug: string; name: string; seats: number; vip_seats: number; currency: string; is_open: boolean }[];
  sessions: { id: string; cohort_id: string; starts_at: string }[];
  enrollments: { cohort_id: string; seat: 'founding' | 'vip'; status: string; amount_paid: number; currency: string; created_at: string; updated_at: string }[];
  claims: { kind: 'cooling_off' | 'build_guarantee'; status: string; created_at: string; decided_at: string | null }[];
  attendance: { session_id: string; attended: boolean }[];
  support: { status: string; created_at: string }[];
  leads: { kind: string; created_at: string }[];
  downloads: { created_at: string }[];
  release: { version: string } | null;
  usageReports: { received_at: string }[];
};

export type Period = { from: string; to: string };

/** The current or a given quarter, e.g. "2026-Q3". */
export function quarter(q?: string, now = new Date()): Period & { label: string } {
  let y = now.getUTCFullYear(), n = Math.floor(now.getUTCMonth() / 3) + 1;
  const m = q ? /^(\d{4})-Q([1-4])$/.exec(q) : null;
  if (q && !m) throw new Error('Use a quarter like 2026-Q3');
  if (m) { y = Number(m[1]); n = Number(m[2]); }
  const from = new Date(Date.UTC(y, (n - 1) * 3, 1)), to = new Date(Date.UTC(y, n * 3, 1));
  return { label: `${y}-Q${n}`, from: from.toISOString(), to: to.toISOString() };
}

const inP = (iso: string | null | undefined, p: Period) => !!iso && iso >= p.from && iso < p.to;
const bump = (o: Record<string, number>, k: string, n = 1) => { o[k] = (o[k] || 0) + n; };

export function licenseeReport(d: ReportInput, period: Period & { label?: string }, meta: { brand: string; generatedAt?: string }) {
  const sessionsByCohort = new Map<string, { id: string; starts_at: string }[]>();
  for (const s of d.sessions) sessionsByCohort.set(s.cohort_id, [...(sessionsByCohort.get(s.cohort_id) ?? []), s]);
  const attendedBySession = new Map<string, number>();
  for (const a of d.attendance) if (a.attended) attendedBySession.set(a.session_id, (attendedBySession.get(a.session_id) ?? 0) + 1);

  const revenue: Record<string, { gross: number; refunded: number; net: number }> = {};
  const money = (cur: string) => (revenue[cur] ||= { gross: 0, refunded: 0, net: 0 });
  const sold = { founding: 0, vip: 0 };
  let refundedSeats = 0;
  for (const e of d.enrollments) {
    if (inP(e.created_at, period)) { sold[e.seat] += 1; money(e.currency).gross += e.amount_paid; }
    if (e.status === 'refunded' && inP(e.updated_at, period)) { refundedSeats += 1; money(e.currency).refunded += e.amount_paid; }
  }
  for (const r of Object.values(revenue)) r.net = r.gross - r.refunded;

  const refundsByReason = { coolingOff: 0, guarantee: 0, other: 0 };
  for (const c of d.claims) if ((c.status === 'approved' || c.status === 'refunded') && inP(c.decided_at, period)) {
    if (c.kind === 'cooling_off') refundsByReason.coolingOff++; else refundsByReason.guarantee++;
  }
  refundsByReason.other = Math.max(0, refundedSeats - refundsByReason.coolingOff - refundsByReason.guarantee);

  const cohorts = d.cohorts.map((c) => {
    const ss = (sessionsByCohort.get(c.id) ?? []).sort((a, b) => a.starts_at.localeCompare(b.starts_at));
    const rows = d.enrollments.filter((e) => e.cohort_id === c.id);
    const active = rows.filter((e) => e.status === 'active');
    const ran = ss.filter((s) => s.starts_at < (meta.generatedAt ?? new Date().toISOString()));
    const rates = ran.map((s) => (active.length ? (attendedBySession.get(s.id) ?? 0) / active.length : 0));
    return {
      slug: c.slug, name: c.name, open: c.is_open, seats: c.seats, vipSeats: c.vip_seats,
      firstSession: ss[0]?.starts_at ?? null, lastSession: ss.at(-1)?.starts_at ?? null,
      inPeriod: ss.some((s) => inP(s.starts_at, period)),
      activeSeats: { founding: active.filter((e) => e.seat === 'founding').length, vip: active.filter((e) => e.seat === 'vip').length },
      refunded: rows.filter((e) => e.status === 'refunded').length,
      sessionsRun: ran.length,
      averageAttendance: rates.length ? Math.round((rates.reduce((a, b) => a + b, 0) / rates.length) * 1000) / 1000 : null,
    };
  });

  const leads: Record<string, number> = {};
  for (const l of d.leads) if (inP(l.created_at, period)) bump(leads, l.kind);
  const claimsOpen = d.claims.filter((c) => c.status === 'open').length;

  return {
    format: 'licensee-report/1',
    brand: meta.brand,
    generatedAt: meta.generatedAt ?? new Date().toISOString(),
    period: { label: period.label ?? null, from: period.from, to: period.to },
    kitVersion: d.release?.version ?? null,
    seatsSold: sold,
    seatsRefunded: { total: refundedSeats, ...refundsByReason },
    revenue,                                  // minor units (cents) per currency
    cohorts,
    leads,
    support: { opened: d.support.filter((s) => inP(s.created_at, period)).length, open: d.support.filter((s) => s.status !== 'closed').length },
    refundRequests: { open: claimsOpen },
    kitDownloads: d.downloads.filter((x) => inP(x.created_at, period)).length,
    usageSummariesShared: d.usageReports.filter((x) => inP(x.received_at, period)).length,
    notTrackedHere: ['Certified Instructors and TAs', 'Demo-day results', 'Self-paced seats sold outside this checkout', 'Issues for the Licensor'],
  };
}
export type LicenseeReport = ReturnType<typeof licenseeReport>;
