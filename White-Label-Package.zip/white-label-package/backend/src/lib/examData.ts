import 'server-only';
import { createHash, randomBytes } from 'node:crypto';
import { supabaseAdmin } from './supabase/admin';

export interface Attempt {
  id: string; instructor_id: string; kit_version: string | null; created_at: string; expires_at: string;
  started_at: string | null; deadline: string | null; submitted_at: string | null;
  answers: Record<string, string>; marks: Record<string, boolean>; score: number | null; safety_ok: boolean | null;
  result: 'pending' | 'pass' | 'fail'; graded_at: string | null;
  instructors?: { name: string; email: string } | null;
}

/** A private exam link token (shown once, in the invite email) and the hash we store. */
export function newToken(): { token: string; hash: string } {
  const token = randomBytes(24).toString('base64url');
  return { token, hash: hashToken(token) };
}
export const hashToken = (t: string) => createHash('sha256').update(t).digest('hex');
export const validToken = (t: string) => /^[A-Za-z0-9_-]{32}$/.test(t);

export async function attemptByToken(token: string): Promise<Attempt | null> {
  if (!validToken(token)) return null;
  const { data } = await supabaseAdmin().from('exam_attempts').select('*, instructors(name, email)').eq('token_hash', hashToken(token)).maybeSingle();
  return (data as Attempt) ?? null;
}
