import 'server-only';
import { createHash } from 'node:crypto';
import { NextResponse, type NextRequest } from 'next/server';
import { allowedOrigins, env } from './env';
import { corsHeaders, isAllowedOrigin } from './cors';
import { rateLimit } from './ratelimit';

export function clientIp(req: NextRequest): string {
  const fwd = req.headers.get('x-forwarded-for');
  return (fwd ? fwd.split(',')[0] : req.headers.get('x-real-ip') ?? '').trim() || 'unknown';
}

export function ipHash(ip: string): string {
  return createHash('sha256').update(env().IP_HASH_SALT + '|' + ip).digest('hex').slice(0, 32);
}

/** JSON response with the CORS headers the caller's origin is entitled to. */
export function json(req: NextRequest, body: unknown, status = 200) {
  return NextResponse.json(body, { status, headers: corsHeaders(req.headers.get('origin'), allowedOrigins()) });
}

export function preflight(req: NextRequest) {
  const origin = req.headers.get('origin');
  if (!isAllowedOrigin(origin, allowedOrigins())) return new NextResponse(null, { status: 403, headers: { Vary: 'Origin' } });
  return new NextResponse(null, { status: 204, headers: corsHeaders(origin, allowedOrigins()) });
}

/**
 * Common gate for public form endpoints: origin allow-list, JSON body under a size cap,
 * and a per-IP rate limit. Returns the parsed body or a ready-made error response.
 */
export async function publicPost(req: NextRequest, bucket: string, limit = 10, windowMs = 10 * 60_000):
  Promise<{ ok: true; body: unknown; ip: string } | { ok: false; res: NextResponse }> {
  const origin = req.headers.get('origin');
  // Browsers always send Origin on cross-site POSTs; same-origin tools (curl) may not. Require it.
  if (!isAllowedOrigin(origin, allowedOrigins())) return { ok: false, res: json(req, { error: 'Origin not allowed' }, 403) };
  const ip = clientIp(req);
  if (!rateLimit(`${bucket}:${ip}`, limit, windowMs).ok) return { ok: false, res: json(req, { error: 'Too many requests. Please try again in a few minutes.' }, 429) };
  const type = req.headers.get('content-type') ?? '';
  // JSON, or JSON sent as text/plain (the site's webhookFormat "simple" mode).
  if (!type.includes('application/json') && !type.startsWith('text/plain')) return { ok: false, res: json(req, { error: 'Send JSON' }, 415) };
  const raw = await req.text();
  if (raw.length > 32_000) return { ok: false, res: json(req, { error: 'Too large' }, 413) };
  try {
    return { ok: true, body: JSON.parse(raw), ip };
  } catch {
    return { ok: false, res: json(req, { error: 'Invalid JSON' }, 400) };
  }
}
