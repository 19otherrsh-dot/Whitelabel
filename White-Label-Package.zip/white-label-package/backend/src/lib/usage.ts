import { usageReportSchema, type UsageReport } from './validation';

export const MAX_USAGE_BYTES = 200_000;

/** Parse and check an uploaded `anonymous-usage-*.json`. Returns the report or a reason for the member. */
export function parseUsageFile(text: string): { ok: true; report: UsageReport } | { ok: false; reason: string } {
  if (text.length > MAX_USAGE_BYTES) return { ok: false, reason: 'That file is larger than a usage summary should be.' };
  let json: unknown;
  try { json = JSON.parse(text); } catch { return { ok: false, reason: 'That isn’t a usage summary. Upload the file from output/learning/ in your workspace.' }; }
  const r = usageReportSchema.safeParse(json);
  if (!r.success) {
    const i = r.error.issues[0];
    return { ok: false, reason: `That file isn’t in the expected shape (${i.path.join('.') || 'file'}: ${i.message}). Make it again with bin/wf learn --export and upload it unchanged.` };
  }
  return { ok: true, report: r.data };
}

export type UsageRow = { received_at: string; kit_version: string | null; skills: Record<string, Record<string, number>> };
export type SkillTotals = { skill: string; workspaces: number; runs: number; done: number; failed: number; rejected: number; lessons: number; failRate: number; rejectRate: number };

/** Totals per skill across shared summaries, worst first by rejections then failures (where to improve). */
export function aggregateUsage(rows: UsageRow[]): SkillTotals[] {
  const t = new Map<string, SkillTotals>();
  for (const row of rows) {
    for (const [skill, c] of Object.entries(row.skills || {})) {
      const s = t.get(skill) ?? { skill, workspaces: 0, runs: 0, done: 0, failed: 0, rejected: 0, lessons: 0, failRate: 0, rejectRate: 0 };
      s.workspaces++;
      s.runs += c.runs || 0; s.done += c.done || 0; s.failed += c.failed || 0; s.rejected += c.rejected || 0; s.lessons += c.lessons || 0;
      t.set(skill, s);
    }
  }
  const out = [...t.values()].map((s) => ({ ...s, failRate: s.runs ? s.failed / s.runs : 0, rejectRate: s.runs ? s.rejected / s.runs : 0 }));
  return out.sort((a, b) => b.rejectRate - a.rejectRate || b.failRate - a.failRate || b.runs - a.runs);
}
