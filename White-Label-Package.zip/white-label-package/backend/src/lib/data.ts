import 'server-only';
import { supabaseAdmin } from './supabase/admin';
import { seatsLeftFor, type CohortLike, type Seat, type SessionLike } from './rules';

export interface Cohort extends CohortLike {
  id: string;
  slug: string;
  name: string;
  price_founding: number;
  price_vip: number;
  currency: string;
  price_renewal?: number | null;   // minor units; null = no paid renewal
  renewal_months?: number;
  self_paced?: boolean;            // a self-paced course product: no live sessions, money-back window instead of the build guarantee
  refund_days?: number;
}

export async function cohortBySlug(slug: string): Promise<Cohort | null> {
  const { data } = await supabaseAdmin().from('cohorts').select('*').eq('slug', slug).maybeSingle();
  return (data as Cohort) ?? null;
}

export async function cohortById(id: string): Promise<Cohort | null> {
  const { data } = await supabaseAdmin().from('cohorts').select('*').eq('id', id).maybeSingle();
  return (data as Cohort) ?? null;
}

export async function sessionsFor(cohortId: string): Promise<(SessionLike & { id: string; title: string; join_url: string | null; replay_url: string | null })[]> {
  const { data } = await supabaseAdmin().from('cohort_sessions').select('*').eq('cohort_id', cohortId).order('position');
  return (data ?? []) as never;
}

export async function takenSeats(cohortId: string): Promise<Record<Seat, number>> {
  const sb = supabaseAdmin();
  const now = new Date().toISOString();
  const [{ data: paid }, { data: holds }] = await Promise.all([
    sb.from('enrollments').select('seat').eq('cohort_id', cohortId).eq('status', 'active'),
    sb.from('checkout_holds').select('seat').eq('cohort_id', cohortId).gt('expires_at', now),
  ]);
  const out: Record<Seat, number> = { founding: 0, vip: 0 };
  for (const r of [...(paid ?? []), ...(holds ?? [])] as { seat: Seat }[]) out[r.seat] += 1;
  return out;
}

export async function availability(c: Cohort, seat: Seat): Promise<number> {
  return seatsLeftFor(c, seat, await takenSeats(c.id));
}

export async function logAdmin(actor: string | null, action: string, target: string | null, detail: Record<string, unknown> = {}) {
  await supabaseAdmin().from('admin_log').insert({ actor, action, target, detail });
}
