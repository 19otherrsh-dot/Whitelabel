import 'server-only';
import { z } from 'zod';

// Server environment, validated once on first use. A missing value fails loudly
// with the variable's name rather than surfacing later as an odd runtime error.
const schema = z.object({
  APP_URL: z.url(),
  SITE_URL: z.url(),
  ALLOWED_ORIGINS: z.string().default(''),
  BRAND_NAME: z.string().min(1).default('Your Brand'),
  SUPPORT_EMAIL: z.email(),
  DEFAULT_COHORT: z.string().min(2),
  NEXT_PUBLIC_SUPABASE_URL: z.url(),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().min(20),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(20),
  STRIPE_SECRET_KEY: z.string().regex(/^(sk|rk)_(test|live)_/),
  STRIPE_WEBHOOK_SECRET: z.string().startsWith('whsec_'),
  STRIPE_AUTOMATIC_TAX: z.enum(['true', 'false']).default('false'),
  RESEND_API_KEY: z.string().optional().default(''),
  EMAIL_FROM: z.string().min(3),
  IP_HASH_SALT: z.string().min(16),
  COMMUNITY_URL: z.union([z.url(), z.literal('')]).optional().default(''),
  TRAINING_START: z.union([z.iso.datetime({ offset: true }), z.literal('')]).optional().default(''),
  TRAINING_TIME_ZONE: z.string().optional().default('America/New_York'),
  TRAINING_JOIN_URL: z.union([z.url(), z.literal('')]).optional().default(''),
  TRAINING_REPLAY_URL: z.union([z.url(), z.literal('')]).optional().default(''),   // sent to registrants 2 hours after the training
  CRON_SECRET: z.union([z.string().min(24), z.literal('')]).optional().default(''),  // protects /api/cron/emails
  STRIPE_INVOICES: z.enum(['true', 'false']).default('false'),                        // a Stripe invoice (PDF, VAT details) for every purchase
  BOOKING_URL: z.union([z.url(), z.literal('')]).optional().default(''),   // linked from the audit result email
  COURSE_NAME: z.string().min(2).optional().default('Build your AI workforce'),   // shown on certificates
  LEAD_FORWARD_WEBHOOK: z.union([z.url(), z.literal('')]).optional().default(''),
  // Lets the licensor's fleet console read the quarterly report (aggregates only). Empty = off.
  LICENSOR_REPORT_TOKEN: z.union([z.string().min(32), z.literal('')]).optional().default(''),
});

export type Env = z.infer<typeof schema>;
let cached: Env | null = null;

export function env(): Env {
  if (cached) return cached;
  const parsed = schema.safeParse(process.env);
  if (!parsed.success) {
    const names = parsed.error.issues.map((i) => i.path.join('.')).join(', ');
    throw new Error(`Missing or invalid environment variables: ${names}. See .env.example.`);
  }
  cached = parsed.data;
  return cached;
}

export function allowedOrigins(): string[] {
  return env().ALLOWED_ORIGINS.split(',').map((s) => s.trim().replace(/\/+$/, '')).filter(Boolean);
}
