// The instructor certification exam (Part 2 of delivery/instructor/certification.md): the questions
// and answer key (built from delivery/instructor/exam*.md), the time window and the marking rules.
// Pure functions, no I/O. The key is in here, so only server code may import this file.
import 'server-only';
import data from '@/content/exam.json';

export interface ExamQuestion {
  n: number; safety: boolean; type: 'choice' | 'tf' | 'short';
  text: string; options?: string[]; answer?: number; key: string;
}
export const EXAM = data as { minutes: number; passPercent: number; passScore: number; questions: ExamQuestion[] };
export const GRACE_MS = 2 * 60_000;            // network and clock slack after the deadline
export const LINK_DAYS = 14;                   // how long an unused invite link stays valid

/** What the candidate's browser may see: no keys and no correct options. */
export function publicExam() {
  return EXAM.questions.map(({ n, safety, type, text, options }) => ({ n, safety, type, text, options }));
}

export interface AttemptLike {
  expires_at: string; started_at: string | null; deadline: string | null; submitted_at: string | null;
}
export type ExamState = 'expired' | 'ready' | 'in_progress' | 'time_up' | 'submitted';

export function examState(a: AttemptLike, now = new Date()): ExamState {
  const t = now.getTime();
  if (a.submitted_at) return 'submitted';
  if (!a.started_at) return t > Date.parse(a.expires_at) ? 'expired' : 'ready';
  return a.deadline && t > Date.parse(a.deadline) + GRACE_MS ? 'time_up' : 'in_progress';
}

/** Keep only answers to real questions, as the right type, and trimmed to a sane length. */
export function cleanAnswers(raw: Record<string, unknown>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const q of EXAM.questions) {
    const v = raw[String(q.n)];
    if (typeof v !== 'string' || !v.trim()) continue;
    if (q.type === 'short') out[q.n] = v.trim().slice(0, 4000);
    else if (/^\d+$/.test(v) && Number(v) < (q.options?.length ?? 0)) out[q.n] = v;
  }
  return out;
}

/** Marks for the questions a computer can mark (multiple choice and true/false). */
export function autoMarks(answers: Record<string, string>): Record<string, boolean> {
  const marks: Record<string, boolean> = {};
  for (const q of EXAM.questions) if (q.type !== 'short') marks[q.n] = answers[q.n] != null && Number(answers[q.n]) === q.answer;
  return marks;
}

export interface ExamResult { score: number; total: number; safetyOk: boolean; ungraded: number[]; result: 'pending' | 'pass' | 'fail' }

/**
 * Pass = at least passScore (24 of 30) AND every ★ safety question correct. A blank answer is wrong.
 * While any answered short question is unmarked the result stays pending.
 */
export function examResult(answers: Record<string, string>, marks: Record<string, boolean | undefined>): ExamResult {
  let score = 0;
  let safetyOk = true;
  const ungraded: number[] = [];
  for (const q of EXAM.questions) {
    const blank = answers[q.n] == null || answers[q.n] === '';
    const m = blank ? false : marks[q.n];
    if (m === undefined) { ungraded.push(q.n); if (q.safety) safetyOk = false; continue; }
    if (m) score++; else if (q.safety) safetyOk = false;
  }
  const total = EXAM.questions.length;
  const result = ungraded.length ? 'pending' : score >= EXAM.passScore && safetyOk ? 'pass' : 'fail';
  return { score, total, safetyOk, ungraded, result };   // safetyOk is false until every ★ answer is marked correct
}
