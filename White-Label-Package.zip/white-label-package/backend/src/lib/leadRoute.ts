import 'server-only';
import type { NextRequest } from 'next/server';
import type { z } from 'zod';
import { ipHash, json, publicPost } from './http';
import { fieldErrors } from './validation';
import { saveLead, type LeadInput } from './leads';

/**
 * Shared handler for the public form endpoints: origin check, rate limit,
 * validation, honeypot, then store. Bots that fill the honeypot get a normal
 * "ok" so they learn nothing, but nothing is stored.
 */
export async function handleLead<S extends z.ZodType>(
  req: NextRequest,
  bucket: string,
  schema: S,
  toLead: (d: z.infer<S>) => Omit<LeadInput, 'ipHash'>,
  after?: (d: z.infer<S>) => Promise<void>,
) {
  const gate = await publicPost(req, bucket);
  if (!gate.ok) return gate.res;
  const raw = gate.body as Record<string, unknown>;
  if (raw && typeof raw === 'object' && typeof raw.website === 'string' && raw.website.length > 0) return json(req, { ok: true });
  const parsed = schema.safeParse(gate.body);
  if (!parsed.success) return json(req, { error: 'Please check the form', fields: fieldErrors(parsed.error) }, 422);
  try {
    await saveLead({ ...toLead(parsed.data), ipHash: ipHash(gate.ip) });
    if (after) await after(parsed.data);
    return json(req, { ok: true });
  } catch (err) {
    console.error(`[${bucket}]`, (err as Error).message);
    return json(req, { error: 'Something went wrong. Please try again.' }, 500);
  }
}
