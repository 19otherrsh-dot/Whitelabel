// The self-paced course: content (built from delivery/self-paced/*.md by scripts/build-course.mjs)
// and the rules for progress, quizzes, completion and the certificate. Pure functions, no I/O.
// The content includes the quiz answers, so only server code may import this file.
import 'server-only';
import data from '@/content/course.json';

export interface Lesson { id: string; title: string; minutes: number; summary: string | null; say: string | null; show: string | null; commands: string | null }
export interface QuizQuestion { id: string; text: string; options: string[]; answer: number }
export interface Module {
  n: number; title: string; length: string | null; outcome: string | null;
  assignment: { label: string; text: string } | null; check: string | null;
  lessons: Lesson[]; quiz: QuizQuestion[];
}

export const COURSE = data as { quizPassMark: number; modules: Module[] };
export const MODULES: Module[] = COURSE.modules;
export const LESSON_IDS = new Set(MODULES.flatMap((m) => m.lessons.map((l) => l.id)));
export const moduleByNumber = (n: number) => MODULES.find((m) => m.n === n) ?? null;

/** What the browser may see of a quiz: the questions and options, never which one is right. */
export function publicQuiz(m: Module) {
  return m.quiz.map(({ id, text, options }) => ({ id, text, options }));
}

export interface QuizResult { score: number; total: number; passed: boolean; wrong: string[]; answered: number }

/** Grade a quiz. `answers` maps question id → chosen option index; anything else counts as wrong. */
export function gradeQuiz(m: Module, answers: Record<string, unknown>, passMark = COURSE.quizPassMark): QuizResult {
  let score = 0, answered = 0;
  const wrong: string[] = [];
  for (const q of m.quiz) {
    const raw = answers[q.id];
    const pick = typeof raw === 'number' ? raw : typeof raw === 'string' && /^\d+$/.test(raw) ? Number(raw) : null;
    if (pick !== null && pick >= 0 && pick < q.options.length) answered++;
    if (pick === q.answer) score++; else wrong.push(q.id);
  }
  const total = m.quiz.length;
  // The pass mark is written "4 of 5"; scale it if a quiz has a different number of questions.
  const need = Math.ceil((passMark / 5) * total);
  return { score, total, passed: total > 0 && score >= need, wrong, answered };
}

export type SubmissionStatus = 'none' | 'submitted' | 'complete' | 'not_yet';
export interface MemberCourseState {
  done: Set<string>;                                                    // lesson ids marked as watched
  attempts: { module: number; passed: boolean; score: number; total: number; created_at: string }[];
  submissions: { module: number; status: 'submitted' | 'complete' | 'not_yet'; created_at: string }[];
}

export interface ModuleStatus {
  n: number; lessonsDone: number; lessonsTotal: number;
  quiz: { passed: boolean; best: number | null; total: number; attempts: number };
  submission: SubmissionStatus;
  complete: boolean;                                                    // quiz passed and submission marked complete
  started: boolean;
}

export function moduleStatus(m: Module, s: MemberCourseState): ModuleStatus {
  const lessonsDone = m.lessons.filter((l) => s.done.has(l.id)).length;
  const tries = s.attempts.filter((a) => a.module === m.n);
  const subs = s.submissions.filter((x) => x.module === m.n).sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
  // Once any submission for a module is marked complete, it stays complete.
  const submission: SubmissionStatus = subs.some((x) => x.status === 'complete') ? 'complete' : subs[0]?.status ?? 'none';
  const passed = tries.some((a) => a.passed);
  return {
    n: m.n, lessonsDone, lessonsTotal: m.lessons.length,
    quiz: { passed, best: tries.length ? Math.max(...tries.map((a) => a.score)) : null, total: m.quiz.length, attempts: tries.length },
    submission, complete: passed && submission === 'complete',
    started: lessonsDone > 0 || tries.length > 0 || subs.length > 0,
  };
}

export function courseStatus(s: MemberCourseState) {
  const modules = MODULES.map((m) => moduleStatus(m, s));
  const lessonsTotal = modules.reduce((a, m) => a + m.lessonsTotal, 0);
  const lessonsDone = modules.reduce((a, m) => a + m.lessonsDone, 0);
  return {
    modules, lessonsDone, lessonsTotal,
    modulesComplete: modules.filter((m) => m.complete).length,
    complete: modules.length > 0 && modules.every((m) => m.complete),
    /** For the self-paced money-back window: a module counts once its quiz is passed or its work accepted. */
    modulesUsed: modules.filter((m) => m.quiz.passed || m.submission === 'complete').length,
    next: modules.find((m) => !m.complete)?.n ?? null,
  };
}

/** A certificate code like 7KQ2-M9XD-4TPA: no 0/O/1/I so it can be read out and typed. */
export function certificateCode(random: (n: number) => Uint8Array): string {
  const abc = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  const b = random(12);
  const s = Array.from(b, (x) => abc[x % abc.length]).join('');
  return `${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}`;
}

export { inlineParts } from './inline';
