import 'server-only';
import type Stripe from 'stripe';
import { env } from './env';
import { stripe } from './stripe';
import { supabaseAdmin } from './supabase/admin';
import { cohortById, logAdmin } from './data';
import { money, renewedUntil } from './rules';
import { sendMail } from './email';

export type RenewalOffer = { enrollmentId: string; cohortName: string; price: number; currency: string; months: number; libraryUntil: string | null };

/** The member's renewal offer, if their cohort has a renewal price. */
export async function renewalOffer(memberId: string): Promise<RenewalOffer | null> {
  const { data: en } = await supabaseAdmin().from('enrollments').select('id, cohort_id, status, library_until').eq('member_id', memberId).eq('status', 'active').order('created_at', { ascending: false }).limit(1).maybeSingle();
  if (!en) return null;
  const c = await cohortById(en.cohort_id);
  if (!c || c.price_renewal == null) return null;
  return { enrollmentId: en.id, cohortName: c.name, price: c.price_renewal, currency: c.currency, months: c.renewal_months ?? 12, libraryUntil: en.library_until };
}

/** Invoice settings shared by seat checkouts and renewals (a PDF invoice with the buyer's tax details). */
export function invoiceParams(description: string): Partial<Stripe.Checkout.SessionCreateParams> {
  if (env().STRIPE_INVOICES !== 'true') return {};
  return { invoice_creation: { enabled: true, invoice_data: { description, footer: env().BRAND_NAME } }, tax_id_collection: { enabled: true } };
}

export async function startRenewal(memberId: string, email: string): Promise<{ ok: true; url: string } | { ok: false; message: string }> {
  const offer = await renewalOffer(memberId);
  if (!offer) return { ok: false, message: 'Renewals aren’t available for your seat. Reply to any of our emails and we’ll help.' };
  const e = env();
  const { data: en } = await supabaseAdmin().from('enrollments').select('stripe_customer').eq('id', offer.enrollmentId).maybeSingle();
  const name = `${offer.cohortName} · library and updates, ${offer.months} months`;
  try {
    const s = await stripe().checkout.sessions.create({
      mode: 'payment',
      ...(en?.stripe_customer ? { customer: en.stripe_customer } : { customer_email: email, customer_creation: 'always' as const }),
      line_items: [{ quantity: 1, price_data: { currency: offer.currency, unit_amount: offer.price, product_data: { name, description: 'New kit releases and updates in your member area.' }, ...(e.STRIPE_AUTOMATIC_TAX === 'true' ? { tax_behavior: 'exclusive' as const } : {}) } }],
      metadata: { type: 'renewal', enrollment_id: offer.enrollmentId, member_id: memberId, months: String(offer.months) },
      payment_intent_data: { metadata: { type: 'renewal', enrollment_id: offer.enrollmentId } },
      allow_promotion_codes: true,
      ...(e.STRIPE_AUTOMATIC_TAX === 'true' ? { automatic_tax: { enabled: true } } : {}),
      ...invoiceParams(name),
      success_url: `${e.APP_URL}/member?ok=${encodeURIComponent('Thank you. Your library access has been renewed.')}`,
      cancel_url: `${e.APP_URL}/member/renew`,
    }, { idempotencyKey: `renew-${offer.enrollmentId}-${new Date().toISOString().slice(0, 13)}` });
    return { ok: true, url: s.url! };
  } catch (err) {
    console.error('[renewal] stripe error', (err as Error).message);
    return { ok: false, message: 'Checkout is unavailable right now. Please try again in a few minutes.' };
  }
}

/** Paid renewal → extend library access. Safe to run more than once for the same session. */
export async function fulfilRenewal(s: Stripe.Checkout.Session): Promise<'renewed' | 'already' | 'unpaid' | 'flagged'> {
  if (s.payment_status !== 'paid' && s.payment_status !== 'no_payment_required') return 'unpaid';
  const sb = supabaseAdmin();
  const { data: done } = await sb.from('renewals').select('id').eq('stripe_checkout_session', s.id).maybeSingle();
  if (done) return 'already';
  const enrollmentId = s.metadata?.enrollment_id, memberId = s.metadata?.member_id, months = Number(s.metadata?.months);
  const { data: en } = enrollmentId ? await sb.from('enrollments').select('id, member_id, cohort_id, library_until').eq('id', enrollmentId).maybeSingle() : { data: null };
  if (!en || en.member_id !== memberId || !(months > 0)) {
    await logAdmin(null, 'renewal_missing_data', s.id, { enrollmentId, memberId, months });
    return 'flagged';
  }
  const after = renewedUntil(en.library_until, months);
  const { error } = await sb.from('renewals').insert({
    enrollment_id: en.id, member_id: en.member_id, stripe_checkout_session: s.id,
    stripe_payment_intent: typeof s.payment_intent === 'string' ? s.payment_intent : s.payment_intent?.id ?? null,
    amount: s.amount_total ?? 0, currency: s.currency ?? 'usd', months, library_until_before: en.library_until, library_until_after: after,
  });
  if (error) { if (error.code === '23505') return 'already'; throw new Error(`renewal insert: ${error.message}`); }
  await sb.from('enrollments').update({ library_until: after }).eq('id', en.id);
  await logAdmin(null, 'renewed', en.id, { months, until: after });
  const { data: m } = await sb.from('members').select('email, full_name').eq('id', en.member_id).maybeSingle();
  const c = await cohortById(en.cohort_id);
  if (m?.email) await sendMail({ to: m.email, subject: 'Your library access is renewed', text: `Hi${m.full_name ? ` ${m.full_name.split(' ')[0]}` : ''},\n\nThank you. Your library access and updates${c ? ` for ${c.name}` : ''} now run until ${new Date(after).toLocaleDateString('en-US', { dateStyle: 'long' })}. New releases appear in your member area: ${env().APP_URL}/member\n\n${env().BRAND_NAME}` });
  return 'renewed';
}

/** A fully refunded renewal takes the added months back. Returns true if the charge was a renewal. */
export async function refundRenewal(ch: Stripe.Charge): Promise<boolean> {
  const pi = typeof ch.payment_intent === 'string' ? ch.payment_intent : ch.payment_intent?.id;
  if (!pi) return false;
  const sb = supabaseAdmin();
  const { data: r } = await sb.from('renewals').select('id, enrollment_id, library_until_before, library_until_after, amount, currency').eq('stripe_payment_intent', pi).maybeSingle();
  if (!r) return false;
  if (!ch.refunded) { await logAdmin(null, 'partial_renewal_refund', r.enrollment_id, { amount_refunded: ch.amount_refunded }); return true; }
  const { data: en } = await sb.from('enrollments').select('library_until').eq('id', r.enrollment_id).maybeSingle();
  // Only roll back if nothing else changed access since this renewal.
  if (en && en.library_until === r.library_until_after) await sb.from('enrollments').update({ library_until: r.library_until_before }).eq('id', r.enrollment_id);
  await logAdmin(null, 'renewal_refunded', r.enrollment_id, { amount: money(ch.amount_refunded, ch.currency) });
  return true;
}
