// CORS for the public form endpoints. The static marketing site lives on a
// different origin, so it needs explicit permission to POST here.

export function normaliseOrigin(o: string | null): string {
  return (o ?? '').trim().replace(/\/+$/, '').toLowerCase();
}

export function isAllowedOrigin(origin: string | null, allowed: string[]): boolean {
  const o = normaliseOrigin(origin);
  if (!o) return false;
  return allowed.map(normaliseOrigin).includes(o);
}

export function corsHeaders(origin: string | null, allowed: string[]): Record<string, string> {
  if (!isAllowedOrigin(origin, allowed)) return { Vary: 'Origin' };
  return {
    'Access-Control-Allow-Origin': normaliseOrigin(origin),
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Max-Age': '86400',
    Vary: 'Origin',
  };
}
