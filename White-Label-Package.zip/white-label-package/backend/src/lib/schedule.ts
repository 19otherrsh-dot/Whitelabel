// The scheduled emails: which ones are due right now. Pure (no database, no sending), so every rule is
// tested. The runner (lib/scheduleRun.ts) loads the data, asks this module what's due, and sends each
// email once, recording it in email_log.
//
// Every email has a window: it goes out the first time the job runs inside it, and never after, so
// switching the job on late doesn't flood people with stale reminders. The tightest window is one hour
// (the "starting soon" reminders), so run the job at least every hour; every 15 minutes is better.

const H = 3600_000, D = 24 * H;

export type SchedCohort = { id: string; name: string; time_zone: string; price_renewal?: number | null; currency?: string };
export type SchedSession = { id: string; cohort_id: string; position: number; title: string; starts_at: string; ends_at: string; join_url: string | null; replay_url: string | null; have_ready?: string | null; homework?: string | null };
export type SchedEnrollment = { id: string; member_id: string; cohort_id: string; seat: string; status: string; library_until: string | null; support_until: string | null };
export type SchedMember = { id: string; email: string; full_name: string | null };
export type SchedCall = { id: string; cohort_id: string; starts_at: string; ends_at: string; join_url: string | null };
export type SchedLead = { id: string; email: string | null; name: string | null; created_at: string };
export type SchedInput = {
  now: Date;
  brand: string; appUrl: string; siteUrl: string; supportEmail: string; communityUrl?: string;
  cohorts: SchedCohort[]; sessions: SchedSession[]; enrollments: SchedEnrollment[]; members: SchedMember[]; calls: SchedCall[];
  trainingLeads: SchedLead[]; training: { start?: string; joinUrl?: string; replayUrl?: string; timeZone?: string };
  sent: Set<string>;
};
export type DueEmail = { key: string; kind: string; to: string; memberId?: string; leadId?: string; subject: string; text: string };

// Defaults from the curriculum (delivery/curriculum/session-0n.md); a session's own fields override them.
export const HAVE_READY: Record<number, string> = {
  1: 'the kit downloaded, your Claude sign-in, and your for-claude folder',
  2: 'your ten things worksheet and a GitHub (or GitLab) account',
  3: 'the for-claude folder with your documents and writing samples',
  4: 'sign-ins for the tools your department needs (you type them yourself; never share them)',
  5: 'your phone with the Claude app signed in',
  6: 'your five-minute demo, tested twice',
};
export const HOMEWORK: Record<number, string> = {
  1: '1. Finish the interview\'s company and offers sections if you didn\'t.\n2. Fill in the ten things worksheet: ten pieces of repeat work your first department should do.\n3. Collect your website, one proposal, your pricing, a call transcript or notes, and three to five things you wrote yourself.\n4. Run bin/wf backup once.',
  2: '1. Finish the onboarding interview (all sections).\n2. Put your website, a proposal, pricing, a call transcript or notes and three to five pieces of your own writing in one folder.\n3. Read your department plan and mark anything wrong.\n4. bin/wf backup.',
  3: '1. Run two more jobs from your first-week plan. Reject anything that\'s wrong, with a reason.\n2. List the tools your department needs and check you can sign in to each (never share a password).\n3. If a tool isn\'t available, decide what file will replace it.\n4. bin/wf backup.',
  4: '1. Run the department every working day until Session 5; approve or reject everything with reasons.\n2. Write down which jobs you\'d trust on a timer, and when.\n3. Install the Claude app on your phone with the same account.\n4. bin/wf backup.',
  5: '1. Let the schedules run; every morning approve or reject with reasons.\n2. Prepare your five-minute demo and test the live job twice.\n3. Read the rubric; book the clinic if anything is red.\n4. bin/wf backup.',
};

export function when(iso: string, tz: string, opts: Intl.DateTimeFormatOptions = { weekday: 'long', month: 'long', day: 'numeric', hour: 'numeric', minute: '2-digit' }) {
  try { return new Date(iso).toLocaleString('en-US', { ...opts, timeZone: tz, timeZoneName: 'short' }); } catch { return new Date(iso).toUTCString(); }
}
const day = (iso: string) => new Date(iso).toLocaleDateString('en-US', { dateStyle: 'long', timeZone: 'UTC' });
const first = (name: string | null) => (name ? ` ${name.trim().split(/\s+/)[0]}` : '');
const inWin = (t: number, a: number, b: number) => t >= a && t < b;
const erased = (email: string) => /@invalid\.example$/i.test(email);

export function dueEmails(d: SchedInput): DueEmail[] {
  const out: DueEmail[] = [];
  const t = d.now.getTime();
  const sig = `\n\n${d.brand}`;
  const memberArea = `${d.appUrl.replace(/\/$/, '')}/member`;
  const add = (e: DueEmail) => { if (!d.sent.has(e.key) && e.to && !erased(e.to)) out.push(e); };
  const members = new Map(d.members.map((m) => [m.id, m]));
  const cohorts = new Map(d.cohorts.map((c) => [c.id, c]));
  const sessionsOf = (cid: string) => d.sessions.filter((s) => s.cohort_id === cid).sort((a, b) => a.position - b.position);

  for (const en of d.enrollments) {
    if (en.status !== 'active') continue;
    const m = members.get(en.member_id); const c = cohorts.get(en.cohort_id);
    if (!m || !c) continue;
    const ss = sessionsOf(c.id); const s1 = ss[0]; const last = ss.at(-1);
    const hi = `Hi${first(m.full_name)},`;
    const base = { to: m.email, memberId: m.id };

    if (s1) {
      const st = Date.parse(s1.starts_at);
      if (inWin(t, st - 7 * D, st - D)) add({ ...base, key: `prep:${en.id}`, kind: 'prep', subject: 'Before Session 1: 30 minutes of prep',
        text: `${hi}\n\nSession 1 is on ${when(s1.starts_at, c.time_zone)}. Thirty minutes now makes it smooth:\n\n1. Check you can install software on your computer (work laptops: ask IT now).\n2. Check your Claude plan works (Pro, Max, Team or Enterprise), and put the Claude app on your phone.\n3. Download the kit from your member area (${memberArea}). Don't install it yet; we do that together.\n4. Make a folder called for-claude with your website address, a proposal, your prices, a call transcript or notes, and three to five things you wrote yourself.\n5. Have a first guess at your first department: outreach, content, delivery, admin, or replies and support.\n\nWhen you've done the setup steps in the member area, press "I've finished these steps" so we know you're ready.\n\nThe build guarantee needs live attendance at all six sessions. If you know you'll miss one, reply and tell us now.${sig}` });
      if (inWin(t, st - D, st - 3 * H)) add({ ...base, key: `eve:${en.id}`, kind: 'eve', subject: 'Tomorrow: Session 1',
        text: `${hi}\n\nSession 1 is tomorrow, ${when(s1.starts_at, c.time_zone)}.${s1.join_url ? `\nJoin: ${s1.join_url}` : ''}\n\nHave your laptop charged, the kit downloaded, and 30 minutes free afterwards in case your install needs a hand.\n\nAll sessions and links: ${memberArea}${sig}` });
    }

    for (const s of ss) {
      const st = Date.parse(s.starts_at), en_ = Date.parse(s.ends_at);
      if (inWin(t, st - 2 * H, st)) add({ ...base, key: `soon:${s.id}:${m.id}`, kind: 'reminder', subject: `Today at ${when(s.starts_at, c.time_zone, { hour: 'numeric', minute: '2-digit' })}: Session ${s.position} · ${s.title}`,
        text: `${hi}\n\nSession ${s.position}, ${s.title}, starts at ${when(s.starts_at, c.time_zone, { hour: 'numeric', minute: '2-digit' })}.${s.join_url ? `\nJoin: ${s.join_url}` : `\nThe join link is in your member area: ${memberArea}`}\n\nHave ready: ${s.have_ready || HAVE_READY[s.position] || 'your laptop and your questions'}.${sig}` });
      const hw = s.homework || HOMEWORK[s.position];
      if (s.replay_url && last && s.id !== last.id && inWin(t, en_, en_ + 5 * D)) add({ ...base, key: `rec:${s.id}:${m.id}`, kind: 'recording', subject: `Session ${s.position} recording${hw ? ' and homework' : ''}`,
        text: `${hi}\n\nThe recording of Session ${s.position} is up: ${s.replay_url}\n${hw ? `\nHomework before the next session:\n${hw}\n` : ''}\nStuck? ${d.communityUrl ? `Post in the community (${d.communityUrl}) or reply` : 'Reply'} to this email.${sig}` });
    }

    for (const call of d.calls.filter((x) => x.cohort_id === c.id)) {
      const st = Date.parse(call.starts_at);
      if (inWin(t, st - 2 * D, st)) add({ ...base, key: `call:${call.id}:${m.id}`, kind: 'support-call', subject: `Support call on ${when(call.starts_at, c.time_zone, { month: 'long', day: 'numeric' })}`,
        text: `${hi}\n\nThe next support call is ${when(call.starts_at, c.time_zone)}.${call.join_url ? `\nJoin: ${call.join_url}` : ''}\n\nBring one thing that's stuck and, if you can, the output of bin/wf runs --week so we can see what your department did.${sig}` });
    }

    if (last) {
      const dd = Date.parse(last.ends_at);
      if (inWin(t, dd + 30 * D, dd + 33 * D)) add({ ...base, key: `30d:${en.id}`, kind: 'follow-up', subject: 'What has your department done?',
        text: `${hi}\n\nIt's 30 days since demo day. Would you run bin/wf outcomes and reply with the summary (or just the top three lines: runs, hours saved, what changed)?\n\nIt helps us improve the next cohort. With your permission, and only exactly as you say it, it may also become a result on our site. You can say no to that and still reply.${sig}` });
    }

    if (en.support_until) {
      const su = Date.parse(en.support_until);
      if (inWin(t, su - 10 * D, su - 7 * D)) add({ ...base, key: `support-end:${en.id}`, kind: 'support-ending', subject: `Your support window ends on ${day(en.support_until)}`,
        text: `${hi}\n\nYour cohort support ends on ${day(en.support_until)}. Your files, skills and workspace stay yours${en.library_until ? `, and library updates continue until ${day(en.library_until)}` : ''}.\n\nIf something is still stuck, now is the time: reply to this email or ask in your member area (${memberArea}/support).${sig}` });
    }

    if (en.library_until) {
      const lu = Date.parse(en.library_until);
      const renew = c.price_renewal != null ? `${d.appUrl.replace(/\/$/, '')}/member/renew` : null;
      if (inWin(t, lu - 30 * D, lu - 27 * D)) add({ ...base, key: `lib-30:${en.id}:${en.library_until.slice(0, 10)}`, kind: 'library-ending', subject: 'Your library access: renew or keep what you have',
        text: `${hi}\n\nYour library access and updates end on ${day(en.library_until)}. You keep everything you've downloaded, and it keeps working.\n\n${renew ? `To keep getting new releases, renew here: ${renew}` : `To keep getting new releases, reply to this email and we'll tell you how to renew.`}${sig}` });
      if (inWin(t, lu, lu + 3 * D)) add({ ...base, key: `lib-end:${en.id}:${en.library_until.slice(0, 10)}`, kind: 'library-ended', subject: 'Library access has ended (your files are yours)',
        text: `${hi}\n\nYour library access ended today. Everything on your computer is yours and keeps working; new releases are no longer available to download.${renew ? `\n\nWant them again? ${renew}` : ''}${sig}` });
    }
  }

  // Free training registrants (one email per address, however many times they registered).
  const ts = d.training.start ? Date.parse(d.training.start) : NaN;
  if (!Number.isNaN(ts)) {
    const tz = d.training.timeZone || 'UTC';
    const seen = new Set<string>();
    for (const l of d.trainingLeads) {
      const to = (l.email || '').trim().toLowerCase();
      if (!to || seen.has(to) || Date.parse(l.created_at) > ts) continue;
      seen.add(to);
      const hi = `Hi${first(l.name)},`;
      const stamp = d.training.start!.slice(0, 16);
      const base = { to, leadId: l.id };
      const join = d.training.joinUrl ? `\nJoin: ${d.training.joinUrl}` : '';
      if (inWin(t, ts - D, ts - 3 * H)) add({ ...base, key: `t-eve:${stamp}:${to}`, kind: 'training-reminder', subject: 'Tomorrow: the free live training',
        text: `${hi}\n\nA reminder that we're live tomorrow, ${when(d.training.start!, tz)}.${join}\n\nIf you've taken the free AI audit (${d.siteUrl.replace(/\/$/, '')}/audit.html), have your result open; we'll use a few in the session.${sig}` });
      if (inWin(t, ts - H, ts)) add({ ...base, key: `t-hour:${stamp}:${to}`, kind: 'training-reminder', subject: 'Starting in an hour',
        text: `We start in an hour, ${when(d.training.start!, tz, { hour: 'numeric', minute: '2-digit' })}.${join || `\nThe link is in your confirmation email.`}\nSee you there.${sig}` });
      if (d.training.replayUrl && inWin(t, ts + 2 * H, ts + 3 * D)) add({ ...base, key: `t-replay:${stamp}:${to}`, kind: 'training-replay', subject: 'The replay of the free training',
        text: `${hi}\n\nThanks for registering. Here's the replay: ${d.training.replayUrl}\n\nQuestions? Reply to this email.${sig}` });
    }
  }
  return out;
}
