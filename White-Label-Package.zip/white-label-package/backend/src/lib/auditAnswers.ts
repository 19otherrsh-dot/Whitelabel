// The free audit's answers in the shape the kit's onboarding interview reads
// (data/imports/audit-answers.json). Ids match the site's audit (assets/audit.js) and the kit's
// library: businessType is a vertical pack id, departments are department names on the map.
const SIZES: Record<string, string> = { solo: 'just me', s2: '2-5', s6: '6-15', s16: '16-50', s51: '51-200', s200: '200+' };
const TOOLS: Record<string, string> = { crm: 'a CRM', meet: 'meeting recorder', money: 'accounting or invoicing', leads: 'lead data', content: 'content tools', auto: 'automation (Zapier, Make, n8n)' };
const list = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string').slice(0, 20) : []);

export function auditAnswersFile(lead: { company: string | null; payload: Record<string, unknown> | null; created_at: string }) {
  const p = lead.payload ?? {};
  const type = typeof p.businessType === 'string' ? p.businessType : null;
  const size = typeof p.teamSize === 'string' ? p.teamSize : null;
  return {
    format: 'audit-answers/1',
    takenAt: lead.created_at,
    company: lead.company || null,
    businessType: type,                                   // agency | saas | consulting | professional | local | solo
    teamSize: size, teamSizeLabel: size ? SIZES[size] ?? size : null,
    departments: list(p.departments),                     // the departments they want help with first
    tools: list(p.tools).map((t) => ({ id: t, label: TOOLS[t] ?? t })),
    suggestedStart: list(p.start),                        // the audit's suggested first jobs
    estimate: typeof p.estimate === 'number' ? { yearlyValue: p.estimate, note: 'The audit’s estimate from its published method, not a promise.' } : null,
  };
}
