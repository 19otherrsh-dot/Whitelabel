import 'server-only';
import { env } from './env';
import { supabaseAdmin } from './supabase/admin';
import { sendMail } from './email';
import { dueEmails, type DueEmail, type SchedInput } from './schedule';

const MAX_PER_RUN = 300;   // keeps one run well inside a serverless time limit; the rest go next run

/** Load everything the schedule needs, from the last few months only. */
export async function loadSchedule(now = new Date()): Promise<SchedInput> {
  const sb = supabaseAdmin();
  const e = env();
  const since = new Date(now.getTime() - 120 * 864e5).toISOString();
  const [cohorts, sessions, enrollments, calls, leads, log] = await Promise.all([
    sb.from('cohorts').select('id, name, time_zone, price_renewal, currency'),
    sb.from('cohort_sessions').select('id, cohort_id, position, title, starts_at, ends_at, join_url, replay_url, have_ready, homework'),
    sb.from('enrollments').select('id, member_id, cohort_id, seat, status, library_until, support_until').eq('status', 'active'),
    sb.from('support_calls').select('id, cohort_id, starts_at, ends_at, join_url'),
    sb.from('leads').select('id, email, name, created_at').eq('kind', 'training').gte('created_at', since),
    sb.from('email_log').select('key').gte('sent_at', since),
  ]);
  const failed = [cohorts, sessions, enrollments, calls, leads, log].find((r) => r.error);
  if (failed?.error) throw new Error(failed.error.message);
  const memberIds = [...new Set((enrollments.data ?? []).map((x) => x.member_id))];
  const { data: members, error } = memberIds.length ? await sb.from('members').select('id, email, full_name').in('id', memberIds) : { data: [], error: null };
  if (error) throw new Error(error.message);
  return {
    now, brand: e.BRAND_NAME, appUrl: e.APP_URL, siteUrl: e.SITE_URL, supportEmail: e.SUPPORT_EMAIL, communityUrl: e.COMMUNITY_URL || undefined,
    cohorts: cohorts.data ?? [], sessions: sessions.data ?? [], enrollments: enrollments.data ?? [], members: members ?? [], calls: calls.data ?? [],
    trainingLeads: leads.data ?? [], training: { start: e.TRAINING_START || undefined, joinUrl: e.TRAINING_JOIN_URL || undefined, replayUrl: e.TRAINING_REPLAY_URL || undefined, timeZone: e.TRAINING_TIME_ZONE },
    sent: new Set((log.data ?? []).map((r) => r.key)),
  };
}

/** What would go out right now (for the admin preview). */
export async function previewDue(now = new Date()): Promise<DueEmail[]> {
  return dueEmails(await loadSchedule(now));
}

/**
 * Send everything that's due, each exactly once: the email_log row is claimed first (its key is unique),
 * so two overlapping runs can't both send the same email.
 */
export async function runSchedule(now = new Date()): Promise<{ due: number; sent: number; failed: number; skipped: number }> {
  const due = dueEmails(await loadSchedule(now));
  const sb = supabaseAdmin();
  let sent = 0, failed = 0, skipped = 0;
  for (const m of due.slice(0, MAX_PER_RUN)) {
    const { error: claim } = await sb.from('email_log').insert({ key: m.key, kind: m.kind, member_id: m.memberId ?? null, lead_id: m.leadId ?? null, ok: null });
    if (claim) { skipped++; continue; }                     // already claimed by another run
    const r = await sendMail({ to: m.to, subject: m.subject, text: m.text });
    if (r.ok) { await sb.from('email_log').update({ ok: true }).eq('key', m.key); sent++; continue; }
    // Failed: keep a record for the admin page, and free the key so the next run tries again (inside the window).
    await sb.from('email_log').update({ key: `${m.key}#failed-${now.getTime()}`, ok: false, error: (r.error ?? 'failed').slice(0, 500) }).eq('key', m.key);
    failed++;
  }
  return { due: due.length, sent, failed, skipped: skipped + Math.max(0, due.length - MAX_PER_RUN) };
}
