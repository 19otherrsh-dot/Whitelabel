import 'server-only';
import type { SupabaseClient } from '@supabase/supabase-js';
import { entitlements, type EnrollmentLike } from './rules';

export interface MemberEnrollment extends EnrollmentLike {
  id: string;
  seat: 'founding' | 'vip';
  cohort_id: string;
  amount_paid: number;
  currency: string;
  setup_done_at?: string | null;
  cohorts: { name: string; slug: string; time_zone: string; self_paced?: boolean; refund_days?: number } | null;
}

/**
 * Everything the member area needs, read with the member's own client so
 * row-level security decides what comes back.
 */
export async function loadMember(sb: SupabaseClient, userId: string) {
  const [{ data: member }, { data: enrollments }] = await Promise.all([
    sb.from('members').select('id, email, full_name, company').eq('id', userId).maybeSingle(),
    sb.from('enrollments').select('id, seat, status, cohort_id, created_at, library_until, support_until, setup_done_at, amount_paid, currency, cohorts(name, slug, time_zone, self_paced, refund_days)').eq('member_id', userId).order('created_at', { ascending: false }),
  ]);
  const list = (enrollments ?? []) as unknown as MemberEnrollment[];
  const current = list.find((e) => e.status === 'active') ?? list[0] ?? null;
  return { member, enrollment: current, ent: entitlements(current) };
}
