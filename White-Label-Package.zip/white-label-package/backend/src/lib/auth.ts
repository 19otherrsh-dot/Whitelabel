import 'server-only';
import { redirect } from 'next/navigation';
import { currentUser } from './supabase/server';
import { supabaseAdmin } from './supabase/admin';

/** For member pages: the signed-in user, or a redirect to /login. */
export async function requireUser(next = '/member') {
  const { sb, user } = await currentUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(next)}`);
  return { sb, user };
}

export async function isAdmin(userId: string): Promise<boolean> {
  const { data } = await supabaseAdmin().from('admins').select('user_id').eq('user_id', userId).maybeSingle();
  return !!data;
}

/** For admin pages and actions: a signed-in admin, or a 404-style redirect. */
export async function requireAdmin() {
  const { sb, user } = await requireUser('/admin');
  if (!(await isAdmin(user.id))) redirect('/member?notice=not-admin');
  return { sb, user };
}
