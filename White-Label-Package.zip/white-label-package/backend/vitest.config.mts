import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';

const here = (p: string) => fileURLToPath(new URL(p, import.meta.url));

export default defineConfig({
  resolve: {
    alias: {
      '@': here('./src'),
      // `server-only` throws outside Next's server build; tests run server code directly.
      'server-only': here('./tests/fakes/empty.ts'),
    },
  },
  test: { include: ['tests/**/*.test.ts', 'tests/**/*.test.tsx'], environment: 'node', setupFiles: ['tests/setup.ts'] },
});
