#!/usr/bin/env bash
# Runs the migration and the database tests on a throwaway local PostgreSQL.
# Needs PostgreSQL 15+ binaries (initdb, pg_ctl, psql) on PATH or in PG_BIN.
#   scripts/test-db.sh
set -euo pipefail
cd "$(dirname "$0")/.."
PG_BIN="${PG_BIN:-$(dirname "$(command -v initdb 2>/dev/null || ls -d /usr/lib/postgresql/*/bin/initdb 2>/dev/null | tail -1)")}"
TMP="$(mktemp -d)"; PORT="${PORT:-54329}"
if [ "$(id -u)" = "0" ]; then chown postgres "$TMP"; AS="su postgres -c"; else AS="bash -c"; fi
cleanup() { $AS "$PG_BIN/pg_ctl -D $TMP/data -m immediate stop" >/dev/null 2>&1 || true; rm -rf "$TMP"; }
trap cleanup EXIT
$AS "$PG_BIN/initdb -D $TMP/data -A trust -U postgres" >/dev/null
$AS "$PG_BIN/pg_ctl -D $TMP/data -o '-p $PORT -k $TMP -c listen_addresses=' -l $TMP/log -w start" >/dev/null
PSQL="psql -X -q -h $TMP -p $PORT -U postgres -v ON_ERROR_STOP=1"
$PSQL -c 'create database t'
$PSQL -d t -f supabase/tests/supabase_stub.sql
for m in supabase/migrations/*.sql; do $PSQL -d t -f "$m"; done
for m in supabase/migrations/*.sql; do $PSQL -d t -f "$m" 2>/dev/null; done   # migrations must be safe to re-run (notices hidden)
$PSQL -d t -f supabase/seed.sql
$PSQL -d t -f supabase/tests/rls_test.sql 2>&1 | sed -e 's/^psql:[^ ]* NOTICE:  /  /'
