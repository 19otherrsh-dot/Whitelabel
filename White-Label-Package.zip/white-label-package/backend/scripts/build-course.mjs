#!/usr/bin/env node
// Builds the member-area course and the instructor exam from the delivery Markdown, so there is one
// source to edit:
//   ../delivery/self-paced/modules.md   -> modules and lessons
//   ../delivery/self-paced/quizzes.md   -> the six module quizzes (correct answers in **bold**)
//   ../delivery/instructor/exam.md      -> the 30 certification questions (★ = safety)
//   ../delivery/instructor/exam-answers.md -> the answer key
// Writes src/content/course.json and src/content/exam.json. Run after editing any of those files:
//   node scripts/build-course.mjs            (or --check to fail if the JSON is out of date)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const delivery = process.env.DELIVERY_DIR || path.resolve(root, '../delivery');

const clean = (s) => s.replace(/\s+/g, ' ').trim();
const unbold = (s) => clean(s.replace(/\*\*/g, ''));

/** Numbered items ("1. …" at the start of a line), each joined into one line. */
function numbered(text) {
  const out = [];
  let cur = null;
  for (const line of text.split('\n')) {
    const m = line.match(/^(\d+)\.\s+(.*)$/);
    if (m) { if (cur) out.push(cur); cur = { n: Number(m[1]), text: m[2] }; continue; }
    if (cur && line.trim() && !/^#/.test(line) && !/^★/.test(line.trim())) cur.text += ' ' + line.trim();
    else if (cur && /^#/.test(line)) { out.push(cur); cur = null; }
  }
  if (cur) out.push(cur);
  return out.map((x) => ({ n: x.n, text: clean(x.text) }));
}

/** Split "Question? a) one b) **two** c) three" into the stem, options and the bold (correct) option. */
function choices(text) {
  const marks = [...text.matchAll(/(\*\*)?\b([a-e])\) /g)];
  // Keep only a run of letters a, b, c… in order (ignores stray "x) " inside an answer).
  const seq = [];
  for (const m of marks) if (m[2].charCodeAt(0) - 97 === seq.length) seq.push(m);
  if (seq.length < 2) return null;
  const stem = unbold(text.slice(0, seq[0].index));
  const options = [];
  let correct = -1;
  seq.forEach((m, i) => {
    const end = i + 1 < seq.length ? seq[i + 1].index : text.length;
    const raw = text.slice(m.index, end);
    if (m[1] === '**') correct = i;
    options.push(unbold(raw.replace(/^(\*\*)?[a-e]\) /, '')));
  });
  return { stem, options, correct };
}

export function parseQuizzes(md) {
  const quizzes = {};
  const passLine = md.match(/pass mark (\d+) of (\d+)/i);
  for (const part of md.split(/^## Module (\d+)\s*$/m).slice(1).reduce((a, x, i, arr) => (i % 2 ? a : [...a, [arr[i], arr[i + 1]]]), [])) {
    const [n, body] = part;
    quizzes[n] = numbered(body).map((q) => {
      const tf = q.text.match(/^True or false: (.*?)\s*\*\*(True|False)\*\*\s*$/i);
      if (tf) return { id: `${n}.${q.n}`, text: `True or false: ${unbold(tf[1])}`, options: ['True', 'False'], answer: tf[2].toLowerCase() === 'true' ? 0 : 1 };
      const c = choices(q.text);
      if (!c || c.correct < 0) throw new Error(`Quiz ${n} question ${q.n}: no options or no bold answer`);
      return { id: `${n}.${q.n}`, text: c.stem, options: c.options, answer: c.correct };
    });
  }
  return { passMark: passLine ? Number(passLine[1]) : 4, quizzes };
}

export function parseModules(md) {
  const mods = [];
  const parts = md.split(/^## Module (\d+) · (.+)$/m);
  for (let i = 1; i < parts.length; i += 3) {
    const n = Number(parts[i]);
    const head = parts[i + 1];
    const body = parts[i + 2].split(/^---\s*$/m)[0];
    const title = clean(head.replace(/\(.*?\)\s*$/, ''));
    const length = (head.match(/\((≈[^)]*)\)/) || [])[1]?.replace(/ of video/, '') ?? null;
    const outcome = (body.match(/\*\*Module outcome:\*\*\s*([\s\S]*?)(?:\n\n|\n###)/) || [])[1];
    const assign = body.match(/\*\*(Assignment \d+|Final submission):\*\*\s*([\s\S]*?)(?:\n\n|$)/);
    const lessons = [];
    const blocks = body.split(/^### /m).slice(1);
    for (const b of blocks) {
      const [first, ...rest] = b.split('\n');
      const text = rest.join('\n').split(/\n\*\*(?:Assignment|Final submission)/)[0];
      const bullets = {};
      for (const m of text.matchAll(/^- \*\*(Say|Show|Commands):\*\*\s*([\s\S]*?)(?=^- \*\*|^\*\*|\n\n|$(?![\s\S]))/gm)) bullets[m[1].toLowerCase()] = clean(m[2]);
      // "### 1.3 Install on a Mac (7 min) · 1.4 Install on Windows (7 min)" is two lessons with one outline.
      for (const piece of first.split(/ · (?=\d+\.\d+ )/)) {
        const m = piece.match(/^(\d+\.\d+)\s+(.*?)\s*\((\d+) min\)\s*(?:—\s*(.*))?$/);
        if (!m) throw new Error(`Module ${n}: can't read lesson heading "${piece}"`);
        lessons.push({ id: m[1], title: clean(m[2]), minutes: Number(m[3]), summary: m[4] ? clean(m[4].replace(/\.$/, '')) : null, say: bullets.say ?? null, show: bullets.show ?? null, commands: bullets.commands ? unbold(bullets.commands) : null });
      }
    }
    mods.push({ n, title, length, outcome: outcome ? clean(outcome) : null, assignment: assign ? { label: assign[1], text: clean(assign[2]) } : null, lessons });
  }
  return mods;
}

export function parseSubmissionChecks(md) {
  const checks = {};
  for (const m of md.matchAll(/^\| (\d) \| (.+?) \|$/gm)) checks[m[1]] = clean(m[2]);
  return checks;
}

export function parseExam(examMd, keyMd) {
  const pass = examMd.match(/Pass: (\d+)% \((\d+) of (\d+)\)/);
  const minutes = Number((examMd.match(/^(\d+) minutes\./m) || [])[1] ?? 45);
  const key = Object.fromEntries(numbered(keyMd.split(/^★/m)[0]).map((x) => [x.n, x.text]));
  const qs = numbered(examMd.split(/^\d+ minutes\./m)[1] ?? examMd).map((q) => {
    const safety = q.text.startsWith('★');
    const text = q.text.replace(/^★\s*/, '');
    const k = key[q.n];
    if (!k) throw new Error(`Exam question ${q.n} has no answer in the key`);
    const tf = text.match(/^True or false: (.*)$/i);
    if (tf) {
      const ans = /^\*\*(True|False)\.?\*\*/i.exec(k);
      if (!ans) throw new Error(`Exam question ${q.n}: key should start with **True** or **False**`);
      return { n: q.n, safety, type: 'tf', text, options: ['True', 'False'], answer: ans[1].toLowerCase() === 'true' ? 0 : 1, key: unbold(k) };
    }
    const c = choices(text);
    if (c) {
      const ans = /^\*\*([a-e])\.?\*\*/.exec(k);
      if (!ans) throw new Error(`Exam question ${q.n}: key should start with the letter, e.g. **b.**`);
      return { n: q.n, safety, type: 'choice', text: c.stem, options: c.options, answer: ans[1].charCodeAt(0) - 97, key: unbold(k) };
    }
    return { n: q.n, safety, type: 'short', text: unbold(text), key: unbold(k) };
  });
  return { minutes, passPercent: pass ? Number(pass[1]) : 80, passScore: pass ? Number(pass[2]) : Math.ceil(qs.length * 0.8), questions: qs };
}

export function build() {
  const read = (p) => fs.readFileSync(path.join(delivery, p), 'utf8');
  const modules = parseModules(read('self-paced/modules.md'));
  const { passMark, quizzes } = parseQuizzes(read('self-paced/quizzes.md'));
  const checks = parseSubmissionChecks(read('self-paced/submission-guide.md'));
  for (const m of modules) { m.quiz = quizzes[m.n] ?? []; m.check = checks[m.n] ?? null; }
  const course = { source: 'delivery/self-paced', quizPassMark: passMark, modules };
  const exam = { source: 'delivery/instructor', ...parseExam(read('instructor/exam.md'), read('instructor/exam-answers.md')) };
  return { course, exam };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { course, exam } = build();
  const out = path.join(root, 'src/content');
  const files = { 'course.json': course, 'exam.json': exam };
  fs.mkdirSync(out, { recursive: true });
  let stale = 0;
  for (const [f, data] of Object.entries(files)) {
    const text = JSON.stringify(data, null, 2) + '\n';
    const p = path.join(out, f);
    if (process.argv.includes('--check')) { if (!fs.existsSync(p) || fs.readFileSync(p, 'utf8') !== text) { console.error(`${f} is out of date: run node scripts/build-course.mjs`); stale++; } }
    else fs.writeFileSync(p, text);
  }
  if (stale) process.exit(1);
  const lessons = course.modules.reduce((a, m) => a + m.lessons.length, 0);
  console.log(`${course.modules.length} modules, ${lessons} lessons, ${course.modules.reduce((a, m) => a + m.quiz.length, 0)} quiz questions; exam: ${exam.questions.length} questions (${exam.questions.filter((q) => q.safety).length} safety)`);
}
