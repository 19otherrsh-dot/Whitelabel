-- Run the scheduled emails every 15 minutes from Supabase itself (works on every Supabase plan,
-- and on any app host, including Vercel's Hobby plan, whose own cron runs only once a day).
--
-- 1. Database → Extensions: turn on pg_cron and pg_net.
-- 2. Replace the two values below, then run this in the SQL editor once.
--    APP_URL     your back end's address, e.g. https://app.yourbrand.com
--    CRON_SECRET the same value as the app's CRON_SECRET environment variable
-- To stop it: select cron.unschedule('scheduled-emails');

create extension if not exists pg_cron;
create extension if not exists pg_net;

select cron.schedule(
  'scheduled-emails',
  '*/15 * * * *',
  $$
  select net.http_get(
    url := 'https://APP_URL/api/cron/emails',
    headers := jsonb_build_object('Authorization', 'Bearer CRON_SECRET'),
    timeout_milliseconds := 60000
  );
  $$
);
