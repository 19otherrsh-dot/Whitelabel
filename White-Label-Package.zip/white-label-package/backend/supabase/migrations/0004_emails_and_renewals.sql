-- Scheduled emails (reminders, recordings, support and library notices) and paid renewals.
-- Safe to re-run.

-- One row per email the scheduler has sent (or tried to). The key makes every email go once:
-- e.g. "reminder:<session>:<member>". Server-only.
create table if not exists email_log (
  key        text primary key,
  kind       text not null,
  member_id  uuid references members(id) on delete set null,
  lead_id    uuid references leads(id) on delete set null,
  sent_at    timestamptz not null default now(),
  ok         boolean,
  error      text
);
create index if not exists email_log_sent on email_log (sent_at desc);
alter table email_log enable row level security;
revoke all on email_log from anon, authenticated;

-- What to bring and the homework for each session, shown in reminders and recording emails.
-- Empty = the defaults from the curriculum.
alter table cohort_sessions add column if not exists have_ready text;
alter table cohort_sessions add column if not exists homework text;

-- The fortnightly support calls after demo day.
create table if not exists support_calls (
  id         uuid primary key default gen_random_uuid(),
  cohort_id  uuid not null references cohorts(id) on delete cascade,
  starts_at  timestamptz not null,
  ends_at    timestamptz not null,
  join_url   text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);
create index if not exists support_calls_cohort on support_calls (cohort_id, starts_at);
alter table support_calls enable row level security;
drop policy if exists support_calls_read on support_calls;
create policy support_calls_read on support_calls for select using (has_active_enrollment(cohort_id) or is_admin());
drop policy if exists support_calls_admin on support_calls;
create policy support_calls_admin on support_calls for all using (is_admin()) with check (is_admin());

-- Renewing library access: price per renewal (minor units; null = renewals off) and how long it adds.
alter table cohorts add column if not exists price_renewal int check (price_renewal is null or price_renewal >= 0);
alter table cohorts add column if not exists renewal_months int not null default 12 check (renewal_months between 1 and 36);

create table if not exists renewals (
  id                      uuid primary key default gen_random_uuid(),
  enrollment_id           uuid not null references enrollments(id) on delete cascade,
  member_id               uuid not null references members(id) on delete cascade,
  stripe_checkout_session text unique not null,
  stripe_payment_intent   text,
  amount                  int not null default 0,
  currency                text not null default 'usd',
  months                  int not null,
  library_until_before    timestamptz,
  library_until_after     timestamptz not null,
  created_at              timestamptz not null default now()
);
alter table renewals enable row level security;
drop policy if exists renewals_self on renewals;
create policy renewals_self on renewals for select using (member_id = auth.uid() or is_admin());
