-- =====================================================================
-- Cohort back end · initial schema
-- Run with `supabase db push` (or paste into the SQL editor once).
--
-- Principles
--   * Row-level security is ON for every table. The browser only ever
--     holds the anon key; anything privileged runs on the server with
--     the service-role key (which bypasses RLS).
--   * Members can read their own rows and nothing else.
--   * Sessions and kit releases are visible only to members with an
--     active enrollment.
--   * Leads, holds and Stripe events are service-role only.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------- types ----------------------------------------------------
do $$ begin
  create type seat_kind as enum ('founding', 'vip');
exception when duplicate_object then null; end $$;

do $$ begin
  create type enrollment_status as enum ('active', 'refunded', 'revoked', 'transferred');
exception when duplicate_object then null; end $$;

do $$ begin
  create type lead_kind as enum ('audit', 'contact', 'waitlist', 'training');
exception when duplicate_object then null; end $$;

do $$ begin
  create type claim_status as enum ('open', 'approved', 'declined', 'refunded');
exception when duplicate_object then null; end $$;

do $$ begin
  create type support_status as enum ('open', 'waiting', 'closed');
exception when duplicate_object then null; end $$;

-- ---------- cohorts --------------------------------------------------
create table if not exists cohorts (
  id                uuid primary key default gen_random_uuid(),
  slug              text unique not null check (slug ~ '^[a-z0-9-]{2,60}$'),
  name              text not null,
  seats             int  not null check (seats >= 0),          -- total places, VIP included
  vip_seats         int  not null default 0 check (vip_seats >= 0), -- how many of those places can be VIP
  price_founding    int  not null check (price_founding >= 0),   -- minor units (cents)
  price_vip         int  not null check (price_vip >= 0),
  currency          text not null default 'usd' check (currency ~ '^[a-z]{3}$'),
  enrollment_closes timestamptz,
  time_zone         text not null default 'America/New_York',      -- how session times are shown
  support_days      int  not null default 90,
  library_months    int  not null default 12,
  is_open           boolean not null default true,
  created_at        timestamptz not null default now()
);

create table if not exists cohort_sessions (
  id          uuid primary key default gen_random_uuid(),
  cohort_id   uuid not null references cohorts(id) on delete cascade,
  position    int  not null check (position between 1 and 50),
  title       text not null,
  starts_at   timestamptz not null,
  ends_at     timestamptz not null,
  join_url    text,          -- only visible to enrolled members (RLS below)
  replay_url  text,
  unique (cohort_id, position)
);

-- ---------- people ---------------------------------------------------
create table if not exists members (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text not null,
  full_name   text,
  company     text,
  created_at  timestamptz not null default now()
);
create unique index if not exists members_email_idx on members (lower(email));

create table if not exists admins (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  created_at  timestamptz not null default now()
);

create table if not exists enrollments (
  id                       uuid primary key default gen_random_uuid(),
  member_id                uuid not null references members(id) on delete cascade,
  cohort_id                uuid not null references cohorts(id) on delete restrict,
  seat                     seat_kind not null,
  status                   enrollment_status not null default 'active',
  amount_paid              int  not null default 0,
  currency                 text not null default 'usd',
  stripe_checkout_session  text unique,
  stripe_payment_intent    text unique,
  stripe_customer          text,
  library_until            timestamptz,
  support_until            timestamptz,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now(),
  unique (member_id, cohort_id)
);
create index if not exists enrollments_cohort_idx on enrollments (cohort_id, seat, status);

-- A seat is held while a buyer is on the Stripe page, so two people
-- can't both pay for the last seat. Holds expire after 30 minutes.
create table if not exists checkout_holds (
  id                       uuid primary key default gen_random_uuid(),
  cohort_id                uuid not null references cohorts(id) on delete cascade,
  seat                     seat_kind not null,
  stripe_checkout_session  text unique,
  expires_at               timestamptz not null default now() + interval '30 minutes',
  created_at               timestamptz not null default now()
);
create index if not exists holds_cohort_idx on checkout_holds (cohort_id, seat, expires_at);

-- ---------- leads ----------------------------------------------------
create table if not exists leads (
  id                 uuid primary key default gen_random_uuid(),
  kind               lead_kind not null,
  email              text,
  name               text,
  company            text,
  payload            jsonb not null default '{}'::jsonb,
  marketing_consent  boolean not null default false,
  source_page        text,
  ip_hash            text,       -- salted SHA-256, never the raw address
  created_at         timestamptz not null default now()
);
create index if not exists leads_kind_idx on leads (kind, created_at desc);
create index if not exists leads_email_idx on leads (lower(email));

-- ---------- kit releases ---------------------------------------------
create table if not exists releases (
  id            uuid primary key default gen_random_uuid(),
  version       text unique not null check (version ~ '^[0-9]+\.[0-9]+\.[0-9]+([-.][0-9A-Za-z.]+)?$'),
  storage_path  text not null,   -- path inside the private "kit" bucket
  notes         text,
  sha256        text,
  size_bytes    bigint,
  is_latest     boolean not null default false,
  published_at  timestamptz not null default now()
);
create unique index if not exists releases_one_latest on releases (is_latest) where is_latest;

create table if not exists downloads (
  id          uuid primary key default gen_random_uuid(),
  member_id   uuid not null references members(id) on delete cascade,
  release_id  uuid not null references releases(id) on delete cascade,
  created_at  timestamptz not null default now()
);

-- ---------- support & guarantee --------------------------------------
create table if not exists support_requests (
  id          uuid primary key default gen_random_uuid(),
  member_id   uuid not null references members(id) on delete cascade,
  subject     text not null check (char_length(subject) between 3 and 160),
  body        text not null check (char_length(body) between 10 and 8000),
  status      support_status not null default 'open',
  admin_reply text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists guarantee_claims (
  id             uuid primary key default gen_random_uuid(),
  enrollment_id  uuid not null references enrollments(id) on delete cascade,
  member_id      uuid not null references members(id) on delete cascade,
  kind           text not null check (kind in ('cooling_off', 'build_guarantee')),
  reason         text not null check (char_length(reason) between 10 and 8000),
  evidence       jsonb not null default '{}'::jsonb,   -- e.g. sessions attended, homework links
  status         claim_status not null default 'open',
  admin_note     text,
  stripe_refund  text,
  created_at     timestamptz not null default now(),
  decided_at     timestamptz
);
create unique index if not exists claims_one_open on guarantee_claims (enrollment_id) where status = 'open';

-- Live attendance, recorded by staff (or imported from the meeting tool's
-- attendance report). The build guarantee depends on it.
create table if not exists attendance (
  session_id  uuid not null references cohort_sessions(id) on delete cascade,
  member_id   uuid not null references members(id) on delete cascade,
  attended    boolean not null default true,
  minutes     int,
  recorded_by uuid references auth.users(id) on delete set null,
  recorded_at timestamptz not null default now(),
  primary key (session_id, member_id)
);

-- ---------- Stripe idempotency & audit -------------------------------
create table if not exists stripe_events (
  id           text primary key,      -- Stripe event id (evt_…)
  type         text not null,
  received_at  timestamptz not null default now(),
  processed_at timestamptz,
  error        text
);

create table if not exists admin_log (
  id         bigserial primary key,
  actor      uuid references auth.users(id) on delete set null,
  action     text not null,
  target     text,
  detail     jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- ---------- helpers --------------------------------------------------
create or replace function is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from admins where user_id = auth.uid());
$$;

create or replace function has_active_enrollment(c uuid default null) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from enrollments e
    where e.member_id = auth.uid()
      and e.status = 'active'
      and (c is null or e.cohort_id = c)
  );
$$;

-- Seats left for a cohort and seat type, counting paid seats and live holds.
-- VIP places sit inside the total: founding can use any free place, VIP is
-- also capped at vip_seats. Keep in step with seatsLeftFor() in src/lib/rules.ts.
create or replace function seats_left(c uuid, s seat_kind) returns int
language sql stable security definer set search_path = public as $$
  with cap as (select seats, vip_seats from cohorts where id = c),
  taken as (
    select seat from enrollments where cohort_id = c and status = 'active'
    union all
    select seat from checkout_holds where cohort_id = c and expires_at > now()
  )
  select greatest(0, case
    when s = 'vip' then least(
      (select seats from cap) - (select count(*) from taken),
      (select vip_seats from cap) - (select count(*) from taken where seat = 'vip'))
    else (select seats from cap) - (select count(*) from taken)
  end)::int;
$$;

-- Atomically take a hold if a seat is free. Returns the hold id or null.
create or replace function take_hold(c uuid, s seat_kind) returns uuid
language plpgsql security definer set search_path = public as $$
declare h uuid;
begin
  perform pg_advisory_xact_lock(hashtext(c::text));   -- one lock per cohort: seat types share the total
  delete from checkout_holds where expires_at <= now();
  if seats_left(c, s) <= 0 then return null; end if;
  insert into checkout_holds (cohort_id, seat) values (c, s) returning id into h;
  return h;
end $$;

create or replace function touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists enrollments_touch on enrollments;
create trigger enrollments_touch before update on enrollments for each row execute function touch_updated_at();
drop trigger if exists support_touch on support_requests;
create trigger support_touch before update on support_requests for each row execute function touch_updated_at();

-- ---------- row-level security --------------------------------------
alter table cohorts           enable row level security;
alter table cohort_sessions   enable row level security;
alter table members           enable row level security;
alter table admins            enable row level security;
alter table enrollments       enable row level security;
alter table checkout_holds    enable row level security;
alter table leads             enable row level security;
alter table releases          enable row level security;
alter table downloads         enable row level security;
alter table support_requests  enable row level security;
alter table guarantee_claims  enable row level security;
alter table attendance        enable row level security;
alter table stripe_events     enable row level security;
alter table admin_log         enable row level security;

-- Cohort names, dates and prices are public information.
drop policy if exists cohorts_read on cohorts;
create policy cohorts_read on cohorts for select using (true);
drop policy if exists cohorts_admin on cohorts;
create policy cohorts_admin on cohorts for all using (is_admin()) with check (is_admin());

-- Session times and join links: enrolled members of that cohort, and admins.
drop policy if exists sessions_read on cohort_sessions;
create policy sessions_read on cohort_sessions for select using (has_active_enrollment(cohort_id) or is_admin());
drop policy if exists sessions_admin on cohort_sessions;
create policy sessions_admin on cohort_sessions for all using (is_admin()) with check (is_admin());

drop policy if exists members_self on members;
create policy members_self on members for select using (id = auth.uid() or is_admin());
drop policy if exists members_update_self on members;
create policy members_update_self on members for update using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists admins_read on admins;
create policy admins_read on admins for select using (user_id = auth.uid());

drop policy if exists enroll_self on enrollments;
create policy enroll_self on enrollments for select using (member_id = auth.uid() or is_admin());

drop policy if exists releases_read on releases;
create policy releases_read on releases for select using (has_active_enrollment() or is_admin());

drop policy if exists downloads_self on downloads;
create policy downloads_self on downloads for select using (member_id = auth.uid() or is_admin());

drop policy if exists support_self_read on support_requests;
create policy support_self_read on support_requests for select using (member_id = auth.uid() or is_admin());
drop policy if exists support_self_insert on support_requests;
create policy support_self_insert on support_requests for insert with check (member_id = auth.uid() and has_active_enrollment());

drop policy if exists claims_self_read on guarantee_claims;
create policy claims_self_read on guarantee_claims for select using (member_id = auth.uid() or is_admin());

drop policy if exists attendance_self on attendance;
create policy attendance_self on attendance for select using (member_id = auth.uid() or is_admin());

-- leads, checkout_holds, stripe_events, admin_log: no policies = no access
-- for anon/authenticated roles. Only the service role (server) can touch them.

-- ---------- function and column privileges ----------
-- take_hold reserves a seat, so only the server may call it (otherwise anyone
-- holding the public anon key could reserve every seat through the API).
revoke execute on function take_hold(uuid, seat_kind) from public, anon, authenticated;
grant execute on function take_hold(uuid, seat_kind) to service_role;
-- Members may edit their name and company, not the email used to match payments.
revoke update on members from anon, authenticated;
grant update (full_name, company) on members to authenticated;

-- ---------- storage --------------------------------------------------
insert into storage.buckets (id, name, public)
values ('kit', 'kit', false)
on conflict (id) do nothing;
-- No storage policies: files are only ever handed out as short-lived
-- signed URLs created on the server after an entitlement check.
