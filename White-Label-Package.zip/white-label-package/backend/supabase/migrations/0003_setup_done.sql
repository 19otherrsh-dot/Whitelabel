-- Setup completion: the member confirms the kit is installed and `bin/wf doctor` shows no problems,
-- so the instructor can chase anyone who isn't ready before Session 1. Set by the server only.
-- Safe to re-run.
alter table enrollments add column if not exists setup_done_at timestamptz;
