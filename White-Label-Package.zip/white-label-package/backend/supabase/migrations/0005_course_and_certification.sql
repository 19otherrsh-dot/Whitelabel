-- The self-paced course in the member area (lessons, quizzes, module submissions, certificate of
-- completion) and instructor certification (the online exam and certification records).
-- Course content itself lives in src/content/course.json, built from delivery/self-paced/*.md.
-- Safe to re-run.

-- A cohort can be a self-paced product: no live sessions, no build guarantee, a plain money-back window.
alter table cohorts add column if not exists self_paced boolean not null default false;
alter table cohorts add column if not exists refund_days int not null default 14 check (refund_days between 0 and 60);

-- Video and transcript links per lesson, set by staff in Admin → Course. Lesson ids look like "1.3".
create table if not exists course_media (
  lesson_id      text primary key check (lesson_id ~ '^[1-9][0-9]?\.[0-9]{1,2}$'),
  video_url      text check (video_url is null or video_url ~ '^https://'),
  transcript_url text check (transcript_url is null or transcript_url ~ '^https://'),
  updated_at     timestamptz not null default now()
);
alter table course_media enable row level security;
drop policy if exists course_media_read on course_media;
create policy course_media_read on course_media for select using (has_active_enrollment() or is_admin());
drop policy if exists course_media_admin on course_media;
create policy course_media_admin on course_media for all using (is_admin()) with check (is_admin());

-- Lessons a member has marked as watched. Members write their own rows while their seat is active.
create table if not exists course_progress (
  member_id  uuid not null references members(id) on delete cascade,
  lesson_id  text not null check (lesson_id ~ '^[1-9][0-9]?\.[0-9]{1,2}$'),
  done_at    timestamptz not null default now(),
  primary key (member_id, lesson_id)
);
alter table course_progress enable row level security;
drop policy if exists course_progress_read on course_progress;
create policy course_progress_read on course_progress for select using (member_id = auth.uid() or is_admin());
drop policy if exists course_progress_add on course_progress;
create policy course_progress_add on course_progress for insert with check (member_id = auth.uid() and has_active_enrollment());
drop policy if exists course_progress_remove on course_progress;
create policy course_progress_remove on course_progress for delete using (member_id = auth.uid());

-- Quiz attempts. Graded on the server (the answers never reach the browser), so inserts are server-only.
create table if not exists quiz_attempts (
  id         uuid primary key default gen_random_uuid(),
  member_id  uuid not null references members(id) on delete cascade,
  module     int not null check (module between 1 and 20),
  answers    jsonb not null default '{}' check (jsonb_typeof(answers) = 'object'),
  score      int not null check (score >= 0),
  total      int not null check (total > 0 and score <= total),
  passed     boolean not null,
  created_at timestamptz not null default now()
);
create index if not exists quiz_attempts_member on quiz_attempts (member_id, module, created_at desc);
alter table quiz_attempts enable row level security;
drop policy if exists quiz_attempts_read on quiz_attempts;
create policy quiz_attempts_read on quiz_attempts for select using (member_id = auth.uid() or is_admin());

-- Module assignments, reviewed by staff (delivery/self-paced/submission-guide.md). Server-only inserts.
create table if not exists course_submissions (
  id            uuid primary key default gen_random_uuid(),
  member_id     uuid not null references members(id) on delete cascade,
  module        int not null check (module between 1 and 20),
  body          text not null check (length(body) between 20 and 20000),
  link          text check (link is null or link ~ '^https://'),
  status        text not null default 'submitted' check (status in ('submitted', 'complete', 'not_yet')),
  reviewer_note text,
  reviewed_by   uuid references members(id) on delete set null,
  created_at    timestamptz not null default now(),
  reviewed_at   timestamptz
);
create index if not exists course_submissions_queue on course_submissions (status, created_at);
create index if not exists course_submissions_member on course_submissions (member_id, module, created_at desc);
alter table course_submissions enable row level security;
drop policy if exists course_submissions_read on course_submissions;
create policy course_submissions_read on course_submissions for select using (member_id = auth.uid() or is_admin());

-- Certificate of completion: one per member, with a public verification code.
create table if not exists course_certificates (
  id         uuid primary key default gen_random_uuid(),
  member_id  uuid unique not null references members(id) on delete cascade,
  name       text not null,
  code       text unique not null check (code ~ '^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$'),
  issued_at  timestamptz not null default now(),
  revoked_at timestamptz
);
alter table course_certificates enable row level security;
drop policy if exists course_certificates_read on course_certificates;
create policy course_certificates_read on course_certificates for select using (member_id = auth.uid() or is_admin());

-- Instructor certification records (delivery/instructor/certification.md, "Records"). Server-only.
create table if not exists instructors (
  id          uuid primary key default gen_random_uuid(),
  email       text unique not null,
  name        text not null,
  level       text not null default 'candidate' check (level in ('candidate', 'associate', 'lead', 'trainer')),
  status      text not null default 'in_progress' check (status in ('in_progress', 'certified', 'suspended', 'lapsed')),
  kit_major   int,
  parts       jsonb not null default '{}' check (jsonb_typeof(parts) = 'object'),
  certified_at timestamptz,
  renew_by    timestamptz,
  notes       text,
  created_at  timestamptz not null default now()
);
alter table instructors enable row level security;
revoke all on instructors from anon, authenticated;

-- The online written exam (Part 2). Candidates use a private link; only a hash of its token is stored.
create table if not exists exam_attempts (
  id           uuid primary key default gen_random_uuid(),
  instructor_id uuid not null references instructors(id) on delete cascade,
  token_hash   text unique not null,
  kit_version  text,
  created_by   uuid references members(id) on delete set null,
  created_at   timestamptz not null default now(),
  expires_at   timestamptz not null,
  started_at   timestamptz,
  deadline     timestamptz,
  submitted_at timestamptz,
  answers      jsonb not null default '{}' check (jsonb_typeof(answers) = 'object'),
  marks        jsonb not null default '{}' check (jsonb_typeof(marks) = 'object'),
  score        int,
  safety_ok    boolean,
  result       text not null default 'pending' check (result in ('pending', 'pass', 'fail')),
  graded_by    uuid references members(id) on delete set null,
  graded_at    timestamptz,
  check (deadline is null or started_at is not null)
);
create index if not exists exam_attempts_instructor on exam_attempts (instructor_id, created_at desc);
alter table exam_attempts enable row level security;
revoke all on exam_attempts from anon, authenticated;
