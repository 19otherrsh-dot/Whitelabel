-- Anonymous usage summaries that members choose to share from their workspace
-- (`bin/wf learn --export` writes the file; the member uploads it in the member area).
--
-- Deliberately anonymous: no member id, no email, no IP. The server checks the file's exact shape
-- (counts per kit skill only) before it is stored, so nothing else can be smuggled in.
-- Written and read only by the server (service role); no policies for browsers.
-- Safe to re-run.

create table if not exists usage_reports (
  id            uuid primary key default gen_random_uuid(),
  received_at   timestamptz not null default now(),
  kit_version   text check (kit_version is null or length(kit_version) <= 40),
  business_type text check (business_type is null or length(business_type) <= 60),
  team_size     text check (team_size is null or length(team_size) <= 20),
  generated_at  timestamptz,
  skills        jsonb not null check (jsonb_typeof(skills) = 'object')
);

create index if not exists usage_reports_received on usage_reports (received_at desc);

alter table usage_reports enable row level security;
revoke all on usage_reports from anon, authenticated;
