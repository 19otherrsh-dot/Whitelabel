-- Example cohort matching the site's default config. Edit before use.
-- Prices are in minor units (1497.00 USD = 149700).
insert into cohorts (slug, name, seats, vip_seats, price_founding, price_vip, currency, enrollment_closes, time_zone, support_days, library_months)
values ('founding-01', 'Founding Cohort 01', 50, 5, 149700, 500000, 'usd', '2027-01-11T15:00:00Z', 'America/New_York', 90, 12)
on conflict (slug) do nothing;

with c as (select id from cohorts where slug = 'founding-01')
insert into cohort_sessions (cohort_id, position, title, starts_at, ends_at)
select c.id, s.position, s.title, s.starts_at::timestamptz, s.ends_at::timestamptz from c,
(values
  (1, 'Session 1 · Foundations', '2027-01-11T15:00:00Z', '2027-01-11T17:00:00Z'),
  (2, 'Session 2 · Your workspace',           '2027-01-13T15:00:00Z', '2027-01-13T17:00:00Z'),
  (3, 'Session 3 · Encode your business',    '2027-01-15T15:00:00Z', '2027-01-15T17:00:00Z'),
  (4, 'Session 4 · Deploy your department',    '2027-01-18T15:00:00Z', '2027-01-18T17:00:00Z'),
  (5, 'Session 5 · Put it on a clock',          '2027-01-20T15:00:00Z', '2027-01-20T17:00:00Z'),
  (6, 'Session 6 · Demo day',                        '2027-01-22T15:00:00Z', '2027-01-22T17:00:00Z')
) as s(position, title, starts_at, ends_at)
on conflict (cohort_id, position) do nothing;

-- Make yourself an admin after your first sign-in:
--   insert into admins (user_id) select id from auth.users where email = 'you@yourbrand.com';
