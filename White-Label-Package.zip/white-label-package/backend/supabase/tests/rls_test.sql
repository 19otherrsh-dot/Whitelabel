-- Database tests: row-level security and seat counting.
-- Run with scripts/test-db.sh (plain PostgreSQL 15+ with supabase_stub.sql), or in a
-- throwaway Supabase branch. Any failed check raises an error and stops the script.
\set ON_ERROR_STOP on
set client_min_messages = warning;
\o /dev/null

-- ---------- fixtures (as the owner, which bypasses RLS) ----------
insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-00000000000a', 'alice@example.com'),
  ('00000000-0000-0000-0000-00000000000b', 'bob@example.com'),
  ('00000000-0000-0000-0000-00000000000c', 'carol@example.com'),
  ('00000000-0000-0000-0000-0000000000ad', 'admin@example.com');
insert into members (id, email) select id, email from auth.users;
insert into admins (user_id) values ('00000000-0000-0000-0000-0000000000ad');
insert into cohorts (id, slug, name, seats, vip_seats, price_founding, price_vip)
  values ('10000000-0000-0000-0000-000000000001', 'c1', 'Cohort 1', 4, 1, 149700, 500000);
insert into cohort_sessions (cohort_id, position, title, starts_at, ends_at, join_url)
  values ('10000000-0000-0000-0000-000000000001', 1, 'S1', now() + interval '1 day', now() + interval '1 day 2 hours', 'https://meet.example/secret');
insert into enrollments (member_id, cohort_id, seat, amount_paid) values
  ('00000000-0000-0000-0000-00000000000a', '10000000-0000-0000-0000-000000000001', 'founding', 149700),
  ('00000000-0000-0000-0000-00000000000b', '10000000-0000-0000-0000-000000000001', 'vip', 500000);
update enrollments set status = 'refunded' where member_id = '00000000-0000-0000-0000-00000000000b';
insert into releases (version, storage_path, is_latest) values ('1.0.0', 'releases/1.0.0/kit.zip', true);
insert into leads (kind, email) values ('audit', 'lead@example.com');
insert into support_requests (member_id, subject, body) values ('00000000-0000-0000-0000-00000000000a', 'Help me', 'Something is not working right');
insert into support_calls (cohort_id, starts_at, ends_at, join_url) values ('10000000-0000-0000-0000-000000000001', now() + interval '30 days', now() + interval '30 days 1 hour', 'https://meet.example/support');
insert into email_log (key, kind, member_id, ok) values ('prep:x', 'prep', '00000000-0000-0000-0000-00000000000a', true);
insert into renewals (enrollment_id, member_id, stripe_checkout_session, months, library_until_after)
  select id, member_id, 'cs_renew_a', 12, now() + interval '2 years' from enrollments where member_id = '00000000-0000-0000-0000-00000000000a';
insert into course_media (lesson_id, video_url) values ('1.1', 'https://video.example/1-1');
insert into quiz_attempts (member_id, module, answers, score, total, passed) values ('00000000-0000-0000-0000-00000000000a', 1, '{"1.1":2}', 5, 5, true);
insert into course_submissions (member_id, module, body) values ('00000000-0000-0000-0000-00000000000a', 1, 'doctor output pasted here, all fine');
insert into course_certificates (member_id, name, code) values ('00000000-0000-0000-0000-00000000000a', 'Alice', 'ABCD-EFGH-JKLM');
insert into instructors (id, email, name) values ('50000000-0000-0000-0000-000000000001', 'jo@example.com', 'Jo');
insert into exam_attempts (instructor_id, token_hash, expires_at) values ('50000000-0000-0000-0000-000000000001', 'hash', now() + interval '14 days');

create temp table expected as select (select count(*) from cohort_sessions) as sessions;
grant select on pg_temp.expected to authenticated;

create or replace function pg_temp.check(ok boolean, what text) returns void language plpgsql as $$
begin if not coalesce(ok, false) then raise exception 'FAILED: %', what; end if; raise notice 'ok  %', what; end $$;
set client_min_messages = notice;

-- ---------- seats (VIP inside the total) ----------
select pg_temp.check(seats_left('10000000-0000-0000-0000-000000000001', 'founding') = 3, 'founding: 4 total - 1 active');
select pg_temp.check(seats_left('10000000-0000-0000-0000-000000000001', 'vip') = 1, 'vip: refunded VIP frees its place');
select pg_temp.check(take_hold('10000000-0000-0000-0000-000000000001', 'vip') is not null, 'vip hold taken');
select pg_temp.check(take_hold('10000000-0000-0000-0000-000000000001', 'vip') is null, 'second vip hold refused (vip cap 1)');
select pg_temp.check(seats_left('10000000-0000-0000-0000-000000000001', 'founding') = 2, 'vip hold uses a place from the total');
select pg_temp.check(take_hold('10000000-0000-0000-0000-000000000001', 'founding') is not null, 'founding hold 1');
select pg_temp.check(take_hold('10000000-0000-0000-0000-000000000001', 'founding') is not null, 'founding hold 2');
select pg_temp.check(take_hold('10000000-0000-0000-0000-000000000001', 'founding') is null, 'sold out once holds fill the total');
update checkout_holds set expires_at = now() - interval '1 minute';
select pg_temp.check(seats_left('10000000-0000-0000-0000-000000000001', 'founding') = 3, 'expired holds release their places');
select take_hold('10000000-0000-0000-0000-000000000001', 'founding');
select pg_temp.check((select count(*) from checkout_holds) = 1, 'take_hold sweeps expired holds');
delete from checkout_holds;

-- ---------- anonymous visitor ----------
set role anon;
select pg_temp.check((select count(*) from cohorts where slug = 'c1') = 1, 'anon can read cohort names and prices');
select pg_temp.check((select count(*) from cohort_sessions) = 0, 'anon cannot see sessions or join links');
select pg_temp.check((select count(*) from enrollments) = 0, 'anon cannot see enrollments');
select pg_temp.check((select count(*) from leads) = 0, 'anon cannot read leads');
select pg_temp.check((select count(*) from releases) = 0, 'anon cannot see releases');
do $$ begin
  begin insert into leads (kind, email) values ('contact', 'x@example.com'); raise exception 'anon insert into leads should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'anon cannot write leads directly');
do $$ begin
  begin perform take_hold('10000000-0000-0000-0000-000000000001', 'founding'); raise exception 'anon take_hold should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'anon cannot reserve seats through the API');
do $$ begin
  begin perform count(*) from usage_reports; raise exception 'anon read of usage reports should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'anon cannot read usage reports');
reset role;

-- ---------- active member (alice) ----------
set role authenticated;
select set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-00000000000a', false);
select pg_temp.check((select count(*) from enrollments) = 1, 'alice sees only her enrollment');
select pg_temp.check((select count(*) from members) = 1, 'alice sees only her member row');
select pg_temp.check((select join_url from cohort_sessions limit 1) = 'https://meet.example/secret', 'alice sees her cohort join link');
select pg_temp.check((select count(*) from releases) = 1, 'alice can see kit releases');
select pg_temp.check((select count(*) from support_requests) = 1, 'alice sees her support request');
select pg_temp.check((select count(*) from leads) = 0, 'alice cannot read leads');
insert into support_requests (member_id, subject, body) values ('00000000-0000-0000-0000-00000000000a', 'Another', 'A second question here');
select pg_temp.check((select count(*) from support_requests) = 2, 'alice can open support requests');
do $$ begin
  begin insert into support_requests (member_id, subject, body) values ('00000000-0000-0000-0000-00000000000b', 'Spoof', 'Pretending to be bob'); raise exception 'spoofed insert should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'alice cannot open requests as someone else');
update enrollments set status = 'active', seat = 'vip' where member_id = '00000000-0000-0000-0000-00000000000a';
update members set full_name = 'Alice A' where id = '00000000-0000-0000-0000-00000000000a';
select pg_temp.check((select full_name from members) = 'Alice A', 'alice can edit her name');
do $$ begin
  begin update members set email = 'bob@example.com' where id = '00000000-0000-0000-0000-00000000000a'; raise exception 'email change should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'alice cannot change the email her payment is matched on');
do $$ begin
  begin insert into usage_reports (skills) values ('{"x":{}}'); raise exception 'member insert of usage report should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'members cannot write usage reports directly (only the server, after checking the shape)');
select pg_temp.check((select count(*) from support_calls) = 1, 'active member sees the support call link');
select pg_temp.check((select count(*) from renewals) = 1, 'member sees their own renewal');
do $$ begin
  begin perform count(*) from email_log; raise exception 'member read of email_log should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'the email log is server-only');
do $$ begin
  begin insert into support_calls (cohort_id, starts_at, ends_at) values ('10000000-0000-0000-0000-000000000001', now(), now() + interval '1 hour'); raise exception 'member insert of support call should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'members cannot add support calls');
do $$ begin
  begin insert into renewals (enrollment_id, member_id, stripe_checkout_session, months, library_until_after) values ((select id from enrollments limit 1), '00000000-0000-0000-0000-00000000000a', 'cs_fake', 36, now() + interval '10 years'); raise exception 'member insert of renewal should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'members cannot grant themselves a renewal');
select pg_temp.check((select count(*) from course_media) = 1, 'active member sees lesson video links');
insert into course_progress (member_id, lesson_id) values ('00000000-0000-0000-0000-00000000000a', '1.1');
select pg_temp.check((select count(*) from course_progress) = 1, 'member marks a lesson watched');
do $$ begin
  begin insert into course_progress (member_id, lesson_id) values ('00000000-0000-0000-0000-00000000000b', '1.2'); raise exception 'spoofed progress should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'members cannot mark lessons for someone else');
select pg_temp.check((select count(*) from quiz_attempts) = 1 and (select count(*) from course_submissions) = 1 and (select count(*) from course_certificates) = 1, 'member sees their own quiz attempts, submissions and certificate');
do $$ begin
  begin insert into quiz_attempts (member_id, module, score, total, passed) values ('00000000-0000-0000-0000-00000000000a', 2, 5, 5, true); raise exception 'member quiz insert should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'members cannot record their own quiz pass (graded on the server)');
do $$ begin
  begin update course_submissions set status = 'complete';   -- no update policy: changes nothing (or is refused)
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check((select status from course_submissions limit 1) = 'submitted', 'members cannot mark their own work complete');
do $$ begin
  begin insert into course_certificates (member_id, name, code) values ('00000000-0000-0000-0000-00000000000a', 'X', 'ZZZZ-ZZZZ-ZZZZ'); raise exception 'member certificate insert should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'members cannot issue themselves a certificate');
do $$ begin
  begin perform count(*) from exam_attempts; raise exception 'member read of exam attempts should fail';
  exception when insufficient_privilege then null; end;
end $$;
do $$ begin
  begin perform count(*) from instructors; raise exception 'member read of instructors should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'instructor records and exam attempts are server-only');
reset role;
select pg_temp.check((select seat from enrollments where member_id = '00000000-0000-0000-0000-00000000000a') = 'founding', 'members cannot change their own enrollment');

-- ---------- refunded member (bob) ----------
set role authenticated;
select set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-00000000000b', false);
select pg_temp.check((select count(*) from enrollments) = 1, 'bob still sees his (refunded) enrollment');
select pg_temp.check((select count(*) from cohort_sessions) = 0, 'refunded member loses session links');
select pg_temp.check((select count(*) from releases) = 0, 'refunded member loses downloads');
select pg_temp.check((select count(*) from support_requests) = 0, 'bob cannot see alice''s support requests');
do $$ begin
  begin insert into support_requests (member_id, subject, body) values ('00000000-0000-0000-0000-00000000000b', 'Help', 'I would like some help'); raise exception 'refunded insert should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'refunded member cannot open support requests');
select pg_temp.check((select count(*) from support_calls) = 0, 'refunded member loses the support call link');
select pg_temp.check((select count(*) from renewals) = 0, 'bob cannot see alice''s renewal');
select pg_temp.check((select count(*) from course_media) = 0, 'refunded member loses lesson video links');
select pg_temp.check((select count(*) from quiz_attempts) = 0 and (select count(*) from course_submissions) = 0 and (select count(*) from course_certificates) = 0 and (select count(*) from course_progress) = 0, 'bob cannot see alice''s course work');
do $$ begin
  begin insert into course_progress (member_id, lesson_id) values ('00000000-0000-0000-0000-00000000000b', '1.1'); raise exception 'refunded progress should fail';
  exception when insufficient_privilege then null; end;
end $$;
select pg_temp.check(true, 'refunded member cannot keep marking lessons');
reset role;

-- ---------- signed-in, never bought (carol) ----------
set role authenticated;
select set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-00000000000c', false);
select pg_temp.check((select count(*) from enrollments) = 0 and (select count(*) from cohort_sessions) = 0 and (select count(*) from releases) = 0, 'carol sees nothing private');
reset role;

-- ---------- admin ----------
set role authenticated;
select set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-0000000000ad', false);
select pg_temp.check((select count(*) from enrollments) = 2, 'admin sees all enrollments');
select pg_temp.check((select count(*) from cohort_sessions) = (select sessions from pg_temp.expected), 'admin sees sessions in every cohort');
select pg_temp.check((select count(*) from members) = 4, 'admin sees all members');
select pg_temp.check((select count(*) from leads) = 0, 'leads stay service-role only, even for admins in the browser');
select pg_temp.check((select count(*) from renewals) = 1 and (select count(*) from support_calls) = 1, 'admin sees renewals and support calls');
reset role;

-- ---------- service role ----------
set role service_role;
select pg_temp.check((select count(*) from leads) = 1, 'service role (server) reads leads');
insert into usage_reports (kit_version, skills) values ('1.0.0', '{"weekly-review":{"runs":3}}');
select pg_temp.check((select count(*) from usage_reports) = 1, 'service role stores usage reports');
do $$ begin
  begin insert into usage_reports (skills) values ('[1,2]'); raise exception 'non-object skills should fail';
  exception when check_violation then null; end;
end $$;
select pg_temp.check(true, 'usage report skills must be an object');
reset role;

-- ---------- constraints ----------
do $$ begin
  begin insert into enrollments (member_id, cohort_id, seat) values ('00000000-0000-0000-0000-00000000000a', '10000000-0000-0000-0000-000000000001', 'vip'); raise exception 'duplicate enrollment should fail';
  exception when unique_violation then null; end;
end $$;
select pg_temp.check(true, 'one enrollment per member per cohort');
do $$ begin
  begin insert into releases (version, storage_path, is_latest) values ('1.0.1', 'x', true); raise exception 'two latest releases should fail';
  exception when unique_violation then null; end;
end $$;
select pg_temp.check(true, 'only one release can be current');
do $$ begin
  begin insert into releases (version, storage_path) values ('v1', 'x'); raise exception 'bad version should fail';
  exception when check_violation then null; end;
end $$;
select pg_temp.check(true, 'release versions must be semver');

do $$ begin
  begin insert into renewals (enrollment_id, member_id, stripe_checkout_session, months, library_until_after) select enrollment_id, member_id, 'cs_renew_a', 12, now() from renewals limit 1; raise exception 'duplicate renewal should fail';
  exception when unique_violation then null; end;
end $$;
select pg_temp.check(true, 'a checkout session renews only once');
do $$ begin
  begin update cohorts set renewal_months = 99; raise exception 'bad renewal length should fail';
  exception when check_violation then null; end;
end $$;
select pg_temp.check(true, 'renewal length stays between 1 and 36 months');
do $$ begin
  begin insert into course_media (lesson_id, video_url) values ('1.2', 'http://insecure.example/v'); raise exception 'http video should fail';
  exception when check_violation then null; end;
end $$;
select pg_temp.check(true, 'lesson links must be https');
do $$ begin
  begin insert into course_certificates (member_id, name, code) values ('00000000-0000-0000-0000-00000000000a', 'Again', 'QQQQ-QQQQ-QQQQ'); raise exception 'second certificate should fail';
  exception when unique_violation then null; end;
end $$;
select pg_temp.check(true, 'one certificate per member');
do $$ begin
  begin insert into quiz_attempts (member_id, module, score, total, passed) values ('00000000-0000-0000-0000-00000000000a', 1, 6, 5, true); raise exception 'score above total should fail';
  exception when check_violation then null; end;
end $$;
select pg_temp.check(true, 'a quiz score cannot exceed the number of questions');

\o
\echo 'All database checks passed.'
