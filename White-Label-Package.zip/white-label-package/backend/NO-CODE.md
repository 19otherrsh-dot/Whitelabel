# Running the cohort without the back end (no-code)

The included app (`README.md`) is the complete version: one place for checkout, members,
downloads, refunds and admin, with the rules enforced in code. If a buyer would rather launch
with hosted tools and no developer, this is the same set of flows, built from mainstream
services. Everything here works with the static site as shipped; only `assets/config.js` changes.

Tool names are examples of each category. Any tool with the same capability works; check each
one's current plans and limits before committing.

| Job | Back-end app | No-code equivalent |
|---|---|---|
| Take payment | `/checkout` + Stripe Checkout | Stripe Payment Links |
| Stop at 50 places | seat holds in the database | Payment Link "Limit the number of payments" |
| Create the member and send the welcome | Stripe webhook → member + email | Automation (Zapier / Make / n8n) on "checkout completed" → list + email |
| Member area, sessions, recordings | `/member` | A community platform (Circle, Skool, Kajabi…) or a shared folder |
| Kit download | 2-minute signed link, library dates | Private download in the community platform, or a shared drive folder |
| Audit and contact forms | `/api/audit`, `/api/contact` | Automation webhook → sheet / CRM |
| Waitlist and training | `/join` | Form tool (Tally, Typeform) or the webinar tool's own registration |
| Support | `/member/support` | Help inbox or the community's support space |
| Refunds and the guarantee | `/member/guarantee` + admin | Email request → check attendance → refund in the Stripe Dashboard |
| Attendance | ticks in admin | The meeting tool's attendance report, saved to the sheet |

What you give up compared with the app: holds while someone pays (two buyers can race for the
last place, and Stripe stops the link only after the limit is reached), automatic end of access
after a refund, per-member library expiry, and one admin screen. All of these become manual
steps, listed below.

---

## 1. Checkout with Stripe Payment Links

1. In Stripe, create a product "Founding seat" with a one-time price, and "VIP seat".
2. Create a **Payment Link** for each. In the link's options:
   - **Limit the number of payments**: VIP places sit inside the total (the pricing page says
     "5 VIP places within the 50"), and two links can't share one limit. Simplest: Founding
     45 and VIP 5. Edit the Founding limit if VIP doesn't sell out.
   - Change the **deactivation message** to point people to the waitlist.
   - **Collect customer names**. Turn on **Collect tax automatically** if you use Stripe Tax.
   - **Require agreement to terms of service** (set your terms URL first under
     Settings → Public details: `https://<your site>/terms.html`).
   - **After payment** → redirect to `https://<your site>/thank-you.html?for=founding`
     (and `?for=vip` for the VIP link).
3. In **Settings → Checkout and Payment Links**, add your refund policy and support email.
4. Optional: use your own subdomain for links (Stripe custom domains).
5. In the site's `assets/config.js`:

```js
links: {
  checkoutFounding: "https://buy.stripe.com/…",
  checkoutVip:      "https://buy.stripe.com/…",
}
```

Close sales on the enrollment deadline by **deactivating** both links (put it in your calendar;
links don't close on a date by themselves).

## 2. Welcome and member records (automation)

One automation, triggered by Stripe when a checkout completes (Zapier, Make and n8n all have a
Stripe trigger for completed checkouts or new payments):

1. **Add a row** to a "Members" sheet or Airtable base: date, name, email, seat, amount, Stripe
   payment ID, library-until (purchase or Session 1 date + 12 months, whichever is later),
   support-until (demo day + 90 days), status "active".
2. **Invite the member** to the community platform (most have an "invite member" action) or
   share the kit folder with their email.
3. **Send the welcome email** from your email tool: seat confirmed, session dates and times,
   how to get in, what to do before Session 1, how to ask for help. A template is below.
4. **Tag them** in your email tool ("cohort-01") so session reminders go only to members.

Second automation, on **refund** (Stripe "charge refunded"): set the row's status to "refunded",
remove them from the community and the shared folder, remove the tag, send the refund email.
Check the amount: only end access on a full refund.

## 3. Member area, sessions and the kit

Pick one home for members and put everything there:

- **Session list** with dates, the meeting link, and the recording added after each session.
- **The kit zip** (`dist/workforce-kit-<version>.zip`) as a private download, with the version
  number and what changed. Post updates there for 12 months.
- **The setup checklist** (from the welcome email) pinned at the top.
- **Community link, SOPs and documentation**, as promised on the pricing page.

Calendar invites: create the six sessions in your calendar and invite the members' emails, or
share a calendar file; meeting tools can also send registrant links and reminders.

## 4. The site's forms

Create an incoming webhook in your automation tool (Zapier "Catch Hook", Make "Custom webhook",
n8n "Webhook" node). Then in `assets/config.js`:

```js
links: {
  auditWebhook:   "https://hooks.zapier.com/…",   // or your Make / n8n URL
  contactWebhook: "https://hooks.zapier.com/…",
},
webhookFormat: "simple",
```

`"simple"` sends the same JSON as plain text without the browser's cross-origin check, which
these webhook URLs usually don't answer. (Your tool may need a "parse JSON" step on the raw body.)
With a webhook set, the contact form sends there and shows the thank-you page; without one, it
opens the visitor's email app.

Fields you'll receive:

- **Contact**: `name, email, company, topic, message, consent ("yes"), page, sentAt` (and an
  empty `website` field: if it's filled in, it's a bot; filter those out).
- **Audit**: `company, email, marketingConsent, businessType, teamSize, departments[], tools[],
  estimate, jobs, departmentsCount, runToday, start[], at`.

Route both into a "Leads" sheet or your CRM. For contact messages, also email your inbox with
Reply-To set to the visitor. Only add people to marketing lists when `marketingConsent` is true.

**The audit result email.** When an audit arrives with an `email`, the visitor asked for their result,
so send it (a "Send email" step in the same zap, filtered on `email` not empty). Suggested text, with
the fields filled in:

> Here is your AI workforce audit for {company}. Estimate: about ${estimate} a year of work across
> {jobs} jobs, {runToday} of which could run with the tools you already have. This is an estimate from
> your answers and our published method (your-site/methodology.html), not a promise. Where we'd start:
> {start}. See your result again: your-site/audit.html#r={businessType},{teamSize},{departments joined
> with +},{tools joined with +},{company}. Book a call: your booking link.

Send at most a couple per address per day (most automation tools can deduplicate on `email`), so the
form can't be used to flood someone else's inbox.

**Waitlist and free training**: use a form tool (Tally, Typeform) or your webinar tool's
registration page, and put its URL in `links.waitlist` and `links.trainingRegistration`.

## 5. Support, refunds and the guarantee

- **Support**: a shared inbox (or the community's help space). Reply within the support window
  (90 days after demo day); check the Members sheet for support-until.
- **Attendance**: after each session, download the meeting tool's attendance report and mark
  each member present or absent in the sheet. The build guarantee depends on it.
- **Refund requests** arrive by email with "Refund" in the subject, as `refunds.html` says.
  Check, in this order:
  - Cooling-off: within 3 days of purchase **and** before Session 1 starts.
  - Build guarantee: requested between the start of Session 6 and 7 days after it; attended all
    six sessions live (sheet); setup steps done; no working department despite that.
  - Reply within two working days. Refund in the Stripe Dashboard (Payments → the payment →
    Refund). The refund automation then ends access.
- Keep a "Refunds" tab: date, member, type, decision, reason. Declines need a reason you'd be
  comfortable showing the member.

## 6. Launch checklist

- [ ] Payment links tested in Stripe test mode, then recreated in live mode
- [ ] Limits set (45 + 5), deactivation messages point to the waitlist
- [ ] Terms URL set in Stripe; terms and refunds pages reviewed by a lawyer
- [ ] Purchase automation tested end to end with a test payment: row added, invite sent, email received
- [ ] Refund automation tested with a test refund: access removed, email received
- [ ] Contact and audit webhooks tested from the live site; a lead appears in the sheet
- [ ] Waitlist and training forms live, linked in `config.js`
- [ ] Member home ready: sessions, kit zip, checklist, community
- [ ] Calendar reminder to deactivate the links when enrollment closes
- [ ] `privacy.html` lists every tool that stores members' or visitors' data

## Welcome email template

> **Subject:** You're in: {{cohort name}}
>
> Hi {{first name}},
>
> Your {{Founding / VIP}} seat in {{cohort name}} is confirmed. Thank you.
>
> **Sessions** ({{time zone}}): {{six dates}}, {{start}} to {{end}}. The joining link and
> recordings are in {{member home}}.
>
> **Before Session 1**:
> 1. Download the kit from {{member home}}, unzip it, and double-click *Install on Mac* or
>    *Install on Windows*.
> 2. Start Claude in the folder (`bin/wf start`) and say "run the onboarding interview"
>    (15 to 45 minutes).
> 3. Run `bin/wf library` and pick a starter for your first department.
> 4. Run `bin/wf serve` and check the map shows your business.
>
> Stuck? Reply to this email. Refund terms: {{site}}/refunds.html
>
> {{Your Brand}}
