import { beforeEach, describe, expect, it, vi } from 'vitest';
import { NextRequest } from 'next/server';
import { FakeDb } from './fakes/supabase';
import { licenseeReport, quarter } from '../src/lib/report';

const TOKEN = 'licensor-token-for-tests-0123456789abcdef';
process.env.LICENSOR_REPORT_TOKEN = TOKEN;
const db = new FakeDb();
vi.mock('@/lib/supabase/admin', () => ({ supabaseAdmin: () => db.client() }));
const { GET } = await import('../src/app/api/licensor/report/route');

const Q3 = quarter('2026-Q3');
function seed() {
  db.tables = {};
  db.seed('cohorts', [{ id: 'c1', slug: 'founding-01', name: 'Founding cohort', seats: 50, vip_seats: 5, currency: 'usd', is_open: false }]);
  db.seed('cohort_sessions', [1, 2].map((n) => ({ id: `s${n}`, cohort_id: 'c1', starts_at: `2026-08-0${n}T16:00:00.000Z` })));
  db.seed('enrollments', [
    { member_id: 'm1', cohort_id: 'c1', seat: 'founding', status: 'active', amount_paid: 149700, currency: 'usd', created_at: '2026-07-10T00:00:00.000Z', updated_at: '2026-07-10T00:00:00.000Z', stripe_customer: 'cus_secret' },
    { member_id: 'm2', cohort_id: 'c1', seat: 'vip', status: 'active', amount_paid: 299700, currency: 'usd', created_at: '2026-07-11T00:00:00.000Z', updated_at: '2026-07-11T00:00:00.000Z' },
    { member_id: 'm3', cohort_id: 'c1', seat: 'founding', status: 'refunded', amount_paid: 149700, currency: 'usd', created_at: '2026-07-12T00:00:00.000Z', updated_at: '2026-07-20T00:00:00.000Z' },
    { member_id: 'm4', cohort_id: 'c1', seat: 'founding', status: 'active', amount_paid: 149700, currency: 'usd', created_at: '2026-06-01T00:00:00.000Z', updated_at: '2026-06-01T00:00:00.000Z' },
  ]);
  db.seed('guarantee_claims', [{ kind: 'cooling_off', status: 'refunded', reason: 'Private reason here', created_at: '2026-07-18T00:00:00.000Z', decided_at: '2026-07-20T00:00:00.000Z' }, { kind: 'build_guarantee', status: 'open', reason: 'x'.repeat(12), created_at: '2026-09-01T00:00:00.000Z', decided_at: null }]);
  db.seed('attendance', [{ session_id: 's1', member_id: 'm1', attended: true }, { session_id: 's1', member_id: 'm2', attended: true }, { session_id: 's2', member_id: 'm1', attended: true }]);
  db.seed('support_requests', [{ status: 'open', subject: 'Help', body: 'Something private', created_at: '2026-08-05T00:00:00.000Z' }]);
  db.seed('leads', [{ kind: 'audit', email: 'lead@example.test', created_at: '2026-07-02T00:00:00.000Z' }, { kind: 'waitlist', email: 'w@example.test', created_at: '2026-10-02T00:00:00.000Z' }]);
  db.seed('downloads', [{ created_at: '2026-07-15T00:00:00.000Z' }]);
  db.seed('releases', [{ version: '1.2.0', is_latest: true }]);
  db.seed('usage_reports', [{ received_at: '2026-08-01T00:00:00.000Z', skills: {} }]);
}
beforeEach(seed);
const req = (url: string, token?: string) => new NextRequest(url, { headers: token ? { authorization: `Bearer ${token}` } : {} });

describe('quarters', () => {
  it('parses and defaults', () => {
    expect(quarter('2026-Q3')).toEqual({ label: '2026-Q3', from: '2026-07-01T00:00:00.000Z', to: '2026-10-01T00:00:00.000Z' });
    expect(quarter(undefined, new Date('2026-11-05T00:00:00Z')).label).toBe('2026-Q4');
    expect(() => quarter('2026-Q5')).toThrow();
  });
});

describe('licensee report (Schedule 4)', () => {
  it('counts the quarter: seats, refunds by reason, revenue, attendance, leads', () => {
    const r = licenseeReport({ cohorts: db.t('cohorts'), sessions: db.t('cohort_sessions'), enrollments: db.t('enrollments'), claims: db.t('guarantee_claims'), attendance: db.t('attendance'), support: db.t('support_requests'), leads: db.t('leads'), downloads: db.t('downloads'), release: { version: '1.2.0' }, usageReports: db.t('usage_reports') } as never, Q3, { brand: 'Your Brand', generatedAt: '2026-10-05T00:00:00.000Z' });
    expect(r.seatsSold).toEqual({ founding: 2, vip: 1 });
    expect(r.seatsRefunded).toEqual({ total: 1, coolingOff: 1, guarantee: 0, other: 0 });
    expect(r.revenue.usd).toEqual({ gross: 599100, refunded: 149700, net: 449400 });
    expect(r.cohorts[0]).toMatchObject({ slug: 'founding-01', sessionsRun: 2, inPeriod: true, activeSeats: { founding: 2, vip: 1 }, refunded: 1 });
    expect(r.cohorts[0].averageAttendance).toBe(0.5);   // (2/3 + 1/3) / 2
    expect(r.leads).toEqual({ audit: 1 });
    expect(r).toMatchObject({ kitVersion: '1.2.0', kitDownloads: 1, usageSummariesShared: 1, refundRequests: { open: 1 }, support: { opened: 1, open: 1 } });
  });
});

describe('GET /api/licensor/report', () => {
  it('needs the token', async () => {
    expect((await GET(req('https://app.example.test/api/licensor/report'))).status).toBe(401);
    expect((await GET(req('https://app.example.test/api/licensor/report', 'wrong-token-wrong-token-wrong-token'))).status).toBe(401);
    expect((await GET(req('https://app.example.test/api/licensor/report?quarter=nope', TOKEN))).status).toBe(400);
  });
  it('returns counts and totals only, never personal data', async () => {
    const res = await GET(req('https://app.example.test/api/licensor/report?quarter=2026-Q3', TOKEN));
    expect(res.status).toBe(200);
    expect(res.headers.get('cache-control')).toBe('no-store');
    const text = await res.text();
    const j = JSON.parse(text);
    expect(j.format).toBe('licensee-report/1');
    expect(j.seatsSold).toEqual({ founding: 2, vip: 1 });
    expect(text).not.toMatch(/@|cus_|Private|private|m1|m2/);
  });
});
