import { describe, expect, it } from 'vitest';
import { accessPeriods, addMonths, claimEligibility, entitlements, money, safeNext, saleState, seatsLeftFor, toCsv, type CohortLike, type EnrollmentLike, type SessionLike } from '../src/lib/rules';

const cohort: CohortLike = { seats: 50, vip_seats: 5, is_open: true, enrollment_closes: '2026-09-21T14:00:00Z', support_days: 90, library_months: 12 };
const sessions: SessionLike[] = [1, 2, 3, 4, 5, 6].map((p, i) => {
  const day = ['2026-09-21', '2026-09-23', '2026-09-25', '2026-09-28', '2026-09-30', '2026-10-02'][i];
  return { position: p, starts_at: `${day}T14:00:00Z`, ends_at: `${day}T16:00:00Z` };
});
const enr = (over: Partial<EnrollmentLike> = {}): EnrollmentLike => ({ status: 'active', created_at: '2026-09-01T12:00:00Z', library_until: null, support_until: null, ...over });

describe('seats', () => {
  it('counts VIP places inside the total', () => {
    expect(seatsLeftFor(cohort, 'founding', { founding: 0, vip: 0 })).toBe(50);
    expect(seatsLeftFor(cohort, 'vip', { founding: 0, vip: 0 })).toBe(5);
    expect(seatsLeftFor(cohort, 'founding', { founding: 40, vip: 5 })).toBe(5);
    expect(seatsLeftFor(cohort, 'vip', { founding: 40, vip: 5 })).toBe(0);
  });
  it('caps VIP by the remaining total', () => {
    expect(seatsLeftFor(cohort, 'vip', { founding: 48, vip: 0 })).toBe(2);
    expect(seatsLeftFor(cohort, 'vip', { founding: 50, vip: 0 })).toBe(0);
  });
  it('never goes negative when oversold', () => {
    expect(seatsLeftFor(cohort, 'founding', { founding: 52, vip: 1 })).toBe(0);
  });
  it('stops selling after the deadline, when closed, or when sold out', () => {
    expect(saleState(cohort, 'founding', 10, new Date('2026-09-20T00:00:00Z'))).toEqual({ ok: true });
    expect(saleState(cohort, 'founding', 10, new Date('2026-09-21T14:00:00Z'))).toEqual({ ok: false, reason: 'past_deadline' });
    expect(saleState({ ...cohort, is_open: false }, 'founding', 10, new Date('2026-09-01T00:00:00Z'))).toEqual({ ok: false, reason: 'closed' });
    expect(saleState(cohort, 'vip', 0, new Date('2026-09-01T00:00:00Z'))).toEqual({ ok: false, reason: 'sold_out' });
    expect(saleState({ ...cohort, vip_seats: 0 }, 'vip', 3, new Date('2026-09-01T00:00:00Z'))).toEqual({ ok: false, reason: 'sold_out' });
  });
});

describe('access periods', () => {
  it('adds months and clamps to the end of short months', () => {
    expect(addMonths(new Date('2026-01-31T10:00:00Z'), 1).toISOString()).toBe('2026-02-28T10:00:00.000Z');
    expect(addMonths(new Date('2028-01-31T10:00:00Z'), 1).toISOString()).toBe('2028-02-29T10:00:00.000Z');
    expect(addMonths(new Date('2026-09-21T14:00:00Z'), 12).toISOString()).toBe('2027-09-21T14:00:00.000Z');
  });
  it('starts the library clock at Session 1 for early buyers', () => {
    const p = accessPeriods(cohort, sessions, new Date('2026-08-01T00:00:00Z'));
    expect(p.library_until).toBe('2027-09-21T14:00:00.000Z');
  });
  it('starts the library clock at purchase for late buyers', () => {
    const p = accessPeriods(cohort, sessions, new Date('2026-09-24T00:00:00Z'));
    expect(p.library_until).toBe('2027-09-24T00:00:00.000Z');
  });
  it('runs support 90 days from the end of demo day', () => {
    const p = accessPeriods(cohort, sessions, new Date('2026-08-01T00:00:00Z'));
    expect(p.support_until).toBe(new Date(Date.parse('2026-10-02T16:00:00Z') + 90 * 86_400_000).toISOString());
  });
  it('copes with a cohort that has no sessions yet', () => {
    const p = accessPeriods(cohort, [], new Date('2026-08-01T00:00:00Z'));
    expect(p.library_until).toBe('2027-08-01T00:00:00.000Z');
  });
});

describe('entitlements', () => {
  it('gives nothing without an active seat', () => {
    expect(entitlements(null).active).toBe(false);
    expect(entitlements(enr({ status: 'refunded' }))).toEqual({ active: false, library: false, support: false, sessions: false });
  });
  it('ends library and support on their dates', () => {
    const e = enr({ library_until: '2027-09-21T14:00:00Z', support_until: '2026-12-31T16:00:00Z' });
    expect(entitlements(e, new Date('2026-12-01T00:00:00Z'))).toMatchObject({ library: true, support: true });
    expect(entitlements(e, new Date('2027-01-05T00:00:00Z'))).toMatchObject({ library: true, support: false, sessions: true });
    expect(entitlements(e, new Date('2027-10-01T00:00:00Z'))).toMatchObject({ library: false, support: false });
  });
});

describe('refund eligibility (matches refunds.html)', () => {
  const all = [1, 2, 3, 4, 5, 6];
  it('cooling-off: within 3 days and before Session 1', () => {
    expect(claimEligibility('cooling_off', enr(), sessions, [], new Date('2026-09-03T11:00:00Z')).ok).toBe(true);
    expect(claimEligibility('cooling_off', enr(), sessions, [], new Date('2026-09-04T12:00:01Z')).ok).toBe(false);
    const late = enr({ created_at: '2026-09-20T12:00:00Z' });
    expect(claimEligibility('cooling_off', late, sessions, [], new Date('2026-09-21T13:59:00Z')).ok).toBe(true);
    expect(claimEligibility('cooling_off', late, sessions, [], new Date('2026-09-21T14:00:00Z')).ok).toBe(false);
  });
  it('build guarantee: opens at Session 6, closes 7 days after it ends', () => {
    expect(claimEligibility('build_guarantee', enr(), sessions, all, new Date('2026-10-01T00:00:00Z')).ok).toBe(false);
    expect(claimEligibility('build_guarantee', enr(), sessions, all, new Date('2026-10-02T15:00:00Z')).ok).toBe(true);
    expect(claimEligibility('build_guarantee', enr(), sessions, all, new Date('2026-10-09T15:59:00Z')).ok).toBe(true);
    expect(claimEligibility('build_guarantee', enr(), sessions, all, new Date('2026-10-09T16:01:00Z')).ok).toBe(false);
  });
  it('build guarantee needs every session attended live', () => {
    const r = claimEligibility('build_guarantee', enr(), sessions, [1, 2, 3, 5, 6], new Date('2026-10-03T00:00:00Z'));
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.reason).toContain('missed session 4');
  });
  it('nothing for an inactive seat', () => {
    expect(claimEligibility('cooling_off', enr({ status: 'refunded' }), sessions, [], new Date('2026-09-02T00:00:00Z')).ok).toBe(false);
  });
});

describe('helpers', () => {
  it('formats money from minor units', () => {
    expect(money(149700, 'usd')).toBe('$1,497');
    expect(money(149750, 'usd')).toBe('$1,497.50');
    expect(money(500000, 'eur', 'en-IE')).toBe('€5,000');
  });
  it('quotes CSV cells and blocks formula injection', () => {
    const csv = toCsv([{ a: '=HYPERLINK("x")', b: 'say "hi"', c: { k: 1 } }]);
    expect(csv).toBe('"a","b","c"\r\n"\'=HYPERLINK(""x"")","say ""hi""","{""k"":1}"\r\n');
  });
  it('only allows relative redirect targets after sign-in', () => {
    expect(safeNext('/member/support')).toBe('/member/support');
    expect(safeNext('https://evil.example')).toBe('/member');
    expect(safeNext('//evil.example')).toBe('/member');
    expect(safeNext('/\\evil.example')).toBe('/member');
    expect(safeNext(null)).toBe('/member');
  });
});

describe('renewals', () => {
  it('adds months to the time left, or to today once access has ended', async () => {
    const { renewedUntil } = await import('../src/lib/rules');
    const now = new Date('2027-06-01T00:00:00Z');
    expect(renewedUntil('2027-09-15T00:00:00.000Z', 12, now)).toBe('2028-09-15T00:00:00.000Z');
    expect(renewedUntil('2027-01-15T00:00:00.000Z', 12, now)).toBe('2028-06-01T00:00:00.000Z');
    expect(renewedUntil(null, 6, now)).toBe('2027-12-01T00:00:00.000Z');
  });
});
