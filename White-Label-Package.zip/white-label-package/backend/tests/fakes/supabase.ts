// In-memory stand-in for the parts of supabase-js the server code uses, so the
// webhook, fulfilment and form endpoints can be tested without a database.
// It enforces the unique constraints the code relies on (error code 23505).
import { randomUUID } from 'node:crypto';

type Row = Record<string, unknown>;
type Filter = (r: Row) => boolean;

const UNIQUE: Record<string, string[][]> = {
  enrollments: [['stripe_checkout_session'], ['stripe_payment_intent'], ['member_id', 'cohort_id']],
  members: [['id'], ['email']],
  stripe_events: [['id']],
  checkout_holds: [['stripe_checkout_session']],
  cohorts: [['slug']],
  email_log: [['key']],
  renewals: [['stripe_checkout_session']],
  course_media: [['lesson_id']],
  course_progress: [['member_id', 'lesson_id']],
  course_certificates: [['member_id'], ['code']],
  instructors: [['email']],
  exam_attempts: [['token_hash']],
};
const DEFAULTS: Record<string, () => Row> = {
  enrollments: () => ({ status: 'active', created_at: new Date().toISOString() }),
  guarantee_claims: () => ({ status: 'open', created_at: new Date().toISOString() }),
  leads: () => ({ created_at: new Date().toISOString() }),
  email_log: () => ({ sent_at: new Date().toISOString() }),
  renewals: () => ({ created_at: new Date().toISOString() }),
  quiz_attempts: () => ({ created_at: new Date().toISOString() }),
  course_submissions: () => ({ status: 'submitted', created_at: new Date().toISOString() }),
  course_progress: () => ({ done_at: new Date().toISOString() }),
  course_certificates: () => ({ issued_at: new Date().toISOString(), revoked_at: null }),
  instructors: () => ({ level: 'candidate', status: 'in_progress', parts: {}, created_at: new Date().toISOString() }),
  exam_attempts: () => ({ answers: {}, marks: {}, result: 'pending', created_at: new Date().toISOString() }),
  checkout_holds: () => ({ expires_at: new Date(Date.now() + 30 * 60_000).toISOString() }),
};

export class FakeDb {
  tables: Record<string, Row[]> = {};
  users: { id: string; email: string }[] = [];
  failNext: { table: string; op: string; message: string } | null = null;

  t(name: string) { return (this.tables[name] ??= []); }
  seed(name: string, rows: Row[]) { for (const r of rows) this.t(name).push({ id: randomUUID(), ...(DEFAULTS[name]?.() ?? {}), ...r }); }

  client() {
    const db = this;
    return {
      from: (table: string) => new Query(db, table),
      rpc: async (fn: string, args: Row) => {
        if (fn === 'take_hold') {
          const id = randomUUID();
          db.seed('checkout_holds', [{ id, cohort_id: args.c, seat: args.s }]);
          return { data: id, error: null };
        }
        return { data: null, error: { message: `unknown rpc ${fn}` } };
      },
      auth: {
        admin: {
          createUser: async ({ email }: { email: string }) => {
            if (db.users.some((u) => u.email === email)) return { data: { user: null }, error: { message: 'A user with this email address has already been registered' } };
            const user = { id: randomUUID(), email };
            db.users.push(user);
            return { data: { user }, error: null };
          },
          listUsers: async () => ({ data: { users: db.users }, error: null }),
          updateUserById: async (id: string, attrs: { email?: string; ban_duration?: string }) => {
            const u = db.users.find((x) => x.id === id);
            if (u && attrs.email) u.email = attrs.email;
            if (u) (u as { banned?: boolean }).banned = !!attrs.ban_duration;
            return { data: { user: u ?? null }, error: null };
          },
          generateLink: async ({ email }: { email: string }) => ({ data: { properties: { hashed_token: `hash-${email}` } }, error: null }),
        },
      },
    };
  }
}

class Query implements PromiseLike<{ data: unknown; error: unknown; count?: number | null }> {
  private filters: Filter[] = [];
  private op: 'select' | 'insert' | 'update' | 'delete' | 'upsert' = 'select';
  private payload: Row | Row[] | null = null;
  private mode: 'many' | 'maybe' | 'single' = 'many';
  private head = false;
  private orderBy: { col: string; asc: boolean } | null = null;
  private lim: number | null = null;
  private conflict: string[] = [];
  private returning = false;
  private embeds: string[] = [];

  constructor(private db: FakeDb, private table: string) {}

  select(cols?: string, opts?: { count?: string; head?: boolean }) {
    if (this.op === 'select') this.head = !!opts?.head; else this.returning = true;
    // Embedded relations like "members(email), cohorts(name)" join on <singular>_id.
    this.embeds = [...(cols ?? '').matchAll(/([a-z_]+)\(/g)].map((m) => m[1]);
    return this;
  }
  private embed(r: Row): Row {
    const out = { ...r };
    for (const rel of this.embeds) {
      const fk = rel.replace(/s$/, '') + '_id';
      out[rel] = this.db.t(rel).find((x) => x.id === r[fk]) ?? null;
    }
    return out;
  }
  insert(p: Row | Row[]) { this.op = 'insert'; this.payload = p; return this; }
  update(p: Row) { this.op = 'update'; this.payload = p; return this; }
  delete() { this.op = 'delete'; return this; }
  upsert(p: Row | Row[], o?: { onConflict?: string }) { this.op = 'upsert'; this.payload = p; this.conflict = (o?.onConflict ?? 'id').split(','); return this; }
  eq(c: string, v: unknown) { this.filters.push((r) => r[c] === v); return this; }
  neq(c: string, v: unknown) { this.filters.push((r) => r[c] !== v); return this; }
  gt(c: string, v: string) { this.filters.push((r) => String(r[c]) > v); return this; }
  gte(c: string, v: string) { this.filters.push((r) => String(r[c]) >= v); return this; }
  in(c: string, vs: unknown[]) { this.filters.push((r) => vs.includes(r[c])); return this; }
  is(c: string, v: null) { this.filters.push((r) => (r[c] ?? null) === v); return this; }
  not(c: string, _op: 'is', v: null) { this.filters.push((r) => (r[c] ?? null) !== v); return this; }
  ilike(c: string, v: string) {
    // Like PostgreSQL: % and _ are wildcards unless escaped with a backslash.
    const re = new RegExp('^' + v.replace(/\\([\\%_])|([%_])|([.*+?^${}()|[\]\\])/g, (_m, esc, wild, meta) => (esc ? esc.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') : wild ? (wild === '%' ? '.*' : '.') : '\\' + meta)) + '$', 'i');
    this.filters.push((r) => re.test(String(r[c] ?? '')));
    return this;
  }
  order(col: string, o?: { ascending?: boolean }) { this.orderBy = { col, asc: o?.ascending !== false }; return this; }
  limit(n: number) { this.lim = n; return this; }
  maybeSingle() { this.mode = 'maybe'; return this; }
  single() { this.mode = 'single'; return this; }

  private rows() { return this.db.t(this.table).filter((r) => this.filters.every((f) => f(r))); }
  private clash(row: Row, except?: Row) {
    for (const cols of UNIQUE[this.table] ?? []) {
      if (cols.some((c) => row[c] == null)) continue;
      if (this.db.t(this.table).some((r) => r !== except && cols.every((c) => r[c] === row[c]))) return true;
    }
    return false;
  }

  private run(): { data: unknown; error: unknown; count?: number | null } {
    const f = this.db.failNext;
    if (f && f.table === this.table && f.op === this.op) { this.db.failNext = null; return { data: null, error: { message: f.message } }; }
    const t = this.db.t(this.table);
    if (this.op === 'insert') {
      const list = Array.isArray(this.payload) ? this.payload : [this.payload!];
      const made: Row[] = [];
      for (const p of list) {
        const row = { id: randomUUID(), ...(DEFAULTS[this.table]?.() ?? {}), ...p };
        if (this.clash(row)) return { data: null, error: { code: '23505', message: 'duplicate key value violates unique constraint' } };
        t.push(row); made.push(row);
      }
      return this.shape(made);
    }
    if (this.op === 'upsert') {
      const list = Array.isArray(this.payload) ? this.payload : [this.payload!];
      for (const p of list) {
        const hit = t.find((r) => this.conflict.every((c) => r[c] === p[c]));
        if (hit) Object.assign(hit, p); else t.push({ id: randomUUID(), ...(DEFAULTS[this.table]?.() ?? {}), ...p });
      }
      return { data: null, error: null };
    }
    if (this.op === 'update') {
      for (const r of this.rows()) {
        const next = { ...r, ...(this.payload as Row) };
        if (this.clash(next, r)) return { data: null, error: { code: '23505', message: 'duplicate key' } };
        Object.assign(r, this.payload);
      }
      return { data: null, error: null };
    }
    if (this.op === 'delete') {
      const gone = new Set(this.rows());
      this.db.tables[this.table] = t.filter((r) => !gone.has(r));
      return { data: null, error: null };
    }
    let rows = this.rows();
    if (this.orderBy) { const { col, asc } = this.orderBy; rows = [...rows].sort((a, b) => (String(a[col]) < String(b[col]) ? -1 : 1) * (asc ? 1 : -1)); }
    if (this.lim != null) rows = rows.slice(0, this.lim);
    if (this.head) return { data: null, error: null, count: rows.length };
    return this.shape(rows);
  }

  private shape(rows: Row[]) {
    if (this.op !== 'select' && !this.returning) return { data: null, error: null };
    if (this.mode === 'many') return { data: rows.map((r) => this.embed(r)), error: null, count: rows.length };
    if (rows.length > 1) return { data: null, error: { message: 'multiple rows' } };
    if (this.mode === 'single' && rows.length === 0) return { data: null, error: { message: 'no rows' } };
    return { data: rows[0] ? this.embed(rows[0]) : null, error: null };
  }

  then<A, B>(ok?: ((v: { data: unknown; error: unknown; count?: number | null }) => A | PromiseLike<A>) | null, bad?: ((e: unknown) => B | PromiseLike<B>) | null) {
    try { return Promise.resolve(this.run()).then(ok, bad); } catch (e) { return Promise.reject(e).then(ok, bad); }
  }
}
