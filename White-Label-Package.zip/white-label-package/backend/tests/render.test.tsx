// Renders every member and admin page with realistic data (in-memory database),
// to catch crashes and wrong numbers. With RENDER_OUT=<dir> it also writes the
// HTML so the pages can be screenshotted for a visual check.
import { beforeAll, describe, expect, it, vi } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { renderToStaticMarkup } from 'react-dom/server';
import { FakeDb } from './fakes/supabase';

const db = new FakeDb();
const ALICE = '00000000-0000-0000-0000-00000000000a';
const ADMIN = '00000000-0000-0000-0000-0000000000ad';
let who = ALICE;

vi.mock('@/lib/supabase/admin', () => ({ supabaseAdmin: () => db.client() }));
vi.mock('@/lib/supabase/server', () => ({ supabaseServer: async () => db.client(), currentUser: async () => ({ sb: db.client(), user: { id: who, email: 'alice@example.test' } }) }));
vi.mock('next/navigation', () => ({ redirect: (u: string) => { throw new Error(`redirect ${u}`); }, notFound: () => { throw new Error('not found'); } }));
vi.mock('next/cache', () => ({ revalidatePath: () => {} }));

const COHORT = '10000000-0000-0000-0000-000000000001';
const day = 86_400_000;
const now = Date.now();
const iso = (t: number) => new Date(t).toISOString();

beforeAll(() => {
  db.seed('cohorts', [{ id: COHORT, slug: 'founding-01', name: 'Founding Cohort 01', seats: 50, vip_seats: 5, price_founding: 149700, price_vip: 500000, currency: 'usd', is_open: true, enrollment_closes: iso(now + 3 * day), support_days: 90, library_months: 12, time_zone: 'America/New_York', created_at: iso(now - 30 * day) }]);
  db.seed('cohort_sessions', [1, 2, 3, 4, 5, 6].map((p) => ({ id: `20000000-0000-0000-0000-00000000000${p}`, cohort_id: COHORT, position: p, title: ['Your workspace and the interview', 'Your first department', 'Approvals, outbox and safety', 'Schedules and the run ledger', 'Your second department', 'Demo day'][p - 1],
    starts_at: iso(now + (p - 3) * 2 * day), ends_at: iso(now + (p - 3) * 2 * day + 2 * 3600_000), join_url: 'https://meet.example.test/room', replay_url: p < 3 ? 'https://video.example.test/r' : null })));
  db.seed('members', [{ id: ALICE, email: 'alice@example.test', full_name: 'Alice Rivera' }, { id: ADMIN, email: 'admin@example.test', full_name: 'Sam Admin' },
    { id: '00000000-0000-0000-0000-00000000000b', email: 'bob@example.test', full_name: 'Bob Chen' }]);
  db.seed('admins', [{ user_id: ADMIN }]);
  db.seed('enrollments', [
    { id: '30000000-0000-0000-0000-00000000000a', member_id: ALICE, cohort_id: COHORT, seat: 'founding', status: 'active', amount_paid: 149700, currency: 'usd', created_at: iso(now - 10 * day), library_until: iso(now + 360 * day), support_until: iso(now + 100 * day), stripe_payment_intent: 'pi_a', setup_done_at: iso(now - 8 * day) },
    { id: '30000000-0000-0000-0000-00000000000b', member_id: '00000000-0000-0000-0000-00000000000b', cohort_id: COHORT, seat: 'vip', status: 'active', amount_paid: 500000, currency: 'usd', created_at: iso(now - 5 * day), library_until: iso(now + 360 * day), support_until: iso(now + 100 * day), stripe_payment_intent: 'pi_b' },
  ]);
  db.seed('attendance', [{ session_id: '20000000-0000-0000-0000-000000000001', member_id: ALICE, attended: true }, { session_id: '20000000-0000-0000-0000-000000000002', member_id: ALICE, attended: true }]);
  db.seed('releases', [{ id: '40000000-0000-0000-0000-000000000001', version: '1.0.0', storage_path: 'releases/1.0.0/k.zip', notes: 'First release.', size_bytes: 912_000, sha256: 'a'.repeat(64), is_latest: true, published_at: iso(now - 12 * day) }]);
  db.seed('support_requests', [{ member_id: ALICE, subject: 'Gmail won’t connect', body: 'The connector asks for a scope I do not see.', status: 'waiting', admin_reply: 'Use the files option for now; we will connect it live in Session 3.', created_at: iso(now - 2 * day), members: undefined }]);
  db.seed('guarantee_claims', [{ enrollment_id: '30000000-0000-0000-0000-00000000000b', member_id: '00000000-0000-0000-0000-00000000000b', kind: 'cooling_off', reason: 'My schedule changed and I cannot attend live.', status: 'open', evidence: {}, created_at: iso(now - 1 * day) }]);
  db.seed('leads', [
    { kind: 'audit', email: 'ceo@acme.example', company: 'Acme', marketing_consent: true, payload: { businessType: 'agency', teamSize: '2-10', departments: ['Sales'], estimate: 41000 }, created_at: iso(now - day) },
    { kind: 'contact', email: 'sam@example.test', name: 'Sam', payload: { topic: 'Seats', message: 'Team rate?' }, created_at: iso(now - 2 * day) },
    { kind: 'waitlist', email: 'w@example.test', payload: {}, created_at: iso(now - 3 * day) },
    { kind: 'audit', email: 'Alice@Example.test', company: 'Rivera Studio', payload: { businessType: 'agency', teamSize: 's6', departments: ['Sales'] }, created_at: iso(now - 20 * day) },
  ]);
  db.seed('usage_reports', [
    { received_at: iso(now - 3 * day), kit_version: '1.0.0', skills: { 'proposal-writer': { runs: 10, done: 8, failed: 1, rejected: 3, lessons: 2 }, custom: { runs: 4, done: 4, failed: 0 } } },
    { received_at: iso(now - 1 * day), kit_version: '1.0.0', skills: { 'proposal-writer': { runs: 6, done: 6, failed: 0, rejected: 1 }, 'weekly-review': { runs: 4, done: 3, failed: 1 } } },
  ]);
});

const out = process.env.RENDER_OUT;
const css = fs.readFileSync(path.join(__dirname, '../src/app/globals.css'), 'utf8').replace(/url\('\/fonts\//g, `url('${path.join(__dirname, '../public/fonts/')}`);
function save(name: string, html: string) {
  if (!out) return;
  fs.mkdirSync(out, { recursive: true });
  fs.writeFileSync(path.join(out, `${name}.html`), `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${name}</title><style>${css}</style></head><body>${html}</body></html>`);
}
async function render(name: string, mod: Promise<{ default: (p: { searchParams: Promise<Record<string, string>> }) => Promise<React.ReactElement> }>, sp: Record<string, string> = {}) {
  const Page = (await mod).default;
  const html = renderToStaticMarkup(await Page({ searchParams: Promise.resolve(sp) }));
  save(name, html);
  return html;
}

describe('member pages', () => {
  it('overview shows the seat, sessions, attendance and the download', async () => {
    who = ALICE;
    const html = await render('member', import('@/app/member/page'));
    expect(html).toContain('Welcome, Alice');
    expect(html).toContain('Founding seat');
    expect(html).toContain('Download the kit');
    expect(html).toContain('Version 1.0.0');
    expect(html).toContain('Recording');
    expect(html).toContain('$1,497');
    expect(html).not.toContain('Admin');
    expect(html).toContain('href="/member/audit-answers"');            // took the audit with this email (any case)
    expect(html).toContain('Help improve the kit');
    expect(html).toContain('Setup done');
  });
  it('support shows the thread and the form', async () => {
    const html = await render('member-support', import('@/app/member/support/page'));
    expect(html).toContain('Gmail won’t connect');
    expect(html).toContain('Our reply');
    expect(html).toContain('name="subject"');
  });
  it('refunds page explains both windows and shows the cooling-off is closed', async () => {
    const html = await render('member-guarantee', import('@/app/member/guarantee/page'));
    expect(html).toContain('Cooling-off');
    expect(html).toContain('The 3-day cooling-off period has ended');
    expect(html).toContain('The build guarantee opens at Session 6');
  });
  it('renewal page: closed until a price is set, then shows the price and the date it extends from', async () => {
    who = ALICE;
    expect(await render('member-renew-off', import('@/app/member/renew/page'))).toContain('Renewals aren’t open for your seat yet');
    db.t('cohorts')[0].price_renewal = 49700; db.t('cohorts')[0].renewal_months = 12;
    const html = await render('member-renew', import('@/app/member/renew/page'));
    expect(html).toContain('Renew for $497');
    expect(html).toContain('on top of the time you have left');
    db.t('cohorts')[0].price_renewal = null;
  });
});

describe('admin pages', () => {
  it('dashboard counts seats, revenue and waiting work', async () => {
    who = ADMIN;
    const html = await render('admin', import('@/app/admin/page'));
    expect(html).toContain('2 / 50');
    expect(html).toContain('$6,497');
    expect(html).toContain('48</b><span>Places left (4 of them can be VIP)');
    expect(html).toContain('Refund requests waiting');
  });
  it('members, leads, refunds, support, cohorts and releases render', async () => {
    const members = await render('admin-members', import('@/app/admin/members/page'));
    expect(members).toContain('bob@example.test');
    expect(members).toContain('Setup done');
    expect(members).toContain('Kit not downloaded');
    const leads = await render('admin-leads', import('@/app/admin/leads/page'));
    expect(leads).toContain('ceo@acme.example');
    expect(leads).toContain('est. 41,000');
    const claims = await render('admin-claims', import('@/app/admin/claims/page'));
    expect(claims).toContain('My schedule changed');
    expect(claims).toContain('Approve and refund in full');
    expect(await render('admin-support', import('@/app/admin/support/page'))).toContain('Gmail won’t connect');
    const cohorts = await render('admin-cohorts', import('@/app/admin/cohorts/page'));
    expect(cohorts).toContain('Save attendance');
    expect(cohorts).toMatch(/value="20\d\d-\d\d-\d\dT\d\d:\d\d-0[45]:00"/);   // shown in the cohort's own offset
    expect(await render('admin-releases', import('@/app/admin/releases/page'))).toContain('Current');
    const priv = await render('admin-privacy', import('@/app/admin/privacy/page'), { email: 'alice@example.test' });
    expect(priv).toContain('Erase');
    expect(priv).toMatch(/Enrollments \(purchase records\)<\/th><td>1</);
  });
  it('skill usage and the quarterly report render', async () => {
    who = ADMIN;
    const usage = await render('admin-usage', import('@/app/admin/usage/page'));
    expect(usage).toContain('<code>proposal-writer</code>');
    expect(usage).toMatch(/proposal-writer<\/code><\/td><td>2<\/td><td>16<\/td>/);   // two workspaces, 16 runs
    expect(usage).toContain('pooled');
    const report = await render('admin-report', import('@/app/admin/report/page'));
    expect(report).toContain('Quarterly report');
    expect(report).toContain('Download JSON');
    expect(report).toContain('Founding Cohort 01');
  });
  it('scheduled emails page previews what is due and lists what was sent', async () => {
    who = ADMIN;
    db.seed('email_log', [{ key: 'prep:30000000-0000-0000-0000-00000000000a', kind: 'prep', member_id: ALICE, ok: true, sent_at: iso(now - day) }, { key: 'eve:x#failed-1', kind: 'eve', member_id: ALICE, ok: false, error: 'Resend 422', sent_at: iso(now - 2 * day) }]);
    const html = await render('admin-emails', import('@/app/admin/emails/page'));
    expect(html).toContain('Scheduled emails');
    expect(html).toContain('Send what’s due now');
    expect(html).toContain('Failed, will retry');
  });
  it('non-admins are sent away from admin pages', async () => {
    who = ALICE;
    await expect(render('x', import('@/app/admin/page'))).rejects.toThrow('redirect /member?notice=not-admin');
  });
});

// Pages with route params (/member/course/[module], /exam/[token] …).
async function renderWith(name: string, mod: Promise<{ default: (p: never) => Promise<React.ReactElement> }>, params: Record<string, string>, sp: Record<string, string> = {}) {
  const Page = (await mod).default as (p: { params: Promise<Record<string, string>>; searchParams: Promise<Record<string, string>> }) => Promise<React.ReactElement>;
  const html = renderToStaticMarkup(await Page({ params: Promise.resolve(params), searchParams: Promise.resolve(sp) }));
  save(name, html);
  return html;
}

describe('course and certification pages', () => {
  it('course overview, a module with lessons, quiz and assignment, and the certificate states', async () => {
    who = ALICE;
    db.seed('course_progress', [{ member_id: ALICE, lesson_id: '1.1' }, { member_id: ALICE, lesson_id: '1.2' }]);
    db.seed('course_media', [{ lesson_id: '1.1', video_url: 'https://video.example.test/1-1', transcript_url: null }]);
    db.seed('quiz_attempts', [{ id: '70000000-0000-0000-0000-000000000001', member_id: ALICE, module: 1, score: 3, total: 5, passed: false, answers: { '1.1': 0, '1.2': 1, '1.3': 1, '1.4': 1, '1.5': 0 } }]);
    db.seed('course_submissions', [{ member_id: ALICE, module: 1, body: 'doctor output here', status: 'not_yet', reviewer_note: 'Add the ten-things worksheet.' }]);
    const overview = await render('member-course', import('@/app/member/course/page'));
    expect(overview).toContain('2 of 34');
    expect(overview).toContain('Best 3/5');
    expect(overview).toContain('Not yet: see the note');
    const mod = await renderWith('member-course-1', import('@/app/member/course/[module]/page'), { module: '1' }, { attempt: '70000000-0000-0000-0000-000000000001' });
    expect(mod).toContain('Foundations');
    expect(mod).toContain('href="https://video.example.test/1-1"');
    expect(mod).toContain('Video coming soon');
    expect(mod).toContain('<code>bin/wf doctor</code>');
    expect(mod).toContain('You need 4 to pass');
    expect(mod).toContain('class="q wrong"');
    expect(mod).not.toContain('Answer: ');                     // answers stay hidden until the quiz is passed
    expect(mod).toContain('Add the ten-things worksheet.');
    await expect(renderWith('x', import('@/app/member/course/[module]/page'), { module: '9' })).rejects.toThrow('not found');
    const cert = await render('member-certificate-locked', import('@/app/member/course/certificate/page'));
    expect(cert).toContain('You’ve completed 0 of 6');
    expect((await render('member', import('@/app/member/page')))).toContain('Continue with Module 1');
  });
  it('a finished course: the certificate and its public check', async () => {
    who = ALICE;
    db.seed('course_certificates', [{ member_id: ALICE, name: 'Alice Rivera', code: 'ABCD-EFGH-JKLM', issued_at: iso(now) }]);
    const cert = await render('member-certificate', import('@/app/member/course/certificate/page'));
    expect(cert).toContain('Alice Rivera');
    expect(cert).toContain('https://app.example.test/certificate/ABCD-EFGH-JKLM');
    expect(await renderWith('verify', import('@/app/certificate/[code]/page'), { code: 'abcd-efgh-jklm' })).toContain('Valid');
    expect(await renderWith('verify-missing', import('@/app/certificate/[code]/page'), { code: 'ZZZZ-ZZZZ-ZZZZ' })).toContain('Not found');
  });
  it('self-paced seat: course first, no live sessions, the money-back window instead of the build guarantee', async () => {
    who = ALICE;
    db.t('cohorts')[0].self_paced = true; db.t('cohorts')[0].refund_days = 14;
    const home = await render('member-self-paced', import('@/app/member/page'));
    expect(home).toContain('Self-paced course');
    expect(home).not.toContain('Live sessions');
    const refunds = await render('member-guarantee-self-paced', import('@/app/member/guarantee/page'));
    expect(refunds).toContain('Money-back window');
    expect(refunds).not.toContain('Build guarantee</h3>');
    db.t('cohorts')[0].self_paced = false;
  });
  it('admin course page: the review queue, progress by module, video links', async () => {
    who = ADMIN;
    db.seed('course_submissions', [{ member_id: ALICE, module: 2, body: 'starter plan and department plan attached', status: 'submitted', members: undefined }]);
    const html = await render('admin-course', import('@/app/admin/course/page'));
    expect(html).toContain('Waiting for review (1)');
    expect(html).toContain('Complete when:');
    expect(html).toContain('Videos linked');
    expect(html).toContain('name="video-1.1"');
    expect(html).toContain('ABCD-EFGH-JKLM');
  });
  it('instructors, the exam for a candidate, and the marking page', async () => {
    who = ADMIN;
    const IID = '50000000-0000-0000-0000-000000000001', AID = '51000000-0000-0000-0000-000000000001';
    db.seed('instructors', [{ id: IID, email: 'jo@example.test', name: 'Jo Teacher', level: 'associate', status: 'certified', kit_major: 1, renew_by: iso(now + 300 * day), certified_at: iso(now - 65 * day),
      parts: { part1: { passed_on: '2027-01-05', assessor: 'lead@example.test' }, part2: { passed_on: '2027-01-06', assessor: 'lead@example.test', score: '27/30' }, part3: { passed_on: '2027-01-07', assessor: 'lead@example.test' } } }]);
    const { hashToken } = await import('@/lib/examData');
    const token = 'T'.repeat(32);
    db.seed('exam_attempts', [{ id: AID, instructor_id: IID, token_hash: hashToken(token), expires_at: iso(now + 10 * day), started_at: iso(now - 10 * 60_000), deadline: iso(now + 35 * 60_000), submitted_at: null, answers: { 2: 'draft, approve, autonomous' }, marks: {}, result: 'pending' }]);
    const list = await render('admin-instructors', import('@/app/admin/instructors/page'));
    expect(list).toContain('Jo Teacher');
    expect(list).toContain('Certified');
    expect(list).toContain('In progress');
    const taking = await renderWith('exam-in-progress', import('@/app/exam/[token]/page'), { token });
    expect(taking).toContain('Hand in by');
    expect(taking).toMatch(/\d\d:\d\d UTC/);
    expect(taking).toContain('draft, approve, autonomous');
    expect(taking).not.toContain('Accept equivalent wording');     // no key on the candidate's page
    expect(taking).not.toMatch(/Keep this file away from candidates|owner lessons &gt; vertical notes/);
    expect(await renderWith('exam-bad', import('@/app/exam/[token]/page'), { token: 'nope' })).toContain('Exam link not found');
    db.t('exam_attempts')[0].submitted_at = iso(now);
    const mark = await renderWith('admin-exam-mark', import('@/app/admin/instructors/exam/[id]/page'), { id: AID });
    expect(mark).toContain('Written exam · Jo Teacher');
    expect(mark).toContain('Key:');
    expect(mark).toContain('name="m2"');
    expect(mark).toContain('(blank)');
  });
});
