// The course and the certification exam end to end through the real server actions,
// on the in-memory database: what members and candidates can do, and what they can't.
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { FakeDb } from './fakes/supabase';

const db = new FakeDb();
const ALICE = '00000000-0000-0000-0000-00000000000a';
const ADMIN = '00000000-0000-0000-0000-0000000000ad';
let who = ALICE;
const mail: { to: string; subject: string; text?: string }[] = [];

vi.mock('@/lib/supabase/admin', () => ({ supabaseAdmin: () => db.client() }));
vi.mock('@/lib/supabase/server', () => ({ supabaseServer: async () => db.client(), currentUser: async () => ({ sb: db.client(), user: { id: who, email: who === ALICE ? 'alice@example.test' : 'admin@example.test' } }) }));
vi.mock('next/navigation', () => ({ redirect: (u: string) => { throw new Error(`redirect ${u}`); }, notFound: () => { throw new Error('not found'); } }));
vi.mock('next/cache', () => ({ revalidatePath: () => {} }));
vi.mock('@/lib/email', async (orig) => ({ ...(await orig<typeof import('@/lib/email')>()), sendMail: async (m: { to: string; subject: string }) => { mail.push(m); return { ok: true }; } }));

const course = await import('@/app/member/course/actions');
const adminCourse = await import('@/app/admin/course/actions');
const inst = await import('@/app/admin/instructors/actions');
const exam = await import('@/app/exam/[token]/actions');
const { MODULES } = await import('@/lib/course');
const { EXAM } = await import('@/lib/exam');

const fd = (o: Record<string, string>) => { const f = new FormData(); for (const [k, v] of Object.entries(o)) f.append(k, v); return f; };
/** Run an action and return where it redirected (actions always end in a redirect). */
async function go(p: Promise<unknown>): Promise<string> {
  try { await p; } catch (e) { const m = String((e as Error).message); if (m.startsWith('redirect ')) return decodeURIComponent(m.slice(9)); throw e; }
  throw new Error('no redirect');
}
const quizForm = (n: number, right = 5) => fd({ module: String(n), ...Object.fromEntries(MODULES[n - 1].quiz.map((q, i) => [`q-${q.id}`, String(i < right ? q.answer : (q.answer + 1) % q.options.length)])) });

beforeEach(() => {
  db.tables = {}; mail.length = 0; who = ALICE;
  db.seed('members', [{ id: ALICE, email: 'alice@example.test', full_name: 'Alice Rivera' }, { id: ADMIN, email: 'admin@example.test', full_name: 'Sam Admin' }]);
  db.seed('admins', [{ user_id: ADMIN }]);
  db.seed('cohorts', [{ id: 'c1', slug: 'sp', name: 'Self-paced', self_paced: true, refund_days: 14, time_zone: 'UTC' }]);
  db.seed('enrollments', [{ id: 'e1', member_id: ALICE, cohort_id: 'c1', seat: 'founding', status: 'active', amount_paid: 49700, currency: 'usd', library_until: null, support_until: null }]);
  db.seed('releases', [{ version: '1.2.0', is_latest: true }]);
});

describe('the course, as a member', () => {
  it('grades the quiz on the server and keeps every attempt', async () => {
    expect(await go(course.submitQuiz(quizForm(1, 3)))).toMatch(/^\/member\/course\/1\?attempt=.+#quiz$/);
    expect(db.t('quiz_attempts')[0]).toMatchObject({ member_id: ALICE, module: 1, score: 3, total: 5, passed: false });
    await go(course.submitQuiz(quizForm(1, 4)));
    expect(db.t('quiz_attempts').map((a) => a.passed)).toEqual([false, true]);
  });
  it('asks for every answer before grading', async () => {
    const f = quizForm(2); f.delete('q-2.3');
    expect(await go(course.submitQuiz(f))).toContain('Answer every question');
    expect(db.t('quiz_attempts')).toHaveLength(0);
  });
  it('marks lessons watched (and undoes it), only lessons that exist in that module', async () => {
    await go(course.toggleLesson(fd({ module: '1', lesson: '1.2' })));
    await go(course.toggleLesson(fd({ module: '1', lesson: '1.2' })));      // twice = still one row
    expect(db.t('course_progress')).toHaveLength(1);
    expect(await go(course.toggleLesson(fd({ module: '1', lesson: '2.1' })))).toContain('couldn’t find that lesson');
    await go(course.toggleLesson(fd({ module: '1', lesson: '1.2', undo: '1' })));
    expect(db.t('course_progress')).toHaveLength(0);
  });
  it('takes an assignment, refuses anything that looks like a key, and tells the reviewers', async () => {
    expect(await go(course.submitAssignment(fd({ module: '3', body: 'short', link: '' })))).toContain('at least a couple of lines');
    expect(await go(course.submitAssignment(fd({ module: '3', body: 'my key is sk-ant-api03-abcdefghijklmnop and here is the output', link: '' })))).toContain('looks like it contains an API key');
    expect(await go(course.submitAssignment(fd({ module: '3', body: 'bin/wf status: knowledge complete, 3 voice samples, one run logged.', link: 'http://insecure.example' })))).toContain('https://');
    expect(await go(course.submitAssignment(fd({ module: '3', body: 'bin/wf status: knowledge complete, 3 voice samples, one run logged.', link: 'https://video.example.test/x' })))).toContain('Sent.');
    expect(db.t('course_submissions')).toHaveLength(1);
    expect(mail.at(-1)?.subject).toBe('[Course] Module 3 submission · alice@example.test');
  });
  it('a reviewer’s “not yet” needs a note and emails the member exactly what’s missing', async () => {
    await go(course.submitAssignment(fd({ module: '1', body: 'doctor --problems: no failures. First department: outreach.', link: '' })));
    const id = db.t('course_submissions')[0].id as string;
    who = ADMIN;
    expect(await go(adminCourse.reviewSubmission(fd({ submission: id, decision: 'not_yet', note: '' })))).toContain('Say exactly what’s missing');
    await go(adminCourse.reviewSubmission(fd({ submission: id, decision: 'not_yet', note: 'Add the ten-things worksheet (five repeat-work lines).' })));
    expect(db.t('course_submissions')[0]).toMatchObject({ status: 'not_yet', reviewed_by: ADMIN });
    expect(mail.at(-1)).toMatchObject({ to: 'alice@example.test', subject: 'Module 1: one more step' });
    expect(mail.at(-1)?.text).toContain('ten-things worksheet');
  });
  it('members can’t review their own work', async () => {
    db.seed('course_submissions', [{ id: '60000000-0000-0000-0000-000000000001', member_id: ALICE, module: 1, body: 'x'.repeat(30) }]);
    await expect(go(adminCourse.reviewSubmission(fd({ submission: '60000000-0000-0000-0000-000000000001', decision: 'complete' })))).resolves.toBe('/member?notice=not-admin');
    expect(db.t('course_submissions')[0].status).toBe('submitted');
  });
  it('the certificate is issued only when all six modules are complete, once', async () => {
    expect(await go(course.claimCertificate(fd({ name: 'Alice Rivera' })))).toContain('once all six modules are complete');
    for (const m of MODULES) {
      db.seed('quiz_attempts', [{ member_id: ALICE, module: m.n, score: 5, total: 5, passed: true, answers: {} }]);
      db.seed('course_submissions', [{ member_id: ALICE, module: m.n, body: 'done and accepted here', status: 'complete' }]);
    }
    expect(await go(course.claimCertificate(fd({ name: 'Alice Rivera' })))).toContain('Congratulations');
    await go(course.claimCertificate(fd({ name: 'Someone Else' })));
    expect(db.t('course_certificates')).toHaveLength(1);
    expect(db.t('course_certificates')[0].name).toBe('Alice Rivera');
    expect(db.t('course_certificates')[0].code).toMatch(/^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/);
  });
  it('nothing works without an active seat', async () => {
    db.t('enrollments')[0].status = 'refunded';
    expect(await go(course.submitQuiz(quizForm(1)))).toContain('active seat');
    expect(db.t('quiz_attempts')).toHaveLength(0);
  });
  it('self-paced refunds: the money-back window closes once more than two modules are used', async () => {
    const { fileClaim } = await import('@/app/member/actions');
    db.t('enrollments')[0].created_at = new Date(Date.now() - 2 * 86_400_000).toISOString();
    for (const n of [1, 2, 3]) db.seed('quiz_attempts', [{ member_id: ALICE, module: n, score: 5, total: 5, passed: true, answers: {} }]);
    expect(await go(fileClaim(fd({ kind: 'cooling_off', reason: 'It isn’t for me after all, sorry.' })))).toContain('More than 2 modules');
    db.tables.quiz_attempts = db.t('quiz_attempts').slice(0, 2);
    expect(await go(fileClaim(fd({ kind: 'cooling_off', reason: 'It isn’t for me after all, sorry.' })))).toContain('Request received');
  });
});

describe('the certification exam', () => {
  async function invited() {
    who = ADMIN;
    await go(inst.addInstructor(fd({ name: 'Jo Teacher', email: 'Jo@Example.test' })));
    const id = db.t('instructors')[0].id as string;
    await go(inst.inviteToExam(fd({ instructor: id })));
    const token = /\/exam\/([A-Za-z0-9_-]{32})/.exec(mail.at(-1)!.text!)![1];
    return { id, token };
  }
  it('only a hash of the link is stored, and the link is emailed to the candidate', async () => {
    const { token } = await invited();
    expect(mail.at(-1)?.to).toBe('jo@example.test');
    expect(JSON.stringify(db.t('exam_attempts'))).not.toContain(token);
    expect(db.t('exam_attempts')[0]).toMatchObject({ kit_version: '1.2.0', result: 'pending' });
    expect(await go(inst.inviteToExam(fd({ instructor: db.t('instructors')[0].id as string })))).toContain('already have an unused exam link');
  });
  it('start → save → hand in → mark → pass records Part 2 and emails the result', async () => {
    const { id, token } = await invited();
    await go(exam.startExam(fd({ token })));
    const a = db.t('exam_attempts')[0];
    expect(Date.parse(a.deadline as string) - Date.parse(a.started_at as string)).toBe(45 * 60_000);
    const answers: Record<string, string> = { token, intent: 'save' };
    for (const q of EXAM.questions) answers[`q${q.n}`] = q.type === 'short' ? `answer ${q.n}` : String(q.answer);
    expect(await go(exam.saveExam(fd(answers)))).toMatch(/\?saved=/);
    expect(Object.keys(db.t('exam_attempts')[0].answers as object)).toHaveLength(30);
    await go(exam.saveExam(fd({ ...answers, intent: 'submit' })));
    expect(db.t('exam_attempts')[0].submitted_at).toBeTruthy();
    expect(db.t('exam_attempts')[0].marks).toEqual({ 1: true, 7: true });
    expect(mail.at(-1)?.subject).toBe('[Certification] Exam handed in · Jo Teacher');
    // After handing in, nothing more is accepted.
    await go(exam.saveExam(fd({ token, intent: 'save', q2: 'changed' })));
    expect((db.t('exam_attempts')[0].answers as Record<string, string>)[2]).toBe('answer 2');

    const attempt = db.t('exam_attempts')[0].id as string;
    const shorts = EXAM.questions.filter((q) => q.type === 'short');
    expect(await go(inst.gradeExam(fd({ attempt, m2: '1' })))).toContain('Mark every answered question first');
    const marks = Object.fromEntries(shorts.map((q) => [`m${q.n}`, [3, 5, 6].includes(q.n) ? '0' : '1']));
    expect(await go(inst.gradeExam(fd({ attempt, ...marks })))).toContain('passed (27/30)');
    expect(db.t('exam_attempts')[0]).toMatchObject({ result: 'pass', score: 27, safety_ok: true, graded_by: ADMIN });
    expect((db.t('instructors')[0].parts as Record<string, { score: string }>).part2.score).toBe('27/30');
    expect(mail.at(-1)).toMatchObject({ to: 'jo@example.test', subject: 'You passed the certification exam' });
    expect(id).toBeTruthy();
  });
  it('a missed safety question fails, whatever the score', async () => {
    const { token } = await invited();
    await go(exam.startExam(fd({ token })));
    const answers: Record<string, string> = { token, intent: 'submit' };
    for (const q of EXAM.questions) answers[`q${q.n}`] = q.type === 'short' ? `answer ${q.n}` : String(q.answer);
    await go(exam.saveExam(fd(answers)));
    const attempt = db.t('exam_attempts')[0].id as string;
    const marks = Object.fromEntries(EXAM.questions.filter((q) => q.type === 'short').map((q) => [`m${q.n}`, q.n === 21 ? '0' : '1']));
    expect(await go(inst.gradeExam(fd({ attempt, ...marks })))).toContain('not passed (29/30, a safety question missed)');
    expect(db.t('instructors')[0].parts).toEqual({});
  });
  it('after the time limit only the last saved answers count', async () => {
    const { token } = await invited();
    await go(exam.startExam(fd({ token })));
    await go(exam.saveExam(fd({ token, intent: 'save', q2: 'draft, approve, autonomous' })));
    const a = db.t('exam_attempts')[0];
    a.started_at = new Date(Date.now() - 60 * 60_000).toISOString();
    a.deadline = new Date(Date.now() - 15 * 60_000).toISOString();
    expect(await go(exam.saveExam(fd({ token, intent: 'submit', q2: 'late change', q3: 'late answer' })))).toContain('?late=1');
    expect(db.t('exam_attempts')[0].answers).toEqual({ 2: 'draft, approve, autonomous' });
    expect(db.t('exam_attempts')[0].submitted_at).toBeTruthy();
  });
  it('a wrong or malformed token gets nowhere', async () => {
    await invited();
    expect(await go(exam.startExam(fd({ token: 'x'.repeat(32) })))).toBe('/exam/invalid');
    expect(await go(exam.startExam(fd({ token: '../../admin' })))).toBe('/exam/invalid');
    expect(db.t('exam_attempts')[0].started_at ?? null).toBeNull();
  });
  it('a level can’t be set above what the record shows, and certifying sets the 12-month renewal', async () => {
    const { id } = await invited();
    const base = { instructor: id, status: 'certified', kit_major: '1', notes: '' };
    expect(await go(inst.saveInstructor(fd({ ...base, level: 'associate', 'part1-date': '2027-01-05', 'part1-assessor': 'lead@example.test' })))).toContain('requirements for Candidate, not Associate');
    const parts = { 'part1-date': '2027-01-05', 'part1-assessor': 'lead@example.test', 'part2-date': '2027-01-06', 'part2-assessor': 'lead@example.test', 'part3-date': '2027-01-07', 'part3-assessor': 'lead@example.test' };
    expect(await go(inst.saveInstructor(fd({ ...base, level: 'associate', ...parts, 'part3-assessor': '' })))).toContain('record who assessed it');
    expect(await go(inst.saveInstructor(fd({ ...base, level: 'associate', ...parts })))).toContain('certified Associate');
    const r = db.t('instructors')[0];
    expect(r).toMatchObject({ level: 'associate', status: 'certified', kit_major: 1 });
    expect(Date.parse(r.renew_by as string) - Date.parse(r.certified_at as string)).toBeGreaterThan(364 * 86_400_000);
  });
});
