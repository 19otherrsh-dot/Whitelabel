import { beforeEach, describe, expect, it, vi } from 'vitest';
import { FakeDb } from './fakes/supabase';

const db = new FakeDb();
const mail: { to: string; subject: string }[] = [];
let failFor = '';
vi.mock('@/lib/supabase/admin', () => ({ supabaseAdmin: () => db.client() }));
vi.mock('@/lib/email', async (orig) => ({
  ...(await orig<typeof import('@/lib/email')>()),
  sendMail: async (m: { to: string; subject: string }) => { if (m.to === failFor) return { ok: false, error: 'mailbox down' }; mail.push(m); return { ok: true }; },
}));
const { runSchedule } = await import('../src/lib/scheduleRun');

const S1 = Date.parse('2027-01-11T15:00:00Z');
beforeEach(() => {
  db.tables = {}; mail.length = 0; failFor = '';
  db.seed('cohorts', [{ id: 'c1', name: 'Founding Cohort 01', time_zone: 'America/New_York', price_renewal: null }]);
  db.seed('cohort_sessions', [{ id: 's1', cohort_id: 'c1', position: 1, title: 'Foundations', starts_at: new Date(S1).toISOString(), ends_at: new Date(S1 + 7200e3).toISOString(), join_url: null, replay_url: null }]);
  db.seed('members', [{ id: 'm1', email: 'alice@example.test', full_name: 'Alice' }, { id: 'm2', email: 'bob@example.test', full_name: 'Bob' }]);
  db.seed('enrollments', [{ id: 'e1', member_id: 'm1', cohort_id: 'c1', seat: 'founding', status: 'active' }, { id: 'e2', member_id: 'm2', cohort_id: 'c1', seat: 'founding', status: 'active' }]);
});

describe('running the scheduled emails', () => {
  it('sends what is due once, even if the job runs again', async () => {
    const now = new Date(S1 - 3600e3);
    expect(await runSchedule(now)).toMatchObject({ due: 2, sent: 2, failed: 0 });
    expect(mail.map((m) => m.to).sort()).toEqual(['alice@example.test', 'bob@example.test']);
    expect(await runSchedule(now)).toMatchObject({ due: 0, sent: 0 });
    expect(db.t('email_log').every((r) => r.ok === true)).toBe(true);
  });
  it('a failed send is recorded and retried on the next run', async () => {
    const now = new Date(S1 - 3600e3);
    failFor = 'bob@example.test';
    expect(await runSchedule(now)).toMatchObject({ sent: 1, failed: 1 });
    expect(db.t('email_log').some((r) => r.ok === false && String(r.key).includes('#failed-'))).toBe(true);
    failFor = '';
    expect(await runSchedule(new Date(now.getTime() + 15 * 60e3))).toMatchObject({ due: 1, sent: 1 });
    expect(mail.filter((m) => m.to === 'bob@example.test')).toHaveLength(1);
  });
});
