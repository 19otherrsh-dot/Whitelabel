import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { COURSE, MODULES, gradeQuiz, courseStatus, moduleStatus, publicQuiz, certificateCode, inlineParts } from '@/lib/course';
import { EXAM, publicExam, examState, cleanAnswers, autoMarks, examResult } from '@/lib/exam';
import { levelMet, standing, renewBy } from '@/lib/certification';
import { claimEligibility } from '@/lib/rules';
// @ts-expect-error plain ESM build script without types
import { build, parseQuizzes, parseExam } from '../scripts/build-course.mjs';

const allRight = (n: number) => Object.fromEntries(MODULES[n - 1].quiz.map((q) => [q.id, q.answer]));

describe('course content', () => {
  it('the committed JSON matches the delivery Markdown (run scripts/build-course.mjs after editing it)', () => {
    const { course, exam } = build();
    const read = (f: string) => JSON.parse(fs.readFileSync(path.join(__dirname, '../src/content', f), 'utf8'));
    expect(read('course.json')).toEqual(course);
    expect(read('exam.json')).toEqual(exam);
  });
  it('six modules, every lesson with an outline, five quiz questions each with one right answer', () => {
    expect(MODULES.map((m) => m.n)).toEqual([1, 2, 3, 4, 5, 6]);
    expect(MODULES.reduce((a, m) => a + m.lessons.length, 0)).toBe(34);
    for (const m of MODULES) {
      expect(m.assignment, `module ${m.n}`).not.toBeNull();
      expect(m.check, `module ${m.n}`).toBeTruthy();
      expect(m.quiz).toHaveLength(5);
      for (const q of m.quiz) { expect(q.options.length).toBeGreaterThanOrEqual(2); expect(q.answer).toBeGreaterThanOrEqual(0); expect(q.answer).toBeLessThan(q.options.length); }
      for (const l of m.lessons) expect(l.say || l.show || l.summary, l.id).toBeTruthy();
    }
    expect(MODULES[0].lessons.map((l) => l.id)).toEqual(['1.1', '1.2', '1.3', '1.4', '1.5', '1.6', '1.7']);   // "1.3 … · 1.4 …" split in two
    expect(MODULES[0].quiz[2].options[MODULES[0].quiz[2].answer]).toBe('`bin/wf doctor`');
    expect(MODULES[0].quiz[4]).toMatchObject({ options: ['True', 'False'], answer: 1 });
    expect(MODULES[5].assignment?.label).toBe('Final submission');
  });
  it('the parser refuses a quiz question with no bold answer, rather than guessing', () => {
    expect(() => parseQuizzes('## Module 1\n\n1. Which? a) one b) two\n')).toThrow(/no bold answer/);
    expect(parseQuizzes('## Module 1\n\n1. Which? a) one **b) two** c) three\n').quizzes['1'][0]).toMatchObject({ text: 'Which?', options: ['one', 'two', 'three'], answer: 1 });
  });
  it('the exam: 30 questions, 4 safety, a key for every one, choice questions marked by machine', () => {
    expect(EXAM.questions).toHaveLength(30);
    expect(EXAM.questions.filter((q) => q.safety).map((q) => q.n)).toEqual([1, 4, 10, 21]);
    expect(EXAM).toMatchObject({ minutes: 45, passScore: 24, passPercent: 80 });
    expect(EXAM.questions[0]).toMatchObject({ type: 'choice', answer: 1 });
    expect(EXAM.questions[6]).toMatchObject({ type: 'tf', answer: 1 });
    expect(() => parseExam('45 minutes.\n\n1. A question?\n', '# key\n')).toThrow(/no answer in the key/);
  });
  it('nothing sent to the browser carries the answers', () => {
    for (const m of MODULES) for (const q of publicQuiz(m)) expect(q).not.toHaveProperty('answer');
    for (const q of publicExam()) { expect(q).not.toHaveProperty('key'); expect(q).not.toHaveProperty('answer'); }
  });
});

describe('quizzes and completion', () => {
  it('4 of 5 passes, 3 of 5 does not, and junk answers count as wrong', () => {
    const right = allRight(1);
    expect(gradeQuiz(MODULES[0], right)).toMatchObject({ score: 5, passed: true, wrong: [] });
    const one = { ...right, '1.1': (right['1.1'] + 1) % 4 };
    expect(gradeQuiz(MODULES[0], one)).toMatchObject({ score: 4, passed: true, wrong: ['1.1'] });
    expect(gradeQuiz(MODULES[0], { ...one, '1.3': 9, '1.4': 'x' })).toMatchObject({ score: 2, passed: false });
    expect(gradeQuiz(MODULES[0], {})).toMatchObject({ score: 0, answered: 0, passed: false });
  });
  it('a module is complete when its quiz is passed and its assignment accepted; the course when all six are', () => {
    const t = '2027-01-01T00:00:00Z';
    const s = { done: new Set(['1.1', '1.2']), attempts: [{ module: 1, passed: false, score: 3, total: 5, created_at: t }, { module: 1, passed: true, score: 5, total: 5, created_at: t }], submissions: [{ module: 1, status: 'complete' as const, created_at: t }, { module: 1, status: 'submitted' as const, created_at: '2027-02-01T00:00:00Z' }] };
    expect(moduleStatus(MODULES[0], s)).toMatchObject({ lessonsDone: 2, complete: true, submission: 'complete', quiz: { passed: true, best: 5, attempts: 2 } });
    const c = courseStatus(s);
    expect(c).toMatchObject({ modulesComplete: 1, complete: false, next: 2, modulesUsed: 1 });
    const all = { done: new Set<string>(), attempts: MODULES.map((m) => ({ module: m.n, passed: true, score: 5, total: 5, created_at: t })), submissions: MODULES.map((m) => ({ module: m.n, status: 'complete' as const, created_at: t })) };
    expect(courseStatus(all)).toMatchObject({ complete: true, modulesComplete: 6, next: null });
  });
  it('the latest “not yet” shows until something is accepted', () => {
    const s = { done: new Set<string>(), attempts: [], submissions: [{ module: 2, status: 'submitted' as const, created_at: '2027-01-01' }, { module: 2, status: 'not_yet' as const, created_at: '2027-01-03' }] };
    expect(moduleStatus(MODULES[1], s).submission).toBe('not_yet');
  });
  it('certificate codes are readable: no 0/O/1/I', () => {
    const c = certificateCode((n) => new Uint8Array(n).map((_, i) => i * 37));
    expect(c).toMatch(/^[2-9A-HJ-NP-Z]{4}-[2-9A-HJ-NP-Z]{4}-[2-9A-HJ-NP-Z]{4}$/);
  });
  it('keeps `code`, **bold** and *italic* from the Markdown, nothing else', () => {
    expect(inlineParts('*"run the interview"*, 2 * 3')).toEqual([{ t: 'i', v: '"run the interview"' }, { t: 'text', v: ', 2 * 3' }]);
    expect(inlineParts('Run `bin/wf doctor` and say **No** <b>x</b>')).toEqual([
      { t: 'text', v: 'Run ' }, { t: 'code', v: 'bin/wf doctor' }, { t: 'text', v: ' and say ' }, { t: 'b', v: 'No' }, { t: 'text', v: ' <b>x</b>' },
    ]);
  });
  it('self-paced: a money-back window, no build guarantee', () => {
    const e = { status: 'active' as const, created_at: '2027-01-01T00:00:00Z', library_until: null, support_until: null };
    const at = (d: string) => new Date(d);
    expect(claimEligibility('cooling_off', e, [], [], at('2027-01-10T00:00:00Z'), { refundDays: 14, modulesUsed: 2 })).toMatchObject({ ok: true });
    expect(claimEligibility('cooling_off', e, [], [], at('2027-01-10T00:00:00Z'), { refundDays: 14, modulesUsed: 3 })).toMatchObject({ ok: false, reason: 'More than 2 modules are already complete.' });
    expect(claimEligibility('cooling_off', e, [], [], at('2027-01-16T00:00:00Z'), { refundDays: 14, modulesUsed: 0 })).toMatchObject({ ok: false, reason: 'The 14-day money-back window has ended.' });
    expect(claimEligibility('build_guarantee', e, [], [], at('2027-01-02T00:00:00Z'), { refundDays: 14, modulesUsed: 0 }).ok).toBe(false);
  });
});

describe('the online exam', () => {
  const base = { expires_at: '2027-01-15T00:00:00Z', started_at: null, deadline: null, submitted_at: null };
  it('link valid until it expires; 45 minutes plus a 2-minute grace once started', () => {
    expect(examState(base, new Date('2027-01-10T00:00:00Z'))).toBe('ready');
    expect(examState(base, new Date('2027-01-16T00:00:00Z'))).toBe('expired');
    const going = { ...base, started_at: '2027-01-10T10:00:00Z', deadline: '2027-01-10T10:45:00Z' };
    expect(examState(going, new Date('2027-01-10T10:46:00Z'))).toBe('in_progress');
    expect(examState(going, new Date('2027-01-10T10:48:00Z'))).toBe('time_up');
    expect(examState({ ...going, submitted_at: '2027-01-10T10:40:00Z' }, new Date('2027-01-20T00:00:00Z'))).toBe('submitted');
  });
  it('keeps only real answers of the right shape', () => {
    expect(cleanAnswers({ 1: '1', 2: '  draft, approve, autonomous ', 7: '5', 99: 'x', 3: '' })).toEqual({ 1: '1', 2: 'draft, approve, autonomous' });
  });
  const allAnswered = () => Object.fromEntries(EXAM.questions.map((q) => [q.n, q.type === 'short' ? 'an answer' : String(q.answer)]));
  const marksWith = (wrong: number[]) => Object.fromEntries(EXAM.questions.map((q) => [q.n, !wrong.includes(q.n)]));
  it('machine-marks choice and true/false; short answers stay pending until marked', () => {
    const a = allAnswered();
    const auto = autoMarks(a);
    expect(Object.keys(auto).sort()).toEqual(['1', '7']);
    expect(examResult(a, auto)).toMatchObject({ result: 'pending', score: 2 });
  });
  it('pass needs 24 of 30 AND every safety question right', () => {
    const a = allAnswered();
    expect(examResult(a, marksWith([2, 3, 5, 6, 8, 9]))).toMatchObject({ score: 24, result: 'pass', safetyOk: true });
    expect(examResult(a, marksWith([2, 3, 5, 6, 8, 9, 11]))).toMatchObject({ score: 23, result: 'fail' });
    expect(examResult(a, marksWith([21]))).toMatchObject({ score: 29, result: 'fail', safetyOk: false });
  });
  it('a blank answer is wrong, never pending', () => {
    const a = allAnswered(); delete a[30];
    const r = examResult(a, marksWith([]));
    expect(r).toMatchObject({ score: 29, result: 'pass' });
    expect(r.ungraded).toEqual([]);
  });
});

describe('certification records', () => {
  const d = (k: string) => ({ [k]: { passed_on: '2027-01-01', assessor: 'a@example.test' } });
  it('levels follow the parts passed', () => {
    expect(levelMet({ ...d('part1'), ...d('part2') })).toBe('candidate');
    expect(levelMet({ ...d('part1'), ...d('part2'), ...d('part3') })).toBe('associate');
    expect(levelMet({ ...d('part1'), ...d('part2'), ...d('part3'), ...d('part4'), ...d('part5') })).toBe('associate');
    expect(levelMet({ ...d('part1'), ...d('part2'), ...d('part3'), ...d('part4'), ...d('part5'), ...d('shadowing') })).toBe('lead');
  });
  it('renewal every 12 months, a warning 60 days before, and an update module after a new major version', () => {
    expect(renewBy('2027-01-31T00:00:00.000Z')).toBe('2028-01-31T00:00:00.000Z');
    const r = { status: 'certified', level: 'associate' as const, renew_by: '2028-01-31T00:00:00.000Z', kit_major: 1 };
    expect(standing(r, 1, new Date('2027-06-01'))).toBe('certified');
    expect(standing(r, 1, new Date('2027-12-15'))).toBe('due');
    expect(standing(r, 1, new Date('2028-02-01'))).toBe('lapsed');
    expect(standing(r, 2, new Date('2027-06-01'))).toBe('update_needed');
    expect(standing({ ...r, status: 'suspended' }, 1)).toBe('suspended');
  });
  it('quiz pass mark is read from the Markdown', () => { expect(COURSE.quizPassMark).toBe(4); });
});
