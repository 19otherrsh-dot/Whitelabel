import { afterEach, describe, expect, it, vi } from 'vitest';

afterEach(() => { delete process.env.STRIPE_INVOICES; vi.resetModules(); });

describe('invoices', () => {
  it('off by default: Stripe sends its usual receipt only', async () => {
    const { invoiceParams } = await import('../src/lib/renewal');
    expect(invoiceParams('Seat')).toEqual({});
  });
  it('with STRIPE_INVOICES=true every checkout makes an invoice and collects a VAT/tax ID', async () => {
    process.env.STRIPE_INVOICES = 'true';
    const { invoiceParams } = await import('../src/lib/renewal');
    expect(invoiceParams('Founding seat')).toEqual({
      invoice_creation: { enabled: true, invoice_data: { description: 'Founding seat', footer: 'Your Brand' } },
      tax_id_collection: { enabled: true },
    });
  });
});
