import { describe, expect, it } from 'vitest';
import { auditSchema, claimSchema, cohortSchema, contactSchema, fieldErrors, waitlistSchema } from '../src/lib/validation';

describe('contact form (what assets/site.js sends)', () => {
  const base = { name: 'Sam', email: 'sam@example.com', company: '', topic: 'Seats', message: 'Is there a team rate?', consent: 'yes', page: '/contact.html', sentAt: '2026-09-01T00:00:00Z' };
  it('accepts the site payload', () => expect(contactSchema.safeParse(base).success).toBe(true));
  it('requires reply consent', () => {
    const r = contactSchema.safeParse({ ...base, consent: undefined });
    expect(r.success).toBe(false);
    if (!r.success) expect(fieldErrors(r.error).consent).toBeTruthy();
  });
  it('rejects a filled honeypot', () => expect(contactSchema.safeParse({ ...base, website: 'spam.example' }).success).toBe(false));
  it('rejects bad email', () => expect(contactSchema.safeParse({ ...base, email: 'nope' }).success).toBe(false));
});

describe('audit (what assets/audit.js sends)', () => {
  it('accepts the audit payload', () => {
    const r = auditSchema.safeParse({ company: 'Acme', email: '', marketingConsent: false, businessType: 'agency', teamSize: '2-10', departments: ['Sales'], tools: ['gmail'],
      estimate: 41000, jobs: 23, departmentsCount: 3, runToday: 9, start: ['Lead research'], at: '2026-09-01T00:00:00Z' });
    expect(r.success).toBe(true);
  });
  it('drops unknown fields', () => {
    const r = auditSchema.parse({ company: 'Acme', evil: '<script>' });
    expect('evil' in r).toBe(false);
  });
});

describe('waitlist, claims, cohorts', () => {
  it('waitlist defaults to kind waitlist', () => expect(waitlistSchema.parse({ email: 'a@b.co' }).kind).toBe('waitlist'));
  it('claim kind is restricted', () => expect(claimSchema.safeParse({ kind: 'other', reason: 'long enough reason' }).success).toBe(false));
  it('cohort form coerces numbers and lowercases currency', () => {
    const r = cohortSchema.parse({ slug: 'c-02', name: 'Cohort 02', seats: '50', vip_seats: '5', price_founding: '1497', price_vip: '5000', currency: 'USD', support_days: '90', library_months: '12', is_open: 'on' });
    expect(r).toMatchObject({ seats: 50, currency: 'usd', is_open: true });
  });
});
