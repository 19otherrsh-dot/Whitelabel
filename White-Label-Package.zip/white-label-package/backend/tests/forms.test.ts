import { beforeEach, describe, expect, it, vi } from 'vitest';
import { NextRequest } from 'next/server';
import { FakeDb } from './fakes/supabase';

const db = new FakeDb();
const mail: { to: string; replyTo?: string; subject: string; text?: string }[] = [];
vi.mock('@/lib/supabase/admin', () => ({ supabaseAdmin: () => db.client() }));
vi.mock('@/lib/email', async (orig) => ({
  ...(await orig<typeof import('@/lib/email')>()),
  sendMail: async (m: { to: string; subject: string }) => { mail.push(m); return { ok: true }; },
}));

const contact = await import('@/app/api/contact/route');
const audit = await import('@/app/api/audit/route');
const waitlist = await import('@/app/api/waitlist/route');

let ip = 0;
function post(path: string, body: unknown, opts: { origin?: string | null; ip?: string; type?: string } = {}) {
  const headers: Record<string, string> = { 'content-type': opts.type ?? 'application/json', 'x-forwarded-for': opts.ip ?? `203.0.113.${++ip}` };
  if (opts.origin !== null) headers.origin = opts.origin ?? 'https://www.example.test';
  return new NextRequest(`https://app.example.test${path}`, { method: 'POST', body: typeof body === 'string' ? body : JSON.stringify(body), headers });
}

const contactBody = { name: 'Sam', email: 'sam@example.test', company: 'Acme', topic: 'Seats', message: 'Is there a team rate for three people?', consent: 'yes', page: '/contact.html' };

beforeEach(() => { db.tables = {}; mail.length = 0; });

describe('public form endpoints', () => {
  it('answers the CORS preflight only for the site origin', async () => {
    const ok = await contact.OPTIONS(new NextRequest('https://app.example.test/api/contact', { method: 'OPTIONS', headers: { origin: 'https://www.example.test' } }));
    expect(ok.status).toBe(204);
    expect(ok.headers.get('access-control-allow-origin')).toBe('https://www.example.test');
    const no = await contact.OPTIONS(new NextRequest('https://app.example.test/api/contact', { method: 'OPTIONS', headers: { origin: 'https://evil.example' } }));
    expect(no.status).toBe(403);
  });

  it('refuses other origins and requests without one', async () => {
    expect((await contact.POST(post('/api/contact', contactBody, { origin: 'https://evil.example' }))).status).toBe(403);
    expect((await contact.POST(post('/api/contact', contactBody, { origin: null }))).status).toBe(403);
    expect(db.t('leads')).toHaveLength(0);
  });

  it('stores a contact message, forwards it with Reply-To, and never stores the raw IP', async () => {
    const res = await contact.POST(post('/api/contact', contactBody, { ip: '198.51.100.7' }));
    expect(res.status).toBe(200);
    expect(res.headers.get('access-control-allow-origin')).toBe('https://www.example.test');
    const [lead] = db.t('leads');
    expect(lead).toMatchObject({ kind: 'contact', email: 'sam@example.test', company: 'Acme' });
    expect(JSON.stringify(lead)).not.toContain('198.51.100.7');
    expect(String(lead.ip_hash)).toMatch(/^[0-9a-f]{32}$/);
    expect(mail[0]).toMatchObject({ to: 'support@example.test', replyTo: 'sam@example.test' });
  });

  it('returns field errors for invalid input', async () => {
    const res = await contact.POST(post('/api/contact', { ...contactBody, email: 'nope', consent: '' }));
    expect(res.status).toBe(422);
    const body = await res.json();
    expect(Object.keys(body.fields)).toEqual(expect.arrayContaining(['email', 'consent']));
  });

  it('quietly drops honeypot submissions', async () => {
    const res = await contact.POST(post('/api/contact', { ...contactBody, website: 'http://spam.example' }));
    expect(res.status).toBe(200);
    expect(db.t('leads')).toHaveLength(0);
    expect(mail).toHaveLength(0);
  });

  it('rejects non-JSON, oversized and malformed bodies', async () => {
    expect((await contact.POST(post('/api/contact', 'a=b', { type: 'application/x-www-form-urlencoded' }))).status).toBe(415);
    expect((await contact.POST(post('/api/contact', { ...contactBody, message: 'x'.repeat(40_000) }))).status).toBe(413);
    expect((await contact.POST(post('/api/contact', '{not json'))).status).toBe(400);
  });

  it('also accepts the same JSON sent as text/plain (the site\'s "simple" webhook mode)', async () => {
    const res = await contact.POST(post('/api/contact', contactBody, { type: 'text/plain;charset=UTF-8' }));
    expect(res.status).toBe(200);
    expect(db.t('leads')).toHaveLength(1);
  });

  it('rate-limits one address after 10 submissions in 10 minutes', async () => {
    const codes: number[] = [];
    for (let i = 0; i < 11; i++) codes.push((await waitlist.POST(post('/api/waitlist', { email: `p${i}@example.test` }, { ip: '192.0.2.50' }))).status);
    expect(codes.slice(0, 10).every((c) => c === 200)).toBe(true);
    expect(codes[10]).toBe(429);
  });

  it('stores the audit payload the site sends, keeping answers in payload', async () => {
    const res = await audit.POST(post('/api/audit', { company: 'Acme', email: 'ceo@acme.example', marketingConsent: true, businessType: 'agency', teamSize: '2-10',
      departments: ['Sales', 'Marketing'], tools: ['gmail'], estimate: 41000, jobs: 23, departmentsCount: 2, runToday: 9, start: ['Lead research'], at: '2026-09-01T00:00:00Z' }));
    expect(res.status).toBe(200);
    const [lead] = db.t('leads');
    expect(lead).toMatchObject({ kind: 'audit', email: 'ceo@acme.example', marketing_consent: true });
    expect(lead.payload).toMatchObject({ businessType: 'agency', estimate: 41000, departments: ['Sales', 'Marketing'] });
    expect(lead.payload).not.toHaveProperty('website');
    // the visitor asked for the result: it is emailed, as an estimate, with the share link and no email in it
    const m = mail.find((x) => x.subject === 'Your AI workforce audit result');
    expect(m?.to).toBe('ceo@acme.example');
    expect(m?.text).toContain('about $41,000 a year');
    expect(m?.text).toContain('not a promise');
    expect(m?.text).toContain('audit.html#r=agency%2C2-10%2CSales%2BMarketing%2Cgmail%2CAcme');
    expect(m?.text).not.toMatch(/#r=[^\s]*ceo/);
  });

  it('sends the audit result at most twice a day to one address, and never without an email', async () => {
    const before = mail.length;
    for (let i = 0; i < 4; i++) await audit.POST(post('/api/audit', { email: 'Flood@Victim.example', businessType: 'local', departments: [], tools: [], start: [] }));
    await audit.POST(post('/api/audit', { email: '', businessType: 'local', departments: [], tools: [], start: [] }));
    expect(mail.length - before).toBe(2);
  });

  it('records training sign-ups separately from the waitlist', async () => {
    await waitlist.POST(post('/api/waitlist', { kind: 'training', email: 't@example.test' }));
    expect(db.t('leads')[0].kind).toBe('training');
  });

  it('answers 500 (not a crash) when the database is down', async () => {
    db.failNext = { table: 'leads', op: 'insert', message: 'down' };
    const res = await waitlist.POST(post('/api/waitlist', { email: 'z@example.test' }));
    expect(res.status).toBe(500);
  });
});
