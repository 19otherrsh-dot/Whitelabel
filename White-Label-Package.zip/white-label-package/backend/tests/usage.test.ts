import { describe, expect, it } from 'vitest';
import { aggregateUsage, parseUsageFile } from '../src/lib/usage';

// What `bin/wf learn --export` writes (bin/lib/maintain.mjs → exportLearning).
const report = {
  kitVersion: '1.0.0', businessType: 'agency', teamSize: '2-5', generated: '2026-10-21T08:00:00.000Z',
  skills: {
    'social-copywriter': { runs: 10, done: 7, failed: 1, skipped: 0, queued: 2, draft: 0, rejected: 3, lessons: 3 },
    custom: { runs: 4, done: 4, failed: 0, skipped: 0, queued: 0, draft: 0, rejected: 0, lessons: 0 },
  },
};

describe('usage summaries', () => {
  it('accepts the file the kit writes', () => expect(parseUsageFile(JSON.stringify(report)).ok).toBe(true));
  it('refuses extra fields (nothing can be smuggled in)', () => {
    expect(parseUsageFile(JSON.stringify({ ...report, owner: 'jane@acme.example' })).ok).toBe(false);
    expect(parseUsageFile(JSON.stringify({ ...report, skills: { ...report.skills, 'social-copywriter': { ...report.skills['social-copywriter'], note: 'Jane' } } })).ok).toBe(false);
  });
  it('refuses free text where a label belongs and odd skill names', () => {
    expect(parseUsageFile(JSON.stringify({ ...report, businessType: 'Jane <jane@acme.example>' })).ok).toBe(false);
    expect(parseUsageFile(JSON.stringify({ ...report, skills: { 'Acme Dental Intake': report.skills.custom } })).ok).toBe(false);
  });
  it('refuses non-JSON, empty and oversized files', () => {
    expect(parseUsageFile('hello').ok).toBe(false);
    expect(parseUsageFile(JSON.stringify({ ...report, skills: {} })).ok).toBe(false);
    expect(parseUsageFile('x'.repeat(200_001)).ok).toBe(false);
  });
  it('totals per skill, worst first', () => {
    const t = aggregateUsage([
      { received_at: '', kit_version: '1.0.0', skills: report.skills },
      { received_at: '', kit_version: '1.0.0', skills: { 'social-copywriter': { runs: 10, failed: 0, rejected: 1 }, 'weekly-review': { runs: 5, failed: 1, rejected: 0 } } },
    ]);
    expect(t[0]).toMatchObject({ skill: 'social-copywriter', workspaces: 2, runs: 20, rejected: 4 });
    expect(t[0].rejectRate).toBeCloseTo(0.2);
    expect(t.map((x) => x.skill)).toEqual(['social-copywriter', 'weekly-review', 'custom']);
  });
});
