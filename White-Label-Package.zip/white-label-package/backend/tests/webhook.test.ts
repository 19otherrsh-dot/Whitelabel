import { beforeEach, describe, expect, it, vi } from 'vitest';
import { NextRequest } from 'next/server';
import Stripe from 'stripe';
import { FakeDb } from './fakes/supabase';

const db = new FakeDb();
const mail: { to: string; subject: string; text: string }[] = [];

vi.mock('@/lib/supabase/admin', () => ({ supabaseAdmin: () => db.client() }));
vi.mock('@/lib/email', async (orig) => ({
  ...(await orig<typeof import('@/lib/email')>()),
  sendMail: async (m: { to: string; subject: string; text: string }) => { mail.push(m); return { ok: true, id: 'test' }; },
}));

const { POST } = await import('@/app/api/stripe/webhook/route');
const stripe = new Stripe('sk_test_for_tests_only');
const SECRET = 'whsec_test_secret_for_tests';
const COHORT = '10000000-0000-0000-0000-000000000001';

function delivery(event: object, secret = SECRET) {
  const payload = JSON.stringify(event);
  const header = stripe.webhooks.generateTestHeaderString({ payload, secret });
  return new NextRequest('https://app.example.test/api/stripe/webhook', { method: 'POST', body: payload, headers: { 'stripe-signature': header, 'content-type': 'application/json' } });
}

let n = 0;
function completed(over: Record<string, unknown> = {}, type = 'checkout.session.completed') {
  n += 1;
  return {
    id: `evt_${n}`, object: 'event', type, api_version: '2025-01-01', created: 1790000000, livemode: false, pending_webhooks: 1, request: null,
    data: { object: {
      id: `cs_test_${over.sessionNo ?? n}`, object: 'checkout.session', payment_status: 'paid', status: 'complete', amount_total: 149700, currency: 'usd',
      created: Math.floor(Date.parse('2026-09-01T12:00:00Z') / 1000), customer: 'cus_1', payment_intent: `pi_${over.sessionNo ?? n}`,
      customer_details: { email: 'Alex@Example.test', name: 'Alex Rivera' },
      metadata: { cohort_id: COHORT, seat: 'founding', hold_id: 'h' }, ...over,
    } },
  };
}

beforeEach(() => {
  db.tables = {};
  db.users = [];
  mail.length = 0;
  db.seed('cohorts', [{ id: COHORT, slug: 'founding-01', name: 'Founding Cohort 01', seats: 50, vip_seats: 5, price_founding: 149700, price_vip: 500000, currency: 'usd', is_open: true, enrollment_closes: null, support_days: 90, library_months: 12, time_zone: 'America/New_York' }]);
  db.seed('cohort_sessions', [1, 2, 3, 4, 5, 6].map((p) => ({ cohort_id: COHORT, position: p, title: `S${p}`, starts_at: `2026-09-${20 + p}T14:00:00.000Z`, ends_at: `2026-09-${20 + p}T16:00:00.000Z` })));
});

describe('stripe webhook', () => {
  it('rejects a bad signature without touching the database', async () => {
    const res = await POST(delivery(completed(), 'whsec_wrong'));
    expect(res.status).toBe(400);
    expect(db.t('stripe_events')).toHaveLength(0);
  });

  it('turns a paid checkout into a member, an enrollment and a welcome email', async () => {
    const ev = completed();
    db.seed('checkout_holds', [{ cohort_id: COHORT, seat: 'founding', stripe_checkout_session: ev.data.object.id }]);
    const res = await POST(delivery(ev));
    expect(res.status).toBe(200);
    expect((await res.json()).outcome).toBe('fulfilled');

    const [member] = db.t('members');
    expect(member.email).toBe('alex@example.test');
    const [en] = db.t('enrollments');
    expect(en).toMatchObject({ member_id: member.id, cohort_id: COHORT, seat: 'founding', status: 'active', amount_paid: 149700, stripe_payment_intent: ev.data.object.payment_intent });
    expect(en.library_until).toBe('2027-09-21T14:00:00.000Z');       // 12 months from Session 1
    expect(db.t('checkout_holds')).toHaveLength(0);                  // hold released
    expect(mail).toHaveLength(1);
    expect(mail[0].to).toBe('alex@example.test');
    expect(mail[0].text).toContain('https://app.example.test/auth/confirm?token_hash=');
    expect(db.t('stripe_events')[0].processed_at).toBeTruthy();
  });

  it('is idempotent: the same event twice gives one enrollment and one email', async () => {
    const ev = completed();
    await POST(delivery(ev));
    const again = await POST(delivery(ev));
    expect((await again.json()).duplicate).toBe(true);
    expect(db.t('enrollments')).toHaveLength(1);
    expect(mail).toHaveLength(1);
  });

  it('a second event for the same session (async success after completed) does nothing', async () => {
    await POST(delivery(completed({ sessionNo: 'same' })));
    const res = await POST(delivery(completed({ sessionNo: 'same' }, 'checkout.session.async_payment_succeeded')));
    expect((await res.json()).outcome).toBe('already');
    expect(db.t('enrollments')).toHaveLength(1);
  });

  it('waits for delayed payment methods instead of granting access', async () => {
    const res = await POST(delivery(completed({ payment_status: 'unpaid' })));
    expect((await res.json()).outcome).toBe('unpaid');
    expect(db.t('enrollments')).toHaveLength(0);
  });

  it('flags a second purchase by the same person for a human, without a second seat', async () => {
    await POST(delivery(completed()));
    const res = await POST(delivery(completed({ metadata: { cohort_id: COHORT, seat: 'vip', hold_id: 'h2' }, amount_total: 500000 })));
    expect((await res.json()).outcome).toBe('flagged');
    expect(db.t('enrollments')).toHaveLength(1);
    expect(db.t('admin_log').map((l) => l.action)).toContain('duplicate_purchase');
    expect(mail.some((m) => m.to === 'support@example.test' && m.text.includes('paid again'))).toBe(true);
  });

  it('flags a paid session with missing metadata', async () => {
    const res = await POST(delivery(completed({ metadata: {} })));
    expect((await res.json()).outcome).toBe('flagged');
    expect(db.t('enrollments')).toHaveLength(0);
  });

  it('releases the hold when a session expires', async () => {
    db.seed('checkout_holds', [{ cohort_id: COHORT, seat: 'vip', stripe_checkout_session: 'cs_test_expired' }]);
    const res = await POST(delivery({ ...completed(), type: 'checkout.session.expired', data: { object: { id: 'cs_test_expired', object: 'checkout.session' } } }));
    expect((await res.json()).outcome).toBe('released');
    expect(db.t('checkout_holds')).toHaveLength(0);
  });

  it('a full refund ends access and emails the member; a partial refund is only logged', async () => {
    const ev = completed();
    await POST(delivery(ev));
    const pi = ev.data.object.payment_intent;
    const charge = (refunded: boolean, amount_refunded: number) => ({ ...completed(), type: 'charge.refunded', data: { object: { id: 'ch_1', object: 'charge', payment_intent: pi, refunded, amount: 149700, amount_refunded, currency: 'usd' } } });

    await POST(delivery(charge(false, 50000)));
    expect(db.t('enrollments')[0].status).toBe('active');
    expect(db.t('admin_log').map((l) => l.action)).toContain('partial_refund');

    const [en] = db.t('enrollments');
    db.seed('guarantee_claims', [{ enrollment_id: en.id, member_id: en.member_id, kind: 'cooling_off', reason: 'Changed my mind', status: 'approved' }]);
    await POST(delivery(charge(true, 149700)));
    expect(db.t('enrollments')[0].status).toBe('refunded');
    expect(db.t('guarantee_claims')[0].status).toBe('refunded');
    expect(mail.at(-1)!.subject).toContain('refund');
    expect(mail.at(-1)!.text).toContain('$1,497');
  });

  it('reports a processing failure as 500 so Stripe retries, then succeeds on retry', async () => {
    const ev = completed();
    db.failNext = { table: 'enrollments', op: 'insert', message: 'database is restarting' };
    const first = await POST(delivery(ev));
    expect(first.status).toBe(500);
    expect(db.t('stripe_events')[0].error).toContain('restarting');
    const retry = await POST(delivery(ev));
    expect(retry.status).toBe(200);
    expect(db.t('enrollments')).toHaveLength(1);
    expect(db.t('members')).toHaveLength(1);                         // the user from the first attempt is reused
  });

  it('alerts support when a dispute opens', async () => {
    await POST(delivery({ ...completed(), type: 'charge.dispute.created', data: { object: { id: 'dp_1', object: 'dispute', payment_intent: 'pi_x', reason: 'fraudulent', amount: 149700, currency: 'usd' } } }));
    expect(mail.some((m) => m.to === 'support@example.test' && m.text.includes('dispute'))).toBe(true);
  });
});

describe('paid renewals', () => {
  const EN = '30000000-0000-0000-0000-0000000000aa', M = '00000000-0000-0000-0000-0000000000aa';
  const renewalEvent = (no: number, over: Record<string, unknown> = {}) => completed({ sessionNo: `r${no}`, amount_total: 49700, metadata: { type: 'renewal', enrollment_id: EN, member_id: M, months: '12' }, ...over });
  beforeEach(() => {
    db.seed('members', [{ id: M, email: 'alex@example.test', full_name: 'Alex Rivera' }]);
    db.seed('enrollments', [{ id: EN, member_id: M, cohort_id: COHORT, seat: 'founding', status: 'active', stripe_payment_intent: 'pi_seat', library_until: '2099-01-22T17:00:00.000Z' }]);
  });
  it('adds the months on top of the time left, once, and confirms by email', async () => {
    const ev = renewalEvent(1);
    expect((await (await POST(delivery(ev))).json()).outcome).toBe('renewed');
    expect(db.t('enrollments')[0].library_until).toBe('2100-01-22T17:00:00.000Z');
    expect(db.t('renewals')).toHaveLength(1);
    expect(mail.at(-1)?.subject).toBe('Your library access is renewed');
    const again = { ...renewalEvent(1), id: 'evt_again' };
    expect((await (await POST(delivery(again))).json()).outcome).toBe('already');
    expect(db.t('enrollments')[0].library_until).toBe('2100-01-22T17:00:00.000Z');
  });
  it('a renewal for someone else’s seat is flagged, not applied', async () => {
    const ev = renewalEvent(2, { metadata: { type: 'renewal', enrollment_id: EN, member_id: '00000000-0000-0000-0000-0000000000bb', months: '12' } });
    expect((await (await POST(delivery(ev))).json()).outcome).toBe('flagged');
    expect(db.t('enrollments')[0].library_until).toBe('2099-01-22T17:00:00.000Z');
  });
  it('a full refund of the renewal takes the months back but leaves the seat active', async () => {
    await POST(delivery(renewalEvent(3)));
    const refund = { id: 'evt_rf', object: 'event', type: 'charge.refunded', api_version: '2025-01-01', created: 1790000000, livemode: false, pending_webhooks: 1, request: null,
      data: { object: { id: 'ch_1', object: 'charge', payment_intent: 'pi_r3', refunded: true, amount: 49700, amount_refunded: 49700, currency: 'usd' } } };
    expect((await (await POST(delivery(refund))).json()).outcome).toBe('renewal-refund');
    expect(db.t('enrollments')[0]).toMatchObject({ library_until: '2099-01-22T17:00:00.000Z', status: 'active' });
  });
});
