import { describe, expect, it } from 'vitest';
import { dueEmails, type SchedInput } from '../src/lib/schedule';

const H = 3600_000, D = 24 * H;
const S1 = Date.parse('2027-01-11T15:00:00Z');   // 10 a.m. Eastern
const sess = [1, 2, 3, 4, 5, 6].map((p) => ({
  id: `s${p}`, cohort_id: 'c1', position: p, title: ['Foundations', 'Your workspace', 'Encode your business', 'Deploy your department', 'Put it on a clock', 'Demo day'][p - 1],
  starts_at: new Date(S1 + [0, 2, 4, 7, 9, 11][p - 1] * D).toISOString(), ends_at: new Date(S1 + [0, 2, 4, 7, 9, 11][p - 1] * D + 2 * H).toISOString(),
  join_url: 'https://meet.example.test/room', replay_url: null as string | null,
}));
function input(now: number, over: Partial<SchedInput> = {}): SchedInput {
  return {
    now: new Date(now), brand: 'Your Brand', appUrl: 'https://app.example.test', siteUrl: 'https://www.example.test', supportEmail: 'help@example.test',
    cohorts: [{ id: 'c1', name: 'Founding Cohort 01', time_zone: 'America/New_York', price_renewal: 49700, currency: 'usd' }],
    sessions: sess.map((s) => ({ ...s })),
    enrollments: [
      { id: 'e1', member_id: 'm1', cohort_id: 'c1', seat: 'founding', status: 'active', library_until: '2028-01-22T17:00:00.000Z', support_until: '2027-04-22T17:00:00.000Z' },
      { id: 'e2', member_id: 'm2', cohort_id: 'c1', seat: 'vip', status: 'refunded', library_until: null, support_until: null },
      { id: 'e3', member_id: 'm3', cohort_id: 'c1', seat: 'founding', status: 'active', library_until: null, support_until: null },
    ],
    members: [{ id: 'm1', email: 'alice@example.test', full_name: 'Alice Rivera' }, { id: 'm2', email: 'bob@example.test', full_name: 'Bob' }, { id: 'm3', email: 'erased-x@invalid.example', full_name: null }],
    calls: [{ id: 'k1', cohort_id: 'c1', starts_at: '2027-02-05T15:00:00.000Z', ends_at: '2027-02-05T16:00:00.000Z', join_url: 'https://meet.example.test/support' }],
    trainingLeads: [], training: {}, sent: new Set(), ...over,
  };
}
const kinds = (x: { kind: string }[]) => x.map((e) => e.kind);

describe('scheduled emails', () => {
  it('prep a week before, the evening-before note, and nothing to refunded or erased members', () => {
    const due = dueEmails(input(S1 - 6 * D));
    expect(kinds(due)).toEqual(['prep']);
    expect(due[0]).toMatchObject({ to: 'alice@example.test', key: 'prep:e1' });
    expect(due[0].text).toContain('Monday, January 11');
    expect(due[0].text).toContain('EST');
    expect(kinds(dueEmails(input(S1 - 20 * H)))).toEqual(['eve']);
  });
  it('reminds two hours before each session, in the cohort time zone, with what to have ready', () => {
    const due = dueEmails(input(S1 - 90 * 60_000));
    expect(kinds(due)).toEqual(['reminder']);
    expect(due[0].subject).toBe('Today at 10:00 AM EST: Session 1 · Foundations');
    expect(due[0].text).toContain('your for-claude folder');
    expect(due[0].text).toContain('https://meet.example.test/room');
  });
  it('sends each email once: a sent key is never repeated', () => {
    expect(dueEmails(input(S1 - 90 * 60_000, { sent: new Set(['soon:s1:m1']) }))).toEqual([]);
  });
  it('recording and homework only once a recording link is added, and not for demo day', () => {
    const t = Date.parse(sess[1].ends_at) + 3 * H;
    expect(dueEmails(input(t))).toEqual([]);
    const withRec = input(t); withRec.sessions[1].replay_url = 'https://video.example.test/2';
    const due = dueEmails(withRec);
    expect(kinds(due)).toEqual(['recording']);
    expect(due[0].text).toContain('https://video.example.test/2');
    expect(due[0].text).toContain('Finish the onboarding interview');
    const demo = input(Date.parse(sess[5].ends_at) + 3 * H); demo.sessions[5].replay_url = 'https://video.example.test/6';
    expect(kinds(dueEmails(demo))).toEqual([]);
  });
  it('a session’s own homework replaces the default', () => {
    const inp = input(Date.parse(sess[0].ends_at) + H); inp.sessions[0].replay_url = 'https://v.example.test/1'; inp.sessions[0].homework = 'Read chapter 2.';
    expect(dueEmails(inp)[0].text).toContain('Read chapter 2.');
  });
  it('support call two days before, 30-day check-in, support ending, library ending with the renewal link, library ended', () => {
    expect(kinds(dueEmails(input(Date.parse('2027-02-04T12:00:00Z'))))).toEqual(['support-call']);
    expect(kinds(dueEmails(input(Date.parse(sess[5].ends_at) + 31 * D)))).toEqual(['follow-up']);
    expect(kinds(dueEmails(input(Date.parse('2027-04-22T17:00:00Z') - 9 * D)))).toEqual(['support-ending']);
    const lib = dueEmails(input(Date.parse('2028-01-22T17:00:00Z') - 29 * D));
    expect(kinds(lib)).toEqual(['library-ending']);
    expect(lib[0].text).toContain('https://app.example.test/member/renew');
    expect(kinds(dueEmails(input(Date.parse('2028-01-22T17:00:00Z') + D)))).toEqual(['library-ended']);
  });
  it('without a renewal price the library email asks them to reply instead', () => {
    const inp = input(Date.parse('2028-01-22T17:00:00Z') - 29 * D); inp.cohorts[0].price_renewal = null;
    expect(dueEmails(inp)[0].text).toContain('reply to this email');
  });
  it('outside every window nothing is sent, so switching the job on late sends nothing stale', () => {
    expect(dueEmails(input(S1 + 60 * D))).toEqual([]);
  });
  it('free training: day-before and hour-before reminders and the replay, once per address, only for people registered before it', () => {
    const start = '2026-12-10T10:00:00-05:00', ts = Date.parse(start);
    const leads = [
      { id: 'l1', email: 'Pat@Example.test', name: 'Pat Doe', created_at: '2026-11-01T00:00:00Z' },
      { id: 'l2', email: 'pat@example.test', name: 'Pat', created_at: '2026-11-02T00:00:00Z' },
      { id: 'l3', email: 'late@example.test', name: null, created_at: '2026-12-11T00:00:00Z' },
    ];
    const base = { trainingLeads: leads, training: { start, joinUrl: 'https://webinar.example.test/j', replayUrl: 'https://webinar.example.test/r', timeZone: 'America/New_York' }, enrollments: [] };
    const eve = dueEmails(input(ts - 20 * H, base));
    expect(eve.map((e) => e.to)).toEqual(['pat@example.test']);
    expect(eve[0].text).toContain('https://webinar.example.test/j');
    expect(kinds(dueEmails(input(ts - 30 * 60_000, base)))).toEqual(['training-reminder']);
    expect(kinds(dueEmails(input(ts + 3 * H, base)))).toEqual(['training-replay']);
  });
});
