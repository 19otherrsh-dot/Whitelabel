import { beforeEach, describe, expect, it, vi } from 'vitest';
import { FakeDb } from './fakes/supabase';

const db = new FakeDb();
vi.mock('@/lib/supabase/admin', () => ({ supabaseAdmin: () => db.client() }));
const { findPerson, erasePerson } = await import('@/lib/privacy');

const ID = '00000000-0000-0000-0000-0000000000aa';
beforeEach(() => {
  db.tables = {}; db.users = [{ id: ID, email: 'pat@example.test' }];
  db.seed('members', [{ id: ID, email: 'pat@example.test', full_name: 'Pat Doe', company: 'Doe Ltd' }]);
  db.seed('enrollments', [{ member_id: ID, cohort_id: 'c', seat: 'founding', amount_paid: 149700, stripe_customer: 'cus_1' }]);
  db.seed('leads', [{ kind: 'audit', email: 'PAT@example.test', payload: {} }, { kind: 'contact', email: 'someone@example.test', payload: {} }]);
  db.seed('support_requests', [{ member_id: ID, subject: 'Help', body: 'Something private' }]);
  db.seed('guarantee_claims', [{ member_id: ID, enrollment_id: 'e', kind: 'cooling_off', reason: 'Personal reasons', evidence: { url: 'x' } }]);
  db.seed('attendance', [{ member_id: ID, session_id: 's', attended: true }]);
  db.seed('course_progress', [{ member_id: ID, lesson_id: '1.1' }]);
  db.seed('quiz_attempts', [{ member_id: ID, module: 1, answers: {}, score: 5, total: 5, passed: true }]);
  db.seed('course_submissions', [{ member_id: ID, module: 1, body: 'doctor output: all fine, private notes' }]);
  db.seed('course_certificates', [{ member_id: ID, name: 'Pat Doe', code: 'ABCD-EFGH-JKLM' }]);
  db.seed('instructors', [{ id: '50000000-0000-0000-0000-000000000001', email: 'Pat@example.test', name: 'Pat Doe' }]);
  db.seed('exam_attempts', [{ instructor_id: '50000000-0000-0000-0000-000000000001', token_hash: 'h', expires_at: '2030-01-01T00:00:00Z', answers: { 2: 'draft, approve, autonomous' } }]);
});

describe('privacy requests', () => {
  it('matches the exact address only: _ and % in an email are not wildcards', async () => {
    db.seed('leads', [{ kind: 'audit', email: 'a_b@example.test', payload: {} }, { kind: 'audit', email: 'axb@example.test', payload: {} }, { kind: 'audit', email: 'a%@example.test', payload: {} }]);
    expect((await findPerson('a_b@example.test')).leads.map((l: { email: string }) => l.email)).toEqual(['a_b@example.test']);
    await erasePerson('a_b@example.test');
    expect(db.t('leads').map((l) => l.email)).toContain('axb@example.test');
    expect((await findPerson('a%@example.test')).leads).toHaveLength(1);
  });

  it('finds everything held about an email, case-insensitively', async () => {
    const p = await findPerson(' Pat@Example.test ');
    expect(p.leads).toHaveLength(1);
    expect(p.member).not.toBeNull();
    expect(p.enrollments).toHaveLength(1);
    expect(p.support).toHaveLength(1);
    expect(p.claims).toHaveLength(1);
    expect(p.attendance).toHaveLength(1);
    expect(p.course.submissions).toHaveLength(1);
    expect(p.course.certificates).toHaveLength(1);
    expect(p.instructor).not.toBeNull();
    expect(p.exams).toHaveLength(1);
  });

  it('erases personal data but keeps anonymised purchase records', async () => {
    const r = await erasePerson('pat@example.test');
    expect(r).toEqual({ leads: 1, member: true, instructor: true });
    expect(db.t('leads').map((l) => l.email)).toEqual(['someone@example.test']);
    expect(db.t('support_requests')).toHaveLength(0);
    expect(db.t('attendance')).toHaveLength(0);
    for (const t of ['course_progress', 'quiz_attempts', 'course_submissions', 'course_certificates', 'instructors', 'exam_attempts']) expect(db.t(t), t).toHaveLength(0);
    const [m] = db.t('members');
    expect(m.email).toMatch(/^erased-.*@invalid\.example$/);
    expect(m.full_name).toBeNull();
    expect(db.t('enrollments')[0]).toMatchObject({ amount_paid: 149700, stripe_customer: null });
    expect(db.t('guarantee_claims')[0]).toMatchObject({ reason: '[erased]', evidence: {} });
    expect(db.users[0].email).toMatch(/^erased-/);
    expect(await findPerson('pat@example.test')).toMatchObject({ leads: [], member: null });
  });
});
