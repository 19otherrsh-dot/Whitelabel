import { describe, expect, it } from 'vitest';
import { auditAnswersFile } from '../src/lib/auditAnswers';

describe('audit answers for the onboarding interview', () => {
  it('maps what the audit stored into the file the kit reads', () => {
    const f = auditAnswersFile({ company: 'Acme', created_at: '2026-09-01T00:00:00Z', payload: { businessType: 'agency', teamSize: 's6', departments: ['Sales', 'Operations'], tools: ['crm', 'meet'], start: ['Cold Email Drafting'], estimate: 84000 } });
    expect(f).toMatchObject({ format: 'audit-answers/1', company: 'Acme', businessType: 'agency', teamSize: 's6', teamSizeLabel: '6-15', departments: ['Sales', 'Operations'], suggestedStart: ['Cold Email Drafting'] });
    expect(f.tools[0]).toEqual({ id: 'crm', label: 'a CRM' });
    expect(f.estimate?.yearlyValue).toBe(84000);
  });
  it('copes with an empty or odd payload', () => {
    const f = auditAnswersFile({ company: null, created_at: 'x', payload: { departments: 'Sales', tools: [1, 'crm'] } });
    expect(f).toMatchObject({ businessType: null, departments: [], estimate: null });
    expect(f.tools).toEqual([{ id: 'crm', label: 'a CRM' }]);
  });
});
