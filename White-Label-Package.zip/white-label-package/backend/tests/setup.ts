// Test environment: placeholder values only. Nothing here reaches a real service.
Object.assign(process.env, {
  APP_URL: 'https://app.example.test',
  SITE_URL: 'https://www.example.test',
  ALLOWED_ORIGINS: 'https://www.example.test',
  BRAND_NAME: 'Your Brand',
  SUPPORT_EMAIL: 'support@example.test',
  DEFAULT_COHORT: 'founding-01',
  NEXT_PUBLIC_SUPABASE_URL: 'https://fake.supabase.test',
  NEXT_PUBLIC_SUPABASE_ANON_KEY: 'anon-key-for-tests-0000000000',
  SUPABASE_SERVICE_ROLE_KEY: 'service-key-for-tests-000000000',
  STRIPE_SECRET_KEY: 'sk_test_for_tests_only',
  STRIPE_WEBHOOK_SECRET: 'whsec_test_secret_for_tests',
  EMAIL_FROM: 'Your Brand <hello@example.test>',
  IP_HASH_SALT: 'test-salt-0123456789abcdef',
  RESEND_API_KEY: '',
});
