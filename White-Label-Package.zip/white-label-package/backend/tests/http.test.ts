import { describe, expect, it } from 'vitest';
import { corsHeaders, isAllowedOrigin } from '../src/lib/cors';
import { MemoryStore, rateLimit } from '../src/lib/ratelimit';
import { buildIcs } from '../src/lib/ics';
import { escapeHtml } from '../src/lib/html';

describe('cors', () => {
  const allowed = ['https://www.yourbrand.com', 'http://localhost:8000/'];
  it('allows listed origins, ignoring case and trailing slashes', () => {
    expect(isAllowedOrigin('https://WWW.yourbrand.com', allowed)).toBe(true);
    expect(isAllowedOrigin('http://localhost:8000', allowed)).toBe(true);
    expect(corsHeaders('https://www.yourbrand.com', allowed)['Access-Control-Allow-Origin']).toBe('https://www.yourbrand.com');
  });
  it('refuses others and missing origins', () => {
    expect(isAllowedOrigin('https://yourbrand.com.evil.example', allowed)).toBe(false);
    expect(isAllowedOrigin(null, allowed)).toBe(false);
    expect(corsHeaders('https://evil.example', allowed)['Access-Control-Allow-Origin']).toBeUndefined();
  });
});

describe('rate limit', () => {
  it('allows up to the limit per window, then resets', () => {
    const s = new MemoryStore();
    const t0 = 1_000_000;
    for (let i = 0; i < 3; i++) expect(rateLimit('k', 3, 1000, s, t0).ok).toBe(true);
    expect(rateLimit('k', 3, 1000, s, t0 + 10).ok).toBe(false);
    expect(rateLimit('other', 3, 1000, s, t0 + 10).ok).toBe(true);
    expect(rateLimit('k', 3, 1000, s, t0 + 1001).ok).toBe(true);
  });
});

describe('calendar', () => {
  it('writes valid, folded iCalendar with escaped text', () => {
    const ics = buildIcs('Your Brand · Cohort', [{ uid: 'a@x', title: 'Session 1, the start; ok', start: '2026-09-21T14:00:00Z', end: '2026-09-21T16:00:00Z', url: 'https://meet.example/' + 'x'.repeat(100), description: 'line1\nline2' }], new Date('2026-09-01T00:00:00Z'));
    expect(ics.startsWith('BEGIN:VCALENDAR\r\n')).toBe(true);
    expect(ics).toContain('DTSTART:20260921T140000Z');
    expect(ics).toContain('SUMMARY:Session 1\\, the start\; ok');
    expect(ics).toContain('DESCRIPTION:line1\\nline2');
    for (const line of ics.split('\r\n')) expect(Buffer.byteLength(line)).toBeLessThanOrEqual(75);
    expect(ics.trimEnd().endsWith('END:VCALENDAR')).toBe(true);
  });
});

describe('html', () => {
  it('escapes markup', () => {
    expect(escapeHtml(`<a href="x">'&'</a>`)).toBe('&lt;a href=&quot;x&quot;&gt;&#39;&amp;&#39;&lt;/a&gt;');
  });
});
