# Cohort back end

Checkout, member area, kit downloads, lead capture and admin for the white-label cohort site.
The marketing site stays a static folder; this app sits beside it on its own address
(for example `https://app.yourbrand.com`) and handles everything that needs a server.

Built with Next.js 16 (App Router), Supabase (Postgres, Auth, Storage) and Stripe Checkout.
Email goes through Resend's HTTP API. There is no brand name in the code: everything a buyer
changes is an environment variable or a row in the database.

If you would rather not run code at all, see **NO-CODE.md** for the same flows built from
hosted tools.

---

## What it does

| Area | What happens |
|---|---|
| **Checkout** `/checkout?seat=founding\|vip` | Shows the seat, price and places left, holds a place for 30 minutes, opens Stripe Checkout. Sold out, closed and past-deadline states are handled. Leaving Stripe releases the hold at once. |
| **Fulfilment** `/api/stripe/webhook` | Verifies Stripe's signature, records each event once (safe against retries), creates the member and their seat, sets library and support end dates, and emails a one-time sign-in link. Double purchases, missing data and overselling are flagged to a person, never guessed. Full refunds end access automatically; disputes alert support. |
| **Member area** `/member` | Next session, join links (highlighted an hour before), recordings, attendance, "add all to calendar" (.ics), the kit download (2-minute signed link), setup checklist, community link, and an optional upload for the kit's anonymous usage summary (stored with no link to the member). |
| **Support** `/member/support` | Members open requests; staff reply from admin; replies are emailed and kept in the thread. |
| **Refunds** `/member/guarantee` | Checks the cooling-off and build-guarantee windows exactly as `refunds.html` states them, using recorded attendance, and takes a request with evidence. |
| **Forms** `/api/audit`, `/api/contact`, `/api/waitlist` | JSON endpoints for the static site: origin allow-list, validation, honeypot, per-IP rate limit, salted IP hash (never the raw address). Optional forwarding to a CRM webhook. |
| **Hosted sign-ups** `/join?kind=waitlist\|training` | Ready-made waitlist and free-training forms with confirmation emails, for when you don't want to build forms. |
| **Admin** `/admin` | Seats, revenue, waiting work and anything needing attention; members (kit downloaded and setup confirmed, resend welcome, revoke, extend access); leads with CSV export; refund decisions (approve issues the Stripe refund); support replies; cohorts, sessions and attendance; kit releases (browser upload, SHA-256, "make current"); privacy requests (find, export as JSON, erase); skill usage from the anonymous summaries members choose to share (which kit skills fail or get rejected most, to improve first); the quarterly licensee report (Schedule 4 of the licence agreement: seats, refunds, revenue, attendance, leads, support) with JSON download. |
| **Licensor report** `/api/licensor/report?quarter=YYYY-Qn` | Off unless `LICENSOR_REPORT_TOKEN` is set. The same quarterly report for the licensor's fleet console (`../licensor/`), behind a bearer token: counts and totals only, no personal data. |
| **Course** `/member/course` | Six modules and 34 lessons (outline, commands, video link), "mark as watched", a five-question quiz per module graded on the server (answers never reach the browser; retakes allowed), an assignment per module reviewed by staff, and a certificate of completion with a public check at `/certificate/<code>`. Open to every active seat; a cohort marked *self-paced* sells it on its own. |
| **Instructor certification** `/admin/instructors`, `/exam/<link>` | Records for each instructor and TA (Parts 1–5, shadowing, level, renewal, kit version), and the written exam online: a private 14-day link, a 45-minute server-enforced clock, multiple choice marked automatically, short answers marked by an assessor beside the key, pass = 24/30 and every ★ safety question. |

## The course and the instructor exam

**Content.** Lessons, quizzes and the exam are built from the delivery Markdown, so there's one source:

```bash
node scripts/build-course.mjs          # after editing ../delivery/self-paced/*.md or ../delivery/instructor/exam*.md
node scripts/build-course.mjs --check  # fails if src/content/*.json is out of date (the tests check this too)
```

Keep quiz options as `a)`, `b)`… with the correct one in **bold**; the build refuses a question
without one rather than guessing.

**Videos.** Record the lessons (`../delivery/self-paced/README.md`, "Production"), host them where
members can watch (your video host or course platform, unlisted or members-only), then paste each
link in Admin → **Course** → *Lesson videos*. Until a lesson has a video, members see its outline and
"video coming soon".

**Reviewing.** Admin → **Course** lists submissions oldest first with the module's "complete when"
check. *Complete* or *Not yet* (with exactly what's missing) emails the member. A module is complete
when its quiz is passed and its assignment accepted; all six = the certificate.

**Selling self-paced on its own.** Create a cohort, tick *Self-paced course*, set VIP seats to 0 and
the founding price to the course price, and add no sessions. Checkout then says "Self-paced course",
the member page leads with the course, and refunds follow the money-back window (default 14 days
while no more than two modules are complete) instead of the build guarantee. Update `refunds.html`
and `terms.html` on the site to say the same.

**The exam.** Admin → **Instructors** → add the person → *Invite to the written exam*. They get a
private link (only its hash is stored). The clock starts when they press Start; after 45 minutes
plus 2 minutes' grace, the last saved answers are handed in. Mark the short answers, add feedback,
and the result is emailed; a pass records Part 2 on their record. Levels can't be set above what the
recorded parts support, and certifying sets the 12-month renewal date.

## Scheduled emails

Reminders before each session, the recording and homework when you add a recording link, support-call
reminders, the 30-day check-in, and the support-ending and library notices (with the renewal link) go out
on their own once the scheduler runs (see `delivery/emails/sequence.md` for the full list and timing):

1. Set `CRON_SECRET` (24+ random characters) in the app's environment.
2. Have something call `GET /api/cron/emails` with `Authorization: Bearer <CRON_SECRET>` every 15 minutes
   (at least hourly). The simplest is Supabase itself: edit and run `supabase/cron-emails.example.sql`.
   Vercel's own cron also works on its Pro plan (Hobby only allows once a day, too rarely for reminders).
3. Admin → **Emails** shows what's due now, what was sent, and a "Send what's due now" button.

Each email goes once (`email_log`), only inside its time window, so switching the scheduler on late never
sends stale reminders; a failed send is retried on the next run.

## Renewals and invoices

**Renewing library access.** Each seat includes `library_months` of new kit releases. To sell more:

1. Admin → **Cohorts** → set *Renewal price* (blank = renewals off) and *Months added* (1–36, default 12).
2. Members see "Library access and renewal" on their page (and the library-ending email links to it).
   `/member/renew` shows the price and opens a one-off Stripe Checkout, not a subscription.
3. When Stripe confirms, the webhook adds the months to whatever time is left (or to today if access has
   ended), records it in `renewals` (once per Checkout, safe against retries) and emails a confirmation.
4. A full refund of the renewal in Stripe takes those months back, unless access was changed again since;
   the seat itself stays active.

**Invoices and VAT/tax IDs.** Set `STRIPE_INVOICES=true` and every Checkout (seats and renewals) creates
a Stripe invoice the buyer can download as a PDF, and lets business buyers add a VAT or tax ID. Stripe
charges a small fee per invoice; check the current rate on Stripe's pricing page. Collecting tax itself
(Stripe Tax) is a separate switch in the Stripe dashboard; ask your accountant whether you need it.

**Local currencies.** Stripe's Adaptive Pricing shows overseas buyers the price in their own currency.
Turn it on in Stripe → Settings → Payments → Adaptive Pricing. It isn't available to every business
location (for example, not to businesses based in India), and the buyer pays the conversion cost.

## How it fits together

```
 Static site (your domain)                 This app (app.your domain)              Services
 ─────────────────────────                 ──────────────────────────              ────────
 pricing.html  "Reserve my seat" ───────▶  /checkout ── hold seat ──────────────▶ Supabase (Postgres)
                                           └─ Stripe Checkout session ──────────▶ Stripe
 thank-you.html ◀── success_url ──────────────────────────────────── Stripe ──┐
                                           /api/stripe/webhook ◀──────────────┘
                                             ├─ member + seat ──────────────────▶ Supabase Auth / DB
                                             └─ welcome email + sign-in link ───▶ Resend
 audit.html / contact.html ── JSON POST ─▶ /api/audit, /api/contact ───────────▶ leads table (+ CRM)
 Member's inbox ── sign-in link ─────────▶ /auth/confirm ─▶ /member ── download ▶ Supabase Storage (private)
```

Security model: row-level security is on for every table. The browser only ever holds the
public anon key and can see only the member's own rows; leads, checkout holds and Stripe events
have no browser access at all. The service-role key is used only in server code, after an
explicit check of who is asking. `supabase/tests/rls_test.sql` proves each of these rules.

---

## Set it up

You need: Node 20.9 or later, a Supabase project, a Stripe account, a Resend account (or skip
email in development), and somewhere to run a Node app (Vercel, Render, Fly.io, Railway, a VPS).

### 1. Install

```bash
npm install
cp .env.example .env.local      # then fill it in, step by step below
```

### 2. Supabase

1. Create a project. In **Project settings → API** copy the URL, the `anon` key and the
   `service_role` key into `.env.local`.
2. Run the schema: paste each file in `supabase/migrations/` into the **SQL editor**, in order
   (`0001_init.sql`, `0002_usage_reports.sql`, `0003_setup_done.sql`), and run it (or `supabase db push` with the CLI).
   They are safe to run again.
3. Edit and run `supabase/seed.sql` for your first cohort (or create it later in `/admin/cohorts`).
4. **Authentication → Providers → Email**: keep email sign-in on. Members are created only at
   checkout and the sign-in form never creates accounts, so turning off "Allow new users to sign
   up" is recommended.
5. **Authentication → URL configuration**: Site URL = your `APP_URL`; add
   `https://<APP_URL>/auth/callback` and `https://<APP_URL>/auth/confirm` as redirect URLs.
6. **Authentication → Email templates → Magic link**: make the link
   `{{ .SiteURL }}/auth/confirm?token_hash={{ .TokenHash }}&type=magiclink&next=/member`.
   This works when members open the email on a different device. (The default template also
   works, through `/auth/callback`, on the same browser.)
7. **Authentication → SMTP**: set a custom SMTP sender (Resend provides one) so sign-in emails
   come from your domain and aren't throttled by the built-in sender.

### 3. Stripe

1. **Developers → API keys**: copy the secret key (use test mode first).
2. **Developers → Webhooks → Add endpoint**: `https://<APP_URL>/api/stripe/webhook` with events
   `checkout.session.completed`, `checkout.session.async_payment_succeeded`,
   `checkout.session.async_payment_failed`, `checkout.session.expired`, `charge.refunded`,
   `charge.dispute.created`. Copy the signing secret into `STRIPE_WEBHOOK_SECRET`.
3. Optional: switch on **Stripe Tax** and set `STRIPE_AUTOMATIC_TAX=true`.
4. Optional: switch on **Adaptive Pricing** (Settings → Adaptive Pricing) so buyers pay in their own currency
   at checkout. Nothing changes here: Stripe still reports the amount in your cohort's currency, which is what
   the back end records. (Not offered to Stripe accounts of businesses in India.)
5. Prices come from the cohort row, not from Stripe products, so you change them in
   `/admin/cohorts`. Keep the site's `assets/config.js` prices in step.

To test locally: `stripe listen --forward-to localhost:3000/api/stripe/webhook`, then buy with
card `4242 4242 4242 4242`.

### 4. Email

Create a Resend API key and verify your sending domain, then set `RESEND_API_KEY` and
`EMAIL_FROM`. With no key, emails are printed in the server log, which is handy in development.

### 5. Run and deploy

```bash
npm run dev        # http://localhost:3000
npm run build && npm start
```

On Vercel: import the folder, add every variable from `.env.example`, deploy. On any other host:
`npm ci && npm run build && npm start` behind HTTPS. Check `https://<APP_URL>/api/health`.

### 6. Make yourself an admin

Buy a seat in test mode (or add yourself with the SQL editor), sign in once, then run:

```sql
insert into admins (user_id) select id from auth.users where email = 'you@yourbrand.com';
```

`/admin` then appears in your member nav.

### 7. Connect the static site

In the site's `assets/config.js`:

```js
links: {
  checkoutFounding: "https://app.yourbrand.com/checkout?seat=founding",
  checkoutVip:      "https://app.yourbrand.com/checkout?seat=vip",
  waitlist:         "https://app.yourbrand.com/join?kind=waitlist",
  trainingRegistration: "https://app.yourbrand.com/join?kind=training",
  auditWebhook:     "https://app.yourbrand.com/api/audit",
  contactWebhook:   "https://app.yourbrand.com/api/contact",
  // bookCall, community: your scheduling and community links
}
```

and set `ALLOWED_ORIGINS` here to the site's exact origin(s), e.g.
`https://www.yourbrand.com,https://yourbrand.com`. Add `?cohort=<slug>` to the checkout links to
sell a cohort other than `DEFAULT_COHORT`.

### 8. Upload the kit

Build it with `node build/release.mjs` (in the product folder), then upload
`dist/workforce-kit-<version>.zip` in `/admin/releases`. Members download the version marked
current; installed kits update with `wf update --from <zip>`.

---

## Running a cohort

- **Before Session 1**: add each session's join link in `/admin/cohorts`. Members see links in
  their area and in the calendar file.
- **After each session**: tick attendance (from the meeting tool's attendance report) and add the
  recording link. The build guarantee depends on attendance, and members see what was recorded.
- **Refund requests** arrive by email and under **Refunds** in admin (`/admin/claims`). The public promise is a reply within
  two working days. Approving refunds in full through Stripe; the webhook then ends access and
  emails the member. Declining needs a note, which the member sees.
- **Needs attention** on the dashboard lists double purchases, disputes, failed emails and Stripe
  events that keep failing.
- **Next cohort**: create it in `/admin/cohorts`, add sessions, close the old one's checkout.

## Tests

```bash
npm test               # 76 unit, integration and render tests (no network, no database)
scripts/test-db.sh     # 46 database checks: RLS, seat counting, constraints (needs local PostgreSQL 15+)
npm run typecheck
```

The integration tests drive the real webhook and form handlers with genuine Stripe signatures
against an in-memory database: fulfilment, idempotency, double purchases, refunds, disputes,
retries after failure, origin checks, honeypot, rate limits and validation. The render tests
draw every member and admin page with realistic data.

## Things to know

- **Rate limits are per server instance** (in memory). That stops casual abuse of the forms. On
  serverless hosting with many instances, swap `src/lib/ratelimit.ts`'s store for a shared one
  (Upstash Redis or a table); the interface is one method.
- **Seats**: VIP places sit inside the total (the pricing page says "5 VIP places within the 50").
  Founding can use any free place; VIP is also capped. A buyer's place is held for 35 minutes
  while they pay, so the last seat can't be sold twice.
- **Times** are stored in UTC and shown in the cohort's time zone. In admin you type them with
  their offset (`2026-09-21T10:00-04:00`) so there's never doubt about daylight saving.
- **Data**: leads store a salted hash of the IP, not the address. Marketing consent is recorded
  separately from "reply to me". Exports are logged in `admin_log`. Update the site's
  `privacy.html` to name Supabase, Stripe and Resend as processors and where they store data.
- **Legal**: the checkout shows links to the Terms and Refund policy. Have both reviewed before
  taking real payments.

## Files

```
supabase/migrations/0001_init.sql   schema, RLS, seat functions, storage bucket
supabase/migrations/0002_usage_reports.sql   anonymous usage summaries (server-only table)
supabase/migrations/0003_setup_done.sql      setup completion on each seat
supabase/seed.sql                   example cohort and sessions
supabase/tests/                     database tests (+ stub of Supabase's built-ins for plain Postgres)
src/proxy.ts                        session refresh; sends signed-out visitors to /login
src/lib/rules.ts                    business rules as pure functions (seats, access, refunds)
src/lib/fulfil.ts                   Stripe → member, seat, email; refunds; disputes
src/lib/checkout.ts                 seat hold + Stripe Checkout session
src/lib/validation.ts               input schemas, matching what the site sends
src/app/…                           pages and route handlers
tests/                              unit, integration and render tests
NO-CODE.md                          the hosted-tools alternative
```
