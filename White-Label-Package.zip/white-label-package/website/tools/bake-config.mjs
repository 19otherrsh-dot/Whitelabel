#!/usr/bin/env node
// Write the dates, times, prices and names from assets/config.js into the pages' own text.
//
//   node tools/bake-config.mjs
//
// The site already applies config.js in the browser. Baking it in as well means search engines,
// link previews, people with JavaScript off and printouts all see the same dates and prices.
// Run it after every change to config.js (then run tools/build-seo.mjs if you use it).
// It uses the exact same rules as assets/site.js (it reads them from that file), and only changes the
// text inside elements marked data-cfg, and the training time on data-cfg-datetime / data-countdown.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const SITE = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sandbox = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(SITE, 'assets', 'config.js'), 'utf8'), sandbox);
const C = sandbox.window.SITE_CONFIG || {};
for (const k of ['links', 'labels', 'company', 'cohort', 'training', 'prices']) C[k] = C[k] || {};
const brand = C.brandName || 'Your Brand';

// Lift the value rules out of site.js so the two can never disagree.
const src = fs.readFileSync(path.join(SITE, 'assets', 'site.js'), 'utf8');
const a = src.indexOf('  var MONTHS = '), b = src.indexOf("  ss.forEach(function (s, i) { V['cohort.s'");
if (a < 0 || b < 0) { console.error('assets/site.js has changed shape; update tools/bake-config.mjs'); process.exit(1); }
const end = src.indexOf('\n', b);
const V = new Function('C', 'brand', `${src.slice(a, end)}\n  return V;`)(C, brand);

const escText = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escAttr = (s) => escText(s).replace(/"/g, '&quot;');
const start = C.training.start || '';
let changed = 0;
for (const file of fs.readdirSync(SITE).filter((f) => f.endsWith('.html'))) {
  const p = path.join(SITE, file);
  const before = fs.readFileSync(p, 'utf8');
  let html = before.replace(/(<([a-z0-9]+)\b[^>]*\bdata-cfg="([\w.]+)"[^>]*>)([^<]*)(<\/\2>)/gi, (m, open, tag, key, text, close) => (V[key] ? open + escText(V[key]) + close : m));
  if (start) {
    html = html.replace(/(<[^>]*\bdata-cfg-datetime="training\.start"[^>]*)/g, (tag) => tag.replace(/\bdatetime="[^"]*"/, `datetime="${escAttr(start)}"`));
    html = html.replace(/\bdata-countdown="[^"]*"/g, `data-countdown="${escAttr(start)}"`);
  }
  if (html !== before) { fs.writeFileSync(p, html); changed++; }
}
console.log(`Baked config.js into ${changed} page(s): ${V['cohort.range'] || '(no cohort dates)'} · training ${V['training.short'] || '(none)'} · ${V['prices.founding'] || ''}`);
