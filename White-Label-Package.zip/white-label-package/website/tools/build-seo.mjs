#!/usr/bin/env node
// Search and social metadata for every page.
//
//   node tools/build-seo.mjs                          social tags only (title, description, type)
//   node tools/build-seo.mjs https://www.example.com  also canonical links, og:url, sitemap.xml and robots.txt
//                                                     (share platforms need the full address for the image too)
//
// Safe to run again after editing pages or changing the domain: it replaces what it wrote before
// (between the <!-- seo --> markers) and nothing else. Pages marked noindex are left out of the sitemap.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SITE = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const base = (process.argv[2] || '').replace(/\/+$/, '');
if (base && !/^https:\/\/[a-z0-9.-]+(:\d+)?(\/[\w./-]*)?$/i.test(base)) {
  console.error('Give the full https address, e.g. https://www.yourbrand.com');
  process.exit(1);
}
const esc = (s) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
const pages = fs.readdirSync(SITE).filter((f) => f.endsWith('.html')).sort();
const listed = [];
const shareImg = fs.existsSync(path.join(SITE, 'assets', 'img', 'share.png'));   // made by tools/make-share-image.mjs

for (const file of pages) {
  const p = path.join(SITE, file);
  let html = fs.readFileSync(p, 'utf8').replace(/\n?<!-- seo -->[\s\S]*?<!-- \/seo -->/, '');
  const title = (html.match(/<title>([^<]*)<\/title>/) || [])[1] || '';
  const desc = (html.match(/<meta name="description" content="([^"]*)"/) || [])[1] || '';
  const noindex = /<meta name="robots" content="[^"]*noindex/.test(html);
  const url = base ? `${base}/${file === 'index.html' ? '' : file}` : '';
  const tags = [
    `<meta property="og:type" content="website">`,
    `<meta property="og:title" content="${esc(title)}">`,
    desc && `<meta property="og:description" content="${desc}">`,
    shareImg && `<meta property="og:image" content="${base ? base + '/' : ''}assets/img/share.png">`,
    shareImg && `<meta property="og:image:width" content="1200">`,
    shareImg && `<meta property="og:image:height" content="630">`,
    shareImg && `<meta property="og:image:alt" content="${esc(title)}">`,
    `<meta name="twitter:card" content="${shareImg ? 'summary_large_image' : 'summary'}">`,
    url && !noindex && `<link rel="canonical" href="${url}">`,
    url && `<meta property="og:url" content="${url}">`,
  ].filter(Boolean);
  html = html.replace('</title>', `</title>\n<!-- seo -->\n${tags.join('\n')}\n<!-- /seo -->`);
  fs.writeFileSync(p, html);
  if (!noindex && file !== '404.html') listed.push(url || file);
}

if (base) {
  const today = new Date().toISOString().slice(0, 10);
  fs.writeFileSync(path.join(SITE, 'sitemap.xml'), `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${listed.map((u) => `  <url><loc>${u}</loc><lastmod>${today}</lastmod></url>`).join('\n')}\n</urlset>\n`);
  fs.writeFileSync(path.join(SITE, 'robots.txt'), `User-agent: *\nAllow: /\nDisallow: /thank-you.html\n\nSitemap: ${base}/sitemap.xml\n`);
  console.log(`Wrote canonical links for ${listed.length} pages, sitemap.xml and robots.txt for ${base}`);
  console.log('Also set siteUrl in assets/config.js to the same address.');
} else {
  console.log(`Wrote social tags for ${pages.length} pages. Run again with your domain to add canonical links, sitemap.xml and robots.txt.`);
}
