#!/usr/bin/env node
// Render the social share image (assets/img/share.png, 1200×630) with the brand name from assets/config.js.
//   node tools/make-share-image.mjs
// Needs Playwright with Chromium (npm i -D playwright && npx playwright install chromium). Then run
// tools/build-seo.mjs, which adds the image to every page's share tags.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath, pathToFileURL } from 'node:url';

const SITE = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const box = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(SITE, 'assets', 'config.js'), 'utf8'), box);
const brand = box.window.SITE_CONFIG?.brandName || 'Your Brand';
let chromium;
try { ({ chromium } = await import('playwright')); } catch { console.error('Playwright is not installed: npm i -D playwright && npx playwright install chromium'); process.exit(1); }
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 1200, height: 630 } });
await p.goto(`${pathToFileURL(path.join(SITE, 'tools', 'share-image.html')).href}?brand=${encodeURIComponent(brand)}`);
await p.evaluate(() => document.fonts.ready);
await p.screenshot({ path: path.join(SITE, 'assets', 'img', 'share.png') });
await b.close();
console.log(`✓ assets/img/share.png (${brand})`);
