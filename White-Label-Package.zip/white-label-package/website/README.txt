WHITE-LABEL COHORT SITE · "Take repeat work off your plate"
=============================================================
Private build for internal and investor review. No company, product or person names
appear anywhere in the pages or their code. Every brand slot reads "Your Brand".


OPEN IT
-------
Double-click index.html. Every page works from the folder; nothing is hosted.
If a browser blocks the embedded map or dashboards when opened straight from disk
(some Safari settings do), run a local preview from this folder instead:
    python3 -m http.server 8000      then open  http://localhost:8000
Fonts are self-hosted (assets/fonts/, SIL Open Font License). The pages make no requests
to any other server unless you switch on analytics or set a webhook in the config.


PAGES
-----
index.html           Home: hero, the bottleneck, example outreach build with the live map,
                     pick your first department, the AI workforce org chart (each agent
                     opens its real skill on the map), results (hidden until you add real
                     proof), audit call-out
how-it-works.html    Who it is for, the onboarding interview, the six sessions (class schedule),
                     what you walk out with, the workspace folder, the live command centers
pricing.html         Founding and VIP seats, guarantee, member perks (off by default), FAQ
faq.html             18 questions, including cost, time, data, results, refunds and tools
free-training.html   Free live training, choosing your first department
map.html             The full-screen interactive map: MAP (the wheel), CHART (every job as
                     a searchable list) and DASHBOARDS (the command-center carousel)
audit.html           Free AI workforce audit: five questions, then a per-company result,
                     with a share link, "Save as PDF" and a link to the methodology
methodology.html     Exactly how the audit calculates its estimate
compare.html         How the cohort compares with hosted AI apps, automation tools and hiring it out
results.html         Real, counted outcomes per cohort (from config.outcomes); says so honestly while empty.
                     Its footer link appears only once there are results
resources.html       Three free guides as PDFs in resources/ (rebuilt by build/site_extras.py)
contact.html         Contact form (sends to your webhook, or opens an email)
thank-you.html       After checkout or registration: ?for=founding|vip|training|waitlist|contact
404.html             Not-found page (point your host's 404 setting at it)
terms.html, refunds.html, privacy.html, cookies.html, ai-disclosure.html
                     Legal templates. They show a "template for legal review" note until
                     company.legalName is set. Have a lawyer review them before launch.


WHAT TO EDIT
------------
1. assets/config.js (the one file to edit)
   brandName            nav, footer, titles, audit page, legal pages
   company              legal name, address, contact and privacy emails, governing law
   siteUrl              your public address (also run the SEO tool below)
   links.*              checkout links, booking, training registration, waitlist, webhooks.
                        While a link is empty, clicking it shows a short "placeholder" note.
   cohort               session dates, days, times, time zone, enrollment close, seats,
                        support days, library months. Every date on the site comes from here.
   training.start       the free training (also drives the home-page countdown)
   prices               seat prices and currency (for buyers abroad, turn on Stripe Adaptive Pricing:
                        checkout then shows their own currency)
   features.localTime   adds "(… your time)" after session and training times for visitors in
                        other time zones (on by default)
   features.perks       the member-perks section (off: the original partner deals were not
                        part of this build; only switch on with a real perks programme)
   webhookFormat        "json" for the included back end; "simple" for Zapier / Make / n8n
                        webhook URLs (see the back end's NO-CODE.md)
   analytics            off by default; "plausible", "ga4" or "custom". With requireConsent
                        (the default) it loads only after the visitor accepts the banner.
                        Then it also records the funnel: each audit step reached, share/PDF,
                        seat, call, training and waitlist clicks, form submits (no personal data).
   proof                real, permissioned results and quotes. Empty = section hidden.
   instructors          "Who teaches it" on How it works. Empty = section hidden.
   outcomes             counted results per cohort for results.html. Never estimate.
   logo                 your logo instead of the circle mark
   appTheme             colour overrides inside the embedded map and dashboards
   audit.anchorLine     the line under the audit result's buttons
   theme                optional colour overrides (CSS variables); empty = original design

   The pages keep sensible default text in the HTML, so they read correctly even if
   JavaScript is off. The dates shipped are placeholders (a January 2027 cohort, free training
   on 10 December 2026): set your own before launch, then run step 2.

2. Bake the config into the pages, so search engines, link previews and visitors without
   JavaScript see the same dates and prices:
       node tools/bake-config.mjs
   (re-run after every change to assets/config.js)

3. Share image: assets/img/share.png (1200×630) shows "Your Brand". To put your name on it:
       node tools/make-share-image.mjs        (needs Playwright; or edit tools/share-image.html
                                                and screenshot it at 1200×630 yourself)

4. Search and social tags:
       node tools/build-seo.mjs https://your-domain.com
   writes canonical links, og:url, the share image tags, sitemap.xml and robots.txt
   (re-run after edits).
   Structured data (Organization, Course, FAQPage) is added automatically from the config.
   Meta descriptions mention prices; update them in each page's <head> if prices change.

5. Logo: the brand mark is a neutral circle drawn in CSS (.mark in assets/site.css,
   .pf-mark in assets/audit.css) and favicon.svg. Swap in the buyer's mark.

6. Claims the buyer must be able to stand behind (all now match the workspace kit):
   prices, seat numbers, the cooling-off and build guarantee (refunds.html has the full
   conditions), "20 OS tools", "5 encoded workspaces", "90 pre-installed skills",
   12 months of library access, 90 days of support. "This is the real thing, live below"
   sits above dashboards showing demo data; soften it if buyers could read it as live
   client data.

7. Checkout, member area and forms: the back end in product/backend (Next.js + Supabase +
   Stripe) gives you the links to put in links.* (see its README, "Connect the static site").
   No developer? product/backend/NO-CODE.md does the same with Stripe Payment Links and an
   automation tool.

8. The audit model is documented at the top of assets/audit.js and on methodology.html.
   Tune the tables in audit.js and keep methodology.html in step.


FILES
-----
assets/site.css            styles for the light pages (original design, plus added-page styles at the end)
assets/site.js             applies the config: brand, dates, prices, legal details, links,
                           proof, structured data, consent-gated analytics, contact form, menu
assets/config.js           the one file to edit
assets/audit.css/.js       audit page; assets/audit-jobs.js = the 137 jobs
assets/map-app.html        the interactive map (also embedded on Home and the audit)
assets/dashboards-app.html the command centers (DASHBOARDS tab and How it works)
assets/fonts/              self-hosted fonts and their licence
assets/img/                logos for dashboard cards and the optional perks section
tools/build-seo.mjs        search and social metadata
tools/bake-config.mjs      writes config.js dates, prices and names into the pages
tools/make-share-image.mjs the social share image (from tools/share-image.html)

Removed from the embedded apps: analytics (Microsoft Clarity, PostHog), sign-in and paid
unlock calls to remote servers, the email gate and lead capture, and all remote links.
The two app files here are minified to load faster; the same apps, readable, are in the
workspace kit (map/index.html and map/dashboards.html). Both work with the keyboard.
