/* =====================================================================
   SITE CONFIG · the one file to edit when this site is white-labelled.
   ---------------------------------------------------------------------
   Every page reads this file. Text on the pages keeps a sensible default,
   so the site still reads correctly if a value is missing.

   brandName    Shown in the nav, footer, audit page and page titles.
   company      Legal details used on the contact and legal pages.
   siteUrl      Your public address (https://…), used for structured data.
                Run `node tools/build-seo.mjs https://your-domain` once it's
                known to write canonical links, sitemap.xml and robots.txt.
   links        Leave a link as "" to keep it as a placeholder: visitors who
                click it see a short note instead of a dead link.
   cohort       Dates, times and seats. Every date on the site comes from here.
   training     The free live training.
   prices       Seat prices.
   features     Optional sections (off by default).
   analytics    Off by default. When on, it only loads after the visitor accepts.
   proof        Real, permissioned results and quotes. Empty = the section stays hidden.
   theme        Optional colour overrides (CSS variables). Empty = the original design.
   ===================================================================== */
window.SITE_CONFIG = {
  brandName: "Your Brand",

  company: {
    legalName: "",           // e.g. "Your Brand Ltd" (legal pages show "[legal name]" until set)
    address: "",             // registered or postal address
    contactEmail: "",        // e.g. "hello@yourbrand.com"
    privacyEmail: "",        // for data requests; falls back to contactEmail
    jurisdiction: "",        // governing law for the terms, e.g. "England and Wales"
    vatOrTaxId: ""           // optional
  },

  siteUrl: "",

  links: {
    checkoutFounding: "",      // Founding seat checkout (e.g. a Stripe payment link)
    checkoutVip: "",           // VIP seat checkout
    bookCall: "",              // "Book a call" scheduling page (e.g. Calendly / Cal.com)
    trainingRegistration: "",  // Free live training registration (e.g. Zoom webinar)
    waitlist: "",              // Waitlist form
    community: "",             // Member community (shown to members only, not on the public pages)
    auditWebhook: "",          // Optional: URL that receives audit answers as JSON (POST)
    contactWebhook: ""         // Optional: URL that receives the contact form as JSON (POST); otherwise the form opens an email
  },

  // How the two webhooks above are sent.
  //   "json"   (default) a normal JSON request. Use with the included back end (product/backend).
  //   "simple" the same JSON sent as plain text, for automation tools (Zapier, Make, n8n) whose
  //            webhook URLs don't answer the browser's cross-origin check. See NO-CODE.md.
  webhookFormat: "json",

  // Friendly names used in the placeholder note
  labels: {
    checkoutFounding: "Founding seat checkout",
    checkoutVip: "VIP seat checkout",
    bookCall: "Book a call",
    trainingRegistration: "free training registration",
    waitlist: "waitlist"
  },

  cohort: {
    name: "Founding Cohort 01",
    sessions: ["2027-01-11", "2027-01-13", "2027-01-15", "2027-01-18", "2027-01-20", "2027-01-22"],
    days: ["Mon", "Wed", "Fri"],
    startTime: "10:00",                 // 24-hour, in the time zone below
    endTime: "12:00",
    timeZone: "America/New_York",
    timeZoneName: "Eastern",            // how the zone is written on the page
    timeZoneShort: "ET",
    enrollmentCloses: "2027-01-11T10:00:00-05:00",
    seats: 50,
    vipSeats: 5,
    supportDays: 90,                    // support after demo day
    libraryMonths: 12                   // library access and updates
  },

  training: {
    start: "2026-12-10T10:00:00-05:00"  // ISO time with offset
  },

  prices: {
    currency: "USD",
    founding: 1497,
    vip: 5000
  },

  features: {
    perks: false,          // the member-perks section on the pricing page; only turn on with a real perks programme
    countdown: true,       // the free-training countdown on the home page (hides itself once the time passes)
    localTime: true        // add "(… your time)" after session and training times for visitors in other time zones
  },

  analytics: {
    provider: "none",      // "none" · "plausible" · "ga4" · "custom"
    id: "",                // plausible: your domain · ga4: G-XXXXXXX · custom: script URL
    requireConsent: true   // ask first (cookie banner); keep true for visitors in the EU/UK
    // When analytics is on, the site also sends funnel events (no email, name or company):
    // "Audit intro" … "Audit result" for each audit step reached, "Audit: share link", "Audit: save as PDF",
    // "Audit: join cohort click", "Seat click" (founding/vip), "Book a call click", "Training click",
    // "Waitlist click", "Pricing click" and "Form submit". In Plausible add them as custom-event goals;
    // in GA4 they arrive as events; with "custom" they're pushed to window.dataLayer.
  },

  // Only results and quotes you have written permission to publish. Never invent or "improve" one.
  // { quote: "…", name: "Jordan P.", role: "Founder, a 6-person agency", result: "Booked 14 calls in 30 days", permission: "public" }
  proof: [],

  // Who teaches it (How it works page). Empty = the section stays hidden. Photos: put them in assets/img/.
  // { name: "Sam Lee", role: "Lead instructor", bio: "Two or three true sentences.", photo: "assets/img/sam.jpg", links: [{ label: "LinkedIn", url: "https://…" }] }
  instructors: [],

  // Counted results per cohort (results.html, and its footer link). Empty = the page says results come after the first cohort.
  // Fill from demo-day rubrics and the outcomes reports members share 30 days later. Never estimate.
  // Shape (numbers only, from your records): { name: "Cohort 01", members, workingDepartments, reportsShared, runs, hoursSaved }
  //   members             seats that took part        workingDepartments  demo-day passes (rubric)
  //   reportsShared       outcomes reports received   runs / hoursSaved   totals from those reports
  outcomes: { cohorts: [], note: "" },

  audit: {
    // One line under the audit result's buttons. Keep it something you can stand behind (no unsourced salary figures).
    anchorLine: ""
  },

  // Optional colour overrides, e.g. { "--buy": "#0F766E" }. Leave empty to keep the original design.
  theme: {},

  // Optional logo instead of the neutral circle mark: { src: "assets/img/logo.svg", height: 22, hideName: false }
  // (hideName: true when the logo already contains the name; the name stays for screen readers).
  logo: {},

  // Optional colour overrides for the embedded map and dashboards, e.g. { "--copper": "#2DD4BF" }.
  // Variables: --bg, --ivory, --ivory-2, --ink-2, --ink-3, --copper (accent), --line, --glass. See docs in the launch kit.
  appTheme: {}
};
