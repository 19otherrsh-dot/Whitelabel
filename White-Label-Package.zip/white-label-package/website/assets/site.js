/* Shared behaviour for every page.
   Reads assets/config.js and applies it: brand name, dates and prices, legal details, placeholder links,
   optional sections, real proof, structured data, consent-gated analytics, the contact form, the mobile
   menu, and links requested from inside the embedded map and dashboards.
   Every element keeps its default text in the HTML, so pages still read correctly without JavaScript. */
(function () {
  var C = window.SITE_CONFIG || {};
  C.links = C.links || {}; C.labels = C.labels || {}; C.company = C.company || {};
  C.cohort = C.cohort || {}; C.training = C.training || {}; C.prices = C.prices || {};
  C.features = C.features || {}; C.analytics = C.analytics || {}; C.proof = C.proof || []; C.theme = C.theme || {};
  var brand = C.brandName || 'Your Brand';
  var links = C.links, labels = C.labels;

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function each(sel, fn) { [].forEach.call(document.querySelectorAll(sel), fn); }

  /* ---------- theme (optional colour overrides; empty = the original design) ---------- */
  Object.keys(C.theme).forEach(function (k) { if (/^--[\w-]+$/.test(k)) document.documentElement.style.setProperty(k, String(C.theme[k])); });

  /* ---------- logo (optional): replaces the neutral circle mark next to the brand name ---------- */
  var LOGO = C.logo || {};
  if (LOGO.src && /^(assets\/|https:\/\/)[\w\/.:%-]+\.(svg|png|webp)$/i.test(LOGO.src)) {
    each('.brand .mark', function (m) {
      var img = document.createElement('img');
      img.src = LOGO.src; img.alt = ''; img.className = 'mark-img';
      img.style.height = (+LOGO.height || 22) + 'px'; img.style.width = 'auto'; img.style.display = 'block';
      m.parentNode.replaceChild(img, m);
    });
    if (LOGO.hideName) each('.brand [data-brand]', function (el) { el.classList.add('sr'); });
  }

  /* ---------- embedded map and dashboards: optional colour overrides (config.appTheme) ---------- */
  var APP = C.appTheme || {};
  function themeFrame(f) {
    try {
      var d = f.contentDocument; if (!d || !d.documentElement) return;
      Object.keys(APP).forEach(function (k) { if (/^--[\w-]+$/.test(k)) d.documentElement.style.setProperty(k, String(APP[k])); });
    } catch (e) { /* not same-origin (e.g. opened from disk in a strict browser): keep the default colours */ }
  }
  if (Object.keys(APP).length) each('iframe', function (f) {
    if (!/(^|\/)assets\//.test(f.getAttribute('src') || '')) return;
    f.addEventListener('load', function () { themeFrame(f); });
    themeFrame(f);
  });

  /* ---------- brand name and year ---------- */
  each('[data-brand]', function (el) { el.textContent = brand; });
  each('[data-brand-upper]', function (el) { el.textContent = brand.toUpperCase(); });
  each('[data-year]', function (el) { el.textContent = new Date().getFullYear(); });
  document.title = document.title.replace('Your Brand', brand);

  /* ---------- dates, times and prices from the config ---------- */
  var MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  var DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  var PLURAL = { Mon: 'Mondays', Tue: 'Tuesdays', Wed: 'Wednesdays', Thu: 'Thursdays', Fri: 'Fridays', Sat: 'Saturdays', Sun: 'Sundays' };
  function ymd(s) { var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s || ''); return m ? { y: +m[1], m: +m[2] - 1, d: +m[3], dow: new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])).getUTCDay() } : null; }
  function clock(hhmm) {
    var m = /^(\d{1,2}):(\d{2})$/.exec(hhmm || ''); if (!m) return '';
    var h = +m[1], min = +m[2], ap = h < 12 ? 'a.m.' : 'p.m.', h12 = h % 12 || 12;
    return h12 + (min ? ':' + m[2] : '') + ' ' + ap;
  }
  // parts of an absolute time, in the cohort's time zone
  function zoned(iso) {
    var d = new Date(iso); if (isNaN(d)) return null;
    try {
      var f = new Intl.DateTimeFormat('en-US', { timeZone: C.cohort.timeZone || undefined, weekday: 'long', month: 'long', day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: false });
      var p = {}; f.formatToParts(d).forEach(function (x) { p[x.type] = x.value; });
      var hh = (+p.hour) % 24;
      return { weekday: p.weekday, month: p.month, day: +p.day, time: clock(hh + ':' + p.minute) };
    } catch (e) { return null; }
  }
  function range(a, b, longMonth) {
    if (!a || !b) return '';
    var ma = longMonth ? MONTHS[a.m] : MONTHS[a.m].slice(0, 3), mb = longMonth ? MONTHS[b.m] : MONTHS[b.m].slice(0, 3);
    return a.m === b.m ? a.d + ' to ' + b.d + ' ' + ma : a.d + ' ' + ma + ' to ' + b.d + ' ' + mb;
  }
  function money(n) {
    if (typeof n !== 'number') return '';
    try { return new Intl.NumberFormat('en-US', { style: 'currency', currency: C.prices.currency || 'USD', maximumFractionDigits: 0 }).format(n); } catch (e) { return '$' + n; }
  }
  var co = C.cohort, ss = (co.sessions || []).map(ymd).filter(Boolean), first = ss[0], last = ss[ss.length - 1];
  var days = co.days || [], tz = co.timeZoneName || '', tzs = co.timeZoneShort || '';
  var time = clock(co.startTime) && clock(co.endTime) ? clock(co.startTime) + ' to ' + clock(co.endTime) : '';
  var tr = zoned(C.training.start), cl = zoned(co.enrollmentCloses);
  var V = {
    'cohort.name': co.name,
    'cohort.range': first && last ? MONTHS[first.m] + ' ' + first.d + ' to ' + (last.m === first.m ? '' : MONTHS[last.m] + ' ') + last.d : '',
    'cohort.rangeDM': first && last ? first.d + ' ' + MONTHS[first.m] + ' to ' + last.d + ' ' + MONTHS[last.m] : '',
    'cohort.startLong': first ? MONTHS[first.m] + ' ' + first.d : '',
    'cohort.daysDot': days.join(' · '),
    'cohort.daysSlash': days.join(' / '),
    'cohort.daysLong': days.length ? days.map(function (d) { return PLURAL[d] || d; }).reduce(function (s, d, i, a) { return i === 0 ? d : s + (i === a.length - 1 ? ' and ' : ', ') + d; }, '') : '',
    'cohort.time': time,
    'cohort.timeTz': time ? time + ' ' + tz : '',
    'cohort.when': days.length && time ? days.join(' · ') + ', ' + time + ' ' + tz : '',
    'cohort.whenSlash': days.length && time ? days.join(' / ') + ' · ' + time + ' ' + tz : '',
    'cohort.closes': cl ? cl.weekday + ', ' + cl.month + ' ' + cl.day + ' at ' + cl.time + ' ' + tz : '',
    'cohort.seats': co.seats != null ? String(co.seats) : '',
    'cohort.vipSeats': co.vipSeats != null ? String(co.vipSeats) : '',
    'cohort.supportDays': co.supportDays != null ? String(co.supportDays) : '',
    'cohort.libraryMonths': co.libraryMonths != null ? String(co.libraryMonths) : '',
    'cohort.week1': range(ss[0], ss[2] || ss[0]),
    'cohort.week2': range(ss[3], ss[5] || ss[3]),
    'training.long': tr ? tr.weekday + ', ' + tr.month + ' ' + tr.day + ' · ' + tr.time + ' ' + tz : '',
    'training.mid': tr ? tr.weekday.slice(0, 3) + ', ' + tr.month.slice(0, 3) + ' ' + tr.day + ' · ' + tr.time + ' ' + tz : '',
    'training.short': tr ? tr.month.slice(0, 3) + ' ' + tr.day + ', ' + tr.time + ' ' + tzs : '',
    'training.sentence': tr ? tr.month + ' ' + tr.day + ' at ' + tr.time + ' ' + tzs : '',
    'prices.founding': money(C.prices.founding),
    'prices.vip': money(C.prices.vip),
    'prices.currency': C.prices.currency,
    'company.legalName': C.company.legalName || brand,
    'company.address': C.company.address || '[registered address]',
    'company.contactEmail': C.company.contactEmail || '[contact email]',
    'company.privacyEmail': C.company.privacyEmail || C.company.contactEmail || '[privacy contact email]',
    'company.jurisdiction': C.company.jurisdiction || '[governing law]',
    'brandName': brand
  };
  ss.forEach(function (s, i) { V['cohort.s' + (i + 1)] = DAYS[s.dow].slice(0, 3) + ' ' + s.d + ' ' + MONTHS[s.m].slice(0, 3); });
  each('[data-cfg]', function (el) { var v = V[el.getAttribute('data-cfg')]; if (v) el.textContent = v; });
  /* ---------- the schedule in the visitor's own time (config.features.localTime) ---------- */
  // Adds "(8:30 p.m. to 10:30 p.m. your time)" after session and training times, only for visitors whose
  // clock differs from the cohort's time zone. The cohort's own time stays first.
  (function () {
    if (C.features.localTime === false || !C.cohort.timeZone) return;
    var here; try { here = Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (e) { return; }
    function offset(tzName, t) {   // minutes east of UTC for a time zone at instant t
      var p = {}; new Intl.DateTimeFormat('en-US', { timeZone: tzName, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).formatToParts(new Date(t)).forEach(function (x) { p[x.type] = x.value; });
      return (Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour % 24, +p.minute) - t) / 60000;
    }
    function inCohortZone(dayYmd, hhmm) {    // the instant of a wall-clock time in the cohort's zone
      var m = /^(\d{1,2}):(\d{2})$/.exec(hhmm || ''); if (!dayYmd || !m) return null;
      var guess = Date.UTC(dayYmd.y, dayYmd.m, dayYmd.d, +m[1], +m[2]);
      return guess - offset(C.cohort.timeZone, guess - offset(C.cohort.timeZone, guess) * 60000) * 60000;
    }
    function hm(t) { return new Date(t).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }); }
    function sameClock(t) { return offset(here, t) === offset(C.cohort.timeZone, t); }
    function dayShift(t) {
      var f = function (z) { return new Intl.DateTimeFormat('en-CA', { timeZone: z, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(t)); };
      var a = f(C.cohort.timeZone), b = f(here); return a === b ? '' : (b > a ? 'next day, ' : 'day before, ');
    }
    var s0 = first && inCohortZone(first, co.startTime), s1 = first && inCohortZone(first, co.endTime);
    if (s0 && s1 && !sameClock(s0)) {
      var note = ' (' + dayShift(s0) + hm(s0) + ' to ' + hm(s1) + ' your time)';
      each('[data-cfg="cohort.when"], [data-cfg="cohort.whenSlash"], [data-cfg="cohort.timeTz"]', function (el) { if (el.textContent) el.textContent += note; });
    }
    var tt = Date.parse(C.training.start);
    if (!isNaN(tt) && !sameClock(tt)) {
      var wd = new Date(tt).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
      each('[data-cfg="training.long"], [data-cfg="training.mid"], [data-cfg="training.sentence"]', function (el) { if (el.textContent) el.textContent += ' (' + wd + ', ' + hm(tt) + ' your time)'; });
      each('[data-cfg="training.short"]', function (el) { if (el.textContent) el.title = wd + ', ' + hm(tt) + ' your time'; });
    }
  })();
  each('[data-cfg-datetime]', function (el) { var k = el.getAttribute('data-cfg-datetime'); var v = k === 'training.start' ? C.training.start : null; if (v) el.setAttribute('datetime', v); });
  each('a[data-cfg-mailto]', function (el) { var e = V[el.getAttribute('data-cfg-mailto')]; if (e && e.indexOf('@') > 0) { el.href = 'mailto:' + e; el.textContent = e; } });

  /* ---------- optional sections ---------- */
  each('[data-feature]', function (el) { el.hidden = !C.features[el.getAttribute('data-feature')]; });
  // legal pages: the "draft, fill in your details" note shows until the legal name is set
  each('[data-draft-note]', function (el) { el.hidden = !!C.company.legalName; });
  // cookie page: say exactly what analytics, if any, is configured
  each('[data-analytics-status]', function (el) {
    var A0 = C.analytics || {}, on = A0.provider && A0.provider !== 'none' && A0.id;
    el.textContent = on ? ({ plausible: 'Plausible Analytics', ga4: 'Google Analytics 4', custom: 'an analytics service' })[A0.provider] + (A0.requireConsent === false ? ', loaded on every visit.' : ', loaded only if you accept it in the banner.') : 'None. This site currently uses no analytics or advertising tools.';
  });

  /* ---------- placeholder note ---------- */
  var toast = document.getElementById('wltoast'), toastT;
  function note(key, html) {
    if (!toast) { toast = document.createElement('div'); toast.id = 'wltoast'; toast.setAttribute('role', 'status'); document.body.appendChild(toast); }
    toast.innerHTML = html || ('Placeholder link: the <b>' + esc(labels[key] || key) + '</b> URL has not been added yet. Set <code>links.' + esc(key) + '</code> in <code>assets/config.js</code>.');
    toast.classList.add('on');
    clearTimeout(toastT); toastT = setTimeout(function () { toast.classList.remove('on'); }, 4200);
  }
  function go(key) {
    if (window.wlTrackLink) window.wlTrackLink(key);
    if (key === 'pricing') { location.href = 'pricing.html#join'; return; }
    if (key === 'audit') { location.href = 'audit.html'; return; }
    var url = links[key];
    if (url) window.open(url, '_blank', 'noopener'); else note(key);
  }
  window.wlGo = go;
  window.wlNote = note;
  each('a[data-link]', function (a) {
    var key = a.getAttribute('data-link'), url = links[key];
    if (url) { a.href = url; a.target = '_blank'; a.rel = 'noopener'; }
    else a.addEventListener('click', function (e) { e.preventDefault(); note(key); });
  });

  /* the embedded map / dashboards ask the page to open a link */
  window.addEventListener('message', function (e) {
    var d = e.data;
    if (d && d.type === 'wl:link' && d.key) go(d.key);
  });

  /* ---------- org chart: each example agent opens its real skill on the map ---------- */
  each('[data-skill]', function (el) {
    var slug = el.getAttribute('data-skill');
    if (!/^[a-z0-9-]+$/.test(slug)) return;
    el.setAttribute('role', 'link'); el.setAttribute('tabindex', '0');
    el.style.cursor = 'pointer';
    if (!el.title) el.title = 'Open the ' + slug + ' skill on the map';
    function open() { location.href = 'map.html?skill=' + slug; }
    el.addEventListener('click', open);
    el.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
  });

  /* ---------- proof: only real, permissioned entries; otherwise the section stays hidden ---------- */
  var proofEl = document.getElementById('proof');
  var proof = C.proof.filter(function (p) { return p && p.quote && p.name && p.permission === 'public'; });
  if (proofEl && proof.length) {
    var list = proofEl.querySelector('.reviews');
    list.innerHTML = proof.slice(0, 6).map(function (p) {
      return '<figure class="rev">' + (p.result ? '<p class="rev-result" style="margin:0 0 12px;font-weight:700;color:var(--ivory);font-size:15px">' + esc(p.result) + '</p>' : '') +
        '<blockquote>' + esc(p.quote) + '</blockquote><figcaption><span class="rev-who"><b>' + esc(p.name) + '</b>' + (p.role ? '<span>' + esc(p.role) + '</span>' : '') + '</span></figcaption></figure>';
    }).join('');
    proofEl.hidden = false;
  }

  /* ---------- instructors (How it works): shown only when config.instructors has entries ---------- */
  var instrEl = document.getElementById('instructors');
  var instr = (C.instructors || []).filter(function (p) { return p && p.name && p.bio; });
  if (instrEl && instr.length) {
    instrEl.querySelector('.reviews').innerHTML = instr.slice(0, 4).map(function (p) {
      var photo = p.photo && /^(https:\/\/|assets\/|\.\/)/.test(p.photo) ? '<img class="rev-av" src="' + esc(p.photo) + '" alt="" loading="lazy">' : '';
      var ls = (p.links || []).filter(function (l) { return l && l.url && /^https:\/\//.test(l.url); })
        .map(function (l) { return '<a href="' + esc(l.url) + '" rel="noopener">' + esc(l.label || 'Profile') + '</a>'; }).join('');
      return '<figure class="rev"><figcaption style="margin:0 0 14px">' + photo + '<span class="rev-who"><b>' + esc(p.name) + '</b>' + (p.role ? '<span>' + esc(p.role) + '</span>' : '') + '</span></figcaption>' +
        '<blockquote>' + esc(p.bio) + '</blockquote>' + (ls ? '<div class="rev-links">' + ls + '</div>' : '') + '</figure>';
    }).join('');
    instrEl.hidden = false;
  }

  /* ---------- outcomes (results page): only real, counted results from config.outcomes ---------- */
  var OC = C.outcomes || {}, ocRows = (OC.cohorts || []).filter(function (c) { return c && c.name && c.members > 0; });
  if (ocRows.length) each('[data-if-outcomes]', function (el) { el.hidden = false; });
  var ocEl = document.getElementById('outcomes');
  if (ocEl && ocRows.length) {
    var n = function (v) { return typeof v === 'number' && isFinite(v) ? v : null; };
    var fmt = function (v) { return v == null ? '–' : Math.round(v).toLocaleString('en-US'); };
    var sum = function (k) { var t = 0, any = false; ocRows.forEach(function (c) { if (n(c[k]) != null) { t += c[k]; any = true; } }); return any ? t : null; };
    var members = sum('members'), working = sum('workingDepartments');
    var stats = [[fmt(members), 'members across ' + ocRows.length + ' cohort' + (ocRows.length > 1 ? 's' : '')],
      [working == null ? '–' : Math.round(100 * working / members) + '%', 'left demo day with a working department'],
      [fmt(sum('runs')), 'job runs in the 30 days after (shared reports)'],
      [fmt(sum('hoursSaved')), 'hours saved in those 30 days (shared reports)']];
    ocEl.querySelector('.oc-stats').innerHTML = stats.map(function (s) { return '<div class="oc-stat"><b>' + esc(s[0]) + '</b><span>' + esc(s[1]) + '</span></div>'; }).join('');
    ocEl.querySelector('tbody').innerHTML = ocRows.map(function (c) {
      return '<tr><th scope="row">' + esc(c.name) + '</th><td>' + fmt(n(c.members)) + '</td><td>' + (n(c.workingDepartments) == null ? '–' : fmt(c.workingDepartments) + ' (' + Math.round(100 * c.workingDepartments / c.members) + '%)') +
        '</td><td>' + fmt(n(c.reportsShared)) + '</td><td>' + fmt(n(c.runs)) + '</td><td>' + fmt(n(c.hoursSaved)) + '</td></tr>';
    }).join('');
    if (OC.note) ocEl.querySelector('.oc-note').textContent = OC.note;
    ocEl.hidden = false;
    var empty = document.getElementById('outcomesEmpty'); if (empty) empty.hidden = true;
  }

  /* ---------- structured data (search engines read it; nothing visible changes) ---------- */
  function ld(obj) { var s = document.createElement('script'); s.type = 'application/ld+json'; s.textContent = JSON.stringify(obj); document.head.appendChild(s); }
  var base = (C.siteUrl || '').replace(/\/+$/, '');
  var org = { '@context': 'https://schema.org', '@type': 'Organization', name: C.company.legalName || brand };
  if (base) org.url = base + '/';
  if (C.company.contactEmail) org.email = C.company.contactEmail;
  ld(org);
  if (document.body.hasAttribute('data-ld-course') && first && last) {
    var offers = [];
    if (typeof C.prices.founding === 'number') offers.push({ '@type': 'Offer', name: 'Founding seat', price: C.prices.founding, priceCurrency: C.prices.currency || 'USD', category: 'Paid', url: base ? base + '/pricing.html#join' : undefined });
    if (typeof C.prices.vip === 'number') offers.push({ '@type': 'Offer', name: 'VIP seat', price: C.prices.vip, priceCurrency: C.prices.currency || 'USD', category: 'Paid', url: base ? base + '/pricing.html#vip' : undefined });
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    ld({ '@context': 'https://schema.org', '@type': 'Course', name: 'Build your first AI department', description: (document.querySelector('meta[name="description"]') || {}).content || '', provider: { '@type': 'Organization', name: C.company.legalName || brand },
      offers: offers, hasCourseInstance: { '@type': 'CourseInstance', courseMode: 'Online', startDate: first.y + '-' + pad(first.m + 1) + '-' + pad(first.d), endDate: last.y + '-' + pad(last.m + 1) + '-' + pad(last.d), courseSchedule: { '@type': 'Schedule', repeatFrequency: 'P1W', byDay: days.map(function (d) { return 'https://schema.org/' + ({ Mon: 'Monday', Tue: 'Tuesday', Wed: 'Wednesday', Thu: 'Thursday', Fri: 'Friday', Sat: 'Saturday', Sun: 'Sunday' })[d]; }) } } });
  }
  var faqs = document.querySelectorAll('body[data-ld-faq] details.faq');
  if (faqs.length) ld({ '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: [].map.call(faqs, function (d) { var q = d.querySelector('summary').cloneNode(true); var pm = q.querySelector('.pm'); if (pm) pm.remove(); return { '@type': 'Question', name: q.textContent.trim(), acceptedAnswer: { '@type': 'Answer', text: d.querySelector('.ans').textContent.trim() } }; }) });

  /* ---------- analytics, only after consent ---------- */
  var A = C.analytics, KEY = 'wl-consent';
  function stored() { try { return localStorage.getItem(KEY); } catch (e) { return null; } }
  function store(v) { try { localStorage.setItem(KEY, v); } catch (e) {} }
  function loadAnalytics() {
    if (window.__wlAnalytics || !A.id) return; window.__wlAnalytics = true;
    var s = document.createElement('script'); s.async = true; s.defer = true;
    if (A.provider === 'plausible') { s.src = 'https://plausible.io/js/script.js'; s.setAttribute('data-domain', A.id); }
    else if (A.provider === 'ga4') {
      s.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(A.id);
      window.dataLayer = window.dataLayer || []; window.gtag = function () { window.dataLayer.push(arguments); };
      window.gtag('js', new Date()); window.gtag('config', A.id, { anonymize_ip: true });
    } else if (A.provider === 'custom') { s.src = A.id; }
    else return;
    document.head.appendChild(s);
  }
  var analyticsOn = A.provider && A.provider !== 'none' && A.id;
  /* Funnel events (audit steps, call and seat clicks, forms). Sent only once analytics has loaded,
     i.e. after consent; never with an email, name or company. Plausible: custom events; GA4: events;
     custom: pushed to window.dataLayer and dispatched as a "wl:track" DOM event. */
  window.wlTrack = function (name, props) {
    if (!window.__wlAnalytics) return;
    props = props || {};
    try {
      if (A.provider === 'plausible') { window.plausible = window.plausible || function () { (window.plausible.q = window.plausible.q || []).push(arguments); }; window.plausible(name, { props: props }); }
      else if (A.provider === 'ga4' && window.gtag) window.gtag('event', name, props);
      else { (window.dataLayer = window.dataLayer || []).push({ event: name, props: props }); document.dispatchEvent(new CustomEvent('wl:track', { detail: { name: name, props: props } })); }
    } catch (e) {}
  };
  var EVENTS = { checkoutFounding: ['Seat click', { seat: 'founding' }], checkoutVip: ['Seat click', { seat: 'vip' }], bookCall: ['Book a call click', {}], trainingRegistration: ['Training click', {}], waitlist: ['Waitlist click', {}] };
  window.wlTrackLink = function (key) { var ev = EVENTS[key]; if (ev) window.wlTrack(ev[0], Object.assign({ page: location.pathname }, ev[1])); };
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[data-link], a[href*="pricing.html#join"], a[href="#join"]'); if (!a) return;
    if (a.hasAttribute('data-link')) window.wlTrackLink(a.getAttribute('data-link'));
    else window.wlTrack('Pricing click', { page: location.pathname });
  }, true);
  document.addEventListener('submit', function (e) {
    var f = e.target; if (!f || !f.getAttribute) return;
    var kind = f.getAttribute('data-form') || f.id || 'form';
    window.wlTrack('Form submit', { form: kind, page: location.pathname });
  }, true);
  function banner() {
    if (document.getElementById('wlconsent')) return;
    var b = document.createElement('div'); b.id = 'wlconsent'; b.setAttribute('role', 'dialog'); b.setAttribute('aria-label', 'Cookie choices');
    b.style.cssText = 'position:fixed;left:16px;right:16px;bottom:16px;z-index:400;max-width:520px;margin:0 auto;background:#161618;color:#F4F4F5;border-radius:16px;padding:16px 18px;font:13.5px/1.55 "Plus Jakarta Sans",-apple-system,system-ui,sans-serif;box-shadow:0 18px 44px -18px rgba(0,0,0,.55)';
    b.innerHTML = '<p style="margin:0 0 12px">We\'d like to use analytics to understand which pages help visitors. It\'s off unless you agree. <a href="cookies.html" style="color:#9EE6BC">Cookie policy</a></p>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" data-c="yes" style="font:inherit;font-weight:700;border:0;border-radius:999px;padding:9px 16px;background:#F4F4F5;color:#161618;cursor:pointer">Accept analytics</button>' +
      '<button type="button" data-c="no" style="font:inherit;font-weight:600;border:1px solid #4a4a52;border-radius:999px;padding:9px 16px;background:transparent;color:#F4F4F5;cursor:pointer">Decline</button></div>';
    b.addEventListener('click', function (e) { var c = e.target.getAttribute && e.target.getAttribute('data-c'); if (!c) return; store(c); b.remove(); if (c === 'yes') loadAnalytics(); });
    document.body.appendChild(b);
  }
  if (analyticsOn) {
    var choice = stored();
    if (!A.requireConsent || choice === 'yes') loadAnalytics();
    else if (choice !== 'no') banner();
  }
  each('[data-cookie-settings]', function (a) {
    a.addEventListener('click', function (e) { e.preventDefault(); if (!analyticsOn) { note('', 'This site doesn\'t use analytics or advertising cookies, so there\'s nothing to choose.'); return; } try { localStorage.removeItem(KEY); } catch (x) {} banner(); });
  });

  /* ---------- contact form ---------- */
  var form = document.getElementById('contactForm');
  if (form) form.addEventListener('submit', function (e) {
    e.preventDefault();
    var f = new FormData(form), data = {};
    f.forEach(function (v, k) { data[k] = String(v).trim(); });
    if (!data.consent) { note('', 'Please tick the box so we can reply to you.'); return; }
    data.page = location.pathname; data.sentAt = new Date().toISOString();
    var btn = form.querySelector('button[type="submit"]'); if (btn) btn.disabled = true;
    function done() { location.href = 'thank-you.html?for=contact'; }
    if (links.contactWebhook) {
      // "simple" sends the same JSON as plain text without a CORS check, for automation tools
      // (Zapier, Make…) whose webhook URLs don't answer browser preflight requests.
      var simple = C.webhookFormat === 'simple';
      fetch(links.contactWebhook, simple
          ? { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain;charset=UTF-8' }, body: JSON.stringify(data) }
          : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) })
        .then(function (r) { if (!simple && !r.ok) throw new Error(r.status); done(); })
        .catch(function () { if (btn) btn.disabled = false; note('', 'Sorry, that didn\'t send. Please email us instead.'); });
      return;
    }
    var to = C.company.contactEmail;
    if (!to) { if (btn) btn.disabled = false; note('', 'Placeholder: set <code>company.contactEmail</code> or <code>links.contactWebhook</code> in <code>assets/config.js</code> so the form can send.'); return; }
    location.href = 'mailto:' + to + '?subject=' + encodeURIComponent((data.topic || 'Enquiry') + ' from ' + (data.name || 'the website')) + '&body=' + encodeURIComponent((data.message || '') + '\n\n' + (data.name || '') + (data.company ? ', ' + data.company : '') + '\n' + (data.email || ''));
    if (btn) btn.disabled = false;
  });

  /* ---------- mobile menu ---------- */
  var btn = document.querySelector('.nav-menu'), menu = document.getElementById('navmenu');
  if (btn && menu) {
    btn.addEventListener('click', function () {
      var open = menu.hidden;
      menu.hidden = !open;
      btn.setAttribute('aria-expanded', String(open));
      btn.textContent = open ? 'Close' : 'Menu';
    });
    document.addEventListener('click', function (e) {
      if (!menu.hidden && !menu.contains(e.target) && e.target !== btn) { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); btn.textContent = 'Menu'; }
    });
    addEventListener('keydown', function (e) { if (e.key === 'Escape' && !menu.hidden) { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); btn.textContent = 'Menu'; btn.focus(); } });
  }
})();
