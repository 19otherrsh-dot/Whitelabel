/* =====================================================================
   AI WORKFORCE AUDIT · five questions → a per-company result
   ---------------------------------------------------------------------
   The estimate is deliberately conservative and fully transparent:

   1. Jobs in your org   = the jobs on the map that fit your business type,
                           all of them in the departments you picked, plus the
                           first job of each relevant function elsewhere.
   2. Hours per job      = weekly hours that job takes at your team size.
   3. Value per job      = hours × 48 weeks × the hourly cost for your business
                           type × the share AI can take (autonomous 70%,
                           human-assisted 45%, human-led 20%), at half weight
                           outside the departments you picked.
   4. Ceiling            = the total never exceeds 35% of your team's paid
                           hours (people × 1,920 h × the same hourly cost).
   5. "Can run today"    = jobs that run autonomously and need no tool you
                           don't already use.
   Edit the tables below to tune the model.
   ===================================================================== */
(function () {
  var JOBS = (window.AUDIT_JOBS || []).map(function (r) {
    return { dept: r[0], fn: r[1], name: r[2], level: r[3], tools: r[4] };
  });

  /* ---------------------------------------------------------- questions */
  var TYPES = [
    { id: 'agency', t: 'Agency', h: 'Marketing, creative, dev or growth', label: 'agency', rate: 55,
      skip: ['Brand Deals', 'Reliability', 'Community'] },
    { id: 'saas', t: 'SaaS or software', h: 'Product-led or sales-led', label: 'software company', rate: 70,
      skip: ['Brand Deals', 'Onboarding', 'Client Comms'] },
    { id: 'consulting', t: 'Consulting or coaching', h: 'Advisory, training, coaching', label: 'consultancy', rate: 75,
      skip: ['Brand Deals', 'Reliability', 'Community', 'Build Ops'] },
    { id: 'professional', t: 'Professional services', h: 'Legal, accounting, architecture, recruiting', label: 'firm', rate: 80,
      skip: ['Brand Deals', 'Build Ops', 'Reliability', 'Community', 'Sequencing & Send'] },
    { id: 'local', t: 'Local business', h: 'Clinics, trades, studios, hospitality', label: 'local business', rate: 38,
      skip: ['Brand Deals', 'Build Ops', 'Reliability', 'Enrichment', 'Sequencing & Send', 'Companies', 'People', 'Monitoring', 'Synthesis', 'Markets', 'Community'] },
    { id: 'ecommerce', t: 'E-commerce or DTC', h: 'Online store or consumer brand', label: 'online store', rate: 42,
      skip: ['Onboarding', 'Build Ops', 'Reliability', 'Client Comms', 'Call Cycle', 'Deal Artifacts', 'Companies', 'People', 'Lead Sourcing', 'Enrichment', 'Sequencing & Send', 'Outreach Writing'] },
    { id: 'creator', t: 'Creator or media', h: 'Audience, content, sponsorships', label: 'media business', rate: 45,
      skip: ['Lead Sourcing', 'Enrichment', 'Sequencing & Send', 'Call Cycle', 'Build Ops', 'Reliability', 'Companies', 'People', 'Onboarding', 'Client Comms'] },
    { id: 'other', t: 'Something else', h: 'We will map the general case', label: 'business', rate: 50,
      skip: ['Brand Deals', 'Reliability'] }
  ];
  var SIZES = [
    { id: 'solo', t: 'Just me', people: 1, hours: 1.2, skip: ['Talent'] },
    { id: 's2', t: '2 to 5', people: 3.5, hours: 2.5, skip: ['Talent'] },
    { id: 's6', t: '6 to 15', people: 10, hours: 4.5, skip: [] },
    { id: 's16', t: '16 to 50', people: 30, hours: 8, skip: [] },
    { id: 's51', t: '51 to 200', people: 110, hours: 14, skip: [] },
    { id: 's200', t: '200+', people: 300, hours: 24, skip: [] }
  ];
  var DEPTS = [
    { id: 'Sales', t: 'Finding and starting conversations', h: 'Outreach' },
    { id: 'Deals', t: 'Following up and closing', h: 'Replies, calls, proposals' },
    { id: 'Marketing', t: 'Posting content consistently', h: 'Content' },
    { id: 'Operations', t: 'Delivering the client work', h: 'Delivery' },
    { id: 'Customer', t: 'Answering customers', h: 'Support and success' },
    { id: 'Back Office', t: 'Invoices, records and admin', h: 'Admin and reporting' },
    { id: 'Intelligence', t: 'Research and market intel', h: 'Companies, people, markets' }
  ];
  var TOOLS = [
    { id: 'crm', t: 'A CRM', h: 'HubSpot, Attio, Pipedrive…', covers: ['Attio'] },
    { id: 'meet', t: 'Calendar and call recording', h: 'Calendly, Cal.com, Fireflies…', covers: ['Cal.com', 'Fireflies'] },
    { id: 'money', t: 'Payments and accounting', h: 'Stripe, Xero, QuickBooks…', covers: ['Stripe', 'Wise', 'Xero'] },
    { id: 'leads', t: 'Lead data and email sending', h: 'Apollo, Clay, Instantly…', covers: ['Apollo', 'Apify', 'Exa', 'Firecrawl', 'Instantly', 'HeyReach'] },
    { id: 'content', t: 'Content and newsletter tools', h: 'Beehiiv, Canva, schedulers…', covers: ['Beehiiv', 'Resend', 'Zernio', 'FAL', 'Remotion', 'Deepgram', 'Instagram API', 'Google Docs'] },
    { id: 'auto', t: 'Automation or a database', h: 'Zapier, n8n, Make, Postgres…', covers: ['Inngest'] }
  ];
  var SHARE = [0.7, 0.45, 0.2];          /* autonomous · human-assisted · human-led */
  var OUTSIDE_WEIGHT = 0.5;              /* jobs outside the departments you picked */
  var WEEKS = 48;
  var CEILING = 0.35, PAID_HOURS = 1920;    /* share of the team's paid hours the estimate may reach */

  /* where we'd start: first runnable job from these lists, one per picked department */
  var START = {
    'Sales': [['Cold Email Drafting', 'fills the top of the funnel'], ['Personalization Research', 'every first line earns the reply'], ['ICP Definition', 'everything downstream reads it'], ['List Building', 'campaign-ready lists, no spreadsheet nights']],
    'Deals': [['Follow-Up Drafting', 'no lead goes cold after a call'], ['Speed-to-Lead', 'answers inbound in minutes, not days'], ['Proposal Generation', 'proposals out the same day'], ['Post-Call Debrief', 'every call becomes next steps']],
    'Marketing': [['Hook Writing', 'the first line that stops the scroll'], ['Cross-Platform Adaptation', 'one idea, every channel'], ['Caption Writing', 'posts ready to approve'], ['Newsletter & Broadcast', 'your list hears from you weekly']],
    'Operations': [['Meeting Follow-Ups', 'closes the loop after every call'], ['Status Updates', 'clients see progress without asking'], ['Kickoff Pack', 'every new client starts the same way'], ['Transcript Processing', 'calls turn into searchable notes']],
    'Customer': [['FAQ & Self-Serve', 'deflects the repeat questions'], ['Macro Authoring', 'replies drafted from your own docs'], ['Onboarding Journeys', 'new customers reach value faster'], ['QBR Prep', 'reviews prepared before the meeting']],
    'Back Office': [['Invoice Generation', 'money in, error-free'], ['Email Triage', 'the inbox sorted by what needs you'], ['Revenue Reporting', 'the numbers report themselves'], ['Document Filing & Retrieval', 'every file findable in seconds']],
    'Intelligence': [['Company Deep-Dive', 'research on demand'], ['Competitor Teardown', 'know what they changed this week'], ['Research Reports', 'answers with sources, not hunches'], ['Person Research', 'walk into every call prepared']]
  };
  var ICON = {
    'Sales': '<path d="M12 19l7-7-3-3-7 7-1 4 4-1z"></path><path d="M15 6l3 3"></path>',
    'Deals': '<path d="M23 4v6h-6"></path><path d="M3.5 9a9 9 0 0 1 14.9-3.4L23 10"></path><path d="M1 20v-6h6"></path><path d="M20.5 15a9 9 0 0 1-14.9 3.4L1 14"></path>',
    'Marketing': '<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2 2-6z"></path>',
    'Operations': '<rect x="3" y="5" width="18" height="16" rx="2"></rect><path d="M3 9h18"></path><path d="M8 3v4M16 3v4"></path>',
    'Customer': '<path d="M4 5h16v11h-9l-5 4v-4H4V5z"></path>',
    'Back Office': '<path d="M6 2h8l6 6v14H6V2z"></path><path d="M14 2v6h6"></path><path d="M9 14h6M9 17h6"></path>',
    'Intelligence': '<circle cx="10" cy="10" r="6"></circle><path d="M15 15l6 6"></path>'
  };
  var DEPT_LABEL = { 'Back Office': 'Back Office' };

  /* ---------------------------------------------------------- state */
  var A = { type: null, size: null, depts: [], tools: [], company: '', email: '', marketing: false };
  var step = 0;                       /* 0 intro · 1-5 questions · 6 building · 7 result */
  var stage = document.getElementById('pfstage'), wrap = document.getElementById('pf'),
      dots = document.getElementById('pfdots'), bg = document.getElementById('pfbg');
  var C = window.SITE_CONFIG || { brandName: 'Your Brand', links: {} };
  document.querySelectorAll('[data-brand-upper]').forEach(function (el) { el.textContent = (C.brandName || 'Your Brand').toUpperCase(); });

  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function byId(list, id) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i]; return null; }
  function money(v) { return '$' + Math.round(v).toLocaleString('en-US'); }

  function renderDots() {
    if (step < 1 || step > 5) { dots.innerHTML = ''; return; }
    var h = '';
    for (var i = 1; i <= 5; i++) h += '<i class="' + (i <= step ? 'on' : '') + '"></i>';
    dots.innerHTML = h;
  }
  function backBtn() {
    return '<div class="pf-qhead"><button class="pf-back" type="button" data-act="back">'
      + '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"></path></svg>Back</button></div>';
  }
  function opt(o, on, multi) {
    return '<button class="pf-opt' + (on ? ' on' : '') + '" type="button" data-id="' + esc(o.id) + '" aria-pressed="' + (on ? 'true' : 'false') + '">'
      + (multi ? '<span class="pf-check"></span>' : '')
      + '<span>' + esc(o.t) + (o.h ? '<span class="pf-ohint">' + esc(o.h) + '</span>' : '') + '</span></button>';
  }
  function card(inner, pop) { return '<div class="pf-card' + (pop ? ' pf-pop' : '') + '"><div class="pf-glass">' + inner + '</div></div>'; }

  /* ---------------------------------------------------------- screens */
  function render() {
    wrap.classList.toggle('intro', step === 0);
    wrap.classList.toggle('reveal', step === 7);
    renderDots();
    var h = '';
    if (step === 0) {
      h = card('<span class="pf-eye">Free AI workforce audit</span>'
        + '<h1 class="pf-h">See the AI org hiding inside your business.</h1>'
        + '<p class="pf-sub">Five quick questions. We map your business against <b>137 jobs</b> AI can already run, and put a conservative number on the work you could hand off.</p>'
        + '<button class="pf-cta pf-big" type="button" data-act="next">Start the audit</button>'
        + '<p class="pf-fine">About two minutes. Your result shows on screen, no sign-up needed.</p>', true);
    } else if (step === 1) {
      h = card(backBtn() + '<h2 class="pf-q">What kind of business do you run?</h2><p class="pf-qh">We tune the jobs and the hourly value to how you make money.</p>'
        + '<div class="pf-opts pf-multi" data-q="type">' + TYPES.map(function (o) { return opt(o, A.type === o.id); }).join('') + '</div>');
    } else if (step === 2) {
      h = card(backBtn() + '<h2 class="pf-q">How many people work in the business?</h2><p class="pf-qh">Including you, contractors and part-timers.</p>'
        + '<div class="pf-opts pf-multi" data-q="size">' + SIZES.map(function (o) { return opt(o, A.size === o.id); }).join('') + '</div>');
    } else if (step === 3) {
      h = card(backBtn() + '<h2 class="pf-q">Where does work keep waiting for you?</h2><p class="pf-qh">Pick every one that applies. We start with these.</p>'
        + '<div class="pf-opts pf-multi" data-q="depts" data-multi="1">' + DEPTS.map(function (o) { return opt(o, A.depts.indexOf(o.id) > -1, true); }).join('') + '</div>'
        + '<button class="pf-cta" type="button" data-act="next"' + (A.depts.length ? '' : ' disabled') + '>Continue</button>');
    } else if (step === 4) {
      h = card(backBtn() + '<h2 class="pf-q">Which tools do you already use?</h2><p class="pf-qh">Connected tools let more jobs run on day one. Skip any you don’t have.</p>'
        + '<div class="pf-opts pf-multi" data-q="tools" data-multi="1">' + TOOLS.map(function (o) { return opt(o, A.tools.indexOf(o.id) > -1, true); }).join('') + '</div>'
        + '<button class="pf-cta" type="button" data-act="next">' + (A.tools.length ? 'Continue' : 'None of these yet') + '</button>');
    } else if (step === 5) {
      var sends = !!(C.links || {}).auditWebhook;
      h = card(backBtn() + (sends
          ? '<h2 class="pf-q">Where should we send your map?</h2><p class="pf-qh">Optional. Add your company name to personalise the result, and your email to get a copy.</p>'
          : '<h2 class="pf-q">Personalise your result</h2><p class="pf-qh">Optional. Your answers stay in this browser.</p>')
        + '<form class="pf-form" id="pfform" novalidate>'
        + '<input id="pfco" type="text" autocomplete="organization" placeholder="Company name" value="' + esc(A.company) + '" aria-label="Company name">'
        + (sends ? '<input id="pfem" type="email" inputmode="email" autocomplete="email" placeholder="you@company.com" value="' + esc(A.email) + '" aria-label="Email address">'
          + '<label class="pf-consent" style="display:flex;gap:8px;align-items:flex-start;font-size:12.5px;line-height:1.5;color:#b0b0b6;text-align:left;margin:4px 0 2px"><input id="pfmk" type="checkbox"' + (A.marketing ? ' checked' : '') + ' style="margin-top:3px"> Also send me occasional updates (unsubscribe any time).</label>'
          + '<p class="pf-fine" style="margin:6px 0 0">We use your answers to send your result and, if you tick the box, updates. <a href="privacy.html" style="color:inherit;text-decoration:underline">Privacy policy</a>.</p>' : '')
        + '<p class="pf-err" id="pferr" hidden>That email doesn’t look right. Fix it, or leave it empty.</p>'
        + '<button class="pf-cta" type="submit">Show my result</button></form>'
        + '<button class="pf-skip" type="button" data-act="skip">Skip and show my result</button>');
    } else if (step === 6) {
      h = '<div class="pf-card"><div class="pf-build"><div class="pf-spin"></div><span id="pfbuildt">Mapping 137 jobs against your business…</span></div></div>';
    } else if (step === 7) {
      h = resultHTML(compute());
    }
    stage.innerHTML = h;
    if (step === 5) { var f = document.getElementById('pfco'); if (f) try { f.focus({ preventScroll: true }); } catch (e) {} }
    if (step === 6) building();
    if (step === 7) afterResult();
    track(step);
    var first = stage.querySelector('.pf-q, .pf-h, .pf-num');
    if (first) first.setAttribute('tabindex', '-1');
    scrollTo(0, 0);
  }

  /* ---------------------------------------------------------- model */
  function compute() {
    var type = byId(TYPES, A.type) || TYPES[TYPES.length - 1], size = byId(SIZES, A.size) || SIZES[2];
    var skip = {}; type.skip.concat(size.skip).forEach(function (f) { skip[f] = 1; });
    var have = {}; A.tools.forEach(function (id) { (byId(TOOLS, id) || { covers: [] }).covers.forEach(function (t) { have[t] = 1; }); });
    var picked = {}; A.depts.forEach(function (d) { picked[d] = 1; });
    var seenFn = {}, org = [];
    JOBS.forEach(function (j) {
      if (skip[j.fn]) return;
      if (picked[j.dept]) { org.push({ j: j, w: 1 }); return; }
      var key = j.dept + '::' + j.fn;
      if (!seenFn[key]) { seenFn[key] = 1; org.push({ j: j, w: OUTSIDE_WEIGHT }); }
    });
    var value = 0, today = [], depts = {};
    org.forEach(function (o) {
      value += size.hours * WEEKS * type.rate * SHARE[o.j.level] * o.w;
      depts[o.j.dept] = 1;
      var ok = o.j.level === 0 && o.j.tools.every(function (t) { return have[t]; });
      if (ok) today.push(o.j);
    });
    value = Math.min(value, CEILING * size.people * PAID_HOURS * type.rate);
    value = value >= 100000 ? Math.round(value / 5000) * 5000 : Math.round(value / 1000) * 1000;
    /* where we'd start: one per picked department (in the order picked), then fill */
    var names = {}; org.forEach(function (o) { names[o.j.name] = o.j; });
    var runnable = {}; today.forEach(function (j) { runnable[j.name] = 1; });
    var starts = [], used = {};
    function take(dept) {
      var list = START[dept] || [];
      for (var i = 0; i < list.length; i++) {
        var n = list[i][0];
        if (runnable[n] && !used[n]) { used[n] = 1; starts.push({ name: n, dept: dept, why: list[i][1] }); return true; }
      }
      return false;
    }
    A.depts.forEach(function (d) { if (starts.length < 3) take(d); });
    var order = ['Operations', 'Back Office', 'Deals', 'Sales', 'Marketing', 'Customer', 'Intelligence'];
    for (var pass = 0; pass < 3 && starts.length < 3; pass++) {
      A.depts.concat(order).forEach(function (d) { if (starts.length < 3) take(d); });
    }
    return { type: type, size: size, value: value, jobs: org.map(function (o) { return o.j.name; }),
             nDepts: Object.keys(depts).length, nToday: today.length, starts: starts };
  }

  function resultHTML(r) {
    var who = A.company ? '<b>' + esc(A.company) + '</b>' : 'your <b>' + esc(r.type.label) + '</b>';
    var cards = r.starts.map(function (s) {
      return '<div class="pf-fcard"><span class="pf-ficon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">'
        + (ICON[s.dept] || '') + '</svg></span><div><b>' + esc(s.name) + '</b><span class="pf-fdept">' + esc(DEPT_LABEL[s.dept] || s.dept) + ' · ' + esc(s.why) + '</span></div></div>';
    }).join('');
    return '<div class="pf-reveal"><span class="pf-eye">Your AI Workforce Audit</span>'
      + '<h1 class="pf-num">' + money(r.value) + '</h1>'
      + '<p class="pf-numsub">of work per year ' + who + ' could hand to AI, across <b>' + r.jobs.length + ' jobs</b> in <b>' + r.nDepts + ' departments</b>. <b>' + r.nToday + '</b> can run today.</p>'
      + '<p class="pf-estnote">An estimate from your answers and our published method, not a promise. Your result depends on your business and how you use it.</p>'
      + '<div class="pf-fork pf-fork-hero"><div class="pf-cta-row"><button class="pf-cta pf-big" type="button" data-act="call">Book a Call</button>'
      + '<button class="pf-cta pf-cta2" type="button" data-act="cohort">Join the founding cohort</button></div>'
      + '<p class="pf-microanchor">' + ((C.audit && C.audit.anchorLine) ? esc(C.audit.anchorLine) : 'Hiring for this work means a salary plus overheads. We help you build your highest-value jobs into your own stack instead.') + '</p></div>'
      + '<div class="pf-maphead"><div class="pf-mapseg"><button type="button" class="on" data-view="org">Your org</button><button type="button" data-view="all">All 137 jobs</button></div>'
      + '<button class="pf-fs" type="button" title="Full screen"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M16 21h3a2 2 0 0 0 2-2v-3"></path></svg>Full screen</button></div>'
      + '<div class="pf-mapbox"><iframe id="pfmap" title="Your AI org on the map of 137 jobs" src="assets/map-app.html?embed=1"></iframe></div>'
      + (cards ? '<div class="pf-first"><div class="pf-firsth">Where we’d start</div><div class="pf-firstgrid">' + cards + '</div></div>' : '')
      + '<div class="pf-tools" style="display:flex;flex-wrap:wrap;gap:10px;justify-content:center;margin:22px 0 4px">'
      + '<button class="pf-alt" type="button" data-act="share">Copy a link to this result</button>'
      + '<button class="pf-alt" type="button" data-act="pdf">Save as PDF</button>'
      + '<a class="pf-alt" href="methodology.html">How we calculate this</a></div>'
      + '<button class="pf-alt pf-restart" type="button" data-act="restart">Start over with different answers</button></div>';
  }

  /* Funnel: one event per step reached (consent-gated in site.js; answers' ids only, never the company or email). */
  var STEPS = ['Audit intro', 'Audit: business type', 'Audit: team size', 'Audit: departments', 'Audit: tools', 'Audit: company and email', 'Audit: building', 'Audit result'], tracked = {};
  function track(s) {
    if (tracked[s] || !window.wlTrack) return; tracked[s] = 1;
    var p = { step: s };
    if (s === 7) { p.type = A.type || ''; p.size = A.size || ''; p.departments = A.depts.length; p.emailed = A.email ? 'yes' : 'no'; p.shared = /#r=/.test(location.hash) ? 'yes' : 'no'; }
    window.wlTrack(STEPS[s] || 'Audit step', p);
  }

  var lastResult = null, view = 'org';
  function sendOrg() {
    var f = document.getElementById('pfmap');
    if (!f || !f.contentWindow || !lastResult) return;
    try { f.contentWindow.postMessage({ type: 'wl:org', jobs: view === 'org' ? lastResult.jobs : null }, '*'); } catch (e) {}
  }
  function afterResult() {
    lastResult = compute();
    view = 'org';
    if (bg) { var bf = bg.querySelector('iframe'); if (bf) bf.src = 'about:blank'; bg.style.display = 'none'; }
    var f = document.getElementById('pfmap');
    if (f) f.addEventListener('load', function () { setTimeout(sendOrg, 300); });
    var hook = (C.links || {}).auditWebhook;
    if (hook) {
      try {
        var simple = C.webhookFormat === 'simple';   // see webhookFormat in assets/config.js
        fetch(hook, { method: 'POST', mode: simple ? 'no-cors' : 'cors', headers: { 'Content-Type': simple ? 'text/plain;charset=UTF-8' : 'application/json' }, keepalive: true,
          body: JSON.stringify({ company: A.company, email: A.email, marketingConsent: !!A.marketing, businessType: A.type, teamSize: A.size, departments: A.depts, tools: A.tools,
            estimate: lastResult.value, jobs: lastResult.jobs.length, departmentsCount: lastResult.nDepts, runToday: lastResult.nToday,
            start: lastResult.starts.map(function (s) { return s.name; }), at: new Date().toISOString() }) }).catch(function () {});
      } catch (e) {}
    }
  }
  window.addEventListener('message', function (e) { if (e.data && e.data.type === 'wl:map-ready') sendOrg(); });

  function building() {
    var lines = ['Mapping 137 jobs against your business…', 'Scoring what can run today…', 'Putting a number on it…'], i = 0;
    var el = document.getElementById('pfbuildt');
    var iv = setInterval(function () { i++; if (el && lines[i]) el.textContent = lines[i]; }, 650);
    setTimeout(function () { clearInterval(iv); step = 7; render(); }, 1900);
  }

  /* ---------------------------------------------------------- events */
  stage.addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    var act = b.getAttribute('data-act');
    if (act === 'next') { step++; render(); return; }
    if (act === 'back') { step = Math.max(0, step - 1); render(); return; }
    if (act === 'skip') { A.email = ''; step = 6; render(); return; }
    if (act === 'restart') { A = { type: null, size: null, depts: [], tools: [], company: A.company, email: A.email }; step = 1;
      if (bg) { bg.style.display = ''; var bf = bg.querySelector('iframe'); if (bf) bf.src = 'assets/map-app.html?embed=1&tour=1'; } render(); return; }
    if (act === 'call') { if (window.wlGo) window.wlGo('bookCall'); return; }
    if (act === 'share') {
      var url = location.href.split('#')[0] + '#r=' + encodeURIComponent([A.type, A.size, A.depts.join('+'), A.tools.join('+'), A.company].join(','));
      if (window.wlTrack) window.wlTrack('Audit: share link', {});
      var done = function () { b.textContent = 'Link copied'; setTimeout(function () { b.textContent = 'Copy a link to this result'; }, 1600); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(done, function () { prompt('Copy this link:', url); });
      else prompt('Copy this link:', url);
      return;
    }
    if (act === 'pdf') { if (window.wlTrack) window.wlTrack('Audit: save as PDF', {}); window.print(); return; }
    if (act === 'cohort') { if (window.wlTrack) window.wlTrack('Audit: join cohort click', {}); location.href = 'pricing.html#join'; return; }
    if (b.hasAttribute('data-view')) {
      view = b.getAttribute('data-view');
      b.parentNode.querySelectorAll('button').forEach(function (x) { x.classList.toggle('on', x === b); });
      sendOrg(); return;
    }
    if (b.classList.contains('pf-fs') || b.classList.contains('pf-mapfull-x')) { toggleFull(); return; }
    var group = b.closest('.pf-opts'); if (!group) return;
    var q = group.getAttribute('data-q'), id = b.getAttribute('data-id');
    if (group.hasAttribute('data-multi')) {
      var arr = A[q], k = arr.indexOf(id);
      if (k > -1) arr.splice(k, 1); else arr.push(id);
      b.classList.toggle('on', k === -1); b.setAttribute('aria-pressed', String(k === -1));
      var cta = stage.querySelector('[data-act="next"]');
      if (q === 'depts' && cta) cta.disabled = !A.depts.length;
      if (q === 'tools' && cta) cta.textContent = A.tools.length ? 'Continue' : 'None of these yet';
    } else {
      A[q] = id;
      group.querySelectorAll('.pf-opt').forEach(function (x) { x.classList.toggle('on', x === b); });
      setTimeout(function () { step++; render(); }, 180);
    }
  });
  stage.addEventListener('submit', function (e) {
    e.preventDefault();
    var co = document.getElementById('pfco').value.trim(), emEl = document.getElementById('pfem'), em = emEl ? emEl.value.trim() : '';
    var mk = document.getElementById('pfmk'); A.marketing = !!(mk && mk.checked);
    var err = document.getElementById('pferr');
    if (em && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) { err.hidden = false; return; }
    A.company = co.slice(0, 60); A.email = em; step = 6; render();
  });

  function toggleFull() {
    var box = document.querySelector('.pf-mapbox'); if (!box) return;
    var on = box.classList.toggle('pf-mapbox-full'), x = box.querySelector('.pf-mapfull-x');
    if (on && !x) { x = document.createElement('button'); x.type = 'button'; x.className = 'pf-mapfull-x'; x.setAttribute('aria-label', 'Exit full screen'); x.textContent = '✕'; x.addEventListener('click', toggleFull); box.appendChild(x); }
    if (!on && x) x.remove();
  }
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { var box = document.querySelector('.pf-mapbox-full'); if (box) toggleFull(); }
  });

  /* testing hook: audit.html#demo=local,s16,Sales+Operations,crm+meet */
  try {
    var m = location.hash.match(/(?:demo|r)=([^&]+)/);   /* #r= is a shared result link (no email is ever included) */
    if (m) { var p = decodeURIComponent(m[1]).split(','); A.type = p[0]; A.size = p[1]; A.depts = (p[2] || '').split('+').filter(Boolean); A.tools = (p[3] || '').split('+').filter(Boolean); A.company = p[4] || ''; step = 7; }
  } catch (e) {}
  render();
})();
