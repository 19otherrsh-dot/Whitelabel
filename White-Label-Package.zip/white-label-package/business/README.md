# The business pack: licensing, compliance, launch and sales

Everything around the product that turns it into a business someone else can run under their own
brand. Legal documents are **drafts for review by a qualified lawyer**; numbers in the pricing
model are inputs to set, not market data.

| Folder | What's inside |
|---|---|
| `licensing/` | `master-licence-agreement.md` (licensor → licensee, with schedules for support tiers, quality standards and reporting), `order-form.md`, `licensee-pricing.md` (models, tiers and the licensee's maths, with a worked example), `rights-checklist.md` (can every part be resold?) |
| `compliance/` | `README.md` (obligations mapped to features: EU AI Act Art. 50, CAN-SPAM, PECR/GDPR, CASL, TCPA, consumer law, privacy, accessibility), `claims-and-disclaimers.md`, `dpa-template.md`, `subprocessors.md`, `retention.md`, `security-practices.md` (SOC 2-ready), `incident-response.md` |
| `launch-kit/` | `launch-checklist.md` (eight weeks from the zip to a first cohort), `theming.md` (logo, colours, map and dashboard colours, emails, decks) |
| `sales/` | `webinar-script.md` (the free training), `launch-emails.md`, `sales-call-script.md`, `ad-creative.md` + `ads/png/` (3 concepts × 3 sizes), `case-study-template.md`, `demo-video/` (a 72-second captioned product demo, with a script to re-record it in your brand), `sales-call-deck.pptx`, `white-label-deck.pptx`, `one-pagers/` (member and licensee one-pagers, PDF) |

## Rebuilding the generated files

```
node ../delivery/curriculum/slides/build_slides.js --in sales/decks.json --out sales   # the two decks
python3 sales/ads/build_ads.py                                                       # ad images
python3 sales/one-pagers/build_one_pagers.py                                         # one-pagers
```

The decks need `pptxgenjs`; the images and PDFs need Playwright with Chromium.

## Related, elsewhere in the package

- Running many licensees: `../licensor/` (how to set up each licensee's isolated deployment in about an
  hour, and the fleet console that collects every licensee's quarterly report and works out what's due).
- The site's new pages: `compare.html` (how it compares), `results.html` (real outcomes only,
  from `config.outcomes`), `resources.html` (three free guides), and the "Who teaches it" section
  (from `config.instructors`).
- Delivery: `../delivery/` (curriculum, rubric, playbook, certification, support, emails,
  self-paced course).
- Back end privacy tools: `/admin/privacy` (find, export, erase a person's data).
