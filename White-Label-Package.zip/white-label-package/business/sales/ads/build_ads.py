"""Renders the static ad creative: 3 concepts x 3 sizes, PNG.

    python3 build_ads.py            (needs Playwright with Chromium: pip install playwright)

Edit BRAND, the copy in CONCEPTS and the colours in CSS, then re-run. The map image is a
screenshot of the product's own map (map-shot.png); re-take it after changing the map's colours.
Copy rules: ../../compliance/claims-and-disclaimers.md (no results or savings claims)."""
import base64, os
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.abspath(os.path.join(HERE, '../../../../site/assets/fonts'))
BRAND = 'Your Brand'

SIZES = {'square': (1080, 1080), 'story': (1080, 1920), 'landscape': (1200, 628)}

CONCEPTS = {
    'approval': {
        'kicker': 'Live cohort · 6 sessions',
        'head': 'Your AI drafts.<br><em>You send.</em>',
        'sub': 'Build an AI department on your own business in two weeks. Nothing goes out without your approval.',
        'cta': 'Join the free training',
        'visual': 'outbox',
    },
    'department': {
        'kicker': 'Live cohort · 6 sessions',
        'head': 'One department.<br><em>End to end.</em>',
        'sub': 'Outreach, content, delivery, admin or replies. Built live, on your business, on your computer. Yours to keep.',
        'cta': 'Take the 2-minute audit',
        'visual': 'steps',
    },
    'map': {
        'kicker': '137 jobs · 7 departments',
        'head': 'A light means<br><em>the job ran.</em>',
        'sub': 'See every job AI can run in a business, then build the first department with us.',
        'cta': 'Explore the map',
        'visual': 'map',
    },
}

CSS = '''
@font-face{font-family:"PJS";font-weight:200 800;src:url("file://%(f)s/plus-jakarta-sans-latin-wght-normal.woff2") format("woff2")}
@font-face{font-family:"Marcellus";src:url("file://%(f)s/marcellus-latin-400-normal.woff2") format("woff2")}
@font-face{font-family:"ISerif";font-style:italic;src:url("file://%(f)s/instrument-serif-latin-400-italic.woff2") format("woff2")}
*{box-sizing:border-box;margin:0}
body{width:%(w)dpx;height:%(h)dpx;overflow:hidden;background:#0E1118;color:#E9E4D6;font-family:"PJS",sans-serif}
.ad{position:relative;width:100%%;height:100%%;display:flex;flex-direction:%(dir)s;padding:%(pad)dpx;gap:%(gap)dpx}
.copy{flex:%(cflex)s;display:flex;flex-direction:column;justify-content:center;gap:%(g2)dpx;min-width:0}
.brand{display:flex;align-items:center;gap:12px;font-family:"Marcellus";letter-spacing:.14em;text-transform:uppercase;font-size:%(bs)dpx}
.mark{width:%(ms)dpx;height:%(ms)dpx;border-radius:50%%;border:3px solid #C58B5F;position:relative}
.mark:after{content:"";position:absolute;inset:30%%;border-radius:50%%;background:#C58B5F}
.kicker{font-size:%(ks)dpx;letter-spacing:.12em;text-transform:uppercase;color:#5EEAD4;font-weight:600}
h1{font-family:"PJS";font-weight:800;font-size:%(hs)dpx;line-height:1.02;letter-spacing:-.02em;color:#F4F1E8}
h1 em{font-family:"ISerif";font-weight:400;font-style:italic;letter-spacing:0;color:#E9E4D6}
.sub{font-size:%(ss)dpx;line-height:1.45;color:#B9B4A6;max-width:30ch}
.cta{align-self:flex-start;background:#149655;color:#fff;font-weight:700;font-size:%(cs)dpx;padding:%(cp)s;border-radius:999px}
.vis{flex:%(vflex)s;overflow:hidden;display:flex;align-items:center;justify-content:center;min-width:0;min-height:0}
.card{background:#171B25;border:1px solid rgba(233,228,214,.12);border-radius:22px;padding:%(vp)dpx;width:100%%;box-shadow:0 30px 80px -30px rgba(0,0,0,.6)}
.row{display:flex;justify-content:space-between;align-items:center;gap:12px}
.lab{font-size:%(ls)dpx;letter-spacing:.1em;text-transform:uppercase;color:#8A8DA0;font-weight:600}
.pill{font-size:%(ls)dpx;padding:6px 12px;border-radius:999px;background:rgba(197,139,95,.15);color:#E2B48F;font-weight:700}
.t{font-size:%(ts)dpx;font-weight:700;color:#F4F1E8;margin:14px 0 6px}
.m{font-size:%(ms2)dpx;color:#B9B4A6;line-height:1.5}
.draft{margin:16px 0;padding:14px 16px;border-radius:14px;background:#0E1118;font-size:%(ms2)dpx;color:#D6D1C3;line-height:1.55}
.btns{display:flex;gap:12px}
.b{flex:1;text-align:center;padding:12px;border-radius:12px;font-weight:700;font-size:%(ms2)dpx}
.ok{background:#149655;color:#fff}.no{border:1px solid rgba(233,228,214,.2);color:#E9E4D6}
.step{display:flex;gap:16px;align-items:center;padding:%(sp)dpx 0;border-bottom:1px solid rgba(233,228,214,.08);font-size:%(ts)dpx;color:#E9E4D6}
.step:last-child{border-bottom:0}
.n{flex:0 0 auto;width:%(ns)dpx;height:%(ns)dpx;border-radius:50%%;background:#149655;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:%(ms2)dpx}
.map{width:100%%;height:100%%;border-radius:22px;background-color:#20242D;background-repeat:no-repeat;background-size:contain;background-position:center;border:1px solid rgba(233,228,214,.1)}
'''

STEPS = ['Install and encode your business', 'Choose your first department', 'Connect your tools', 'Run it end to end', 'Put it on a clock', 'Demo day']


def visual(kind, map_b64):
    if kind == 'outbox':
        return '''<div class="card"><div class="row"><span class="lab">Waiting for you</span><span class="pill">Needs approval</span></div>
<div class="t">Follow-up · 3 positive replies</div><div class="m">Drafted by the follow-up coordinator, in your voice</div>
<div class="draft">Thanks for the call today. As promised, here are the two options we discussed and the timeline for each…</div>
<div class="btns"><div class="b ok">Approve</div><div class="b no">Reject with a reason</div></div></div>'''
    if kind == 'steps':
        return '<div class="card">' + ''.join(f'<div class="step"><span class="n">{i}</span>{s}</div>' for i, s in enumerate(STEPS, 1)) + '</div>'
    return f'<div class="map" style="background-image:url(data:image/png;base64,{map_b64})"></div>'


def page(c, size, map_b64):
    w, h = SIZES[size]
    land = size == 'landscape'
    story = size == 'story'
    k = w / 1080
    p = dict(f=FONTS, w=w, h=h, dir='row' if land else 'column', pad=int(56 if land else 84 * k), gap=int(40 if land else 56),
             cflex='1.15' if land else '0 0 auto', vflex='1' if land else '1', g2=18 if land else 26, bs=18 if land else 24, ms=22 if land else 28,
             ks=15 if land else 22, hs=58 if land else (104 if story else 76), ss=19 if land else (32 if story else 25), cs=18 if land else 28,
             cp='12px 22px' if land else '20px 34px', vp=22 if land else 34, ls=12 if land else (20 if story else 15), ts=17 if land else (34 if story else 22), ms2=14 if land else (26 if story else 17), ns=30 if land else (52 if story else 34), sp=12 if land else (20 if story else 5))
    css = CSS % p
    return f'''<!doctype html><html><head><meta charset="utf-8"><style>{css}</style></head><body><div class="ad">
<div class="copy"><div class="brand"><span class="mark"></span>{BRAND}</div><div class="kicker">{c["kicker"]}</div><h1>{c["head"]}</h1><p class="sub">{c["sub"]}</p><div class="cta">{c["cta"]}</div></div>
<div class="vis">{visual(c["visual"], map_b64)}</div></div></body></html>'''


def main():
    from PIL import Image
    shot = os.path.join(HERE, 'map-shot.png')
    im = Image.open(shot)
    W, H = im.size
    crop = im.crop((int(W * .14), int(H * .1), int(W * .86), int(H * .97)))
    tmp = os.path.join(HERE, '.map-crop.png'); crop.save(tmp)
    map_b64 = base64.b64encode(open(tmp, 'rb').read()).decode(); os.remove(tmp)
    out = os.path.join(HERE, 'png'); os.makedirs(out, exist_ok=True)
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        for cid, c in CONCEPTS.items():
            for size, (w, h) in SIZES.items():
                pg = b.new_page(viewport={'width': w, 'height': h})
                tmp = os.path.join(HERE, '.ad.html')
                open(tmp, 'w', encoding='utf-8').write(page(c, size, map_b64))
                pg.goto('file://' + tmp); pg.evaluate('document.fonts.ready'); pg.wait_for_timeout(200)
                pg.screenshot(path=os.path.join(out, f'{cid}-{size}.png'))
                pg.close()
                print('ad', cid, size)
        b.close()
    os.remove(os.path.join(HERE, '.ad.html'))


if __name__ == '__main__':
    main()
