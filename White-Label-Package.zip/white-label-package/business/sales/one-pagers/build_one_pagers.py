"""Two A4 one-pagers as PDF:
  programme-one-pager.pdf    for prospective members (what the cohort is, who it's for, the guarantee)
  white-label-one-pager.pdf  for prospective licensees (what they get, how they run it, licence models)

    python3 build_one_pagers.py      (needs Playwright with Chromium)

Edit BRAND, PRICES and the text below, then re-run. No results or savings claims (see
../../compliance/claims-and-disclaimers.md)."""
import os
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.abspath(os.path.join(HERE, '../../../../site/assets/fonts'))
BRAND = 'Your Brand'
PRICES = {'founding': '$1,497', 'vip': '$5,000'}
CONTACT = 'yourbrand.com · hello@yourbrand.com'

CSS = f'''
@font-face{{font-family:"PJS";font-weight:200 800;src:url("file://{FONTS}/plus-jakarta-sans-latin-wght-normal.woff2") format("woff2")}}
@font-face{{font-family:"Marcellus";src:url("file://{FONTS}/marcellus-latin-400-normal.woff2") format("woff2")}}
@font-face{{font-family:"ISerif";font-style:italic;src:url("file://{FONTS}/instrument-serif-latin-400-italic.woff2") format("woff2")}}
@page{{size:A4;margin:0}}
*{{box-sizing:border-box;margin:0}}
body{{font-family:"PJS",sans-serif;color:#161618;font-size:9pt;line-height:1.45;background:#F4F4F5}}
.page{{width:210mm;height:296mm;overflow:hidden;padding:12mm 14mm;display:flex;flex-direction:column;gap:3.6mm}}
.top{{display:flex;justify-content:space-between;align-items:center}}
.brand{{display:flex;align-items:center;gap:2.5mm;font-family:"Marcellus";letter-spacing:.14em;text-transform:uppercase;font-size:10pt}}
.mark{{width:4.4mm;height:4.4mm;border-radius:50%;border:.6mm solid #161618;position:relative}}.mark:after{{content:"";position:absolute;inset:28%;border-radius:50%;background:#161618}}
.tag{{font-size:8pt;letter-spacing:.12em;text-transform:uppercase;color:#087A45;font-weight:700}}
.hero{{background:#161618;color:#F4F4F5;border-radius:5mm;padding:7mm 8mm}}
h1{{font-weight:800;font-size:23pt;line-height:1.05;letter-spacing:-.02em}} h1 em{{font-family:"ISerif";font-weight:400;font-style:italic;letter-spacing:0}}

.lead{{font-size:10pt;color:#C9C9CF;margin-top:2.5mm;max-width:150mm}}
.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:3.5mm}}
.grid3{{display:grid;grid-template-columns:repeat(3,1fr);gap:3.5mm}}
.card{{background:#fff;border:1px solid rgba(20,20,24,.1);border-radius:4mm;padding:3.6mm}}
.card h3{{font-size:9.8pt;margin-bottom:1mm}} .card p{{color:#4C4C54;font-size:8.4pt}}
.n{{display:inline-flex;width:6mm;height:6mm;border-radius:50%;background:#149655;color:#fff;font-weight:800;font-size:8.5pt;align-items:center;justify-content:center;margin-bottom:1.2mm}}
h2{{font-family:"Marcellus";font-weight:400;font-size:12.5pt;margin:0}}
.steps{{display:grid;grid-template-columns:repeat(6,1fr);gap:2.5mm}}
.step{{background:#fff;border:1px solid rgba(20,20,24,.1);border-radius:3mm;padding:2.6mm;font-size:7.9pt;line-height:1.35}} .step b{{display:block;font-size:9pt;margin-bottom:1mm}}
.two{{display:grid;grid-template-columns:1.1fr 1fr;gap:4mm}}
ul{{padding-left:4.5mm}} li{{margin:.5mm 0;font-size:8.5pt}}
.price{{display:flex;gap:3.5mm}} .price .card{{flex:1}} .big{{font-size:15pt;font-weight:800}}
.note{{font-size:8pt;color:#6E6E76}}
.foot{{margin-top:auto;display:flex;justify-content:space-between;font-size:8.5pt;color:#6E6E76;border-top:1px solid rgba(20,20,24,.12);padding-top:3mm}}
'''

PROGRAMME = f'''<div class="page">
<div class="top"><div class="brand"><span class="mark"></span>{BRAND}</div><div class="tag">Live cohort · six sessions · two weeks</div></div>
<div class="hero"><h1>Your first AI department.<br><em>Built live, on your business.</em></h1>
<p class="lead">Six live sessions. You build one working AI department on your own business, on your own computer, with your own Claude account. It knows your business, works in your voice, and nothing goes out without your approval.</p></div>
<div class="grid">
<div class="card"><span class="n">1</span><h3>Your knowledge</h3><p>An interview turns your offers, customers and voice into files every agent reads.</p></div>
<div class="card"><span class="n">2</span><h3>Specialists</h3><p>90 skills covering 137 jobs across seven departments, each with tested steps.</p></div>
<div class="card"><span class="n">3</span><h3>Your approval</h3><p>Emails, posts and payments wait for you, enforced by a safety hook.</p></div>
<div class="card"><span class="n">4</span><h3>A record</h3><p>Every job logged, with what it made, saved and cost; a map lights when it ran.</p></div>
</div>
<h2>The six sessions</h2>
<div class="steps">
<div class="step"><b>1 · Foundations</b>Install together; start the interview; choose your department.</div>
<div class="step"><b>2 · Workspace</b>Backups, the library, your ten things into a plan.</div>
<div class="step"><b>3 · Encode</b>Your documents in, read back, corrected; your first run.</div>
<div class="step"><b>4 · Deploy</b>Tools connected; every job run; map and dashboard.</div>
<div class="step"><b>5 · On a clock</b>Schedules, budgets, approvals from your phone.</div>
<div class="step"><b>6 · Demo day</b>Show it working; stress-test; plan the next one.</div>
</div>
<div class="two">
<div class="card"><h3>Who it's for</h3><ul><li>Owners and operators of service businesses, agencies, consultancies and small teams.</li><li>You have repeat work you'd pay to hand off, and can check it in minutes.</li><li>You can attend six two-hour sessions live, plus one to two hours of homework between them.</li><li>A Mac or Windows laptop and a paid Claude plan (paid separately to Anthropic).</li></ul></div>
<div class="card"><h3>Where most people start</h3><ul><li><b>Outreach</b>: more first conversations</li><li><b>Content</b>: publishing every week</li><li><b>Delivery</b>: kickoffs, updates, recaps</li><li><b>Admin</b>: inbox, invoicing, month-end</li><li><b>Replies &amp; support</b>: fast answers to leads and customers</li></ul></div>
</div>
<div class="price">
<div class="card"><h3>Founding seat</h3><div class="big">{PRICES["founding"]}</div><p>The full cohort, the workspace, 12 months of library updates, 90 days of support after demo day.</p></div>
<div class="card"><h3>VIP seat</h3><div class="big">{PRICES["vip"]}</div><p>Everything in Founding, plus three private 1-on-1 build sessions with the lead instructor.</p></div>
<div class="card"><h3>The guarantee</h3><p><b>Cooling-off:</b> 3 days, before Session 1, no questions.<br><b>Build guarantee:</b> attend all six live and complete the setup steps; no working department, full refund (ask within 7 days of demo day).</p></div>
</div>
<p class="note">Your files are yours to keep. Claude usage is billed by Anthropic under your own plan; tools you connect may have their own fees. Full terms on the website.</p>
<div class="foot"><span>Free 2-minute AI audit and free live training on the website</span><span>{CONTACT}</span></div>
</div>'''

WHITE = f'''<div class="page">
<div class="top"><div class="brand"><span class="mark"></span>{BRAND}</div><div class="tag">White-label programme</div></div>
<div class="hero"><h1>An AI-workforce programme.<br><em>Under your brand.</em></h1>
<p class="lead">Everything needed to sell and teach a live cohort in which each member builds a working AI department on their own business: the product, the website, the back end, the curriculum and the playbooks.</p></div>
<div class="grid">
<div class="card"><span class="n">1</span><h3>The product</h3><p>An installable AI workspace: 90 skills, 137 jobs, approvals enforced by a hook, a run record, console with 20 tools, a map, five example businesses.</p></div>
<div class="card"><span class="n">2</span><h3>The website</h3><p>Marketing site, free audit with a published method, interactive map and dashboards, legal templates. One config file to rebrand.</p></div>
<div class="card"><span class="n">3</span><h3>The business</h3><p>Checkout with seat holds, member area, kit downloads, refunds, support, leads and admin. Or a documented no-code route.</p></div>
<div class="card"><span class="n">4</span><h3>The playbook</h3><p>Six run sheets and decks, the demo-day rubric, instructor certification, support SOPs, emails, sales kit and launch checklist.</p></div>
</div>
<h2>How a licensee runs it</h2>
<div class="steps">
<div class="step"><b>1 · Brand</b>Name, logo, colours, prices and dates in one config.</div>
<div class="step"><b>2 · Certify</b>Instructors and TAs certified on the programme.</div>
<div class="step"><b>3 · Launch</b>Back end, payments and legal pages; an eight-week checklist.</div>
<div class="step"><b>4 · Sell</b>Free training script, emails, ads, sales-call deck.</div>
<div class="step"><b>5 · Teach</b>Six live sessions with run sheets and a rubric.</div>
<div class="step"><b>6 · Support</b>90 days of support with SOPs and macros.</div>
</div>
<div class="two">
<div class="card"><h3>Built to be trusted</h3><ul><li>No invented proof: the results page shows only real, counted, permissioned outcomes.</li><li>Members' workspaces run on their own computers; their business data never passes through the licensee or licensor.</li><li>Approval guard, OS-keychain secrets, row-level security, rate limits and signed downloads.</li><li>Compliance mapped: EU AI Act Article 50, outbound email rules, consumer law and privacy.</li></ul></div>
<div class="card"><h3>Licence models</h3><ul><li><b>Annual licence + per-seat royalty</b>: most licensees.</li><li><b>Revenue share</b>: testing a market or bundling.</li><li><b>Enterprise</b>: networks and franchisors, optional exclusivity.</li></ul><p class="note" style="margin-top:2mm">All include updates, certification places and licensor support at your tier.</p></div>
</div>
<div class="grid3">
<div class="card"><h3>Who it suits</h3><p>Training companies, agencies, consultancies, business communities and franchisors serving small businesses.</p></div>
<div class="card"><h3>What you need</h3><p>A lead instructor, teaching assistants at about one per 12–15 members, and an audience to invite to a free training.</p></div>
<div class="card"><h3>Next step</h3><p>A walkthrough of the product and member journey, then your market and numbers in the pricing model.</p></div>
</div>
<div class="foot"><span>Delivered as files you control</span><span>{CONTACT}</span></div>
</div>'''


def main():
    with sync_playwright() as pw:
        b = pw.chromium.launch()
        for name, body in (('programme-one-pager', PROGRAMME), ('white-label-one-pager', WHITE)):
            tmp = os.path.join(HERE, f'.{name}.html')
            open(tmp, 'w', encoding='utf-8').write(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><style>{CSS}</style></head><body>{body}</body></html>')
            pg = b.new_page(); pg.goto('file://' + tmp); pg.evaluate('document.fonts.ready')
            pg.pdf(path=os.path.join(HERE, f'{name}.pdf'), format='A4', print_background=True, prefer_css_page_size=True)
            pg.close(); os.remove(tmp); print('pdf', name)
        b.close()


if __name__ == '__main__':
    main()
