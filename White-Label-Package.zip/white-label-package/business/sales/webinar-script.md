# Free live training: the script (60 minutes)

The free training is the main way seats sell. This is a full script for the lead instructor, with
what to show at each point. Speak it in your own words; keep the structure and the honesty rules.
Everything shown live runs on the fictional Pellmark Growth example or demo data.

**Title options:** "Build your first AI department (live)" · "What to hand to AI first, and how to
keep control" · "From ChatGPT tabs to an AI department you run"

**Set-up:** demo workspace as in Session 1 prep; the free audit open in a browser; three attendee
audit results collected in advance from registrations (with permission) or use three of your own
examples labelled as examples; slides optional (the demo is the slide).

---

## 0:00 · Welcome (5 min)

> Welcome. In the next hour I'll show you a working AI department running on a business, how to
> choose the first one for yours, and how to keep control of what it does. You'll leave with a way
> to decide, whether or not you ever work with us.
>
> Quick housekeeping: this is recorded and the replay goes out after. Put questions in the chat;
> I'll answer as many as I can at the end.
>
> One thing about me before we start: [one or two true sentences about the instructor's own
> experience with this, no revenue claims].

Ask: *"In the chat: what's the one task you'd hand off tomorrow if you could?"* Read a few out.
These answers are your examples for the rest of the hour.

## 0:05 · The problem (5 min)

> Most owners using AI today have a dozen chat tabs and the same problem every time: it doesn't know
> the business, so you explain it again; what it writes sounds like nobody; and you'd never let it
> send anything on its own. So it saves you minutes, not hours.
>
> The fix isn't a better prompt. It's three things: the AI knows your business once, for every job;
> each job has a specialist with tested steps; and nothing leaves without you. That's what we mean
> by an AI department.

## 0:10 · A department running, live (15 min)

Follow Session 1's Demo A, shortened. Narrate in outcomes, not features:

1. `bin/wf status`: *"This is what ran this week, what's waiting for me, what it saved."* (Say it's
   demo data.)
2. The map: *"Every job a business does, by department. A light means it actually ran."*
3. The outbox: *"Here's what it wants to send. Nothing went. I'll reject this one with a reason; it
   learns from the reason."*
4. Live: *"prep me for my call with Tillwater tomorrow"* on Pellmark. While it runs, open
   `offers.md` and `voice.md`: *"This is why it doesn't sound generic."*
5. The output and the run log.

> That's one department. It runs on my laptop, with my own Claude account, and the files are mine.

## 0:25 · Choosing your first department (10 min)

> The question I get most is "where do I start?" Here's the rule: repeat work you'd pay someone to
> take off you this month, that you can check in five minutes. Not the most impressive department:
> the most useful.

Show the five choices (outreach, content, delivery, admin, replies and support) with one line each.
Then the three audit results: what each business answered, where the audit suggested starting, and
why. Show the audit live on one attendee's answers if someone volunteers.

> If you haven't, take the free audit tonight: [link]. It gives you an estimate, with the method
> published, and a first department.

## 0:35 · How the cohort works (10 min)

Plainly, in this order:

1. **Six live sessions over two weeks**, [days], [time and time zone]. Recorded the same day.
2. **You build on your own business**, on your own computer: install, encode your business, choose
   and deploy one department, put it on a schedule, show it working on demo day.
3. **What you need:** a Mac or Windows laptop, a paid Claude plan (paid separately to Anthropic; your
   usage decides the cost), two hours three times a week plus homework.
4. **What you leave with:** the workspace and everything you built; 12 months of library updates;
   90 days of support with a call every two weeks.
5. **The guarantee, with its conditions:** *"Attend all six live and complete the setup steps. If you
   don't leave with a working department, you get your money back. And there's a 3-day cooling-off
   before Session 1, no questions."* Say what "working department" means (the rubric, in one
   sentence).

## 0:45 · Questions (10 min)

Answer honestly. Prepared answers:

| Question | Answer |
|---|---|
| "How much will I save?" | "I can't promise a number. The audit estimates it with a published method; after a month your own run record shows what actually happened." |
| "Do I need to be technical?" | "No coding. If you can follow steps and install an app, you'll be fine; TAs are in the room for installs." |
| "What does Claude cost?" | "It depends on your plan and how much you run. You set budgets in the workspace, and routine jobs use a cheaper model by default." |
| "Is my data safe?" | "It stays on your computer and in the tools you connect, plus Claude itself under your account. We never receive your business data." |
| "Why not just use [hosted app / Zapier]?" | Use the compare page: each is right for someone; here's who this is for. |
| "Can you build it for me?" | [Your done-for-you offer if you have one; otherwise:] "We build it with you, which is why you keep it and can build the next one." |
| "What if I miss a session?" | "Recordings same day, but the guarantee needs all six live. If you know you'll miss one, wait for the next cohort." |

## 0:55 · The offer (5 min)

> Seats for [cohort] are open: Founding at [price], VIP at [price] with three private build sessions.
> [Seats] places in total, enrollment closes [date] or when they're gone. Link's in the chat and
> in the replay email.
>
> If now isn't the time, join the waitlist and take the audit; both are free.

Stop on time. Thank people for coming.

## After the training

- Replay and T4 email within two hours.
- Every attendee who asked a question about their own business gets a one-line personal follow-up.
- Note the questions you couldn't answer well; fix the FAQ.
