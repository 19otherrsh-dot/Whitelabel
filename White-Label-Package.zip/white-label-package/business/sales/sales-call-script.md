# Sales call: discovery and recommendation (20–30 minutes)

For "Book a call" conversations. The goal is the right decision for the caller, including "not
now". Use the sales-call deck (`sales-call-deck.pptx`) only if they want to see something.

## 1. Open (2 min)

> Thanks for booking. I'd like to understand your business and where the time goes, then tell you
> honestly whether the cohort fits. If it doesn't, I'll say so. Sound good?

## 2. Discover (10–15 min)

- What does the business do, for whom, and how many people?
- What do you do every week that you wish you didn't? (Get three concrete examples.)
- Which of those would you pay someone to take off you this month?
- What have you tried with AI so far? What happened?
- What tools do you use: email, CRM, accounting, project tool?
- What would make the next two months a success?
- Can you make [dates/times] live, all six? Any planned travel?
- Who else is involved in the decision?

If they took the audit, open their result: which first department did it suggest, and does that match
their examples?

## 3. Recommend (5 min)

Say the first department you'd pick for them and why, using their examples. Then the fit, honestly:

| They are… | Say |
|---|---|
| A good fit | "This fits: [their three examples] are exactly what [department] does. Here's how the two weeks would go for you…" |
| Can't attend live | "The guarantee needs all six live. I'd wait for the next cohort [or: the self-paced course fits better]." |
| No repeat work they can name | "I don't think you're ready to hand work over yet. Take the audit, list ten things for a month, and come back." |
| Want it done for them | "[Your done-for-you offer], or a hosted app may suit you better; here's the comparison page." |
| Need many users / a whole company | "The cohort is for one person; team setups are [your offer]." |

## 4. Objections

| They say | Answer |
|---|---|
| "It's expensive." | "Compare it with what the department takes off you each month, and with hiring for it. If the numbers don't work for your business, it's not the right time, and that's fine." |
| "What if I fall behind?" | "Recordings the same day, a clinic after each session, TAs in the room. Homework is one to two hours between sessions." |
| "I'm not technical." | "No coding. You'll follow steps; we install it together in Session 1." |
| "What will Claude cost me?" | "It depends on your plan and usage. You set budgets in the workspace; routine work uses a cheaper model." |
| "Is my data safe?" | "Your workspace runs on your computer with your own Claude account. We never receive your business data." |
| "Can I get a refund?" | "Three-day cooling-off before Session 1, no questions. And the build guarantee, if you attend all six live and do the setup steps." |

## 5. Close (2 min)

> Based on what you've told me, I'd [recommend the founding / VIP seat / waiting]. If you want to go
> ahead, here's the link; enrollment closes [date]. Any questions I haven't answered?

Send a short recap within a working day: their three examples, the department, the link, the date.
Never push someone who isn't a fit; refunds and bad reviews cost more than the seat.
