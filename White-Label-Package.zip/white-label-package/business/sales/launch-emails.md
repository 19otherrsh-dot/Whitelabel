# Launch emails (to your list)

Six emails from announcing the free training to enrollment closing. Send only to people who agreed
to hear from you. Every claim follows `../compliance/claims-and-disclaimers.md`. `{{double braces}}`
are placeholders.

| # | When | Subject |
|---|---|---|
| L1 | 3 weeks before Session 1 | Free live training: build your first AI department |
| L2 | 4 days before the training | What to hand to AI first (and what not to) |
| L3 | Day after the training | The replay, and seats for {{cohort}} |
| L4 | 5 days before close | The question everyone asks: "what if it doesn't work?" |
| L5 | 2 days before close | What the two weeks actually look like |
| L6 | Morning of close | Enrollment closes today at {{time}} |

---

## L1 · Free live training: build your first AI department

Hi {{first name}},

On {{date}} at {{time}} {{tz}} I'm running a free live training: **build your first AI department**.

In an hour you'll see a working department run on a business (drafts, approvals, the record of
what it did), how to choose the first one for yours, and how to keep control of what it sends.

It's free, it's live, and there's a replay. Save your seat: {{training link}}

{{signature}}

## L2 · What to hand to AI first (and what not to)

Hi {{first name}},

The most common mistake I see: starting with the most impressive thing AI could do, not the most
useful.

The rule we use: **repeat work you'd pay someone to take off you this month, that you can check in
five minutes.** Follow-ups after calls. The weekly client update. Chasing overdue invoices. Sorting
the inbox. Not "run my marketing".

And keep anything that sends, posts or pays behind your approval until it's earned trust.

If you want to see where your business would start, the free audit takes two minutes: {{audit link}}.
We'll go through a few results live on {{date}}: {{training link}}

## L3 · The replay, and seats for {{cohort}}

Hi {{first name}},

Thanks to everyone who came. The replay is here for {{n}} days: {{replay link}}

If you want to build your first department with us: {{cohort}} runs {{dates}}, {{days}},
{{time}} {{tz}}. Six live sessions, on your own business, on your own computer. You keep everything
you build, with 12 months of updates and 90 days of support after.

Seats: {{pricing link}} (Founding {{price}}, VIP {{price}}). {{seats}} places; enrollment closes
{{close date}} or when they're gone.

Your Claude plan is paid separately to Anthropic, and your usage decides that cost.

## L4 · The question everyone asks: "what if it doesn't work?"

Hi {{first name}},

Fair question. Two answers.

**Cooling-off:** change your mind within 3 days of buying and before Session 1, full refund, no
questions.

**The build guarantee:** attend all six sessions live and complete the setup steps. If you don't
leave with a working department, you get a full refund (ask within 7 days after the last session).
"Working" means one job in your department runs end to end on your own business and produces work
you'd use, with its runs recorded. The full terms: {{refunds link}}

We put the conditions up front because the guarantee only works if you build with us live.

Seats for {{cohort}}: {{pricing link}}

## L5 · What the two weeks actually look like

Hi {{first name}},

Here's the whole thing, session by session:

1. **Foundations.** Install together; start the interview that teaches it your business; pick your
   first department.
2. **Your workspace.** Backups, the department library, and your ten things turned into a plan.
3. **Encode your business.** Your documents in, read back and corrected; your voice matched; your
   first real run.
4. **Deploy your department.** Your tools connected, every job run, on your map and dashboard.
5. **Put it on a clock.** Schedules with budgets and approvals; approve from your phone.
6. **Demo day.** Show it working; we stress-test it; plan your next one.

Plus one to two hours of homework between sessions. Enrollment closes {{close date}}:
{{pricing link}}

## L6 · Enrollment closes today at {{time}}

Hi {{first name}},

A short one: enrollment for {{cohort}} closes today at {{time}} {{tz}}. {{If true: There are
{{n}} places left.}}

{{pricing link}}

If now isn't the time, the waitlist hears first about the next one: {{waitlist link}}

*(Only say places are limited or nearly gone if the number is real. The back end shows it.)*
