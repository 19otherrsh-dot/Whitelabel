# Product demo video

`demo-video.mp4` (1280×720, about 72 seconds, silent with on-screen captions) walks through the white-label
site as a buyer sees it: the promise, the map of 137 jobs, opening a department and a job, the free audit
and its result, a command-centre dashboard (sample data, labelled as such), the six sessions, and the
guarantee, ending on "Take the free 2-minute audit".

| File | Use |
|---|---|
| `demo-video.mp4` | Website, social posts, sales emails, the webinar's opening, licensee pitches |
| `demo-video.srt` | Caption file for platforms that take one (YouTube, LinkedIn, Vimeo) |
| `demo-video-poster.jpg` | Thumbnail / poster frame |
| `record-demo.js` | Re-records the whole video with **your** brand, dates and prices |
| `add-voiceover.py` | Lays a narration over the video, each line starting with its caption: `python3 add-voiceover.py narration.mp3` writes `demo-video-voiceover.mp4` |

It shows "Your Brand" and the placeholder cohort dates. Before using it publicly, set your brand in the
site's `assets/config.js` and re-record (the script's header has the three steps). The captions avoid
results claims: the audit figure is shown as the site shows it, an estimate from the published method,
and the dashboard is marked as sample data. If you add a voice-over, keep to the same wording: record the eight caption lines in order with a short pause
between them, then run `add-voiceover.py`. A narration of exactly these lines was recorded in ElevenLabs
(voice "Martin - Calm, Clear Narrator", two takes) for this package.
