#!/usr/bin/env python3
"""Lay a narration over the demo video, each line starting with its caption.

    python3 add-voiceover.py narration.mp3 [demo-video.mp4] [demo-video.srt] [out.mp4]

The narration is one recording of the caption lines in order, with a short pause between lines (the
ElevenLabs take recorded for this package is exactly that). The script finds the pauses, cuts the
recording into one piece per caption, starts each piece when its caption appears, and writes
demo-video-voiceover.mp4 next to the video (video stream copied untouched, AAC audio, loudness
normalised to -16 LUFS). A line that runs longer than its caption is sped up slightly (at most 8%);
if that is not enough it simply finishes a little later and the next line waits for it.
Needs ffmpeg and ffprobe on the PATH."""
import re, subprocess, sys, os, tempfile

here = os.path.dirname(os.path.abspath(__file__))
narr = sys.argv[1]
video = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, 'demo-video.mp4')
srt = sys.argv[3] if len(sys.argv) > 3 else os.path.join(here, 'demo-video.srt')
out = sys.argv[4] if len(sys.argv) > 4 else os.path.join(here, 'demo-video-voiceover.mp4')


def ts(s):
    h, m, rest = s.split(':'); sec, ms = rest.split(',')
    return int(h) * 3600 + int(m) * 60 + int(sec) + int(ms) / 1000


cues = [(ts(a), ts(b)) for a, b in re.findall(r'(\d\d:\d\d:\d\d,\d{3}) --> (\d\d:\d\d:\d\d,\d{3})', open(srt, encoding='utf-8').read())]
dur = lambda f: float(subprocess.run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f], capture_output=True, text=True, check=True).stdout)
total = dur(narr)
vlen = dur(video)


def silences(noise_db, min_len):
    r = subprocess.run(['ffmpeg', '-hide_banner', '-i', narr, '-af', f'silencedetect=noise={noise_db}dB:d={min_len}', '-f', 'null', '-'], capture_output=True, text=True)
    st = [float(x) for x in re.findall(r'silence_start: ([\d.]+)', r.stderr)]
    en = [float(x) for x in re.findall(r'silence_end: ([\d.]+)', r.stderr)]
    return [(a, b) for a, b in zip(st, en) if a > 0.05 and b < total - 0.05]


# find the (len(cues) - 1) longest pauses inside the recording: those are the gaps between lines
need = len(cues) - 1
gaps = []
for noise, mn in [(-40, 0.35), (-35, 0.3), (-32, 0.25), (-30, 0.2)]:
    gaps = silences(noise, mn)
    if len(gaps) >= need:
        break
if len(gaps) < need:
    sys.exit(f'Found {len(gaps)} pauses but there are {len(cues)} captions; record the lines with a clear pause between them.')
gaps = sorted(sorted(gaps, key=lambda g: g[1] - g[0], reverse=True)[:need])
cuts = [0.0] + [(a + b) / 2 for a, b in gaps] + [total]

tmp = tempfile.mkdtemp()
pieces, cursor = [], 0.0
for i, (start, end) in enumerate(cues):
    a, b = cuts[i], cuts[i + 1]
    seg = os.path.join(tmp, f'p{i}.wav')
    # trim the piece's own leading/trailing silence
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-ss', f'{a:.3f}', '-to', f'{b:.3f}', '-i', narr, '-af',
                    'silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse',
                    '-ar', '44100', '-ac', '1', seg], check=True)
    length = dur(seg)
    window = end - start
    if length > window:
        tempo = min(1.08, length / window)
        sped = os.path.join(tmp, f'p{i}s.wav')
        subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', seg, '-af', f'atempo={tempo:.4f}', sped], check=True)
        seg, length = sped, dur(sped)
    at = max(start + 0.1, cursor)
    pieces.append((seg, at))
    cursor = at + length + 0.15
    print(f'line {i + 1}: {length:4.1f}s at {at:5.2f}s (caption {start:5.2f}-{end:5.2f})')

inputs, filters = [], []
for i, (seg, at) in enumerate(pieces):
    inputs += ['-i', seg]
    filters.append(f'[{i + 1}:a]adelay={int(at * 1000)}|{int(at * 1000)}[a{i}]')
mix = ''.join(f'[a{i}]' for i in range(len(pieces)))
filters.append(f'{mix}amix=inputs={len(pieces)}:normalize=0,apad,atrim=0:{vlen:.3f},loudnorm=I=-16:TP=-1.5:LRA=11[aout]')
subprocess.run(['ffmpeg', '-y', '-v', 'error', '-i', video, *inputs, '-filter_complex', ';'.join(filters),
                '-map', '0:v', '-map', '[aout]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k', '-ar', '44100', '-movflags', '+faststart', out], check=True)
print('wrote', out)
