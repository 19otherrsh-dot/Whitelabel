// Re-record the product demo video with your own brand (silent, with on-screen captions).
//
//   1. Set your brand, dates and prices in the site's assets/config.js (and bake them: node tools/bake-config.mjs).
//   2. Serve the site folder:            cd site && python3 -m http.server 8765
//   3. Record:                            node record-demo.js [http://127.0.0.1:8765/]
//      → demo-video.mp4, demo-video.srt, demo-video-poster.jpg in this folder.
// Needs Node, Playwright with Chromium (npm i playwright && npx playwright install chromium) and ffmpeg.
const { chromium } = require('playwright');
const fs = require('fs'); const path = require('path'); const { spawnSync } = require('child_process');
const BASE = (process.argv[2] || 'http://127.0.0.1:8765/').replace(/\/?$/, '/');
const OUT = path.join(__dirname, 'out'); fs.mkdirSync(OUT, { recursive: true });
const W = 1280, H = 720;
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 1, recordVideo: { dir: OUT, size: { width: W, height: H } }, reducedMotion: 'no-preference' });
  await ctx.route('**/*', (r) => (r.request().url().startsWith(BASE) || r.request().url().startsWith('data:') ? r.continue() : r.abort()));
  const p = await ctx.newPage();
  const t0 = Date.now(); const caps = [];
  const now = () => (Date.now() - t0) / 1000;
  let open = null;
  async function cap(text) {
    if (open) { open.end = now(); caps.push(open); }
    open = text ? { start: now(), text } : null;
    await p.evaluate((t) => {
      let el = document.getElementById('__cap');
      if (!t) { if (el) el.remove(); return; }
      if (!el) {
        el = document.createElement('div'); el.id = '__cap';
        el.style.cssText = 'position:fixed;left:50%;bottom:34px;transform:translateX(-50%);z-index:2147483647;max-width:min(980px,86vw);padding:12px 20px;border-radius:14px;background:rgba(18,18,22,.86);color:#F6F6F7;font:600 21px/1.35 "Plus Jakarta Sans",-apple-system,system-ui,sans-serif;text-align:center;box-shadow:0 14px 40px -14px rgba(0,0,0,.6);backdrop-filter:blur(6px);pointer-events:none;transition:opacity .25s';
        document.documentElement.appendChild(el);
      }
      el.textContent = t;
    }, text).catch(() => {});
  }
  const go = async (u) => { await p.goto(BASE + u, { waitUntil: 'load' }); await p.addStyleTag({ content: '#wlconsent{display:none!important} .training-countdown{display:none!important} html{scroll-behavior:auto!important}' }).catch(() => {}); };
  const wait = (ms) => p.waitForTimeout(ms);
  async function scrollTo(y, ms = 1600) { await p.evaluate(async ([y, ms]) => { const s = scrollY, d = y - s, t = performance.now(); await new Promise((r) => { (function f(n) { const k = Math.min(1, (n - t) / ms), e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2; scrollTo(0, s + d * e); k < 1 ? requestAnimationFrame(f) : r(); })(t); }); }, [y, ms]); }

  // 1 · the promise
  await go('index.html'); await wait(900);
  await cap('Build your first working AI department, in six live sessions.'); await wait(4200);
  // 2 · the map
  const filmY = await p.evaluate(() => { const f = document.querySelector('.hero-film'); return f ? f.getBoundingClientRect().top + scrollY - 60 : 700; });
  await scrollTo(filmY, 1800);
  await cap('Every recurring job in a business, mapped: 137 jobs in 7 departments.'); await wait(4500);
  await go('map.html'); await wait(2200);
  const fr = p.frameLocator('#frame');
  await cap('Open a department to see each job, the AI skill that does it, and where a person stays in the loop.');
  await wait(1200);
  const clickIn = async (loc) => { const bx = await loc.boundingBox().catch(() => null); if (!bx) return false; await p.mouse.move(bx.x + bx.width / 2, bx.y + bx.height / 2, { steps: 12 }); await wait(250); await p.mouse.down(); await p.mouse.up(); return true; };
  await clickIn(fr.locator('.tree').first());
  await wait(3000);
  await clickIn(fr.locator('[role="button"][aria-label^="Cold Email Drafting"]').first());
  await wait(4200);
  // 3 · the audit
  await go('audit.html'); await wait(800);
  await cap('The free audit: five quick questions about your business…');
  await p.click('[data-act="next"]'); await wait(900);
  await p.click('[data-q="type"] [data-id="agency"]'); await wait(1100);
  await p.click('[data-q="size"] [data-id="s6"]'); await wait(1100);
  for (const d of ['Sales', 'Operations']) { await p.click(`[data-q="depts"] [data-id="${d}"]`); await wait(450); }
  await p.click('[data-act="next"]'); await wait(900);
  for (const t of ['crm', 'meet']) { await p.click(`[data-q="tools"] [data-id="${t}"]`); await wait(450); }
  await p.click('[data-act="next"]'); await wait(900);
  await p.fill('#pfco', 'Northfield Studio').catch(() => {}); await wait(700);
  await p.click('[data-act="skip"]');
  await cap('…and a result: an estimate from a published method (not a promise), and which jobs can run today.');
  await wait(3600);
  const cardsY = await p.evaluate(() => { const r = document.querySelector('.pf-fork, .pf-cta-row'); return r ? r.getBoundingClientRect().top + scrollY - 420 : 600; }).catch(() => 600);
  await scrollTo(cardsY, 1400);
  await wait(3600);
  // 4 · the workforce
  await go('assets/dashboards-app.html'); await wait(2600);
  await cap('A command centre for every department (sample data shown).'); await wait(2200);
  await p.mouse.move(640, 430, { steps: 15 }); await wait(200); await p.mouse.down(); await p.mouse.up();
  await wait(4600);
  // 5 · the programme
  await go('how-it-works.html'); await wait(700);
  const sY = await p.evaluate(() => { const h = [...document.querySelectorAll('h2')].find((x) => /session/i.test(x.textContent)); return h ? h.getBoundingClientRect().top + scrollY - 90 : 900; });
  await scrollTo(sY, 1500);
  await cap('Six live sessions, from foundations to demo day. Your business, your tools, files you own.'); await wait(5000);
  await go('pricing.html'); await wait(700);
  await cap('A working department, or your money back. See the build guarantee terms.'); await wait(4800);
  // 6 · end card
  await go('index.html');
  await p.evaluate(() => {
    const d = document.createElement('div');
    d.style.cssText = 'position:fixed;inset:0;z-index:2147483646;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;background:#121214;color:#F6F6F7;font-family:"Plus Jakarta Sans",-apple-system,system-ui,sans-serif;text-align:center';
    const brand = (window.SITE_CONFIG && window.SITE_CONFIG.brandName) || 'Your Brand';
    d.innerHTML = '<div style="font-size:56px;font-weight:700;line-height:1.1;letter-spacing:-.01em">' + brand + '</div><div style="font-size:26px;font-weight:500;line-height:1.4;opacity:.85">Take the free 2-minute audit</div><div style="margin-top:6px;font-size:18px;opacity:.6">Then build your first AI department with us, live.</div>';
    document.documentElement.appendChild(d);
  });
  await cap(null); await wait(3600);
  await ctx.close(); await b.close();
  const vid = fs.readdirSync(OUT).filter((f) => f.endsWith('.webm')).map((f) => path.join(OUT, f)).sort((a, z) => fs.statSync(z).mtimeMs - fs.statSync(a).mtimeMs)[0];
  fs.renameSync(vid, path.join(OUT, 'raw.webm'));
  fs.writeFileSync(path.join(OUT, 'captions.json'), JSON.stringify(caps, null, 2));
  // The video starts when the page opens (t0) and runs on while the browser closes: keep exactly t0 → end.
  const total = now();
  const mp4 = path.join(__dirname, 'demo-video.mp4');
  spawnSync('ffmpeg', ['-v', 'error', '-y', '-i', path.join(OUT, 'raw.webm'), '-t', total.toFixed(2), '-c:v', 'libx264', '-preset', 'slow', '-crf', '22', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-an', mp4], { stdio: 'inherit' });
  spawnSync('ffmpeg', ['-v', 'error', '-y', '-ss', '2.5', '-i', mp4, '-frames:v', '1', '-q:v', '3', path.join(__dirname, 'demo-video-poster.jpg')], { stdio: 'inherit' });
  const ts = (t) => { t = Math.max(0, t); const ms = Math.round((t % 1) * 1000), s = Math.floor(t); return `${String(Math.floor(s / 3600)).padStart(2, '0')}:${String(Math.floor(s % 3600 / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')},${String(ms).padStart(3, '0')}`; };
  fs.writeFileSync(path.join(__dirname, 'demo-video.srt'), caps.map((c, i) => `${i + 1}\n${ts(c.start)} --> ${ts(c.end)}\n${c.text}\n`).join('\n'));
  console.log(`✓ demo-video.mp4 (${total.toFixed(1)} s), demo-video.srt, demo-video-poster.jpg`);
})();
