# Case study template (one per business type)

The audit segments visitors by business type (agency, software, consulting, professional
services, local, e-commerce, creator). A real case study for each lets the audit result say "a
business like yours". **Only real members, with written approval of the final text.** Until you
have one for a type, publish nothing for it; never use the fictional example businesses as case
studies.

## Interview the member (20 minutes, 30+ days after demo day)

1. What did the business look like before: the work you repeated, who did it, how long it took?
2. Which department did you build first, and why that one?
3. What does it do now, in a normal week? (Open `bin/wf runs --week` together.)
4. What did you have to change to make it work (knowledge, lessons, a tool)?
5. What surprised you?
6. What would you tell someone like you who's deciding?
7. May we use your name, role, company and photo? Any numbers you're happy to share, and where they
   come from?

## The write-up (300–500 words)

**Title:** what changed, in their words, without a number unless it's theirs and sourced.
*Example shape: "How a six-person agency stopped writing client updates on Friday nights."*

| Section | Content |
|---|---|
| The business | Type, size, what they sell, to whom (one paragraph) |
| The repeat work | The bottleneck, in their words |
| The department | Which starter, which jobs, what it connects to, what stays with a person |
| A normal week now | What runs, on what schedule, what they approve |
| What it took | Sessions, homework, what they had to fix |
| In their words | One or two quotes, approved |
| The numbers (optional) | Only from their outcomes report or records, with the period and source: "[n] runs and [n] hours saved in the 30 days after demo day, from the member's run log" |

**Always end with:** "Results vary with the business, the department and the work put in."

## Approval record

| Item | Approved by | Date | Where it may appear (site, ads, sales calls) |
|---|---|---|---|
| Final text | | | |
| Name, role, company | | | |
| Photo / logo | | | |
| Numbers | | | |

Store the signed approval with the case study. If the member withdraws permission, remove it
everywhere within 5 business days.
