# Ad creative

Three concepts, each rendered at three sizes in `ads/png/` (square 1080×1080 for feeds, story
1080×1920, landscape 1200×628 for LinkedIn and link ads). Rebuild after rebranding:
`python3 ads/build_ads.py`. Every line follows `../compliance/claims-and-disclaimers.md`: no
results, savings or earnings claims.

| Concept | Image | Best for | Sends to |
|---|---|---|---|
| **Approval** "Your AI drafts. You send." | An approval card from the product | Owners worried about AI going rogue | Free training |
| **Department** "One department. End to end." | The six sessions | People ready to buy, retargeting | Free audit, then pricing |
| **Map** "A light means the job ran." | The product's real map | Cold audiences, curiosity | The map |

## Copy variants

### Meta (Facebook / Instagram)

**Primary text**
1. Most owners use AI in a dozen chat tabs and still do the work. In this free live training we'll
   show a working AI department on a real business: what it drafts, what waits for your approval,
   and how to choose the first one for yours.
2. Your AI should know your business once, for every job, and never send anything without you. Build
   your first AI department in six live sessions, on your own business. Free training on {{date}}.
3. 137 jobs a business does, mapped across seven departments. Which would you hand off first? Take
   the 2-minute audit and see where to start.

**Headlines (≤ 40 characters):** "Build your first AI department" · "Your AI drafts. You send." ·
"Where should your AI start?" · "Free live training, {{date}}"

### LinkedIn

**Intro text**
1. An AI department isn't a better prompt. It's specialists that know your business, follow tested
   steps, and wait for your approval. We'll build one live on {{date}}. Free.
2. For owners of service businesses: six live sessions, one working AI department on your own
   business, on your own computer. You keep everything you build.

**Headlines:** "Build your first AI department, live" · "Nothing goes out without your approval"

### Google Search (responsive search ads)

**Headlines (≤ 30 characters):** Build an AI Department · Free Live AI Training · Your AI Drafts, You
Send · 6 Live Sessions, 2 Weeks · Runs On Your Own Computer · Free 2-Minute AI Audit · Approval
Before Anything Sends · 137 Jobs AI Can Run

**Descriptions (≤ 90 characters):**
- Build one AI department on your own business in six live sessions. Free training first.
- Specialists that know your business and wait for your approval. See it live, free.
- Take the free 2-minute audit and see which department to start with.

**Keywords to start with:** AI for small business training, AI automation course, Claude Code course,
AI agents for business, AI assistant for agency, build AI workflows. Exclude: jobs, free download,
certification (unless you offer it).

## Rules

- No before/after income, "replace your team", or hour counts.
- Don't use Anthropic's or any vendor's logo; "works with Claude Code" in text is fine where accurate.
- Special ad categories: none normally apply, but check each platform's policies for "business
  opportunity" and education ads in your country.
- Keep the landing page promise identical to the ad (training date, price, guarantee conditions).
- Retarget only visitors who accepted analytics/advertising cookies where consent is required.
