# Claims and disclaimers

Rules for anything a licensee publishes about the programme: site, ads, emails, webinars, sales
calls. Consumer-protection regulators (the US FTC, the UK CMA, EU national authorities) treat
results and earnings claims in business-training marketing as a priority; unsubstantiated claims
are the most common problem.

## Claims you can make (true by construction)

| Claim | Why it's safe |
|---|---|
| "Six live sessions over two weeks, recorded the same day" | It's the format |
| "90 pre-installed skills: 78 roles covering 137 jobs, plus 12 core skills" | Counted in the kit |
| "Nothing is sent, posted or paid without your approval" | Enforced by the approval guard; true for default autonomy levels. Say "by default" if members can raise autonomy |
| "Runs on your computer with your own Claude account; your files stay yours" | How the kit works |
| "Build guarantee: attend all six live and complete the setup steps; no working department, full refund" | Only with the conditions stated alongside |
| "Free audit estimates the work you could hand off" | With "estimate" and a link to the method |

## Claims you can't make without evidence

- Revenue, profit or "pays for itself" claims.
- Hours or money saved, as a promise ("save 20 hours a week").
- Headcount claims ("replace three employees").
- "Typical" or "average" results, unless you have data from all (or a fair sample of) members and
  say so.
- Endorsement or partnership with any vendor (Anthropic, HubSpot…) unless true and permitted.

Evidence means: the outcomes data on `results.html`, built from rubrics and members' own outcomes
reports, with the number of members it covers. Keep the records behind every number.

## Testimonials

- Real members only, with **written permission** for the exact words and the name/role shown.
- Don't edit the meaning. Light trimming is fine if the member approves the final text.
- Disclose any incentive (a discount, a free seat) given for the testimonial.
- If a testimonial mentions a result, add context: "Results vary with the business, the department
  and the work put in."
- The site shows only entries in `config.proof` with `permission: "public"`.

## Urgency and scarcity

- Seat limits and deadlines must be real: the back end enforces the seat cap and the enrollment
  deadline; the countdown hides itself when the time has passed.
- Don't reopen "closed" enrollment at the same price within days of a deadline you advertised.

## Standard disclaimers (use as written, adapt the brand)

**Results** (near any results, testimonials or case studies):
> Results vary with the business, the department and the work put in. These are individual
> results, shared with permission, not a promise of what you'll get.

**Audit estimate** (on the audit result; already present):
> An estimate based on your answers and the published method, not a promise. Your actual result
> depends on your business and how you use the workforce.

**Claude costs** (pricing, FAQ, checkout; already present):
> Your Claude account is paid separately to Anthropic. Your plan and usage determine the cost;
> tools you connect may have their own fees.

**AI** (footer link to `ai-disclosure.html`; already present).

## Review process

Every new ad, email sequence and landing page gets a second-person check against this page before it
goes live. Keep a dated copy of each published version with the evidence for any claim in it.
