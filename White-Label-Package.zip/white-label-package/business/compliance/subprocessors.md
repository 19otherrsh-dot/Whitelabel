# Processor and sub-processor register (template)

Each licensee keeps this list current, publishes it (or provides it on request, as the privacy page
says), and has a DPA with each provider. Rows are the **types** the package uses, with common
choices. Fill in what you actually use; delete the rest.

| Purpose | Provider (example choices) | Data involved | Location / transfer | DPA in place | Notes |
|---|---|---|---|---|---|
| Website hosting (static) | [e.g. a static host or CDN] | Visitor IP and request logs | [region] / [SCCs] | [ ] | No cookies unless analytics accepted |
| Member area and database | [Supabase + an app host such as Vercel] | Member accounts, purchases, support, leads, attendance | [region] / [SCCs] | [ ] | Choose an EU/UK region if most members are there |
| Payments | [Stripe] | Name, email, billing address, payment details (held by the provider) | [region] / [SCCs] | [ ] | Card data never touches your servers |
| Transactional email | [Resend] | Email address, email content | [region] / [SCCs] | [ ] | Welcome, sign-in, support replies |
| Marketing email | [Kit / MailerLite / HubSpot…] | Email, name, consent, engagement | [region] / [SCCs] | [ ] | Only people with marketing consent |
| Webinar / meetings | [Zoom / Google Meet / Teams] | Name, email, video/voice, chat, attendance | [region] / [SCCs] | [ ] | Recording notice in invites |
| Community | [Circle / Skool / Slack / Discord] | Name, email, posts | [region] / [SCCs] | [ ] | |
| Chat group (optional) | [WhatsApp Community] | Phone number, messages | [region] | [ ] | Announcement group hides numbers from other members |
| Scheduling | [Calendly / Cal.com] | Name, email, call details | [region] / [SCCs] | [ ] | Book-a-call and VIP 1-on-1s |
| Analytics (optional, consent) | [Plausible / GA4] | Pages, device, approximate location | [region] / [SCCs] | [ ] | Off by default |
| CRM / automation (optional) | [HubSpot / Zapier / Make / n8n] | Leads forwarded from the back end | [region] / [SCCs] | [ ] | `LEAD_FORWARD_WEBHOOK` |
| Course platform (self-paced) | [Kajabi / Teachable / Thinkific…] | Name, email, progress, submissions | [region] / [SCCs] | [ ] | |

**Not your processors:** Anthropic (Claude, Claude Code) and the tools members connect to their
own workspace. Members contract with those providers directly; the workspace runs on the member's
computer under the member's account.

Last reviewed: [date] by [name].
