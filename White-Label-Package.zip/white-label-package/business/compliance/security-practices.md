# Security practices (SOC 2-ready)

What the product already does, and the operating practices a licensee (or the licensor, if it
hosts) adopts so that larger customers' security reviews go smoothly. Organised by the SOC 2 Trust
Services Criteria so it can become the basis of a readiness assessment. **SOC 2 is an audit, not a
document**: these practices make an audit achievable; they don't replace one.

## 1. Scope

| System | Who operates it | Holds |
|---|---|---|
| Static website | Licensee | Nothing personal (forms post to the back end or a webhook) |
| Back end (checkout, member area, admin) | Licensee (or licensor if hosted) | Member accounts, purchases, leads, support, attendance |
| Kit (workspace) | Each member, on their own computer | The member's business data; never sent to licensor or licensee |
| Release pipeline | Licensor | Source, build scripts, release zips |

## 2. Security (common criteria): what the product does

**Back end**
- Row-level security on every table; the browser holds only the public key and sees only the
  member's own rows. Proven by 42 database tests (`supabase/tests/rls_test.sql`).
- The service-role key is server-only (`server-only` imports; never sent to the browser).
- Seat holds callable only by the server; members can't change the email their payment is matched on.
- Stripe webhooks verified by signature; events processed once (idempotency table).
- Kit downloads through 2-minute signed links after an entitlement check; storage bucket private.
- Magic-link sign-in (no passwords to leak); sign-in form reveals nothing about who has a seat.
- Public endpoints: origin allow-list, schema validation, honeypot, per-IP rate limits, 32 KB body cap.
- IP addresses stored only as salted hashes. Security headers (HSTS, frame denial, nosniff, referrer
  policy, permissions policy). Admin actions logged (`admin_log`). CSV exports neutralise formulas.

**Kit**
- Approval guard hook on every tool call: external actions queued for a person; money movement,
  deletion and browser actions always need a person; unattended runs can't approve, change
  permissions or edit safety files.
- Secrets in the OS secure store (macOS Keychain, Windows DPAPI, Linux Secret Service), never in files.
- Console bound to 127.0.0.1, host-header checked, per-session token for changes, strict CSP.
- Untrusted content (emails, web pages) treated as data; injection attempts flagged.
- Budgets and guardrails cap unattended spend and sends; one-command pause.

## 3. Operating practices (adopt these)

| Area | Practice | Evidence to keep |
|---|---|---|
| Access | SSO or unique accounts with 2FA on every admin tool (host, database, Stripe, email, community); least privilege; admins listed in the `admins` table only | Quarterly access review, signed |
| Joiners/leavers | Remove access the same day someone leaves; rotate shared secrets they knew | Checklist per leaver |
| Secrets | Production keys only in the host's secret store; rotate yearly and on any suspicion; never in chat or tickets | Rotation log |
| Change management | All changes through pull requests with review; CI runs `npm test`, `npm run typecheck`, `scripts/test-db.sh`; migrations reviewed | PR history |
| Vulnerabilities | Dependency alerts on (e.g. Dependabot); patch critical issues within 7 days, high within 30 | Alert history |
| Logging | Host and database logs retained ≥ 90 days; admin log reviewed monthly | Review notes |
| Backups | Database point-in-time recovery on; restore tested twice a year | Restore test record |
| Vendors | DPA with each processor (`subprocessors.md`); review their SOC 2 / ISO 27001 reports yearly | Vendor register |
| Training | Annual security and privacy training for staff and instructors, including "never handle members' keys" | Attendance |
| Endpoint | Staff laptops encrypted, updated, screen lock, password manager | Device list |
| Incidents | `incident-response.md` followed; tabletop exercise yearly | Incident log |
| Policies | Information security, acceptable use, access control, data retention (`retention.md`), incident response, vendor management; reviewed yearly | Signed versions |

## 4. Availability

- Uptime monitor on `/api/health` (it checks the database) with alerts to the on-call person.
- Stripe retries webhooks for up to three days; failed events are listed on the admin dashboard.
- Status communication: a pinned post in the community during any outage affecting a cohort.

## 5. Confidentiality

- Members' business data stays in their workspace; support never asks for it wholesale.
- Session recordings private to members; cut anything sensitive before posting.
- Licensor materials marked confidential under the licence.

## 6. Privacy

- Privacy notice, consent-gated analytics, retention schedule, rights-request process (`retention.md`),
  processor register (`subprocessors.md`), DPA template (`dpa-template.md`).

## 7. Path to an audit

1. Gap assessment against this page (half a day).
2. Put the evidence collection on a calendar (access reviews, restore tests, vendor reviews).
3. Consider a compliance-automation tool to collect evidence.
4. SOC 2 Type I (a point in time), then Type II (a period, usually 3–12 months).
