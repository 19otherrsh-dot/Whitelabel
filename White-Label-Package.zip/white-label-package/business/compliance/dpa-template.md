# Data Processing Agreement (template)

> **Draft for legal review.** For use where one party processes personal data on behalf of the
> other: the licensor hosting a licensee's back end or handling member data in support (licensor =
> processor), or a licensee offering members a hosted runtime or done-for-you service that touches
> their business data (licensee = processor). Written to meet GDPR / UK GDPR Article 28. Most
> service providers (Stripe, Supabase, Resend, community and meeting tools) offer their own DPA;
> sign theirs rather than this one.

**Controller:** [name, address] · **Processor:** [name, address]
**Main agreement:** [title and date] · **Effective date:** [date]

## 1. Subject, duration, nature and purpose

| Item | Details |
|---|---|
| Subject matter | [e.g. hosting and operating the checkout, member area and lead capture application] |
| Duration | The term of the main agreement, plus the return/deletion period in clause 9 |
| Nature of processing | [storage, hosting, backup, retrieval for support, deletion] |
| Purpose | Providing the services in the main agreement, and nothing else |
| Categories of data subjects | [members; leads (audit, contact, waitlist, training sign-ups); controller's staff using the admin area] |
| Categories of personal data | [name, email, company, purchase records (no full card data), support messages, audit answers, salted IP hashes, attendance] |
| Special category data | None expected. The controller won't send any |

## 2. Processor obligations

The processor will:

1. Process personal data only on the controller's documented instructions (this DPA and the main
   agreement are the instructions), including on international transfers, unless law requires
   otherwise, in which case it tells the controller first unless the law forbids that.
2. Ensure people authorised to process the data are bound by confidentiality.
3. Implement the security measures in Annex 2, and keep them appropriate to the risk.
4. Engage sub-processors only under clause 3.
5. Assist the controller, taking into account the nature of processing, in responding to data
   subjects' requests, and with security, breach notification, impact assessments and prior
   consultation.
6. Delete or return all personal data at the end of the services under clause 9.
7. Make available the information needed to show compliance, and allow and contribute to audits
   under clause 8.
8. Tell the controller immediately if an instruction, in its opinion, infringes data protection law.

## 3. Sub-processors

The controller gives general authorisation to the sub-processors in Annex 1. The processor will give
[30] days' notice of a new or replacement sub-processor; the controller may object on reasonable
data-protection grounds, and if the parties can't resolve it, terminate the affected service. The
processor imposes the same data protection obligations on each sub-processor and remains liable for
them.

## 4. International transfers

Transfers outside the UK/EEA only to countries with an adequacy decision, or under the EU Standard
Contractual Clauses / UK International Data Transfer Addendum (incorporated by reference, with the
module and options in Annex 3), with a transfer risk assessment where required.

## 5. Personal data breaches

The processor notifies the controller without undue delay, and in any case within [48] hours, after
becoming aware of a breach affecting the controller's data, with what is known (nature, categories
and approximate numbers, likely consequences, measures taken), and updates as more is known.

## 6. Data subject requests

The processor passes any request it receives to the controller within [5] business days and doesn't
respond itself unless instructed. The application's admin area lets the controller find, export and
delete a person's records; the processor assists where it can't.

## 7. Confidentiality

As in the main agreement.

## 8. Audits

Once a year, on [30] days' notice, the controller (or an independent auditor bound by confidentiality)
may audit the processor's compliance, during business hours and without disrupting operations. The
processor may first offer current third-party certifications or audit reports, or a completed security
questionnaire, which the controller will accept if they answer its questions.

## 9. End of services

Within [30] days after the services end, the processor deletes (or, at the controller's choice,
returns in a common format and then deletes) all personal data, including copies, unless law requires
storage, and confirms in writing. Backups expire on their normal cycle (at most [35] days).

## 10. Liability and precedence

Liability is as in the main agreement. If this DPA conflicts with the main agreement on data
protection, this DPA wins.

---

### Annex 1 · Sub-processors

See `subprocessors.md` (fill in the processor's actual providers, locations and transfer mechanisms).

### Annex 2 · Technical and organisational measures

See `security-practices.md`, sections 2–6, as they apply to the hosted application.

### Annex 3 · Transfer mechanism

[EU SCCs Module 2 (controller to processor) / Module 3 (processor to processor); UK IDTA or Addendum;
governing law and forum of the SCCs; competent supervisory authority.]

Signed for the controller: ____________________ Signed for the processor: ____________________
