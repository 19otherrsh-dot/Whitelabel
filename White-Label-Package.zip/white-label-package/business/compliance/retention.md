# Retention schedule (template)

Keep data only as long as needed for the purpose, then delete it. The periods match the privacy page
template; adjust both together, and check local tax and limitation periods with an adviser.

| Data | Where it lives | Keep for | Then | How |
|---|---|---|---|---|
| Purchases, invoices, refunds | Stripe; back end `enrollments` | As long as tax law requires (often 6–7 years) | Delete or anonymise the member link | Annual review |
| Member account (name, email) | Back end `members`, auth | While enrolled + library period, then [12] months | Delete account; keep purchase record as above | Admin → Members; database delete |
| Support requests | Back end `support_requests`; support tool | [24] months after closing | Delete | Scheduled query (below) |
| Refund requests and evidence | Back end `guarantee_claims` | [6] years (dispute and limitation periods) | Delete | Annual review |
| Attendance | Back end `attendance` | Until the refund window closes + [24] months | Delete | Scheduled query |
| Leads: audit, contact, waitlist, training | Back end `leads`; CRM | [24] months after last contact | Delete | Scheduled query |
| Salted IP hashes | Back end `leads.ip_hash` | [12] months | Set to null | Scheduled query |
| Marketing list | Email tool | Until unsubscribe; remove inactive after [24] months without opens or clicks | Delete or suppress | Email tool settings |
| Session recordings | Video host / community | Library period ([12] months) | Delete | Calendar reminder |
| Admin log | Back end `admin_log` | [24] months | Delete | Scheduled query |
| Stripe event log | Back end `stripe_events` | [90] days | Delete | Scheduled query |
| Backups | Database provider | Provider's cycle (≤ 35 days) | Expire | Provider settings |

## Scheduled clean-up (back end)

Run monthly (Supabase scheduled function, `pg_cron`, or by hand in the SQL editor):

```sql
update leads set ip_hash = null where ip_hash is not null and created_at < now() - interval '12 months';
delete from leads where created_at < now() - interval '24 months';
delete from support_requests where status = 'closed' and updated_at < now() - interval '24 months';
delete from stripe_events where received_at < now() - interval '90 days';
delete from admin_log where created_at < now() - interval '24 months';
```

## Members' own workspaces

Members' workspaces are on their computers and are theirs. The kit's own setting
`workspace.json → compliance.dataRetentionDays` (default 365) guides how long skills keep personal
data they collect for jobs (for example prospect research). Members decide; the kit reminds them.

## Requests to delete

Delete across every row above within one month of a valid request, except records the law requires us
to keep (tell the person which and why).
