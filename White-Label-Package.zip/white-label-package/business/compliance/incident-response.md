# Incident response

For the licensee's systems (site, back end, community, email) and for helping members when
something goes wrong in their workspace. Keep it printed or offline; you'll need it when things are
down.

## Severity

| Level | Examples | Response |
|---|---|---|
| **SEV1** | Personal data exposed; payments wrong or charged twice at scale; admin account compromised; a member's agent sent or paid something wrong at scale | Start within 1 hour, any day |
| **SEV2** | Checkout or member area down during enrollment or a cohort; kit release broken for everyone; webhooks failing | Start within 4 business hours |
| **SEV3** | A single member blocked; a broken page; one email not sending | Normal support |

## The first hour (SEV1/SEV2)

1. **Name an incident lead.** One person decides; others help.
2. **Contain.**
   - Compromised account: revoke sessions, rotate passwords and keys (Supabase service key, Stripe
     key, webhook secret, Resend key), check `admin_log`.
   - Data exposure: close the route (take the page down, revoke the signed link, fix the policy).
   - Payments: pause checkout (`/admin/cohorts` → untick Selling) and investigate in Stripe.
   - A member's workspace: tell them to run `bin/wf autopilot pause` immediately (macro S7).
3. **Preserve evidence.** Export logs (host, database, Stripe events, `admin_log`) before they roll over.
4. **Start the log:** time, what's known, what was done, by whom.

## Within 72 hours (personal data breaches)

- Decide whether it's a notifiable breach. Under GDPR / UK GDPR, notify the supervisory authority
  within 72 hours of becoming aware, unless it's unlikely to result in a risk to people; notify the
  affected people without undue delay if the risk is high. US state laws have their own rules.
- If a processor caused it, they notify you (DPA clause 5); you remain responsible for notifying.
- If the licensor is the processor, it notifies the licensee within the DPA's time.
- Get advice from your lawyer before sending notices.

## Communicating

- Members: plain words, what happened, what it means for them, what to do, what we're doing. Post in
  the community and email the affected people. Don't speculate; update at set times.
- No blame, no minimising.

## Afterwards (within 10 business days)

A short post-incident review: timeline, root cause, what worked, what didn't, actions with owners
and dates. Kit or back-end defects go to the licensor with steps to reproduce. Update this page.

## Contacts (fill in)

| Role | Name | How to reach |
|---|---|---|
| Incident lead (primary / backup) | | |
| Licensor support (per your tier) | | |
| Lawyer | | |
| Hosting / database provider support | | |
| Payment provider support | | |
| Supervisory authority | | |
