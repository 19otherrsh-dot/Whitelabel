# Compliance: what applies, and where the package handles it

For the licensor and each licensee. **Not legal advice**: it maps the main obligations to the
parts of the package that help meet them, so a lawyer can review quickly. Laws checked as of
October 2026; re-check before each launch and when selling into a new country.

## Who is who

| Party | Role for personal data | Role under the EU AI Act |
|---|---|---|
| **Licensor** | Separate controller of its own business data; processor only if it hosts a licensee's back end or handles member data in support | Supplier of the programme; not the provider of the AI model (that's Anthropic) |
| **Licensee** | Controller of its leads', members' and website visitors' data | Runs a website with an AI-free audit; teaches members to deploy AI |
| **Member** | Controller of their own business's data, which stays in their workspace and the tools they connect | **Deployer** of the AI system in their own business (the workspace running on Claude) |
| **Anthropic** | Provider of Claude / Claude Code to the member under the member's own account | Provider of the general-purpose AI model and of Claude Code |

The workspace runs on the member's computer with the member's own Claude account; neither the
licensor nor the licensee receives the business data a member puts in it.

## Obligations map

| Area | What it requires (summary) | Where the package handles it | Who acts |
|---|---|---|---|
| **EU AI Act Art. 50** (applies from 2 Aug 2026; fines up to €15M or 3% of worldwide turnover) | AI systems that interact with people must say so unless obvious; deployers must disclose deepfakes and AI-generated text published on matters of public interest unless a person reviewed it editorially and takes responsibility; providers of generative systems must mark synthetic output in a machine-readable way (systems already on the market before 2 Aug 2026 have until 2 Dec 2026). Applies to non-EU businesses whose AI output is used in the EU | The kit's AI chat and voice skills disclose that they're AI; AI-generated media is labelled; every outbound item is human-approved (editorial review) by default; `compliance-check` skill and `compliance-officer` agent; site page `ai-disclosure.html` | Members (as deployers) keep disclosure on; licensee keeps `ai-disclosure.html` accurate |
| **Outbound email: US CAN-SPAM** | Accurate sender and subject, a physical postal address, a working opt-out honoured within 10 business days | `workspace.json → compliance.outbound` (sender, address, opt-out line), suppression list checked at queue and dispatch time | Members fill in their details |
| **UK PECR / UK GDPR, EU ePrivacy / GDPR** | B2B email to corporate addresses generally allowed with an opt-out (UK); consent needed for individuals/sole traders in many cases; EU rules vary by country; legitimate-interest assessment and privacy notice for prospect data | Outreach starter and skills apply jurisdiction rules from `compliance.outbound.jurisdictions`; data minimisation in research skills; suppression list | Members; licensee teaches it in Session 4 and the outreach starter |
| **Canada CASL** | Express or implied consent for commercial electronic messages, identification, unsubscribe | As above (`CA` in jurisdictions) | Members |
| **US TCPA / telemarketing** (if voice or SMS is used) | Consent rules for automated calls and texts; calling hours; do-not-call | Voice/messaging adapters are outbound-off by default and approval-gated (see the hosted runtime docs) | Members |
| **Platform terms** (LinkedIn, etc.) | Automation limits and bans on scraping/automated actions | Skills draft for a person to send; no automated LinkedIn actions | Members |
| **Consumer protection: claims and earnings** (US FTC Act §5 and FTC guidance; UK CMA / DMCC Act 2024; EU UCPD) | No unsubstantiated earnings, savings or results claims; testimonials must be genuine and typical-results context given; no fake urgency or reviews | Site: audit gives an estimate with a published method and disclaimer; proof only from permissioned entries; results page counts only real data; countdown hides when past. See `claims-and-disclaimers.md` | Licensee |
| **Consumer contract rules: EU/UK 14-day withdrawal** | Distance-sale consumers can cancel services within 14 days; if they ask for the service to start earlier they may owe for what was supplied | `refunds.html` and `terms.html` wording; checkout links to both | Licensee (lawyer review) |
| **Data protection: website and member area** | Privacy notice, lawful basis, cookie consent, rights requests, processor contracts, transfers, retention | `privacy.html`, `cookies.html`, consent-gated analytics, back end hashes IPs and stores only what forms send; `dpa-template.md`, `subprocessors.md`, `retention.md` | Licensee |
| **Security** | Appropriate technical and organisational measures | Back end: RLS on every table, server-only keys, signed short-lived downloads, rate limits, security headers; kit: approval guard, secrets in OS keychain, local-only console with token. See `security-practices.md` | Licensor (product), licensee (operations) |
| **Accessibility** (EU Accessibility Act from 28 Jun 2025 for in-scope e-commerce; ADA risk in the US) | Accessible checkout and service pages | Site and member area built to WCAG 2.2 AA patterns (labels, contrast, keyboard, skip links); run an audit before launch | Licensee |

## Before each launch (licensee)

- [ ] Legal pages adapted and reviewed by a lawyer; `company` details set in `assets/config.js`.
- [ ] Privacy notice lists the actual processors (`subprocessors.md` filled in).
- [ ] Processor agreements in place with each processor (most offer standard DPAs online).
- [ ] Claims reviewed against `claims-and-disclaimers.md`; every testimonial has written permission.
- [ ] Cookie consent tested (analytics loads only after acceptance where required).
- [ ] `ai-disclosure.html` matches what the business actually does with AI.
- [ ] Session recordings: notice in invites and at the start of each session.
