# Order Form

Under the White-Label Programme Licence Agreement between [Licensor] and [Licensee].
**Draft for legal review.**

| Term | Selection |
|---|---|
| Order Form date | [date] |
| Initial Term | [12 / 24 / 36] months from [date] |
| Territory | [countries or regions] |
| Field | [e.g. small businesses with 1–50 staff, all sectors / agencies only / a named vertical] |
| Exclusivity | [None] / [Exclusive in the Field in the Territory, subject to minimum annual Seats of [n]] |
| Offers allowed | [Live cohort] [Self-paced course] [Done-for-you build services using the Materials] |
| Seats | [Unlimited, royalty per Seat] / [Up to [n] per year included] |
| Support tier | [Standard / Priority / Partner] (Schedule 2) |
| Certification places included per year | [n] (then [price] per person) |
| "Powered by" credit | [Not allowed / Allowed per Schedule 3] |
| Licensor hosting of the Back End | [No] / [Yes, at [price] per month; Schedule 5 applies] |

## Fees

| Fee | Amount | When |
|---|---|---|
| Onboarding fee | [amount] | On signature |
| Annual licence fee | [amount] | In advance, each year |
| Royalty per paid Seat (live cohort) | [amount or % of the Seat price] | Quarterly in arrears, with the report |
| Royalty per self-paced enrolment | [amount or %] | Quarterly in arrears |
| Refunded Seats | Royalty credited if refunded within the published refund windows | Next report |
| Extra certification | [amount] per person | On booking |
| Optional services (co-teaching, custom skills, translation) | [day rate] | As ordered |

Currency: [currency]. Taxes extra.

Signed for the Licensor: ____________________ Signed for the Licensee: ____________________
