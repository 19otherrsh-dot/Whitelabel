# Rights checklist: can every part of the package be resold?

Before the first licence is signed, confirm the licensor owns, or may sublicense, everything in the
package. Each line says what it is, where it came from, its status, and what to do. **Status is
our understanding from building the package; a lawyer should confirm the items marked ⚠.**

| # | Component | Origin | Status | Action |
|---|---|---|---|---|
| 1 | Website pages, copy and design (index, how it works, pricing, FAQ, free training, map page wrapper, audit) | Your company's own pages, white-labelled; new pages written for this package | ✔ Yours, if your company owns the original pages and their copy (you've told us it does) | Confirm the original site wasn't built by a contractor without an IP assignment. If it was, get the assignment |
| 2 | Interactive map: structure, 137 job names, departments, layout code | From your company's original map, white-labelled and extended | ⚠ The original footer said the department library was licensed from a third party | Find that licence. Either confirm it allows sublicensing to licensees, or rely on item 3 (rewritten content) and remove anything still derived from the third party's text |
| 3 | The 78 role skills, 12 core skills, agents, evals | Written new for this package (you chose "write everything new") | ✔ Original work of the licensor | Keep the build history as evidence of independent creation |
| 4 | Job names and department names on the map | Generic descriptive names (e.g. "Invoice Generation") | ✔ Descriptive terms generally aren't protectable | None |
| 5 | Command-centre dashboards: layout and code | From your company's original dashboards, white-labelled | ✔ If your company owns them (as item 1) | As item 1 |
| 6 | Dashboard sample data | Generated, fictional; clearly labelled as demo | ✔ | Keep the "demo data" labelling |
| 7 | Third-party logos on dashboard cards (`assets/img/logo-*.png`: HeyReach, HubSpot, Instantly, LinkedIn, Meta, Xero) | Vendors' trademarks | ⚠ Nominative use (to show which tool a panel reads) is usually fine; logos are stricter than names | Check each vendor's brand guidelines, or replace logos with plain text names. Never suggest partnership or endorsement |
| 8 | Perk logos (`assets/img/perk-*.png`) and the perks section | Partner deals belonged to the original company | ✖ Not transferable; section is off by default | Delete the `perk-*` images from licensee builds unless the licensee has its own perks programme |
| 9 | Fonts: Marcellus, Plus Jakarta Sans, Instrument Serif | Google Fonts / Fontsource | ✔ SIL Open Font License 1.1 allows bundling and resale with the licence file | Keep `OFL.txt` with the fonts (it's included) |
| 10 | Workspace kit code (`wf` CLI, hooks, console, installers) | Written new for this package | ✔ Original work; no third-party code bundled | Keep `THIRD-PARTY-NOTICES.md` current |
| 11 | Five example businesses | Written new; fictional people, companies and numbers; addresses on reserved/fictional values | ✔ | Keep the "fictional example" notices |
| 12 | Back end (Next.js app) | Written new; depends on open-source packages (mostly MIT and Apache-2.0; one LGPL-3.0 image library pulled in optionally by Next.js; one CC-BY-4.0 data package) | ✔ Licences allow commercial use | Ship `npm ls` output or a licence report with releases; keep attribution files in `node_modules` untouched |
| 13 | Delivery and sales materials (curriculum, slides, playbooks, emails) | Written new for this package | ✔ | None |
| 14 | Competitor report and gap audit | Internal research documents | Internal only; not part of the licensee package | Don't ship to licensees |
| 15 | Claude, Claude Code, MCP servers, Stripe, Supabase and other services | Third-party services, not included | Each member/licensee accepts the provider's own terms | Don't describe the programme as affiliated with or endorsed by any of them |
| 16 | Product names used in text ("HubSpot", "Claude Code", etc.) | Vendors' trademarks, used to describe compatibility | ✔ Nominative use | Keep "works with", never "partner of" unless true |
| 17 | Original founder's name, reviews, logos, photos, video | The original brand | ✖ Removed from the package | Re-check every release with the leak scan in `build/release.mjs` |
| 18 | Any media a licensee adds (photos, videos, testimonials) | The licensee | The licensee's responsibility | Written permission for every testimonial and photo |

## Before signing the first licensee

- [ ] Items 1, 2 and 5: written confirmation (or assignment) that your company owns the original
      site, map and dashboards, including work by contractors.
- [ ] Item 2: the third-party library licence found and reviewed, or the rewrite confirmed complete.
- [ ] Item 7: logos checked against brand guidelines, or replaced.
- [ ] Item 8: perk images removed from the licensee build.
- [ ] A trademark search on the programme's name(s) in each licensee's Territory (the licensee's
      brand is theirs to clear).
- [ ] The Member Workspace Licence (`product/kit/LICENSE.md`) reviewed with the master licence.
