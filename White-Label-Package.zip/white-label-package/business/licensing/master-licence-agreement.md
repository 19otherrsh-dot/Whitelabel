# White-Label Programme Licence Agreement

> **Draft for legal review.** This is a working draft prepared to make the commercial structure
> concrete. It is not legal advice. Have it reviewed and adapted by a lawyer qualified in the
> governing law you choose before you send it to anyone. Square brackets mark choices to make.

**Between**

**[Licensor legal name]**, a [company type] registered in [jurisdiction] under number [number],
whose registered office is at [address] (the **Licensor**); and

**[Licensee legal name]**, a [company type] registered in [jurisdiction] under number [number],
whose registered office is at [address] (the **Licensee**),

each a **party**. This Agreement is made on the date of the last signature below (the
**Effective Date**) and consists of these terms and the Schedules, including each Order Form signed
under it.

---

## 1. Definitions

**Programme** means the AI-workforce programme described in Schedule 1, made up of the Materials.

**Materials** means, in each version the Licensor makes available: (a) the **Website** (the
white-label marketing site, interactive map, command-centre dashboards and free audit); (b) the
**Kit** (the installable workspace, including its skills, agents, hooks, command-line tool,
console, map, library, example businesses and documentation); (c) the **Back End** (the checkout,
member area, lead capture and administration application and its no-code alternative); (d) the
**Delivery Materials** (curriculum, run sheets, slides, rubric, instructor playbook, certification,
support procedures, email sequences and the self-paced course); and (e) the **Sales Materials**
(launch kit, sales collateral and templates); together with Updates.

**Updates** means new versions, fixes and additions to the Materials that the Licensor releases
generally to its licensees during the Term.

**Licensee Brand** means the Licensee's own names, logos, domains and get-up applied to the Materials.

**Licensor Marks** means the Licensor's names and logos. The Materials as delivered carry no
Licensor Marks.

**Member** means a business or person that buys a seat, course or other offer based on the
Programme from the Licensee.

**Member Workspace Licence** means the end-user licence for the Kit in `LICENSE.md` (as updated
from time to time), under which Members use the Kit.

**Territory**, **Field**, **Seats**, **Fees** and **Initial Term** have the meanings in the Order Form.

**Certified Instructor** means a person holding a current certification under the Licensor's
certification programme at the level needed for the role they perform.

**Third-Party Services** means services the Programme works with but the Licensor doesn't provide,
such as Anthropic's Claude and Claude Code, payment, email, hosting, community and meeting
services, and the tools Members connect.

## 2. Grant of licence

2.1 **Licence.** Subject to this Agreement and payment of the Fees, the Licensor grants the Licensee
a [non-exclusive / exclusive within the Field in the Territory], non-transferable licence during the
Term to:
  (a) reproduce, adapt, translate and rebrand the Materials with the Licensee Brand;
  (b) market and sell the Programme to Members in the Territory, under the Licensee Brand, in the
      Field, live and self-paced;
  (c) deliver the Programme to Members using Certified Instructors; and
  (d) distribute the Kit to Members under the Member Workspace Licence, which the Licensee may put
      in its own name provided its terms are no less protective of the Licensor than those supplied.

2.2 **Seats.** Each paid Member enrolment counts as one Seat. The Licensee may deliver the Programme
to as many Members as the Order Form allows, and reports Seats under clause 7.

2.3 **Restrictions.** Except as this Agreement allows, the Licensee must not: (a) sublicense the
Materials other than to Members under the Member Workspace Licence; (b) license, resell or give the
Materials, or any substantial part of them, to another business to run its own programme; (c) offer
the Programme outside the Territory or Field; (d) remove the licence notices and third-party notices
inside the Kit; (e) use the Materials to build a product that competes with the Programme for
licensees; or (f) use the Materials in breach of law or the terms of any Third-Party Service.

2.4 **Exclusivity** (only if chosen in the Order Form). The Licensor will not grant another licence
for the Field in the Territory while the Licensee meets the minimum annual Seats in the Order Form.
If it doesn't for [two] consecutive [quarters], the Licensor may, on [30] days' notice, make the
licence non-exclusive; that is the Licensor's only remedy for the shortfall.

2.5 **Reservation.** All rights not expressly granted are reserved. The licence is a licence, not a
sale.

## 3. Delivery and Updates

3.1 The Licensor will deliver the current Materials within [5] business days of the Effective Date
as downloadable files, and Updates as they are released, with release notes.

3.2 The Licensor will keep the Kit working with the then-current generally available version of
Claude Code and will publish compatibility notes with each release. Third-Party Services change
without notice; the Licensor will use reasonable efforts to release fixes for breaking changes
within the times in Schedule 2.

3.3 The Licensee decides when to adopt an Update for its own Website and Back End. Members receive
Kit Updates through the Licensee's member area for the library period the Licensee sells.

## 4. Brand, quality and conduct

4.1 **Licensee Brand.** The Licensee may sell the Programme only under the Licensee Brand. The
Licensee owns the Licensee Brand and grants the Licensor a limited licence to use it to perform this
Agreement.

4.2 **No Licensor branding unless agreed.** The Licensee must not use Licensor Marks unless the Order
Form allows a "powered by" credit, in which case Schedule 3 applies.

4.3 **Quality standards.** The Licensee will deliver the Programme to the standards in Schedule 3,
including: live sessions taught or led by Certified Instructors; the published build guarantee
honoured as written; same-day recordings; the support model and response targets; and the safety
rules (nothing sent in class, never handling Members' keys).

4.4 **Honest marketing.** The Licensee must not make claims about results, earnings, time saved or
headcount that it cannot substantiate, must not publish testimonials or results without the
Member's permission, must not fabricate proof, and must follow the advertising and consumer
protection law of each country it sells into. The Licensor may ask the Licensee to correct marketing
that breaches this clause, and the Licensee will do so within [5] business days.

4.5 **Legal pages.** The Licensee is responsible for its own terms of sale, refund terms, privacy
notice, cookie notice and AI disclosures, adapted from the templates in the Materials and reviewed
by its own lawyer.

## 5. Certification and support

5.1 Before teaching, each instructor and teaching assistant must be certified at the level their
role requires. The Licensor will run certification for up to [number] people a year included in the
Fees, then at the rate in the Order Form.

5.2 The Licensor provides support to the Licensee (not to Members) at the tier in the Order Form, as
described in Schedule 2. The Licensee provides all support to its Members.

## 6. Fees and payment

6.1 The Licensee pays the Fees in the Order Form: typically a one-off onboarding fee, an annual
licence fee, and a per-Seat royalty (or a revenue share), plus any extra certification or services.

6.2 Invoices are payable within [30] days. Fees exclude VAT and similar taxes, which the Licensee
pays in addition. Late amounts bear interest at [rate]. The Licensor may suspend delivery of Updates
(not the licence) if undisputed amounts are more than [30] days late, after [10] days' notice.

6.3 The annual licence fee may change at each renewal on [90] days' notice before the renewal date.

## 7. Reporting and audit

7.1 Within [15] days after each [quarter], the Licensee sends a report in the form of Schedule 4:
Seats sold and refunded, revenue by offer, cohorts run, Certified Instructors, demo-day pass rates
and support volume. No Member personal data is needed or should be included. The Back End produces
this report (admin → Report); if the Licensee enables the reporting token, the Licensor may read the
same report directly, and that satisfies this clause for the items it contains.

7.2 Once a year, on [30] days' notice, the Licensor (or an independent accountant bound by
confidentiality) may audit the Licensee's records relevant to Fees. If an audit finds an
underpayment of more than [5]%, the Licensee pays the reasonable cost of the audit as well as the
shortfall.

## 8. Intellectual property

8.1 The Licensor (and its licensors) own the Materials and all Updates, including adaptations made by
the Licensor.

8.2 The Licensee owns: the Licensee Brand; its own content added to the Materials (its legal pages,
instructor bios, case studies, photos and copy it writes); and its Member relationships and data.
Adaptations of the Materials made by the Licensee are licensed back to the Licensor on a
non-exclusive, royalty-free, perpetual basis, excluding the Licensee Brand and the Licensee's own
content. [Alternative: the Licensee owns its adaptations but may use them only with the Materials.]

8.3 **Members' work.** As between the parties and Members, what a Member creates about their own
business in their workspace belongs to the Member, as the Member Workspace Licence says.

8.4 **Feedback.** The Licensor may use suggestions from the Licensee without obligation.

## 9. Data protection

9.1 **Roles.** Each party is a separate controller of the personal data it processes for its own
purposes. The Licensee is the controller of its Members' and leads' data. The Licensor receives no
Member personal data under this Agreement and the Licensee must not send any to it, except as
needed to resolve a specific support issue, in which case the data processing terms in Schedule 5
apply.

9.2 **The Kit runs locally.** The Kit runs on each Member's own computer with the Member's own
Claude account. Neither party receives the business data a Member puts in their workspace unless the
Member chooses to send it. Nothing in the Materials sends telemetry to the Licensor or the Licensee;
any anonymous usage summary is created only when a Member runs it, and is shared only if the Member
chooses to.

9.3 If the Licensor hosts any part of the Back End for the Licensee (if chosen in the Order Form),
the Licensor is the Licensee's processor and Schedule 5 applies.

## 10. Third-Party Services

10.1 The Programme depends on Third-Party Services, including Anthropic's Claude and Claude Code.
Members must have their own accounts with those services and accept their terms. The Licensor gives
no warranty for Third-Party Services and is not responsible for their availability, pricing,
features or changes.

10.2 The Licensee will not represent to Members that it or the Licensor is affiliated with,
endorsed by or a partner of any Third-Party Service provider unless that is true and permitted.

## 11. Confidentiality

Each party keeps the other's confidential information confidential, uses it only for this Agreement
and protects it with reasonable care, for the Term and [3] years after. The Materials (other than
what is published on the Licensee's public website) are the Licensor's confidential information.
This doesn't apply to information that is public through no fault of the recipient, already known
to it, independently developed, or that must be disclosed by law (with notice where allowed).

## 12. Warranties

12.1 The Licensor warrants that: (a) it has the right to grant the licence; (b) to its knowledge the
Materials as delivered don't infringe third-party intellectual property rights in [the Territory];
and (c) the Kit will perform materially as described in its documentation for [90] days after each
release (the Licensee's remedy is a fix, or if that isn't possible, a pro-rata refund of the annual
licence fee for the affected period).

12.2 The Licensee warrants that it will comply with law in marketing and delivering the Programme,
including consumer protection, advertising, data protection, electronic marketing and AI
transparency law.

12.3 Otherwise the Materials are provided "as is". The Licensor doesn't warrant any business result,
revenue, time saving or other outcome for the Licensee or Members, or that AI outputs will be
accurate. AI outputs must be reviewed by a person, as the Programme teaches.

## 13. Indemnities

13.1 The Licensor will defend the Licensee against third-party claims that the Materials as
delivered infringe intellectual property rights, and pay resulting damages and costs finally
awarded or agreed in settlement, provided the Licensee notifies promptly, lets the Licensor control
the defence and cooperates. This doesn't cover claims caused by the Licensee's changes, the Licensee
Brand or content, Third-Party Services, or use outside this Agreement. If such a claim is made, the
Licensor may modify the Materials, obtain a licence, or end the licence for the affected part with
a pro-rata refund. This is the Licensee's only remedy for infringement claims.

13.2 The Licensee will defend the Licensor against third-party claims arising from the Licensee's
marketing, sales, delivery of the Programme, dealings with Members (including refunds and
guarantee decisions), the Licensee Brand and content, or breach of law, on the same conditions.

## 14. Liability

14.1 Nothing limits liability for death or personal injury caused by negligence, fraud, or anything
else that cannot be limited by law, or the indemnities in clause 13 [subject to a cap of [amount]].

14.2 Neither party is liable for loss of profit, revenue, business, goodwill or data, or for indirect
or consequential loss.

14.3 Each party's total liability in each contract year is limited to the Fees paid and payable in
the [12] months before the event giving rise to the claim [or [amount], if greater].

## 15. Term and termination

15.1 This Agreement starts on the Effective Date and lasts for the Initial Term, then renews for
successive [12]-month periods unless either party gives [90] days' notice before the end of the
current term.

15.2 Either party may terminate by notice if the other materially breaches and doesn't remedy it
within [30] days of notice, or becomes insolvent.

15.3 The Licensor may terminate on [10] days' notice if the Licensee breaches clause 2.3 or 4.4 in a
way that harms the Licensor's reputation and doesn't stop on notice.

15.4 **On termination or expiry:** (a) the licence ends, except that the Licensee may complete
cohorts already sold that start within [60] days, and must continue to honour its promises to
existing Members (support periods, library access it sold, refunds) for as long as it promised them,
using the Materials only for that purpose; (b) Members keep their Member Workspace Licence for the
Kit versions they already received; (c) the Licensee stops selling the Programme and removes the
Materials from its public website within [30] days; (d) each party returns or deletes the other's
confidential information; and (e) accrued Fees remain payable.

15.5 Clauses 8, 9, 11, 12.3, 13, 14, 15.4 and 16 survive.

## 16. General

16.1 **Assignment.** Neither party may assign this Agreement without the other's consent (not to be
unreasonably withheld), except the Licensor to a buyer of the Programme business.

16.2 **Force majeure.** Neither party is liable for delay caused by events beyond its reasonable
control, including outages of Third-Party Services.

16.3 **Entire agreement.** This Agreement is the whole agreement on its subject and replaces earlier
discussions. Each party confirms it hasn't relied on any statement not set out here.

16.4 **Changes** must be in writing and signed by both parties.

16.5 **Notices** go to the addresses above, or by email to [addresses], and take effect on receipt.

16.6 **No partnership.** The parties are independent contractors.

16.7 **Governing law and disputes.** This Agreement is governed by the law of [governing law]. The
courts of [jurisdiction] have exclusive jurisdiction. [Optional: before going to court, the parties
will try in good faith to resolve a dispute through senior executives for [30] days, then mediation.]

---

## Schedule 1 · The Programme and Order Form

The Order Form (`order-form.md`) sets: Territory; Field; exclusivity; Initial Term; Seats; Fees;
support tier; certification places; any "powered by" credit; any hosting by the Licensor.

**The Programme, as delivered:** a six-session live cohort (two weeks) in which each Member builds one
AI department on their own business, with a build guarantee; an optional self-paced version; the Kit
(90 skills: 78 role skills covering 137 jobs plus 12 core skills, the approval system, run record,
console with 20 tools, the Workforce Map, the department library and five example businesses); the
public Website with free audit; the Back End; and the Delivery and Sales Materials.

## Schedule 2 · Licensor support to the Licensee

| Tier | Channels | First response | Fix target for a Kit defect that blocks Members | Included |
|---|---|---|---|---|
| **Standard** | Email / ticket | 2 business days | Workaround or fix in the next release | Release notes, quarterly licensee call |
| **Priority** | Ticket + shared chat channel | 1 business day (4 business hours for blocking issues) | 5 business days | Plus: launch review of the Licensee's site and first cohort plan |
| **Partner** | Named contact, chat, calls | 4 business hours | 3 business days | Plus: co-teaching of the first cohort, demo-day marking calibration, roadmap input |

A "blocking issue" stops Members installing or running the Kit, or stops checkout, in a way that
affects a cohort in progress.

## Schedule 3 · Quality standards

1. Live sessions led by a Certified Lead Instructor, with teaching assistants at about one per 12–15
   Members.
2. The six checkpoints and the demo-day rubric used as published; guarantee decisions made from the
   rubric with a second reviewer for declines.
3. Recordings posted the same day; support response targets published and met at least 90% of the
   time.
4. The safety rules: nothing sent to real customers in class; Members' keys and passwords never
   requested or handled.
5. Marketing reviewed against clause 4.4; results and testimonials only with written permission.
6. [If a "powered by" credit is allowed: wording "[Programme] powered by [Licensor]", placement and
   size rules.]

## Schedule 4 · Quarterly report

| Item | Value |
|---|---|
| Cohorts run (dates) | |
| Seats sold (founding / VIP / self-paced) | |
| Seats refunded (cooling-off / guarantee / other) | |
| Gross revenue by offer | |
| Royalty or revenue share due | |
| Certified Instructors and TAs (names, levels) | |
| Demo-day results (pass / not yet / fail / blocked) | |
| Support tickets (count, top five tags) | |
| Kit version in use | |
| Issues for the Licensor | |

## Schedule 5 · Data processing terms

Applies only where the Licensor processes personal data for the Licensee (support involving Member
data, or Licensor-hosted Back End). Use the template in `../compliance/dpa-template.md`, with the
Licensor as processor and the Licensee as controller.

---

Signed for the **Licensor** by: ______________________ Name/role: ______________ Date: ________

Signed for the **Licensee** by: ______________________ Name/role: ______________ Date: ________
