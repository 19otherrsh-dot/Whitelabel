# Pricing the licence: models, tiers and the maths

How to price the white-label licence to licensees, and how a licensee checks the deal works for
them. Every number below in *italics* is an **input for you to set**, not market data or a
recommendation. Run the worked example with your own figures.

## Three models

| Model | How it works | Suits | Watch out for |
|---|---|---|---|
| **Annual licence + per-Seat royalty** (default) | Onboarding fee, annual fee, fixed amount per paid Seat | Most licensees; predictable for both sides | Royalty must leave the licensee enough margin on discounted seats |
| **Revenue share** | Onboarding fee, lower annual fee, % of programme revenue | Licensees testing the market; partners who discount or bundle | Needs trustworthy reporting (the back end's admin dashboard and Stripe exports make it auditable) |
| **Flat enterprise licence** | One annual fee, unlimited Seats in a Field and Territory, often exclusive | Large training companies, franchisors, networks | Set minimum Seats for exclusivity, and price the support load |

## Tiers

| | Starter | Growth | Partner |
|---|---|---|---|
| Who | A solo consultant or small agency running 1–2 cohorts a year | A training business running a cohort most months | A network or franchisor, exclusive in a Field or Territory |
| Offers | Live cohort | Live cohort + self-paced | All, including done-for-you builds |
| Support (Schedule 2) | Standard | Priority | Partner |
| Certification places / year | *2* | *6* | *15* |
| Exclusivity | No | Optional, in a narrow Field | Yes, with minimum Seats |
| Onboarding fee | *A* | *B* | *C* |
| Annual fee | *D* | *E* | *F* |
| Royalty per Seat | *G* | *H* | Included up to the minimum, then *I* |

## The licensee's maths (put this in front of every prospect)

Per cohort:

```
Revenue        = founding seats × founding price  +  VIP seats × VIP price
               − refunds (cooling-off + guarantee)
Direct costs   = royalty × paid seats
               + instructor time (6 sessions × 2h + prep + demo day + VIP 1-on-1s)
               + TA time (sessions + clinics) + producer time
               + support in the 90 days (tickets × handling time + support calls)
               + payment fees + tools (email, community, meeting, hosting)
Contribution   = Revenue − Direct costs
Break-even seats = fixed costs per cohort ÷ (average seat price − royalty − variable cost per seat)
```

Annual: contribution × cohorts per year − annual licence fee − certification − marketing.

### Worked example (all inputs hypothetical)

| Input | Value used | Where it comes from |
|---|---|---|
| Founding price | *1,497* | The site's default config |
| VIP price | *5,000* | The site's default config |
| Seats sold | *30 founding, 3 VIP* | Your forecast |
| Refund rate | *8%* of revenue | Your assumption; replace after cohort 1 |
| Royalty per Seat | *250* | Your order form |
| Instructor cost | *60 hours × 100* | Your rates |
| TAs and producer | *70 hours × 40* | 3 TAs and a producer; your rates |
| Support in 90 days | *45 hours × 40* | `delivery/support/sops.md` planning assumptions |
| Payment fees | *3%* of revenue | Your payment provider's rate |
| Tools per cohort | *500* | Your stack |

```
Revenue       = 30 × 1,497 + 3 × 5,000            = 59,910
Refunds (8%)                                      = −4,793
Net revenue                                       = 55,117
Royalty        33 × 250                           = −8,250
Instructor     60 × 100                           = −6,000
TAs/producer   70 × 40                            = −2,800
Support        45 × 40                            = −1,800
Payment fees   3% of 59,910                       = −1,797
Tools                                             = −500
Contribution per cohort                           = 33,970
```

The point of the example is the shape, not the numbers: the licensee's biggest levers are seats
filled, refund rate (which the checkpoints and rubric keep down honestly), and instructor time
(which certification and the run sheets keep predictable). Re-run it with your own inputs.

## Setting the licence fees

1. **Floor:** your cost to serve a licensee for a year (support at their tier, certification,
   onboarding, a share of release work), plus margin.
2. **Ceiling:** what leaves a typical licensee a comfortable contribution at a conservative seat
   count (use the worked example with *their* numbers). If your royalty takes more than about a
   fifth of their contribution at a realistic seat count, expect pushback.
3. **Exclusivity is worth more,** but only with minimum Seats: otherwise you've sold a territory to
   someone who may not use it.
4. **Refunded Seats should credit the royalty** (the order form does this) so licensees never pay
   you for a guarantee they honoured.

## What to include for every tier

- All Updates during the term (the programme promises members 12 months of library updates).
- The back end and no-code guide, the delivery materials and sales materials.
- Quarterly licensee call: what's in the next release, what's breaking in third-party tools.
