# Theming: making it yours

Everything a licensee changes to rebrand the programme, and where. The default design is the
original one; every override is optional.

## The website (`site/assets/config.js`)

| Setting | Changes |
|---|---|
| `brandName` | The name in the nav, footer, titles, audit, legal pages and structured data |
| `logo` | `{ src: "assets/img/logo.svg", height: 22, hideName: false }` replaces the circle mark. SVG or PNG in `assets/img/`. `hideName: true` if the logo contains the name |
| `theme` | Site colours as CSS variables, e.g. `{ "--buy": "#0F766E", "--green": "#0F766E" }`. Main variables: `--bg`, `--bg-2`, `--card`, `--ivory` (main text), `--ivory-2`, `--ink-2`, `--line`, `--line-2`, `--green`, `--buy` (buy buttons), `--copper` (brand mark) |
| `appTheme` | Colours inside the embedded map and dashboards: `--bg`, `--ivory`, `--ivory-2`, `--ink-2`, `--ink-3`, `--copper` (accent), `--line`, `--glass` |
| `instructors` | The "Who teaches it" section on How it works |
| `company`, `cohort`, `training`, `prices`, `links` | Legal details, dates, prices and every link |
| `analytics` | Plausible, GA4 or a custom script, consent-gated |

Also replace `favicon.svg`. Fonts are self-hosted in `assets/fonts/`; to use the brand's own fonts,
add their `@font-face` rules to `assets/fonts/fonts.css` and change the `font-family` values in
`site.css` (search for "Marcellus" and "Plus Jakarta Sans"). Keep the fonts' licence files.

Check contrast after changing colours: body text needs 4.5:1 against its background, large text
3:1 (WCAG 2.2 AA). Any online contrast checker will do.

## The member area and checkout (`product/backend`)

- `BRAND_NAME` and `SUPPORT_EMAIL` environment variables.
- Colours: the variables at the top of `src/app/globals.css` (`--bg`, `--card`, `--ink`,
  `--green`, `--buy`, `--red`…), set to the site's palette by default.
- Logo: replace the `.mark` span in `src/components/Shell.tsx` with an `<img>`; replace
  `public/favicon.svg`.
- Emails: the layout in `src/lib/email.ts` (`layout()`); wording in `welcomeEmail()` and
  `refundEmail()`.
- Stripe Checkout: brand colour, logo and icon in the Stripe Dashboard (Settings → Branding); a
  custom domain for checkout if you want one.

## The workspace kit

- Members see the provider's name and support links from `workspace.json → provider`
  (`name`, `supportUrl`, `supportEmail`, `bookingUrl`, `communityUrl`, `docsUrl`). Set these in the
  kit before building the release.
- The kit's console uses the same map and dashboards; colours are set in `product/kit/map/` and
  `product/kit/dashboards/styles.css` (same variable names as `appTheme`).
- Release name: the zip is `workforce-kit-<version>.zip`; rename in `build/release.mjs` if you
  want your brand in it.

## Slides, PDFs and documents

- Session decks: `delivery/curriculum/slides/slides.json` → `"brand"` and `"cohort"`, colours and
  fonts in `build_slides.js` (`THEME`), or `--theme my-theme.json`. Rebuild with
  `node build_slides.js`.
- Free guides: `build/site_extras.py` (`BRAND`, `PDF_CSS`), then re-run it.
- Sales deck and one-pager: `business/sales/` (same approach as the session decks).

## Checklist

- [ ] No "Your Brand" left anywhere: `grep -rl "Your Brand" site product/backend/src` should
      return only files you've intentionally left (config comments).
- [ ] Logo sharp on retina screens (use SVG).
- [ ] Contrast checked on buttons, links and muted text.
- [ ] Map and dashboards checked in both their dark and light modes.
