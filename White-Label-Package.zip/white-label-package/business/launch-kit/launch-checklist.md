# Licensee launch kit: from the zip to a first cohort

Eight weeks is comfortable; five is possible. Each step names the file in the package that does the
work. Tick as you go.

## Week −8: decide

- [ ] **Brand:** programme name, logo, colours. Trademark search in your territory.
- [ ] **Offer:** seat prices, seat numbers (VIP within the total), cohort dates, free-training date.
      Run `../licensing/licensee-pricing.md` with your own numbers.
- [ ] **People:** lead instructor and TAs booked for certification (`delivery/instructor/certification.md`).
- [ ] **Route for checkout and members:** the included back end (`product/backend/README.md`) or
      no-code (`product/backend/NO-CODE.md`).
- [ ] **Legal:** your lawyer engaged to adapt terms, refunds, privacy, cookies and AI disclosure.

## Week −7: accounts (all in the business's name, 2FA on)

- [ ] Domain and DNS (`www.` for the site, `app.` for the back end).
- [ ] Static site host (any host that serves files; set the 404 page to `404.html`).
- [ ] Back-end route: Supabase project + an app host (or Stripe Payment Links + an automation tool).
- [ ] Stripe account verified; Stripe Tax decided; payout bank set.
- [ ] Local currencies decided: turn on Stripe **Adaptive Pricing** (Settings → Adaptive Pricing; always on for
      Payment Links) so buyers abroad see and pay their own currency, with your price set once. Buyers pay the
      2–4% conversion; you're paid in your currency. Not available to Stripe accounts of Indian businesses.
- [ ] Transactional email (Resend or similar) with your domain verified (SPF, DKIM, DMARC).
- [ ] Marketing email tool; meeting/webinar tool; community platform; scheduling tool.
- [ ] Fill in `../compliance/subprocessors.md` as you go, and accept each provider's DPA.

## Week −6: brand the site (`theming.md`)

- [ ] `assets/config.js`: `brandName`, `company`, `cohort`, `training`, `prices`, `links`, `logo`,
      `theme`, `appTheme`, `instructors`.
- [ ] Replace `favicon.svg`; add an Open Graph share image if you want one.
- [ ] Delete `assets/img/perk-*` unless you run your own perks programme (`../licensing/rights-checklist.md`, item 8).
- [ ] `node tools/build-seo.mjs https://www.yourdomain.com` (canonical links, sitemap, robots).
- [ ] Walk every page on a phone and a laptop. Check every date, price and link.

## Week −5: back end and payments

- [ ] Deploy the back end; run the migration and seed; make yourself admin (`README.md` steps 1–6).
- [ ] Stripe webhook added; test purchase in **test mode** end to end: checkout → welcome email →
      sign in → member area → kit download → refund → access ends.
- [ ] Connect the site (`links.*` to `/checkout`, `/join`, `/api/audit`, `/api/contact`;
      `ALLOWED_ORIGINS` set).
- [ ] Upload the kit release (`/admin/releases`), built with `node build/release.mjs`.
- [ ] Create the cohort and its six sessions in `/admin/cohorts` (keep the site config in step). Add the
      fortnightly support calls, and each session's "have ready" and homework if you differ from the defaults.
- [ ] Decide invoices: `STRIPE_INVOICES=true` gives every buyer a PDF invoice and a VAT/tax ID field.
- [ ] Decide renewals: set the renewal price and months on the cohort (blank keeps renewals off).
- [ ] Switch on scheduled emails: set `CRON_SECRET`, run `supabase/cron-emails.example.sql` (edited), then
      check `/admin/emails` shows the first reminders as due on the right dates.
- [ ] Uptime monitor on `/api/health`.
- [ ] Self-paced course: add the lesson videos in `/admin/course`; decide the self-paced refund window on the cohort.
- [ ] Sign the kit release with your own key (`licensor/sign-release.mjs`) before uploading it.
- [ ] Run the skill tests once with your own Claude account: in a kit folder, `node bin/wf.mjs eval --all --dry-run`
      to see the most it can cost, then run it (raise `--max-usd` if you want the full set in one go). Re-run after
      any model change.
- [ ] If you offer the hosted console: set the push keys (`VAPID_*` in `runtime/.env`) and install it on your phone.

## Week −4: content and legal

- [ ] Legal pages adapted and approved by your lawyer (the draft note disappears once
      `company.legalName` is set).
- [ ] Claims reviewed against `../compliance/claims-and-disclaimers.md`.
- [ ] Email sequences loaded and scheduled (`delivery/emails/sequence.md`).
- [ ] Community spaces created; code of conduct pinned (`delivery/support/community.md`).
- [ ] Support inbox, macros (`delivery/support/macros.md`) and response targets published.

## Week −3: open enrollment

- [ ] Switch Stripe to **live** keys; one real purchase by you, then refund it.
- [ ] Free training registration live (`/join?kind=training` or your webinar tool).
- [ ] Announce: launch emails and posts (`../sales/launch-emails.md`, `../sales/ad-creative.md`).
- [ ] Book-a-call link live; sales-call deck ready (`../sales/sales-call-deck.pptx`).

## Week −2: free training and selling

- [ ] Deliver the free training (`../sales/webinar-script.md`). Replay and T4 email sent.
- [ ] Follow up every call within one working day.
- [ ] Instructors certified; TA briefing booked for the day before Session 1.

## Week −1: prepare to teach

- [ ] Kit tested from a fresh download on a clean Mac and a clean Windows machine.
- [ ] Every member has double-clicked "Check my computer" (top of the kit folder) and fixed what it flagged; chase
      anyone whose setup isn't confirmed in admin → Members.
- [ ] Demo laptop prepared (`delivery/curriculum/session-01.md`, "Before the session").
- [ ] Email 02 (pre-work) sent; enrollment closes as advertised.

## Cohort and after

- [ ] Run sheets, attendance every session, recordings the same day, clinics.
- [ ] Demo day with the rubric; refund decisions within two working days.
- [ ] Support calls every two weeks for 90 days; 30-day outcomes check-in; results page updated
      with real numbers only (`config.outcomes`).
- [ ] Quarterly report to the licensor (master licence, Schedule 4).
