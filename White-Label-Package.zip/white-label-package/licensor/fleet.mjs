#!/usr/bin/env node
// The licensor's fleet console: one view of every licensee's programme.
//
//   node fleet.mjs [--quarter 2026-Q3] [--config fleet.json] [--out out/]
//   node fleet.mjs --serve [--port 4900] [--every 15]     live, on this computer only
//
// Reads fleet.json (who your licensees are and their commercial terms), fetches each licensee's
// quarterly report from their own deployment (GET /api/licensor/report, counts and totals only),
// works out the royalty or revenue share due, and writes three files to --out:
//   fleet-<quarter>.html   a self-contained dashboard (open it in a browser; nothing is hosted)
//   fleet-<quarter>.csv    one row per licensee, for invoicing
//   fleet-<quarter>.json   everything fetched, for your records
// Tokens are read from environment variables named in fleet.json, never stored in the file.
// No dependencies; Node 18.17+.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import http from 'node:http';

export function currentQuarter(now = new Date()) { return `${now.getUTCFullYear()}-Q${Math.floor(now.getUTCMonth() / 3) + 1}`; }

/**
 * Royalty or revenue share due for one licensee's report, per currency (minor units).
 * terms: { royaltyPerSeat: { currency: "usd", amount: 25000 } } and/or { revenueSharePct: 10 }.
 * A seat refunded in the quarter credits the royalty, as the order form says.
 */
export function amountDue(terms = {}, report) {
  const paidSeats = Math.max(0, report.seatsSold.founding + report.seatsSold.vip - report.seatsRefunded.total);
  const due = {};
  if (terms.royaltyPerSeat?.amount) { const c = String(terms.royaltyPerSeat.currency || 'usd').toLowerCase(); due[c] = paidSeats * terms.royaltyPerSeat.amount; }
  if (terms.revenueSharePct) for (const [c, r] of Object.entries(report.revenue || {})) due[c] = (due[c] || 0) + Math.round(Math.max(0, r.net) * terms.revenueSharePct / 100);
  return { paidSeats, due };
}

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtMoney = (minor, cur) => { try { return new Intl.NumberFormat('en-US', { style: 'currency', currency: cur.toUpperCase() }).format(minor / 100); } catch { return `${(minor / 100).toFixed(2)} ${cur}`; } };
const moneyList = (o) => Object.entries(o || {}).map(([c, v]) => fmtMoney(v, c)).join(' · ') || '–';
const csvCell = (v) => { const s = String(v ?? ''); return /[",\n]/.test(s) || /^[=+\-@]/.test(s) ? `"${(/^[=+\-@]/.test(s) ? "'" : '') + s.replace(/"/g, '""')}"` : s; };

export async function fetchReport(lic, quarter, { fetchImpl = fetch, env = process.env } = {}) {
  const token = env[lic.tokenEnv];
  const base = String(lic.url || '').replace(/\/$/, '');
  if (!/^https:\/\//.test(base) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(base)) return { ok: false, error: 'url must start with https://' };
  if (!token) return { ok: false, error: `set the environment variable ${lic.tokenEnv}` };
  try {
    const health = await fetchImpl(`${base}/api/health`, { signal: AbortSignal.timeout(10000) }).then((r) => r.ok).catch(() => false);
    const res = await fetchImpl(`${base}/api/licensor/report?quarter=${encodeURIComponent(quarter)}`, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(20000) });
    if (!res.ok) return { ok: false, health, error: res.status === 401 ? 'token refused' : res.status === 404 ? 'reporting is off on this site (LICENSOR_REPORT_TOKEN not set)' : `HTTP ${res.status}` };
    const report = await res.json();
    if (report.format !== 'licensee-report/1') return { ok: false, health, error: 'unexpected report format' };
    return { ok: true, health, report };
  } catch (e) { return { ok: false, health: false, error: e.name === 'TimeoutError' ? 'timed out' : e.message }; }
}

export async function buildFleet(config, quarter, opts = {}) {
  const rows = [];
  for (const lic of config.licensees || []) {
    const r = await fetchReport(lic, quarter, opts);
    const calc = r.ok ? amountDue(lic.terms, r.report) : null;
    rows.push({ name: lic.name, url: lic.url, terms: lic.terms || {}, ...r, ...(calc || {}) });
  }
  const totals = { seats: 0, refunded: 0, net: {}, due: {}, leads: 0, ok: rows.filter((r) => r.ok).length, failing: rows.filter((r) => !r.ok).length };
  for (const r of rows.filter((x) => x.ok)) {
    totals.seats += r.report.seatsSold.founding + r.report.seatsSold.vip;
    totals.refunded += r.report.seatsRefunded.total;
    totals.leads += Object.values(r.report.leads || {}).reduce((a, b) => a + b, 0);
    for (const [c, v] of Object.entries(r.report.revenue || {})) totals.net[c] = (totals.net[c] || 0) + v.net;
    for (const [c, v] of Object.entries(r.due || {})) totals.due[c] = (totals.due[c] || 0) + v;
  }
  return { quarter, generatedAt: new Date().toISOString(), licensor: config.licensor || '', rows, totals };
}

export function toCsv(fleet) {
  const head = ['licensee', 'status', 'kit_version', 'seats_sold', 'vip', 'refunded', 'paid_seats', 'net_revenue', 'due', 'audits', 'waitlist', 'training', 'support_opened', 'avg_attendance'];
  const lines = [head.join(',')];
  for (const r of fleet.rows) {
    const p = r.report;
    const att = p ? p.cohorts.filter((c) => c.averageAttendance != null).map((c) => c.averageAttendance) : [];
    lines.push([r.name, r.ok ? 'ok' : `error: ${r.error}`, p?.kitVersion, p ? p.seatsSold.founding + p.seatsSold.vip : '', p?.seatsSold.vip, p?.seatsRefunded.total, r.paidSeats ?? '', p ? moneyList(Object.fromEntries(Object.entries(p.revenue).map(([c, v]) => [c, v.net]))) : '', r.due ? moneyList(r.due) : '', p?.leads.audit ?? '', p?.leads.waitlist ?? '', p?.leads.training ?? '', p?.support.opened ?? '', att.length ? Math.round(att.reduce((a, b) => a + b, 0) / att.length * 100) + '%' : ''].map(csvCell).join(','));
  }
  return '﻿' + lines.join('\n') + '\n';
}

export function toHtml(fleet, extra = {}) {
  const t = fleet.totals;
  const kpi = (v, l) => `<div class="kpi"><b>${esc(v)}</b><span>${esc(l)}</span></div>`;
  const row = (r) => {
    const p = r.report;
    if (!r.ok) return `<tr><td><b>${esc(r.name)}</b><br><span class="muted">${esc(r.url)}</span></td><td><span class="pill bad">Not reporting</span><br><span class="muted">${esc(r.error)}</span></td><td colspan="7"></td></tr>`;
    const att = p.cohorts.filter((c) => c.averageAttendance != null).map((c) => c.averageAttendance);
    const avg = att.length ? `${Math.round(att.reduce((a, b) => a + b, 0) / att.length * 100)}%` : '–';
    return `<tr><td><b>${esc(r.name)}</b><br><span class="muted">${esc(r.url)}</span></td>
      <td><span class="pill ${r.health ? 'ok' : 'warn'}">${r.health ? 'Healthy' : 'Health check failed'}</span><br><span class="muted">kit ${esc(p.kitVersion || '–')}</span></td>
      <td class="n">${p.seatsSold.founding + p.seatsSold.vip}<br><span class="muted">${p.seatsSold.vip} VIP</span></td>
      <td class="n">${p.seatsRefunded.total}</td>
      <td class="n">${esc(moneyList(Object.fromEntries(Object.entries(p.revenue).map(([c, v]) => [c, v.net]))))}</td>
      <td class="n"><b>${esc(moneyList(r.due))}</b></td>
      <td class="n">${Object.values(p.leads).reduce((a, b) => a + b, 0)}</td>
      <td class="n">${avg}</td>
      <td class="n">${p.support.open}</td></tr>`;
  };
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fleet ${esc(fleet.quarter)}</title>
<style>
:root{--bg:#F6F6F7;--card:#fff;--ink:#161618;--ink2:#5B5B66;--line:rgba(20,20,24,.1);--ok:#149655;--warn:#B7791F;--bad:#C53B4E;color-scheme:light}
@media (prefers-color-scheme:dark){:root{--bg:#121214;--card:#1C1C20;--ink:#F2F2F4;--ink2:#A1A1AB;--line:rgba(255,255,255,.12);--ok:#3CC47F;--warn:#E0A84A;--bad:#F06B7E;color-scheme:dark}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,system-ui,"Segoe UI",sans-serif}
main{max-width:1180px;margin:0 auto;padding:28px 16px 60px}h1{margin:0 0 4px;font-size:26px}.muted{color:var(--ink2);font-size:13px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin:22px 0}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px}.kpi b{display:block;font-size:24px;line-height:1.15}.kpi span{color:var(--ink2);font-size:13px}
.wrap{background:var(--card);border:1px solid var(--line);border-radius:14px;overflow-x:auto}
table{border-collapse:collapse;width:100%;min-width:860px}th,td{text-align:left;padding:12px 14px;border-bottom:1px solid var(--line);vertical-align:top}th{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--ink2);font-weight:600}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums}tr:last-child td{border-bottom:0}
h2{font-size:17px;margin:26px 0 10px}.live{display:inline-flex;gap:8px;align-items:center}.dot{width:8px;height:8px;border-radius:50%;background:var(--ok)}button{font:inherit;padding:6px 12px;border-radius:999px;border:1px solid var(--line);background:var(--card);color:var(--ink);cursor:pointer}
.pill{display:inline-block;font-size:12px;font-weight:600;padding:2px 9px;border-radius:999px;border:1px solid currentColor}.pill.ok{color:var(--ok)}.pill.warn{color:var(--warn)}.pill.bad{color:var(--bad)}
footer{margin-top:18px}
</style></head><body><main>
<h1>Licensee fleet · ${esc(fleet.quarter)}</h1>
${extra.live ? `<p class="muted live"><span class="dot" aria-hidden="true"></span>Live: refreshes every ${esc(extra.live.every)} minutes · <form method="post" action="/refresh" style="display:inline"><button type="submit">Refresh now</button></form></p>` : ''}
<p class="muted">${esc(fleet.licensor)}${fleet.licensor ? ' · ' : ''}Generated ${esc(new Date(fleet.generatedAt).toUTCString())} from each licensee's own quarterly report (counts and totals only, no personal data).</p>
<div class="kpis">${kpi(`${t.ok} / ${t.ok + t.failing}`, 'Licensees reporting')}${kpi(t.seats, 'Seats sold this quarter')}${kpi(t.refunded, 'Seats refunded')}${kpi(moneyList(t.net), 'Licensee net revenue')}${kpi(moneyList(t.due), 'Due to you this quarter')}${kpi(t.leads, 'New leads across the fleet')}</div>
<div class="wrap"><table><thead><tr><th>Licensee</th><th>Status</th><th class="n">Seats</th><th class="n">Refunded</th><th class="n">Net revenue</th><th class="n">Due</th><th class="n">Leads</th><th class="n">Attendance</th><th class="n">Support open</th></tr></thead>
<tbody>${fleet.rows.map(row).join('') || '<tr><td colspan="9" class="muted">No licensees in fleet.json yet.</td></tr>'}</tbody></table></div>
${extra.uptime ? `<h2>Uptime</h2><div class="wrap"><table><thead><tr><th>Licensee</th><th class="n">Checks</th><th class="n">Healthy</th><th>Last failure</th></tr></thead><tbody>${fleet.rows.map((r) => { const u = extra.uptime[r.url] || { checks: 0, ok: 0 }; return `<tr><td>${esc(r.name)}</td><td class="n">${u.checks}</td><td class="n">${u.checks ? Math.round((u.ok / u.checks) * 1000) / 10 + '%' : '–'}</td><td>${u.lastFail ? esc(new Date(u.lastFail).toUTCString()) : '<span class="muted">none</span>'}</td></tr>`; }).join('')}</tbody></table></div>` : ''}
${extra.setup?.length ? `<h2>Setting up</h2><div class="wrap"><table><thead><tr><th>Licensee</th><th>Steps done</th><th>Domain</th><th>Last deploy</th><th>Health check</th></tr></thead><tbody>${extra.setup.map((x) => `<tr><td><b>${esc(x.slug)}</b></td><td>${esc(x.done.join(', ') || 'none')}</td><td>${x.domain ? `${esc(x.domain.name)} ${x.domain.verified ? '<span class="pill ok">verified</span>' : '<span class="pill warn">DNS needed</span>'}` : '–'}</td><td>${x.deploy ? esc(new Date(x.deploy.at).toUTCString()) : '–'}</td><td>${x.check ? (x.check.ok ? '<span class="pill ok">ok</span>' : '<span class="pill bad">failed</span>') : '–'}</td></tr>`).join('')}</tbody></table></div>` : ''}
<footer class="muted">Due = royalty per paid seat (seats sold minus seats refunded this quarter) and/or revenue share of net revenue, from the terms in fleet.json. Check against each licensee's Schedule 4 report before invoicing.</footer>
</main></body></html>`;
}

/** Setup progress from provision.mjs state files (no secrets are in them). */
export function setupStatus(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter((f) => f.endsWith('.state.json')).map((f) => {
    let st = {}; try { st = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8')); } catch { /* skip a torn file */ }
    return { slug: st.slug || f.replace('.state.json', ''), done: Object.keys(st.done || {}), domain: st.domain || null, deploy: st.deploy || null, check: st.check || null };
  });
}

/**
 * The live fleet console: a small server on this computer only (127.0.0.1) that re-reads every licensee
 * on a timer and keeps an uptime record. Nothing is hosted or shared.
 */
export function serveFleet({ configPath, quarter, port = 4900, every = 15, out, licenseesDir, fetchImpl, log = console.log } = {}) {
  let fleet = null, busy = null;
  const uptime = {};
  const histFile = out ? path.join(out, 'health.jsonl') : null;
  async function refresh() {
    if (busy) return busy;
    busy = (async () => {
      const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      fleet = await buildFleet(cfg, quarter || currentQuarter(), { fetchImpl });
      for (const r of fleet.rows) {
        const u = (uptime[r.url] ||= { checks: 0, ok: 0, lastFail: null });
        u.checks++; if (r.ok && r.health) u.ok++; else u.lastFail = fleet.generatedAt;
        if (histFile) { fs.mkdirSync(path.dirname(histFile), { recursive: true }); fs.appendFileSync(histFile, JSON.stringify({ ts: fleet.generatedAt, url: r.url, ok: !!r.ok, health: !!r.health, error: r.error || null }) + '\n'); }
      }
      return fleet;
    })().finally(() => { busy = null; });
    return busy;
  }
  let last = 0;
  const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://localhost');
    const host = String(req.headers.host || '').replace(/:\d+$/, '');
    if (!['localhost', '127.0.0.1', '[::1]'].includes(host)) { res.writeHead(421); return res.end('Unknown host'); }
    if (req.method === 'POST' && u.pathname === '/refresh') {
      if (req.headers.origin && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(req.headers.origin)) { res.writeHead(403); return res.end('Forbidden'); }
      if (Date.now() - last > 20000) { last = Date.now(); await refresh().catch((e) => log(`refresh failed: ${e.message}`)); }
      res.writeHead(303, { Location: '/' }); return res.end();
    }
    if (u.pathname === '/fleet.json') { res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); return res.end(JSON.stringify({ fleet, uptime })); }
    if (u.pathname !== '/') { res.writeHead(404); return res.end('Not found'); }
    if (!fleet) await refresh();
    const html = toHtml(fleet, { live: { every }, uptime, setup: licenseesDir ? setupStatus(licenseesDir) : [] })
      .replace('<head>', `<head><meta http-equiv="refresh" content="${Math.max(60, every * 60)}">`);
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'", 'X-Frame-Options': 'DENY' });
    res.end(html);
  });
  const timer = setInterval(() => refresh().catch((e) => log(`refresh failed: ${e.message}`)), every * 60_000);
  timer.unref?.();
  return new Promise((resolve) => server.listen(port, '127.0.0.1', () => resolve({ server, refresh, uptime, port: server.address().port, stop: () => { clearInterval(timer); server.close(); } })));
}

async function main() {
  const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, all) => (x.startsWith('--') ? [...a, [x.slice(2), all[i + 1] && !all[i + 1].startsWith('--') ? all[i + 1] : true]] : a), []));
  const here = path.dirname(fileURLToPath(import.meta.url));
  const cfgPath = path.resolve(args.config || path.join(here, 'fleet.json'));
  if (!fs.existsSync(cfgPath)) { console.error(`No ${path.basename(cfgPath)}. Copy fleet.example.json to fleet.json and fill it in.`); process.exit(1); }
  const quarter = args.quarter || currentQuarter();
  if (!/^\d{4}-Q[1-4]$/.test(quarter)) { console.error('Use --quarter YYYY-Q1..Q4'); process.exit(1); }
  if (args.serve) {
    const every = Math.max(1, Number(args.every || 15));
    const r = await serveFleet({ configPath: cfgPath, quarter, port: Number(args.port || 4900), every, out: path.resolve(args.out || path.join(here, 'out')), licenseesDir: path.join(here, 'licensees') });
    console.log(`Fleet console: http://localhost:${r.port}  (this computer only; refreshes every ${every} min; Ctrl+C to stop)`);
    return;
  }
  const fleet = await buildFleet(JSON.parse(fs.readFileSync(cfgPath, 'utf8')), quarter);
  const out = path.resolve(args.out || path.join(here, 'out'));
  fs.mkdirSync(out, { recursive: true });
  fs.writeFileSync(path.join(out, `fleet-${quarter}.html`), toHtml(fleet));
  fs.writeFileSync(path.join(out, `fleet-${quarter}.csv`), toCsv(fleet));
  fs.writeFileSync(path.join(out, `fleet-${quarter}.json`), JSON.stringify(fleet, null, 2));
  for (const r of fleet.rows) console.log(`${r.ok ? '✓' : '✗'} ${r.name}${r.ok ? `: ${r.report.seatsSold.founding + r.report.seatsSold.vip} seats, due ${moneyList(r.due)}` : `: ${r.error}`}`);
  console.log(`\nWrote ${path.join(out, `fleet-${quarter}.html`)} (and .csv, .json)`);
  if (fleet.totals.failing) process.exitCode = 2;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();
