# Running many licensees: the fleet model

This folder is for **you, the licensor**: how to set up each new licensee quickly and see all of them
in one place, without sending anyone a pile of files.

## The model: one codebase, one isolated deployment per licensee

Each licensee gets their own copy of the back end (`../backend`), deployed from the same repository,
with **their own** database, Stripe account, email sender and domain. You run (or they run) that
deployment; their members' data lives only in it. You see each one through a read-only, counts-only
report.

| | Fleet (this) | One shared database for everyone |
|---|---|---|
| A licensee's members' data | in their own database only; you never hold it | all licensees in one database, separated by code |
| Who is the data controller | the licensee, clearly | blurred; you'd need DPAs with every licensee and stronger audits |
| Payments | straight into the licensee's own Stripe account | needs Stripe Connect and platform liability |
| A bug or breach | affects one licensee | can expose every licensee |
| Leaving | they keep their deployment and data | a data export project |
| Cost | one Supabase project and one app deployment per licensee (entry paid tiers are plenty for cohorts of 50; free tiers can pause when idle) | lower at very large numbers of licensees |

For a licensed programme with a few dozen licensees, isolation is the right default (it is the "silo"
model in standard SaaS tenancy terms). Every licensee runs the same tested code; you roll out updates
by redeploying from your repository.

## Set up a new licensee automatically (about 15 minutes, most of it waiting)

`provision.mjs` does steps 2 to 8 below through the Supabase, Stripe and Vercel APIs, from one file:

```
cp licensees/example.json licensees/harbor.json      # fill in from their order form
export SUPABASE_ACCESS_TOKEN=…   VERCEL_TOKEN=…       # yours
export HARBOR_STRIPE_KEY=…       HARBOR_RESEND_KEY=…  # theirs (names set in the file)
node provision.mjs licensees/harbor.json             # the plan: shows every step, calls nothing
node provision.mjs licensees/harbor.json --apply     # does it
```

It creates their Supabase project (in their region, under your organization), runs every migration and
creates their first cohort and sessions, points sign-in links at their app and sends them through Resend
from their domain, creates the Stripe webhook in **their** Stripe account with exactly the events the back
end handles, creates the Vercel project from your repository, sets every environment variable (the hash
salt, cron secret and report token are generated and go straight to Vercel), adds their domain, deploys,
checks `/api/health`, makes their first admin, and adds them to `fleet.json`.

- **Nothing secret touches your disk.** Keys come from environment variables; the Supabase keys and the
  webhook secret are held in memory only for the run. Progress (ids, URLs, DNS records) goes to
  `licensees/<slug>.state.json`. The report token for your fleet console is printed once.
- **Safe to run again.** Finished steps are skipped or repeated harmlessly; existing salts and tokens
  are kept. A failure stops the run and says why; fix it and run again, or resume with
  `--only deploy,check`. Steps that need the Supabase keys or the webhook secret include the step that
  reads them (`--only keys,env`, `--only keys,admin`).
- **What's left for a person:** the DNS records it prints (one CNAME, sometimes a TXT), branding the
  website (step 6), and a test purchase (step 7).
- Your Supabase token needs to create projects, run SQL, change auth settings and read API keys; your
  Vercel token needs the team the projects live in (`vercel.teamId`). Their Stripe key needs to create
  webhooks; a restricted key with *Webhook endpoints: write* is enough.

The manual steps, for reference or for hosts other than Vercel:

## Set up a new licensee (about an hour)

You need: a GitHub repository with `../backend` (private), and accounts at Supabase, Vercel (or any
Node host), Stripe and Resend: the licensee's own, or ones you create and hand over.

1. **Collect their details** with `../business/licensing/order-form.md`: legal name, brand name,
   domains (site and app), support email, currency, seat prices, cohort dates, and their terms
   (royalty per seat or revenue share).
2. **Database.** Create a Supabase project in the region nearest their members. In the SQL editor
   run each file in `supabase/migrations/` in order (`0001_…`, `0002_…`, `0003_…`), then an edited
   `supabase/seed.sql` with their first cohort. Copy the URL, anon key and service-role key.
3. **Payments.** In *their* Stripe account create a restricted key and a webhook to
   `https://<their app domain>/api/stripe/webhook` (events listed in `../backend/README.md`).
4. **Email.** In Resend (or another provider) verify their sending domain; create an API key.
5. **Deploy.** Import the repository in Vercel as a new project, set the root to `backend/`, and fill in
   the environment from `../backend/.env.example`, including:
   - `BRAND_NAME`, `APP_URL`, `SITE_URL`, `ALLOWED_ORIGINS`, `SUPPORT_EMAIL`, `EMAIL_FROM`
   - `IP_HASH_SALT`: `openssl rand -hex 32`
   - `LICENSOR_REPORT_TOKEN`: `openssl rand -hex 32` (this is what lets your console read their report)
   Add their app domain and point DNS at it.
6. **Website.** Brand the site (`../business/launch-kit/theming.md`): `assets/config.js` for name, logo,
   colours, links and prices, and the API URL of step 5. Host it wherever they like.
7. **Check.** `https://<app>/api/health` returns `{"ok":true}`; a test purchase with a Stripe test card
   creates a member and sends the sign-in email; `/admin` opens for the person you made admin.
8. **Add them to your fleet.** Add an entry to `fleet.json` and store the token as an environment
   variable on your computer (never in the file):

   ```json
   { "name": "Harbor Learning", "url": "https://app.harbor-learning.example", "tokenEnv": "FLEET_TOKEN_HARBOR",
     "terms": { "royaltyPerSeat": { "currency": "usd", "amount": 25000 } } }
   ```

   `amount` is in minor units (cents): 25000 = $250. For a revenue share use `{ "revenueSharePct": 12 }`.

Updates: merge to your repository's main branch and redeploy each licensee's project (Vercel does
this automatically when every project tracks the same branch). New migrations are added as new
numbered files and are safe to run more than once.

## The fleet console

**Live, on your computer:** `node fleet.mjs --serve` opens a local dashboard at http://localhost:4900
that re-reads every licensee every 15 minutes (`--every 5` for more often), keeps an uptime record per
licensee (`out/health.jsonl`), shows licensees still being set up (from `licensees/*.state.json`), and
has a *Refresh now* button. It only answers on this computer.

For quarterly invoicing:


```
cp fleet.example.json fleet.json      # then edit it
export FLEET_TOKEN_HARBOR=…            # one per licensee, from step 5
node fleet.mjs                         # this quarter
node fleet.mjs --quarter 2026-Q3       # a past quarter
```

It fetches each licensee's quarterly report (`GET /api/licensor/report`) and health check, works out
the royalty or revenue share due, and writes `out/fleet-<quarter>.html` (open it in a browser), `.csv`
(for invoicing) and `.json` (for your records). Nothing is uploaded or hosted. A licensee whose site
doesn't answer, or whose token is wrong, is listed as **Not reporting** with the reason, and the command
exits with code 2 so you can run it on a schedule and notice.

What each report contains (the same as the licensee sees in their own `/admin/report`, and the figures
Schedule 4 of the licence agreement asks for): seats sold and refunded by reason, revenue gross,
refunded and net per currency, cohorts with dates, sessions run and average attendance, leads by
kind, support opened and open, open refund requests, kit downloads and the kit version. **No names,
emails, messages or per-person rows**, so no member personal data reaches you (clause 7.1).

Not in the report, because the back end doesn't record them: certified instructors and TAs, demo-day
results, self-paced seats sold elsewhere. Licensees add those to their Schedule 4 report themselves.

## Signing kit releases

Sign every kit release you hand out, so members' workspaces can tell a genuine update from a
tampered one:

```
node sign-release.mjs new-key                                   # once; keeps the key in ~/.kit-signing
node sign-release.mjs workforce-kit-1.0.0.zip --key ~/.kit-signing/kit-signing-key.private.pem
#   → workforce-kit-1.0.0-signed.zip: upload this one in each licensee's /admin/releases
```

A workspace installed from a signed release accepts `wf update` only from releases signed with the
same key (it refuses others, and any release whose files don't match its manifest), and `wf doctor`
fails if the installed manifest no longer matches its signature. `wf skills audit` adds a security
review of every skill (dangerous instructions, hidden characters, prompt-injection hardening) and
shows which kit skills a member has edited. Keep the private key out of the kit and out of git, and
back it up: if it's lost, members have to reinstall (or accept one update with `--allow-unsigned`) to
move to a new key.

## Tests

`node --test test/*.test.mjs` (9 tests): signing a release zip and the kit accepting it, royalty and revenue-share maths (refunds credited), per-licensee
tokens, failures shown rather than hidden, HTML escaping, CSV formula neutralising, the live console (local only, uptime, setup progress), and provisioning end to end against fakes of the Supabase, Vercel and Stripe APIs: the plan calls nothing, a full run, running it again, resuming after a failed build or health check, no secret on disk, and SQL escaping. The report
endpoint itself is tested in `../backend/tests/report.test.ts`.
