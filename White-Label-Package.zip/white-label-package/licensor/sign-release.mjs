#!/usr/bin/env node
// Sign a kit release so members' workspaces can trust its updates.
//
//   node sign-release.mjs new-key [folder]                        make your signing key (once; default ~/.kit-signing)
//   node sign-release.mjs <workforce-kit-x.y.z.zip | folder> --key <private.pem> [--out signed.zip]
//
// What signing does: puts your public key in setup/kit-signing-key.pem, recomputes
// setup/kit-manifest.json (the SHA-256 of every kit file, using the release's own code), and writes
// setup/kit-manifest.sig (an Ed25519 signature of that manifest). A workspace installed from a signed
// release then accepts `wf update` only from releases signed with the same key, and `wf doctor`
// reports if installed kit files no longer match. Keep the private key out of the kit and out of git.
// Needs Node 18.17+ and `zip`/`unzip` (macOS, Linux) or PowerShell (Windows).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const argv = process.argv.slice(2);
const opt = (name) => { const i = argv.indexOf(`--${name}`); return i >= 0 ? argv[i + 1] : undefined; };
const die = (m) => { console.error(m); process.exit(1); };
const home = (p) => p && p.replace(/^~(?=$|[\\/])/, os.homedir());

async function signingLib(root) {
  const p = path.join(root, 'bin', 'lib', 'signing.mjs');
  if (!fs.existsSync(p)) die(`${root} is not a kit release that supports signing (no bin/lib/signing.mjs).`);
  return import(pathToFileURL(p).href);
}

if (argv[0] === 'new-key') {
  const crypto = await import('node:crypto');
  const dir = path.resolve(home(argv[1]) || path.join(os.homedir(), '.kit-signing'));
  const priv = path.join(dir, 'kit-signing-key.private.pem');
  if (fs.existsSync(priv)) die(`${priv} already exists. Not overwriting it.`);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  fs.writeFileSync(priv, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  fs.writeFileSync(path.join(dir, 'kit-signing-key.pem'), publicKey.export({ type: 'spki', format: 'pem' }));
  console.log(`Private key: ${priv}\n  Back it up (a password manager is fine). If it's lost, members must reinstall to trust a new key.\nPublic key:  ${path.join(dir, 'kit-signing-key.pem')}`);
  process.exit(0);
}

const input = argv[0] && !argv[0].startsWith('--') ? path.resolve(home(argv[0])) : null;
const keyFile = home(opt('key') || process.env.WF_SIGNING_KEY_FILE);
if (!input || !keyFile) die('Usage: node sign-release.mjs <release.zip | folder> --key <private.pem> [--out signed.zip]\n       node sign-release.mjs new-key [folder]');
if (!fs.existsSync(input)) die(`${input} not found`);
const privatePem = fs.readFileSync(keyFile, 'utf8');

// Unpack a zip into a temporary folder (a release zip holds one top-level folder).
let root = input, tmp = null, top = null;
if (fs.statSync(input).isFile()) {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-sign-'));
  const r = process.platform === 'win32'
    ? spawnSync('powershell.exe', ['-NoProfile', '-Command', `Expand-Archive -LiteralPath '${input.replace(/'/g, "''")}' -DestinationPath '${tmp.replace(/'/g, "''")}' -Force`], { encoding: 'utf8' })
    : spawnSync('unzip', ['-q', input, '-d', tmp], { encoding: 'utf8' });
  if (r.status !== 0) die(`Could not unpack ${input}: ${r.stderr || r.error?.message}`);
  const entries = fs.readdirSync(tmp);
  top = entries.length === 1 && fs.statSync(path.join(tmp, entries[0])).isDirectory() ? entries[0] : null;
  root = top ? path.join(tmp, top) : tmp;
}
const manifestPath = path.join(root, 'setup', 'kit-manifest.json');
if (!fs.existsSync(manifestPath)) die(`${input} is not a kit release (no setup/kit-manifest.json)`);
const old = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const signing = await signingLib(root);
const { buildManifest } = await import(pathToFileURL(path.join(root, 'bin', 'lib', 'maintain.mjs')).href);

// Every file must still match the manifest it shipped with, so nothing is signed that was changed after the build.
const { createHash } = await import('node:crypto');
const sha = (b) => createHash('sha256').update(b).digest('hex');
const bad = signing.mismatchedFiles(root, { files: Object.fromEntries(Object.entries(old.files).filter(([rel]) => rel !== signing.PUBLIC_KEY)) }, sha);
if (bad.length) die(`Not signing: ${bad.length} file(s) differ from the release manifest (${bad.slice(0, 5).map((b) => `${b.rel} ${b.why}`).join(', ')}). Rebuild the release first.`);

fs.writeFileSync(path.join(root, signing.PUBLIC_KEY), signing.publicPemFor(privatePem));
const manifest = buildManifest(root, old.version);
const text = JSON.stringify(manifest, null, 2) + '\n';
fs.writeFileSync(manifestPath, text);
fs.writeFileSync(path.join(root, signing.SIGNATURE), signing.sign(text, privatePem) + '\n');
const check = signing.checkSignature(root);
if (!check.valid) die(`Signature check failed: ${check.reason}`);

if (!tmp) { console.log(`✓ Signed ${input} (kit ${old.version}, ${Object.keys(manifest.files).length} files).`); process.exit(0); }
const out = path.resolve(home(opt('out')) || input.replace(/\.zip$/i, '') + '-signed.zip');
fs.rmSync(out, { force: true });
const z = process.platform === 'win32'
  ? spawnSync('powershell.exe', ['-NoProfile', '-Command', `Compress-Archive -Path '${(top ? path.join(tmp, top) : path.join(tmp, '*')).replace(/'/g, "''")}' -DestinationPath '${out.replace(/'/g, "''")}'`], { encoding: 'utf8' })
  : spawnSync('zip', ['-qr', '-X', out, top || '.'], { cwd: tmp, encoding: 'utf8' });
if (z.status !== 0) die(`Could not write ${out}: ${z.stderr || z.error?.message}`);
fs.rmSync(tmp, { recursive: true, force: true });
console.log(`✓ Signed kit ${old.version}: ${out}`);
