// Provisioning against fakes of the Supabase Management API, Vercel, Stripe and the licensee's app,
// on one local server. Nothing leaves the machine.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { provision, cohortSql, validateLicensee, migrations, STEPS } from '../provision.mjs';

const here = path.dirname(new URL(import.meta.url).pathname);
const example = () => JSON.parse(fs.readFileSync(path.join(here, '..', 'licensees', 'example.json'), 'utf8'));
const calls = [];
const world = { projects: [], webhooks: [], vercelProjects: {}, env: {}, deployments: {}, users: [], sql: [], authCfg: null, buildFails: false, healthy: true };

function handle(req, res, body) {
  const u = new URL(req.url, 'http://x');
  const p = u.pathname;
  const j = (code, v) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(v)); };
  const auth = req.headers.authorization || '';
  calls.push({ method: req.method, path: p, query: u.search, auth, body });
  const data = body && req.headers['content-type']?.includes('json') ? JSON.parse(body) : body;
  // ---- Supabase Management API
  if (p.startsWith('/sb/')) {
    if (auth !== 'Bearer sbp_fake') return j(401, { message: 'Unauthorized' });
    if (p === '/sb/v1/projects' && req.method === 'GET') return j(200, world.projects);
    if (p === '/sb/v1/projects' && req.method === 'POST') { const pr = { id: 'abcdefghijklmnopqrst', ref: 'abcdefghijklmnopqrst', name: data.name, status: 'COMING_UP', polls: 0, body: data }; world.projects.push(pr); return j(201, pr); }
    const m = /^\/sb\/v1\/projects\/([a-z]+)(\/.*)?$/.exec(p);
    if (m) {
      const pr = world.projects.find((x) => x.ref === m[1]);
      if (!pr) return j(404, { message: 'not found' });
      if (!m[2]) { pr.polls++; if (pr.polls >= 2) pr.status = 'ACTIVE_HEALTHY'; return j(200, { ...pr, body: undefined }); }
      if (m[2] === '/database/query') { world.sql.push(data.query); return j(201, []); }
      if (m[2] === '/config/auth') { world.authCfg = data; return j(200, data); }
      if (m[2] === '/api-keys') return j(200, u.searchParams.get('reveal') === 'true' ? [{ name: 'anon', api_key: 'eyJanon.fake', type: 'legacy' }, { name: 'service_role', api_key: 'eyJservice.fake', type: 'legacy' }] : []);
    }
  }
  if (p === '/auth/v1/admin/users') {
    if (req.headers.apikey !== 'eyJservice.fake' || auth !== 'Bearer eyJservice.fake') return j(401, { msg: 'bad key' });
    if (world.users.includes(data.email)) return j(422, { msg: 'A user with this email address has already been registered' });
    world.users.push(data.email); return j(200, { id: 'u1', email: data.email });
  }
  // ---- Stripe
  if (p.startsWith('/stripe/')) {
    if (auth !== 'Bearer rk_test_licensee') return j(401, { error: { message: 'Invalid API Key' } });
    if (p === '/stripe/v1/webhook_endpoints' && req.method === 'GET') return j(200, { data: world.webhooks.map(({ secret, ...w }) => w), has_more: false });
    if (p === '/stripe/v1/webhook_endpoints' && req.method === 'POST') {
      const f = new URLSearchParams(body);
      world.whCount = (world.whCount || 0) + 1;
      const w = { id: `we_${world.whCount}`, url: f.get('url'), enabled_events: f.getAll('enabled_events[]'), secret: `whsec_${world.whCount}` };
      world.webhooks.push(w); return j(200, w);
    }
    const d = /^\/stripe\/v1\/webhook_endpoints\/(we_\d+)$/.exec(p);
    if (d && req.method === 'DELETE') { world.webhooks = world.webhooks.filter((w) => w.id !== d[1]); return j(200, { deleted: true }); }
  }
  // ---- Vercel
  if (p.startsWith('/vc/')) {
    if (auth !== 'Bearer vc_fake') return j(403, { error: { message: 'Not authorized' } });
    if (u.searchParams.get('teamId') !== 'team_test') return j(403, { error: { message: 'missing team' } });
    let m = /^\/vc\/v9\/projects\/([^/]+)$/.exec(p);
    if (m && req.method === 'GET') return world.vercelProjects[m[1]] ? j(200, world.vercelProjects[m[1]]) : j(404, { error: { message: 'Project not found' } });
    if (p === '/vc/v11/projects' && req.method === 'POST') { const pr = { id: 'prj_1', ...data }; world.vercelProjects[data.name] = pr; return j(200, pr); }
    m = /^\/vc\/v9\/projects\/prj_1\/env$/.exec(p);
    if (m) return j(200, { envs: Object.keys(world.env).map((key) => ({ key, type: 'encrypted' })) });
    if (p === '/vc/v10/projects/prj_1/env' && req.method === 'POST') { assert.equal(u.searchParams.get('upsert'), 'true'); for (const e of data) world.env[e.key] = e; return j(200, { created: data }); }
    if (p === '/vc/v10/projects/prj_1/domains' && req.method === 'POST') {
      if (world.domainAdded) return j(409, { error: { message: 'The domain is already assigned to this project' } });
      world.domainAdded = true; return j(200, { name: data.name, verified: false, verification: [{ type: 'TXT', domain: `_vercel.${data.name}`, value: 'vc-domain-verify=abc', reason: 'pending' }] });
    }
    m = /^\/vc\/v9\/projects\/prj_1\/domains\/(.+)$/.exec(p);
    if (m) return j(200, { name: m[1], verified: true, verification: [] });
    if (p === '/vc/v13/deployments' && req.method === 'POST') { const id = `dpl_${Object.keys(world.deployments).length + 1}`; world.deployments[id] = { id, url: `harbor-app-${id}.vercel.app`, readyState: 'QUEUED', polls: 0, body: data }; return j(200, world.deployments[id]); }
    m = /^\/vc\/v13\/deployments\/(dpl_\d+)$/.exec(p);
    if (m) { const d = world.deployments[m[1]]; d.polls++; if (d.polls >= 2) d.readyState = world.buildFails ? 'ERROR' : 'READY'; return j(200, d); }
  }
  // ---- the licensee's app
  if (p === '/app/api/health') return world.healthy ? j(200, { ok: true }) : j(503, { ok: false });
  j(404, { error: { message: `no fake for ${req.method} ${p}` } });
}

let srv, base;
before(async () => {
  srv = http.createServer((req, res) => { let b = ''; req.on('data', (d) => (b += d)); req.on('end', () => { try { handle(req, res, b); } catch (e) { res.writeHead(500); res.end(String(e)); } }); });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${srv.address().port}`;
  process.env.PROVISION_SUPABASE_API = `${base}/sb`; process.env.PROVISION_VERCEL_API = `${base}/vc`; process.env.PROVISION_STRIPE_API = `${base}/stripe`;
  process.env.PROVISION_RETRY_MS = '5';
});
after(() => srv.close());

const ENV = () => ({ SUPABASE_ACCESS_TOKEN: 'sbp_fake', VERCEL_TOKEN: 'vc_fake', HARBOR_STRIPE_KEY: 'rk_test_licensee', HARBOR_RESEND_KEY: 're_fake', PROVISION_POLL_MS: '5', PROVISION_SUPABASE_AUTH: base, PROVISION_CHECK_BASE: `${base}/app` });
const lic = () => ({ ...example(), vercel: { ...example().vercel, teamId: 'team_test' } });
const tmp = () => fs.mkdtempSync(path.join(os.tmpdir(), 'prov-'));

test('the plan calls nothing, and the licensee file is checked first', async () => {
  const n = calls.length;
  const r = await provision(lic(), { statePath: path.join(tmp(), 's.json'), log: () => {} });
  assert.equal(r.applied, false);
  assert.deepEqual(r.plan.map(([k]) => k), STEPS);
  assert.equal(calls.length, n);
  assert.deepEqual(validateLicensee({ ...lic(), appDomain: 'not a domain', admin: '' }).length, 2);
  await assert.rejects(provision({ ...lic(), slug: 'Bad Slug' }, { statePath: 'x' }), /slug/);
  await assert.rejects(provision(lic(), { apply: true, env: {}, statePath: 'x' }), /SUPABASE_ACCESS_TOKEN, VERCEL_TOKEN, HARBOR_STRIPE_KEY, HARBOR_RESEND_KEY/);
});

test('a full run: database, auth, webhook, project, environment, domain, deploy, health, admin and fleet', async () => {
  const dir = tmp(), statePath = path.join(dir, 'harbor.state.json'), fleetPath = path.join(dir, 'fleet.json');
  const r = await provision(lic(), { apply: true, env: ENV(), statePath, fleetPath, log: () => {} });
  assert.ok(r.results.every((x) => x.ok), JSON.stringify(r.results.filter((x) => !x.ok)));
  // Supabase: project in the right org and region, every migration then the cohort, auth via Resend
  assert.equal(world.projects[0].body.organization_slug, 'your-supabase-org');
  assert.deepEqual(world.projects[0].body.region_selection, { type: 'specific', code: 'us-east-1' });
  const names = migrations().map((m) => m.name);
  assert.equal(world.sql.length, names.length + 2, 'migrations, the cohort, then the admin');
  assert.match(world.sql[names.length], /insert into cohorts .*'founding-01'/s);
  assert.equal(world.authCfg.site_url, 'https://app.harbor-learning.example');
  assert.equal(world.authCfg.smtp_admin_email, 'hello@harbor-learning.example');
  assert.equal(world.authCfg.smtp_sender_name, 'Harbor Learning');
  // Stripe: the webhook with exactly the events the back end handles
  assert.equal(world.webhooks[0].url, 'https://app.harbor-learning.example/api/stripe/webhook');
  assert.equal(world.webhooks[0].enabled_events.length, 6);
  // Vercel: project, environment, domain, deployment of the repo
  assert.deepEqual(world.vercelProjects['harbor-app'].gitRepository, { type: 'github', repo: 'your-org/cohort-backend' });
  assert.equal(world.vercelProjects['harbor-app'].rootDirectory, 'backend');
  assert.equal(world.env.NEXT_PUBLIC_SUPABASE_URL.value, 'https://abcdefghijklmnopqrst.supabase.co');
  assert.equal(world.env.SUPABASE_SERVICE_ROLE_KEY.value, 'eyJservice.fake');
  assert.equal(world.env.SUPABASE_SERVICE_ROLE_KEY.type, 'sensitive');
  assert.equal(world.env.STRIPE_WEBHOOK_SECRET.value, 'whsec_1');
  assert.equal(world.env.STRIPE_INVOICES.value, 'true');
  assert.match(world.env.IP_HASH_SALT.value, /^[0-9a-f]{64}$/);
  assert.equal(world.env.LICENSOR_REPORT_TOKEN.value, r.reportToken);
  assert.deepEqual(Object.values(world.deployments)[0].body.gitSource, { type: 'github', org: 'your-org', repo: 'cohort-backend', ref: 'main' });
  assert.equal(r.state.domain.verification[0].type, 'TXT');
  assert.deepEqual(world.users, ['founder@harbor-learning.example']);
  assert.match(world.sql.at(-1), /insert into admins/);
  // fleet.json gets them, with a token variable name, never the token
  const fleet = JSON.parse(fs.readFileSync(fleetPath, 'utf8'));
  assert.deepEqual(fleet.licensees[0], { name: 'Harbor Learning', url: 'https://app.harbor-learning.example', tokenEnv: 'FLEET_TOKEN_HARBOR', terms: { royaltyPerSeat: { currency: 'usd', amount: 25000 } } });
  // no key, secret or generated token anywhere on disk
  const disk = fs.readFileSync(statePath, 'utf8') + fs.readFileSync(fleetPath, 'utf8');
  for (const sec of ['eyJservice.fake', 'eyJanon.fake', 'whsec_1', 'rk_test_licensee', 're_fake', 'sbp_fake', 'vc_fake', r.reportToken, world.env.IP_HASH_SALT.value]) assert.ok(!disk.includes(sec), `${sec} on disk`);
});

test('running it again is safe: same project, same webhook, salts and tokens kept', async () => {
  const dir = tmp(), statePath = path.join(dir, 'harbor.state.json');
  const saltBefore = world.env.IP_HASH_SALT.value, tokenBefore = world.env.LICENSOR_REPORT_TOKEN.value;
  // the state from the first run lives elsewhere: this run must find what exists by name
  let r = await provision(lic(), { apply: true, env: ENV(), statePath, fleetPath: path.join(dir, 'f.json'), log: () => {} });
  assert.ok(r.results.every((x) => x.ok), JSON.stringify(r.results.filter((x) => !x.ok)));
  assert.equal(world.projects.length, 1);
  assert.equal(world.env.IP_HASH_SALT.value, saltBefore);
  assert.equal(world.env.LICENSOR_REPORT_TOKEN.value, tokenBefore);
  assert.equal(r.reportToken, null);
  assert.equal(world.webhooks.length, 1);
  assert.equal(world.webhooks[0].id, 'we_2', 'a webhook whose secret wasn\'t delivered in this state is replaced, not left without a secret');
  assert.equal(world.env.STRIPE_WEBHOOK_SECRET.value, 'whsec_2');
  // and with that state, a third run leaves the webhook alone
  r = await provision(lic(), { apply: true, env: ENV(), statePath, fleetPath: path.join(dir, 'f.json'), log: () => {} });
  assert.equal(world.webhooks[0].id, 'we_2');
  assert.equal(world.env.STRIPE_WEBHOOK_SECRET.value, 'whsec_2');
});

test('a failed build or health check stops the run and is recorded; --only resumes', async () => {
  const dir = tmp(), statePath = path.join(dir, 's.json');
  world.buildFails = true;
  let r = await provision(lic(), { apply: true, env: ENV(), statePath, fleetPath: path.join(dir, 'f.json'), only: 'vercel,deploy,check', log: () => {} });
  assert.deepEqual(r.results.map((x) => [x.step, x.ok]), [['vercel', true], ['deploy', false]]);
  assert.match(r.results[1].msg, /the build ended ERROR/);
  world.buildFails = false; world.healthy = false;
  r = await provision(lic(), { apply: true, env: ENV(), statePath, fleetPath: path.join(dir, 'f.json'), only: 'deploy,check', log: () => {} });
  assert.deepEqual(r.results.map((x) => [x.step, x.ok]), [['deploy', true], ['check', false]]);
  world.healthy = true;
  r = await provision(lic(), { apply: true, env: ENV(), statePath, fleetPath: path.join(dir, 'f.json'), only: 'check', log: () => {} });
  assert.ok(r.results[0].ok);
  // steps that need keys refuse to run without reading them in the same run
  r = await provision(lic(), { apply: true, env: ENV(), statePath, fleetPath: path.join(dir, 'f.json'), only: 'env', log: () => {} });
  assert.match(r.results[0].msg, /run the "keys" step in the same run/);
  await assert.rejects(provision(lic(), { apply: true, env: ENV(), statePath, only: 'teleport' }), /Unknown step: teleport/);
});

test('cohort SQL escapes what the licensee typed', () => {
  const l = lic(); l.cohort.name = "O'Brien's cohort'); drop table members; --";
  const s = cohortSql(l);
  assert.match(s, /'O''Brien''s cohort''\); drop table members; --'/);
  assert.equal((s.match(/insert into/g) || []).length, 2);
});
