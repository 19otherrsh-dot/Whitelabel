// Fleet console tests: two stand-in licensee sites on localhost, one healthy and one misconfigured.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { amountDue, buildFleet, toCsv, toHtml, currentQuarter } from '../fleet.mjs';

const report = (over = {}) => ({
  format: 'licensee-report/1', brand: 'A', period: { label: '2026-Q3' }, kitVersion: '1.2.0',
  seatsSold: { founding: 9, vip: 1 }, seatsRefunded: { total: 1, coolingOff: 1, guarantee: 0, other: 0 },
  revenue: { usd: { gross: 1647000, refunded: 149700, net: 1497300 } },
  cohorts: [{ slug: 'c', name: 'C', averageAttendance: 0.8 }], leads: { audit: 30, waitlist: 5 },
  support: { opened: 4, open: 1 }, refundRequests: { open: 0 }, kitDownloads: 9, ...over,
});

test('royalty per paid seat, refunds credited; revenue share on net', () => {
  assert.deepEqual(amountDue({ royaltyPerSeat: { currency: 'usd', amount: 25000 } }, report()), { paidSeats: 9, due: { usd: 225000 } });
  assert.deepEqual(amountDue({ revenueSharePct: 10 }, report()).due, { usd: 149730 });
  assert.deepEqual(amountDue({}, report()).due, {});
  assert.match(currentQuarter(new Date('2026-02-01T00:00:00Z')), /^2026-Q1$/);
});

test('fetches each licensee with its own token; failures are shown, not hidden', async () => {
  const seen = [];
  const srv = http.createServer((req, res) => {
    seen.push({ url: req.url, auth: req.headers.authorization });
    if (req.url === '/api/health') { res.writeHead(200); return res.end('{"ok":true}'); }
    if (req.url.startsWith('/api/licensor/report')) {
      if (req.headers.authorization !== 'Bearer good-token') { res.writeHead(401); return res.end('{}'); }
      res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(report()));
    }
    res.writeHead(404); res.end();
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const url = `http://127.0.0.1:${srv.address().port}`;
  const fleet = await buildFleet({ licensor: 'L', licensees: [
    { name: 'Good <School>', url, tokenEnv: 'T1', terms: { royaltyPerSeat: { currency: 'usd', amount: 25000 } } },
    { name: '=Bad', url, tokenEnv: 'T2' },
    { name: 'No token', url, tokenEnv: 'T3' },
    { name: 'Plain http', url: 'http://example.test', tokenEnv: 'T1' },
  ] }, '2026-Q3', { env: { T1: 'good-token', T2: 'wrong' } });
  srv.close();
  assert.equal(fleet.totals.ok, 1); assert.equal(fleet.totals.failing, 3);
  assert.equal(fleet.rows[1].error, 'token refused');
  assert.match(fleet.rows[2].error, /set the environment variable T3/);
  assert.match(fleet.rows[3].error, /https/);
  assert.deepEqual(fleet.totals.due, { usd: 225000 });
  assert.ok(seen.some((s) => s.url === '/api/licensor/report?quarter=2026-Q3' && s.auth === 'Bearer good-token'));
  const html = toHtml(fleet);
  assert.match(html, /Good &lt;School&gt;/); assert.doesNotMatch(html, /<School>/);
  assert.match(html, /\$2,250\.00/);
  const csv = toCsv(fleet);
  assert.match(csv, /"'=Bad"/, 'spreadsheet formulas are neutralised');
  assert.doesNotMatch(html + csv, /good-token/);
});

test('live console: local only, refreshes, keeps uptime and shows setup progress', async () => {
  const { serveFleet } = await import('../fleet.mjs');
  const fs = await import('node:fs'); const os = await import('node:os'); const path = await import('node:path');
  let healthy = true;
  const site = http.createServer((req, res) => {
    if (req.url === '/api/health') { res.writeHead(healthy ? 200 : 503); return res.end('{}'); }
    res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(report()));
  });
  await new Promise((r) => site.listen(0, '127.0.0.1', r));
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'fleet-'));
  const url = `http://127.0.0.1:${site.address().port}`;
  fs.writeFileSync(path.join(dir, 'fleet.json'), JSON.stringify({ licensor: 'L', licensees: [{ name: 'Live <One>', url, tokenEnv: 'FLEET_TOKEN_LIVE', terms: { revenueSharePct: 10 } }] }));
  fs.mkdirSync(path.join(dir, 'licensees'));
  fs.writeFileSync(path.join(dir, 'licensees', 'harbor.state.json'), JSON.stringify({ slug: 'harbor', done: { supabase: 'x', database: 'y' }, domain: { name: 'app.h.example', verified: false } }));
  process.env.FLEET_TOKEN_LIVE = 'tok';
  const s = await serveFleet({ configPath: path.join(dir, 'fleet.json'), quarter: '2026-Q3', port: 0, every: 60, out: dir, licenseesDir: path.join(dir, 'licensees'), log: () => {} });
  try {
    const page = await (await fetch(`http://127.0.0.1:${s.port}/`)).text();
    assert.match(page, /Live &lt;One&gt;/);
    assert.match(page, /Refresh now/);
    assert.match(page, /harbor<\/b><\/td><td>supabase, database/);
    assert.match(page, /DNS needed/);
    healthy = false;
    const r = await fetch(`http://127.0.0.1:${s.port}/refresh`, { method: 'POST', redirect: 'manual' });
    assert.equal(r.status, 303);
    const j = await (await fetch(`http://127.0.0.1:${s.port}/fleet.json`)).json();
    assert.deepEqual({ checks: j.uptime[url].checks, ok: j.uptime[url].ok }, { checks: 2, ok: 1 });
    assert.ok(fs.readFileSync(path.join(dir, 'health.jsonl'), 'utf8').trim().split('\n').length === 2);
    // another site in the browser can't use it
    assert.equal((await fetch(`http://127.0.0.1:${s.port}/refresh`, { method: 'POST', headers: { Origin: 'https://evil.example' } })).status, 403);
    const code = await new Promise((r) => http.get({ host: '127.0.0.1', port: s.port, path: '/', headers: { Host: 'fleet.evil.example' } }, (res) => { res.resume(); r(res.statusCode); }));
    assert.equal(code, 421, 'DNS-rebinding: only localhost names are answered');
  } finally { s.stop(); site.close(); }
});
