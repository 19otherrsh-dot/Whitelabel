// Signing a release zip: the signed kit verifies, and a file changed after the build is refused.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
// Needs a copy of the kit next to this folder (../kit), or KIT_DIR pointing at one.
const KIT = [process.env.KIT_DIR, path.join(here, '..', '..', 'kit')].find((d) => d && fs.existsSync(path.join(d, 'bin', 'lib', 'signing.mjs')));
function freshKit() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'kit-copy-'));
  for (const e of fs.readdirSync(KIT)) if (!['runs', 'outbox', 'output', 'data', 'clients', '.git', '.wf', 'node_modules', 'runtime', '_dotclaude'].includes(e)) fs.cpSync(path.join(KIT, e), path.join(dir, e), { recursive: true });
  return dir;
}
const SIGN = path.join(here, '..', 'sign-release.mjs');
const run = (args) => spawnSync(process.execPath, [SIGN, ...args], { encoding: 'utf8' });

test('signs a release zip that the kit then trusts', { skip: !KIT && 'no kit found (set KIT_DIR)' }, async () => {
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'sign-test-'));
  const rel = path.join(work, 'workforce-kit-1.0.0');
  fs.cpSync(freshKit(), rel, { recursive: true });
  const { buildManifest } = await import(path.join(rel, 'bin', 'lib', 'maintain.mjs'));
  fs.writeFileSync(path.join(rel, 'setup', 'kit-manifest.json'), JSON.stringify(buildManifest(rel, '1.0.0'), null, 2) + '\n');
  assert.equal(spawnSync('zip', ['-qr', '-X', 'workforce-kit-1.0.0.zip', 'workforce-kit-1.0.0'], { cwd: work }).status, 0);

  assert.equal(run(['new-key', path.join(work, 'keys')]).status, 0);
  assert.notEqual(run(['new-key', path.join(work, 'keys')]).status, 0, 'never overwrites a key');
  const r = run([path.join(work, 'workforce-kit-1.0.0.zip'), '--key', path.join(work, 'keys', 'kit-signing-key.private.pem')]);
  assert.equal(r.status, 0, r.stderr);
  const out = path.join(work, 'check');
  assert.equal(spawnSync('unzip', ['-q', path.join(work, 'workforce-kit-1.0.0-signed.zip'), '-d', out]).status, 0);
  const { checkSignature } = await import(path.join(rel, 'bin', 'lib', 'signing.mjs'));
  assert.deepEqual(checkSignature(path.join(out, 'workforce-kit-1.0.0')), { signed: true, valid: true, reason: 'signature valid' });
  assert.equal(fs.readFileSync(path.join(out, 'workforce-kit-1.0.0', 'setup', 'kit-signing-key.pem'), 'utf8'), fs.readFileSync(path.join(work, 'keys', 'kit-signing-key.pem'), 'utf8'));

  fs.appendFileSync(path.join(rel, 'docs', 'cli.md'), 'changed after the build');
  const bad = run([rel, '--key', path.join(work, 'keys', 'kit-signing-key.private.pem')]);
  assert.notEqual(bad.status, 0); assert.match(bad.stderr, /docs\/cli\.md changed/);
});
