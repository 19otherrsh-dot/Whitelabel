#!/usr/bin/env node
// Set up a new licensee's back end from one file, through the Supabase, Stripe and Vercel APIs.
//
//   node provision.mjs licensees/harbor.json              plan only: shows every step, calls nothing
//   node provision.mjs licensees/harbor.json --apply      does it (safe to run again; finished steps are skipped)
//   node provision.mjs licensees/harbor.json --apply --only deploy,check
//
// Steps: Supabase project → database (all migrations + their first cohort) → sign-in emails and redirect
// URLs → API keys → Stripe webhook (in the licensee's own Stripe account) → Vercel project → environment
// → domain → deploy → health check → first admin → fleet.json entry.
//
// Keys come from environment variables named in the licensee file or below, never from the file itself:
//   SUPABASE_ACCESS_TOKEN  your Supabase personal access token (account → Access Tokens)
//   VERCEL_TOKEN           your Vercel token (account → Tokens)
//   <stripe.keyEnv>        the licensee's Stripe secret or restricted key (webhooks write + read)
//   <resend.keyEnv>        the licensee's Resend API key (sign-in emails and the app's email)
// Nothing secret is written to disk: generated values (hash salt, cron secret, report token) go straight
// into the Vercel project; the report token is printed once for your fleet console.
// Progress (ids, URLs, DNS records, never keys) is kept in licensees/<slug>.state.json. No dependencies.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BACKEND = process.env.PROVISION_BACKEND_DIR || path.resolve(HERE, '../backend');
// Read when called, so a test (or a proxy) can point them elsewhere.
const API = {
  get supabase() { return process.env.PROVISION_SUPABASE_API || 'https://api.supabase.com'; },
  get vercel() { return process.env.PROVISION_VERCEL_API || 'https://api.vercel.com'; },
  get stripe() { return process.env.PROVISION_STRIPE_API || 'https://api.stripe.com'; },
};
const WEBHOOK_EVENTS = ['checkout.session.completed', 'checkout.session.async_payment_succeeded', 'checkout.session.async_payment_failed', 'checkout.session.expired', 'charge.refunded', 'charge.dispute.created'];
export const STEPS = ['supabase', 'database', 'auth', 'keys', 'stripe', 'vercel', 'env', 'domain', 'deploy', 'check', 'admin', 'fleet'];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------- the licensee file ----------
export function validateLicensee(l) {
  const errs = [];
  const need = (cond, msg) => { if (!cond) errs.push(msg); };
  need(/^[a-z0-9][a-z0-9-]{1,40}$/.test(l.slug || ''), 'slug: lowercase letters, digits and dashes (e.g. "harbor")');
  need(l.brandName, 'brandName');
  need(/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(l.appDomain || ''), 'appDomain: e.g. app.harbor-learning.com');
  need(/^https:\/\//.test(l.siteUrl || ''), 'siteUrl: the marketing site, https://…');
  need(/@/.test(l.supportEmail || ''), 'supportEmail');
  need(/@/.test(l.emailFrom || ''), 'emailFrom: e.g. "Harbor <hello@harbor-learning.com>"');
  need(/@/.test(l.admin || ''), 'admin: the email of their first admin');
  need(l.supabase?.organizationSlug, 'supabase.organizationSlug (Supabase → organization settings)');
  need(l.vercel?.repo && /^[\w.-]+\/[\w.-]+$/.test(l.vercel.repo), 'vercel.repo: "your-org/your-backend-repo"');
  need(l.stripe?.keyEnv, 'stripe.keyEnv: the environment variable holding their Stripe key');
  need(l.resend?.keyEnv, 'resend.keyEnv: the environment variable holding their Resend key');
  const c = l.cohort || {};
  need(/^[a-z0-9-]{2,60}$/.test(c.slug || ''), 'cohort.slug');
  need(c.name, 'cohort.name');
  need(Number.isInteger(c.priceFounding) && c.priceFounding > 0, 'cohort.priceFounding in minor units (149700 = 1,497.00)');
  need(/^[a-z]{3}$/i.test(l.currency || ''), 'currency: e.g. usd');
  for (const [i, s] of (c.sessions || []).entries()) need(s.title && !Number.isNaN(Date.parse(s.start)) && !Number.isNaN(Date.parse(s.end)) && Date.parse(s.end) > Date.parse(s.start), `cohort.sessions[${i}]: title, start, end (ISO with offset)`);
  return errs;
}

const lit = (v) => (v == null ? 'null' : typeof v === 'number' ? String(v) : `'${String(v).replace(/'/g, "''")}'`);
/** Their first cohort and its sessions, as SQL (safe to re-run). */
export function cohortSql(l) {
  const c = l.cohort;
  const rows = [`insert into cohorts (slug, name, seats, vip_seats, price_founding, price_vip, currency, enrollment_closes, time_zone, support_days, library_months, self_paced)
values (${lit(c.slug)}, ${lit(c.name)}, ${Number(c.seats ?? 50)}, ${Number(c.vipSeats ?? 0)}, ${Number(c.priceFounding)}, ${Number(c.priceVip ?? 0)}, ${lit(String(l.currency).toLowerCase())}, ${c.enrollmentCloses ? `${lit(new Date(c.enrollmentCloses).toISOString())}::timestamptz` : 'null'}, ${lit(l.timeZone || 'America/New_York')}, ${Number(c.supportDays ?? 90)}, ${Number(c.libraryMonths ?? 12)}, ${c.selfPaced ? 'true' : 'false'})
on conflict (slug) do nothing;`];
  if ((c.sessions || []).length) rows.push(`with c as (select id from cohorts where slug = ${lit(c.slug)})
insert into cohort_sessions (cohort_id, position, title, starts_at, ends_at)
select c.id, s.position, s.title, s.starts_at::timestamptz, s.ends_at::timestamptz from c, (values
${c.sessions.map((s, i) => `  (${i + 1}, ${lit(s.title)}, ${lit(new Date(s.start).toISOString())}, ${lit(new Date(s.end).toISOString())})`).join(',\n')}
) as s(position, title, starts_at, ends_at)
on conflict (cohort_id, position) do nothing;`);
  return rows.join('\n\n');
}

export function migrations(dir = BACKEND) {
  const d = path.join(dir, 'supabase', 'migrations');
  return fs.readdirSync(d).filter((f) => /^\d{4}_.+\.sql$/.test(f)).sort().map((f) => ({ name: f, sql: fs.readFileSync(path.join(d, f), 'utf8') }));
}

/** The app's environment, from the licensee file and what earlier steps produced. */
export function envFor(l, s) {
  const app = `https://${l.appDomain}`;
  return {
    APP_URL: app, SITE_URL: l.siteUrl.replace(/\/$/, ''), ALLOWED_ORIGINS: [l.siteUrl.replace(/\/$/, ''), ...(l.extraOrigins || [])].join(','),
    BRAND_NAME: l.brandName, SUPPORT_EMAIL: l.supportEmail, EMAIL_FROM: l.emailFrom, DEFAULT_COHORT: l.cohort.slug,
    NEXT_PUBLIC_SUPABASE_URL: `https://${s.supabase.ref}.supabase.co`,
    ...(l.stripeInvoices ? { STRIPE_INVOICES: 'true' } : {}), ...(l.bookingUrl ? { BOOKING_URL: l.bookingUrl } : {}), ...(l.communityUrl ? { COMMUNITY_URL: l.communityUrl } : {}),
    ...(l.courseName ? { COURSE_NAME: l.courseName } : {}),
  };
}

// ---------- HTTP ----------
export function client(fetchImpl = globalThis.fetch) {
  return async function call(service, pathAndQuery, { method = 'GET', token, json, form, headers = {}, okStatuses = [] } = {}) {
    const url = /^https?:/.test(pathAndQuery) ? pathAndQuery : API[service] + pathAndQuery;
    const h = { accept: 'application/json', ...headers };
    if (token) h.authorization = `Bearer ${token}`;
    let body;
    if (json !== undefined) { body = JSON.stringify(json); h['content-type'] = 'application/json'; }
    if (form) { body = form instanceof URLSearchParams ? form.toString() : new URLSearchParams(form).toString(); h['content-type'] = 'application/x-www-form-urlencoded'; }
    for (let attempt = 0; ; attempt++) {
      const res = await fetchImpl(url, { method, headers: h, body });
      if ((res.status === 429 || res.status >= 500) && attempt < 3 && !okStatuses.includes(res.status)) { await sleep(Number(process.env.PROVISION_RETRY_MS || 2000) * (attempt + 1)); continue; }
      const text = await res.text();
      let data = null; try { data = text ? JSON.parse(text) : null; } catch { data = text; }
      if (!res.ok && !okStatuses.includes(res.status)) {
        const msg = data?.error?.message || data?.message || data?.msg || (typeof data === 'string' ? data.slice(0, 200) : JSON.stringify(data).slice(0, 200));
        const e = new Error(`${service} ${method} ${pathAndQuery.split('?')[0]} → ${res.status}: ${msg}`); e.status = res.status; e.data = data; throw e;
      }
      return { status: res.status, data };
    }
  };
}

// ---------- the steps ----------
function stepsFor(l, s, env, call, log, opts) {
  const sbTok = env.SUPABASE_ACCESS_TOKEN, vTok = env.VERCEL_TOKEN;
  const team = l.vercel?.teamId ? `teamId=${encodeURIComponent(l.vercel.teamId)}` : '';
  const q = (p) => (team ? `${p}${p.includes('?') ? '&' : '?'}${team}` : p);
  const projectName = l.vercel?.projectName || `${l.slug}-app`;
  const sbName = l.supabase?.projectName || `${l.slug}-app`;
  const sql = (query) => call('supabase', `/v1/projects/${s.supabase.ref}/database/query`, { method: 'POST', token: sbTok, json: { query } });
  const poll = async (fn, done, { every = Number(env.PROVISION_POLL_MS || 10000), max = 90 } = {}) => { for (let i = 0; i < max; i++) { const v = await fn(); if (done(v)) return v; await sleep(every); } throw new Error('timed out waiting'); };
  const keysFresh = () => s.keys && opts.secrets.anon && opts.secrets.service;

  return {
    async supabase() {
      if (s.supabase?.ref) return `already created (${s.supabase.ref})`;
      const list = (await call('supabase', '/v1/projects', { token: sbTok })).data || [];
      let p = list.find((x) => x.name === sbName);
      if (!p) {
        const json = { name: sbName, organization_slug: l.supabase.organizationSlug, db_pass: crypto.randomBytes(24).toString('base64url') };
        if (l.supabase.region) json.region_selection = { type: 'specific', code: l.supabase.region };
        p = (await call('supabase', '/v1/projects', { method: 'POST', token: sbTok, json })).data;
        log(`  created Supabase project ${p.ref || p.id}; waiting for it to come up (a few minutes)…`);
      }
      const ref = p.ref || p.id;
      await poll(async () => (await call('supabase', `/v1/projects/${ref}`, { token: sbTok })).data, (x) => x?.status === 'ACTIVE_HEALTHY');
      s.supabase = { ref, name: sbName };
      return `ready (${ref})`;
    },
    async database() {
      for (const m of migrations(opts.backendDir)) { await sql(m.sql); log(`  ran ${m.name}`); }
      await sql(cohortSql(l));
      s.database = { migrations: migrations(opts.backendDir).map((m) => m.name), cohort: l.cohort.slug };
      return `${s.database.migrations.length} migrations and cohort "${l.cohort.slug}"`;
    },
    async auth() {
      const from = /<([^>]+)>/.exec(l.emailFrom)?.[1] || l.emailFrom;
      const name = /^([^<]+)</.exec(l.emailFrom)?.[1]?.trim() || l.brandName;
      await call('supabase', `/v1/projects/${s.supabase.ref}/config/auth`, { method: 'PATCH', token: sbTok, json: {
        site_url: `https://${l.appDomain}`, uri_allow_list: `https://${l.appDomain}/**`,
        smtp_host: 'smtp.resend.com', smtp_port: '465', smtp_user: 'resend', smtp_pass: env[l.resend.keyEnv], smtp_admin_email: from, smtp_sender_name: name,
      } });
      s.auth = { siteUrl: `https://${l.appDomain}`, smtp: 'resend' };
      return 'sign-in links go to the app and are sent from their domain';
    },
    async keys() {
      const list = (await call('supabase', `/v1/projects/${s.supabase.ref}/api-keys?reveal=true`, { token: sbTok })).data || [];
      const anon = list.find((k) => k.name === 'anon')?.api_key, service = list.find((k) => k.name === 'service_role')?.api_key;
      if (!anon || !service) throw new Error('could not read the anon and service_role keys (does the token have api_gateway_keys_read?)');
      opts.secrets.anon = anon; opts.secrets.service = service;                    // memory only
      s.keys = { read: new Date().toISOString() };
      return 'read (kept in memory for the next steps only)';
    },
    async stripe() {
      const key = env[l.stripe.keyEnv];
      const url = `https://${l.appDomain}/api/stripe/webhook`;
      const existing = ((await call('stripe', '/v1/webhook_endpoints?limit=100', { token: key })).data?.data || []).find((w) => w.url === url);
      if (existing && s.stripe?.secretDelivered) return `webhook already set up (${existing.id})`;
      if (existing) await call('stripe', `/v1/webhook_endpoints/${existing.id}`, { method: 'DELETE', token: key });   // its secret can't be read again: replace it
      const form = new URLSearchParams({ url, description: `${l.brandName} cohort back end` });
      for (const e of WEBHOOK_EVENTS) form.append('enabled_events[]', e);
      const w = (await call('stripe', '/v1/webhook_endpoints', { method: 'POST', token: key, form })).data;
      opts.secrets.webhook = w.secret;
      s.stripe = { webhookId: w.id, events: WEBHOOK_EVENTS, secretDelivered: false };
      return `webhook ${w.id} → ${url}`;
    },
    async vercel() {
      if (s.vercel?.projectId) return `already created (${s.vercel.projectId})`;
      const got = await call('vercel', q(`/v9/projects/${encodeURIComponent(projectName)}`), { token: vTok, okStatuses: [404] });
      let p = got.status === 404 ? null : got.data;
      if (!p) p = (await call('vercel', q('/v11/projects'), { method: 'POST', token: vTok, json: { name: projectName, framework: 'nextjs', rootDirectory: l.vercel.rootDirectory ?? 'backend', gitRepository: { type: 'github', repo: l.vercel.repo } } })).data;
      s.vercel = { projectId: p.id, name: projectName };
      return `project ${p.id}`;
    },
    async env() {
      if (!keysFresh()) throw new Error('run the "keys" step in the same run (the keys are never stored): use --only keys,stripe,env');
      const have = new Set(((await call('vercel', q(`/v9/projects/${s.vercel.projectId}/env`), { token: vTok })).data?.envs || []).map((e) => e.key));
      const plain = envFor(l, s);
      const secret = {
        NEXT_PUBLIC_SUPABASE_ANON_KEY: opts.secrets.anon, SUPABASE_SERVICE_ROLE_KEY: opts.secrets.service,
        STRIPE_SECRET_KEY: env[l.stripe.keyEnv], RESEND_API_KEY: env[l.resend.keyEnv],
        ...(opts.secrets.webhook ? { STRIPE_WEBHOOK_SECRET: opts.secrets.webhook } : {}),
      };
      let reportToken = null;
      for (const [k, gen] of [['IP_HASH_SALT', 32], ['CRON_SECRET', 32], ['LICENSOR_REPORT_TOKEN', 32]]) if (!have.has(k)) { secret[k] = crypto.randomBytes(gen).toString('hex'); if (k === 'LICENSOR_REPORT_TOKEN') reportToken = secret[k]; }
      if (!opts.secrets.webhook && !have.has('STRIPE_WEBHOOK_SECRET')) throw new Error('no Stripe webhook secret: run the "stripe" step in the same run');
      const items = [
        ...Object.entries(plain).map(([key, value]) => ({ key, value: String(value), type: key.startsWith('NEXT_PUBLIC_') ? 'plain' : 'encrypted', target: ['production', 'preview'] })),
        ...Object.entries(secret).map(([key, value]) => ({ key, value: String(value), type: key.startsWith('NEXT_PUBLIC_') ? 'encrypted' : 'sensitive', target: ['production'] })),
      ];
      await call('vercel', q(`/v10/projects/${s.vercel.projectId}/env?upsert=true`), { method: 'POST', token: vTok, json: items });
      if (opts.secrets.webhook && s.stripe) s.stripe.secretDelivered = true;
      if (reportToken) opts.reportToken = reportToken;
      s.env = { keys: items.map((i) => i.key).sort(), set: new Date().toISOString() };
      return `${items.length} variables${reportToken ? ' (report token generated: printed at the end)' : ''}`;
    },
    async domain() {
      const r = await call('vercel', q(`/v10/projects/${s.vercel.projectId}/domains`), { method: 'POST', token: vTok, json: { name: l.appDomain }, okStatuses: [400, 409] });
      let d = r.data;
      if (r.status !== 200) d = (await call('vercel', q(`/v9/projects/${s.vercel.projectId}/domains/${l.appDomain}`), { token: vTok })).data;
      s.domain = { name: l.appDomain, verified: !!d?.verified, verification: d?.verification || [], dns: `CNAME ${l.appDomain} → cname.vercel-dns.com (or the A record Vercel shows for an apex domain)` };
      return d?.verified ? 'added and verified' : 'added: DNS records needed (see the summary)';
    },
    async deploy() {
      const [org, repo] = l.vercel.repo.split('/');
      const d = (await call('vercel', q('/v13/deployments'), { method: 'POST', token: vTok, json: { name: projectName, project: s.vercel.projectId, target: 'production', gitSource: { type: 'github', org, repo, ref: l.vercel.ref || 'main' } } })).data;
      log(`  building ${d.url || d.id}…`);
      const fin = await poll(async () => (await call('vercel', q(`/v13/deployments/${d.id}`), { token: vTok })).data, (x) => ['READY', 'ERROR', 'CANCELED'].includes(x?.readyState), { max: 120 });
      if (fin.readyState !== 'READY') throw new Error(`the build ended ${fin.readyState}: open it in Vercel to see the log (${d.id})`);
      s.deploy = { id: d.id, url: `https://${fin.url || d.url}`, at: new Date().toISOString() };
      return `live at ${s.deploy.url}`;
    },
    async check() {
      const bases = env.PROVISION_CHECK_BASE ? [env.PROVISION_CHECK_BASE] : [s.domain?.verified ? `https://${l.appDomain}` : null, s.deploy?.url].filter(Boolean);
      for (const b of bases) {
        const r = await call('vercel', `${b}/api/health`, { okStatuses: [401, 404, 500, 503] }).catch((e) => ({ status: 0, data: e.message }));
        if (r.status === 200 && r.data?.ok) { s.check = { url: b, ok: true, at: new Date().toISOString() }; return `${b}/api/health is ok`; }
      }
      s.check = { ok: false, at: new Date().toISOString() };
      throw new Error(`health check failed on ${bases.join(' and ')} (if the app deployment is protected, allow /api/health or check it by hand)`);
    },
    async admin() {
      if (!keysFresh()) throw new Error('run the "keys" step in the same run: use --only keys,admin');
      const base = `https://${s.supabase.ref}.supabase.co`;
      const authBase = env.PROVISION_SUPABASE_AUTH || base;
      const h = { apikey: opts.secrets.service };
      const r = await call('supabase', `${authBase}/auth/v1/admin/users`, { method: 'POST', token: opts.secrets.service, headers: h, json: { email: l.admin, email_confirm: true }, okStatuses: [409, 422] });
      await sql(`insert into members (id, email) select id, email from auth.users where lower(email) = lower(${lit(l.admin)}) on conflict (id) do nothing;
insert into admins (user_id) select id from auth.users where lower(email) = lower(${lit(l.admin)}) on conflict do nothing;`);
      s.admin = { email: l.admin, created: r.status === 200 || r.status === 201 };
      return `${l.admin} is an admin (they sign in with an email link at https://${l.appDomain}/login)`;
    },
    async fleet() {
      const f = opts.fleetPath;
      const cfg = fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : { licensor: '', licensees: [] };
      const url = `https://${l.appDomain}`;
      const tokenEnv = `FLEET_TOKEN_${l.slug.toUpperCase().replace(/-/g, '_')}`;
      if (!cfg.licensees.some((x) => x.url === url)) { cfg.licensees.push({ name: l.brandName, url, tokenEnv, terms: l.terms || {} }); fs.writeFileSync(f, JSON.stringify(cfg, null, 2) + '\n'); }
      s.fleet = { tokenEnv };
      return `in ${path.basename(f)} (token from ${tokenEnv})`;
    },
  };
}

/** What each step would call: the dry-run plan. */
export function plan(l) {
  return [
    ['supabase', `create Supabase project "${l.supabase?.projectName || `${l.slug}-app`}" in ${l.supabase?.region || 'the default region'} (organization ${l.supabase?.organizationSlug}) and wait until it is healthy`],
    ['database', `run ${migrations().length} migrations (${migrations().map((m) => m.name).join(', ')}) and create cohort "${l.cohort?.slug}" with ${(l.cohort?.sessions || []).length} sessions`],
    ['auth', `sign-in links to https://${l.appDomain}, sent through Resend from ${l.emailFrom}`],
    ['keys', 'read the project\'s anon and service-role keys (memory only)'],
    ['stripe', `create a webhook in their Stripe account to https://${l.appDomain}/api/stripe/webhook (${WEBHOOK_EVENTS.length} events)`],
    ['vercel', `create Vercel project "${l.vercel?.projectName || `${l.slug}-app`}" from ${l.vercel?.repo} (root ${l.vercel?.rootDirectory ?? 'backend'})`],
    ['env', `set ${Object.keys(envFor(l, { supabase: { ref: 'REF' } })).length} settings and 8 secrets (Supabase, Stripe, Resend; hash salt, cron secret and report token generated)`],
    ['domain', `add ${l.appDomain} to the project and list the DNS records to create`],
    ['deploy', `deploy ${l.vercel?.repo}@${l.vercel?.ref || 'main'} to production and wait for the build`],
    ['check', `GET https://${l.appDomain}/api/health`],
    ['admin', `create ${l.admin} as their first admin`],
    ['fleet', 'add them to fleet.json for the fleet console'],
  ];
}

export async function provision(l, { apply = false, only, env = process.env, fetchImpl, statePath, fleetPath = path.join(HERE, 'fleet.json'), backendDir = BACKEND, log = console.log } = {}) {
  const errs = validateLicensee(l);
  if (errs.length) throw new Error(`The licensee file needs: ${errs.join('; ')}`);
  const want = only ? only.split(',').map((x) => x.trim()) : STEPS;
  const unknown = want.filter((x) => !STEPS.includes(x)); if (unknown.length) throw new Error(`Unknown step: ${unknown.join(', ')}. Steps: ${STEPS.join(', ')}`);
  if (!apply) return { applied: false, plan: plan(l).filter(([k]) => want.includes(k)) };
  const needEnv = ['SUPABASE_ACCESS_TOKEN', 'VERCEL_TOKEN', l.stripe.keyEnv, l.resend.keyEnv].filter((k) => !env[k]);
  if (needEnv.length) throw new Error(`Set these environment variables first: ${needEnv.join(', ')}`);
  const s = fs.existsSync(statePath) ? JSON.parse(fs.readFileSync(statePath, 'utf8')) : { slug: l.slug, done: {} };
  const opts = { secrets: {}, fleetPath, backendDir };
  const steps = stepsFor(l, s, env, client(fetchImpl), log, opts);
  const save = () => { fs.mkdirSync(path.dirname(statePath), { recursive: true }); fs.writeFileSync(statePath, JSON.stringify(s, null, 2) + '\n'); };
  const results = [];
  for (const name of want) {
    // keys and webhook secrets are never stored, so steps that need them pull "keys"/"stripe" into the same run
    try {
      log(`→ ${name}`);
      const msg = await steps[name]();
      s.done[name] = new Date().toISOString();
      results.push({ step: name, ok: true, msg }); log(`  ✓ ${msg}`);
      save();
    } catch (e) {
      results.push({ step: name, ok: false, msg: e.message }); log(`  ✗ ${e.message}`);
      save();
      break;
    }
  }
  return { applied: true, results, state: s, reportToken: opts.reportToken || null };
}

async function main() {
  const argv = process.argv.slice(2);
  const file = argv.find((a) => !a.startsWith('--'));
  const flag = (n) => argv.includes(`--${n}`);
  const val = (n) => { const i = argv.indexOf(`--${n}`); return i > -1 ? argv[i + 1] : undefined; };
  if (!file) { console.error('Usage: node provision.mjs licensees/<slug>.json [--apply] [--only step,step]\nStart from licensees/example.json.'); process.exit(1); }
  const l = JSON.parse(fs.readFileSync(file, 'utf8'));
  const statePath = path.join(path.dirname(path.resolve(file)), `${l.slug}.state.json`);
  try {
    const r = await provision(l, { apply: flag('apply'), only: val('only'), statePath, fleetPath: path.resolve(val('fleet') || path.join(HERE, 'fleet.json')) });
    if (!r.applied) {
      console.log(`Plan for ${l.brandName} (nothing has been called):\n`);
      for (const [k, v] of r.plan) console.log(`  ${k.padEnd(9)} ${v}`);
      return console.log('\nRun again with --apply to do it.');
    }
    const s = r.state;
    console.log(`\n${r.results.every((x) => x.ok) ? 'Done' : 'Stopped'}: ${r.results.filter((x) => x.ok).length} of ${r.results.length} steps. Progress is in ${path.relative(process.cwd(), statePath)} (no keys in it).`);
    if (s.domain && !s.domain.verified) { console.log(`\nDNS for ${s.domain.name}: ${s.domain.dns}`); for (const v of s.domain.verification) console.log(`  ${v.type} ${v.domain} → ${v.value}`); }
    if (r.reportToken) console.log(`\nFleet console token (shown once): export ${s.fleet?.tokenEnv || `FLEET_TOKEN_${l.slug.toUpperCase()}`}=${r.reportToken}\nKeep it in your password manager.`);
    if (!r.results.every((x) => x.ok)) process.exitCode = 1;
  } catch (e) { console.error(e.message); process.exitCode = 1; }
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();
