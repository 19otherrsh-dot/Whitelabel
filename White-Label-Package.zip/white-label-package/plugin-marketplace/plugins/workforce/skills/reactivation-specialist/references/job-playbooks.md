# Job playbooks · Reactivation specialist

The detail behind each job in `SKILL.md`. Messages go out from the original deal owner, honestly
referencing the past conversation; they are queued, never sent from here.

---

## Reactivation

**Selection table:**

| Closed-lost / stalled reason | Months since | Include? |
|---|---|---|
| Timing, budget, priority | 3–18 | yes |
| "Revisit in <period>" | when that period arrives | yes, first |
| Went with another option | 6–18 | yes, if we have a real reason (new offer, their contract term) |
| Fit (we couldn't serve them) | any | only if the offer has changed to fit |
| Opted out, hostile ending, legal dispute | any | never |

**Message template (≤ 90 words):**

```text
Subject: <their name>, <the reason in 4–6 words>

Hi <name>, when we spoke in <month> you mentioned <their words: e.g. "it wasn't the right quarter">.
<The specific, true reason to reconnect, one sentence.>
<What it could mean for them, one sentence.>
Worth a 15-minute catch-up, or should I check back in <period>?
<owner>
```

**Worked example.** *Harbor Dental Group*, lost in March: "budget frozen until the new practice opens."
Signal: the third practice opened in August (local press). Draft: "When we spoke in March you said budget
would open up once the new practice was running. Congratulations on opening in August. Three-site groups
usually feel missed calls most in the first months; worth 15 minutes, or should I check back in January?"
Queued from the original owner; CRM tag `reactivation-2026-10`.

---

## Win/Loss Analysis

**Reason codes** (one primary, evidence required): price · timing · no decision · competitor · fit ·
product/service gap · relationship · other (explain).

**Report outline** (`output/deals/win-loss-analysis/<period>-win-loss.md`):

```markdown
# Win/loss · <period>
Deals closed: <won> won / <lost> lost (win rate <n>%; previous period <n>%)
## What changed  (3 bullets, the biggest movements)
## Win rate by: segment · source · deal size · owner  (tables; n shown, n < 5 marked "too few")
## Where deals die (stage of loss)
## What winners had in common (with counts, e.g. "second stakeholder on a call: 9 of 11 wins, 3 of 14 losses")
## Primary loss reasons (count, %, example quote with deal link)
## Recommendations (owner skill · change · expected effect)
```

Small samples are labelled; a pattern from fewer than 5 deals is a question to watch, not a finding.

---

## Log each job

```
node bin/wf.mjs log --skill reactivation-specialist --job "Reactivation" --status queued --summary "<n> reactivation emails queued" --minutes-saved 60
node bin/wf.mjs log --skill reactivation-specialist --job "Win/Loss Analysis" --status done --summary "<period>: win rate <n>%, top loss reason <reason>" --minutes-saved 120
```
