# Question bank

Ask in small groups. Skip anything already answered by research. The point of each question is in italics; if the owner's answer misses the point, follow up.

## Company (company.md)

1. In one sentence, who do you help, to get what, and how? *We want who + outcome + mechanism, not a slogan.*
2. Walk me through what happens from the moment someone first hears of you to the moment they've paid and been delivered to. Who does each step, and in which tool? *This maps the jobs and the stack.*
3. What do you do that the alternatives don't? What would a happy client tell a friend? *Real differentiation, in customers' words.*
4. What work do you turn down? Which clients went badly and why? *Boundaries and red flags.*
5. How big is the team, who does what, and which hours do you work? *Routing and escalation.*
6. Is there anything agents must handle carefully or never mention? *Sensitive topics, disputes, confidential clients.*
7. What are the three things that matter most this quarter? *Priorities; numbers go in goals.*

## Offers (offers.md)

1. List everything you sell, even small things. For each: what's included, what isn't, the price and how it's charged.
2. What are the payment terms? Deposits, due dates, late fees?
3. Minimum terms, cancellation, pauses?
4. Which discounts can an agent offer without asking you? Which never?
5. What do people most often push back on, and what do you say? *Approved objection answers.*
6. Any guarantees? Exactly what wording? *Write it verbatim; guarantees are promises.*

## Customers (customers.md)

1. Tell me about the last client who was a perfect fit: their business, size, who you dealt with, what was going on when they found you.
2. And one who looked right but wasn't. What gave it away?
3. Who signs, who champions, who can block a deal?
4. What happened in their business right before they started looking for help? *Buying triggers drive outreach timing.*
5. How do they describe the problem before they know you? Any phrases you hear again and again?
6. What did they try before you? Why didn't it work?
7. Where do they hang out: communities, events, newsletters, platforms?

## Voice (voice.md and examples/)

1. Paste or forward 3–10 things you wrote that you're proud of: emails, posts, a proposal intro.
2. Three words for how you want to come across? And three words you never want to sound like?
3. Words or phrases that make you cringe in other people's emails?
4. First names or titles? Emoji? Exclamation marks? British or American spelling?
5. How long should a first email be? A reply? A post?
6. How do you sign off?

## Goals (goals.md)

1. What revenue (or other number) are you aiming for this year? This quarter? How do you measure it?
2. Which numbers do you look at weekly today, if any?
3. If the workforce gave you back time, how many hours a week, and what would you do with them?

## Policies (policies.md)

1. Refunds and cancellations: what's the rule, and who can bend it?
2. How fast do you promise to reply? In which channels and hours?
3. How do you handle late payment today?
4. What customer data do you keep, where, and for how long? Do you record calls?
5. For staff: leave, expenses, working hours, where the handbook lives.

## Team (team.md)

1. Who approves what? Up to what amount?
2. Who handles urgent customer issues, money, legal, technical failures? Outside hours?
3. Accountant, lawyer, other outside help, and how to reach them?

## Proof (proof.md)

1. Your three best client results: before, what you did, after, measured how, over what time?
2. For each: may we name them publicly, only in private sales conversations, or only anonymously? Is that permission written down?
3. Any exact quotes they've approved?

## Competitors (competitors.md)

1. Who else does a buyer consider? Including doing it in-house or doing nothing.
2. Where are they genuinely better than you? Where are you better?
3. What do you say when a prospect mentions them?
