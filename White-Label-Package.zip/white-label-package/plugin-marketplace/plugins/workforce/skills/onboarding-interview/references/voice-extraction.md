# Extracting a voice from real writing

The goal is rules an agent can follow and a reviewer can check. "Friendly and professional" is useless; "uses first names, contractions, no exclamation marks, 2–4 sentence paragraphs, ends with a question" is useful.

## Method

1. Collect 3–10 samples, ideally of different types (cold email, reply, proposal, update, post). Save them in `knowledge/examples/` with descriptive names.
2. For each sample, note:
   - **Openings**: how the first line works (straight to the point? a reference to the reader? a question?).
   - **Length**: words per message, sentences per paragraph.
   - **Register**: contractions, first names, emoji, exclamation marks, slang, jargon.
   - **Structure**: bullets or prose, bold, headings, P.S.
   - **Moves**: how they ask (direct question, soft suggestion, two options), how they handle bad news, how they show proof.
   - **Signature words**: phrases that recur; words that never appear.
   - **Closings**: sign-off, call to action.
3. Keep only patterns that appear in at least two samples, or that the owner confirms.
4. Write `voice.md`:
   - **In three words** from the owner's own answer.
   - **Tone by situation** table with an example opening line *taken from or closely modelled on* a real sample.
   - **Rules** that are checkable (length limits, spelling, formality).
   - **Never-use list**: the owner's cringe words plus generic AI tells. Start from this list and keep what the owner agrees with: "I hope this email finds you well", "just checking in", "touching base", "game-changer", "revolutionise", "unlock", "leverage" (as a verb), "synergy", "delve", "elevate", "seamless", "in today's fast-paced world", "I wanted to reach out".
   - **Examples to imitate**: name the two best samples.

## Test before saving

Write one short message in the new voice (e.g. a reply to a typical enquiry) and show it to the owner next to one of their real samples. Ask: "Would you send this?" Adjust the rules from their edits, and record what changed in the change log.
