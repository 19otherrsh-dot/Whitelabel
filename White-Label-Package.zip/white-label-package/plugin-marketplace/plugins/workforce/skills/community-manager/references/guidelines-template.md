# {{Community name}} guidelines (draft for the owner)

**What this community is for:** {{purpose in one sentence}}

## Please
- Ask questions, share what you're working on, help others.
- Be generous with credit and specific with feedback.
- Keep private things private: don't share others' messages or personal details outside.

## Please don't
- Spam or pitch without permission (self-promotion only in {{channel}}).
- Harass, insult, or discriminate. Disagree with ideas, not people.
- Share confidential client information or anything illegal.

## How we moderate
1. A friendly private reminder.
2. Removal of the post, with a note why.
3. Temporary or permanent removal from the community for repeated or serious breaches.

Serious issues (threats, harassment) skip straight to step 3. Report anything to {{contact}}.

AI assistance: some replies and summaries are drafted with AI and reviewed by the team. {{if applicable}}
