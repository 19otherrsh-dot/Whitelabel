# Job playbooks · Community manager

The detail behind each job in `SKILL.md`. Examples use invented members.

---

## Engagement & Replies

**Needs:** posts, comments and mentions since the last round (connector or export); the knowledge base;
`knowledge/community-guidelines.md`; who on the team answers which topics (`knowledge/team.md`).

**Priority order:**
1. Questions unanswered for 24h or more.
2. A newcomer's first post (reply within the day: it decides whether they come back).
3. Negative sentiment or a complaint (move to private with an offer to help).
4. Questions about the paid offer (answer the question; no hard sell in the thread).
5. Everything else, newest first.

**Reply rules.** Answer first, then link. Invite others in ("has anyone solved this a different
way?"). Tag a named expert for technical answers rather than guessing. Never argue in public; never
promise features, dates or discounts.

**Output:** queued replies (`--type post` public, `--type message` DMs), and themes appended to
`data/content/ideas.json` with `source: audience` and the evidence (links to the threads).

**Worked example.** A member asks "how do you price a retainer when scope changes monthly?" (unanswered
30h). Reply: the business's own approach from `offers.md` in two sentences, a link to the pricing
guide, and an invitation for two named members who've posted about it to share theirs.

---

## Moderation

**Decision table** (guidelines win where they differ):

| What | First action | Who decides |
|---|---|---|
| Obvious spam / scam links | propose removal | owner (or autonomous if set) |
| Self-promotion against the rules | private note citing the rule | community manager drafts, owner approves |
| Off-topic | gentle redirect to the right space | draft, queued |
| Personal data posted publicly (own or others') | propose hiding at once; private note | owner, same day |
| Misinformation about the business | factual, friendly correction with a source | owner approves |
| Harassment, threats, hate, illegal content | escalate immediately; don't engage | owner (and platform report) |

**Output:** `output/customer/moderation/<date>-moderation.md`: time, link, what, rule, proposed action,
decision, by whom. Bans and removals are approval-required actions.

---

## Member Spotlights

**Find:** members who shared a result, helped others repeatedly, or hit a milestone.

**Consent is explicit and specific.** The private ask includes the exact draft, where it will be posted,
and an easy no. "Sure!" to a different draft isn't consent for this one.

**Spotlight structure:** who they are (as they describe themselves), what they did, one quote in
their words, what others can learn, a thank-you. Under 150 words.

**Output:** `output/customer/member-spotlights/<member>.md` with the consent (date, their reply
verbatim), then the queued post.

---

## Event Coordination

**Plan:** a 3-month calendar with the owner. Times in the two time zones most members live in; avoid
public holidays in those countries.

**For each event, prepare:**

| When | What |
|---|---|
| −14 days | Announcement: what, who it's for, what they'll leave with, link |
| −1 day, −1 hour | Reminders (only to people who registered) |
| Day | Host run sheet: welcome (2 min), topic (25), questions (20), next steps (3); who watches chat |
| +1 day | Recap post: 3–5 takeaways, recording link if recorded with consent, next event |

**Output:** `output/customer/event-coordination/<event>.md` with attendance, questions asked and themes
(also to `data/content/ideas.json`).

---

## Log each job

```
node bin/wf.mjs log --skill community-manager --job "Engagement & Replies" --status queued --summary "<n> replies queued, <n> themes" --minutes-saved 30
node bin/wf.mjs log --skill community-manager --job "Moderation" --status done --summary "<n> items reviewed, <n> escalated" --minutes-saved 15
node bin/wf.mjs log --skill community-manager --job "Member Spotlights" --status queued --summary "Spotlight for <member> (consent recorded)" --minutes-saved 20
node bin/wf.mjs log --skill community-manager --job "Event Coordination" --status draft --summary "<event>: announcement, reminders, run sheet" --minutes-saved 40
```
