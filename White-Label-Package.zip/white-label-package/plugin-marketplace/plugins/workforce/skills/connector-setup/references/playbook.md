# Playbook · Connector setup

`SKILL.md` has the routes and steps. This file has the owner-facing explanation, harmless reads per
capability, and fixes for common errors. The catalog (`connectors/catalog.json`) stays the source for
endpoints; re-check the vendor's docs when an entry is older than 90 days.

## Three-line explanation (adapt per product)

```text
Connecting <product> lets the team read <what, e.g. contacts, deals and notes>.
It can <change: e.g. update deal stages and add notes> — nothing more.
Anything that sends, posts, pays or deletes still waits in your approvals list.
```

## Harmless verification reads

| Capability | Read |
|---|---|
| Email | list the 1 most recent message subject in the inbox |
| Calendar | list today's events (titles only) |
| CRM | fetch 1 recent contact name |
| Accounting | fetch 1 recent invoice number and status |
| Payments | list 1 recent charge id and amount |
| Files | list the 5 newest file names in the chosen folder |
| Chat | list channel names the app can see |
| Meetings | list the 1 most recent recording title |

## Common errors

| Error | Usually means | Fix |
|---|---|---|
| 401 / "invalid token" | sign-in expired or wrong account | the owner reconnects in `/mcp` |
| 403 / "insufficient scope" | key or app lacks the permission | add only the scope the job needs; re-auth |
| 404 on a valid id | wrong region endpoint (EU vs US) | use the region's endpoint from the docs |
| Redirect mismatch on sign-in | callback URL not registered | register `http://localhost:<callbackPort>/callback` |
| Server not listed in `/mcp` | `.mcp.json` not loaded | restart with `node bin/wf.mjs start` |
| `${NAME}` appears literally | secret not stored or not loaded | owner runs `wf secrets set NAME`, then `wf start` |

## Status table for "what's connected?"

| Capability | Product | Status | Access | Fix |
|---|---|---|---|---|
| CRM | HubSpot | verified 2026-10-20 | read-write | — |
| Accounting | Xero | configured, not verified | read | sign in via `/mcp` |
| Calendar | — | missing | — | connect Google Calendar (claude-connector) |

## Log

```
node bin/wf.mjs log --skill connector-setup --job "Connector Setup" --status done --summary "<product> verified (<route>, <access>)" --minutes-saved 30
```
