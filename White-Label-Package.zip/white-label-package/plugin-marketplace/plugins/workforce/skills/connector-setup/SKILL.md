---
name: connector-setup
description: >-
  Connects the business's tools (email, calendar, CRM, accounting, payments, chat, meetings, files, support,
  project management and more) to the workforce with the least access that works, verifies each connection with
  a harmless read, and records it so doctor and the dashboards know what's live. Uses the vendor's official MCP
  server where one exists, a claude.ai connector, or Zapier as the universal fallback. Use when the owner says
  "connect HubSpot", "hook up my Gmail", "set up QuickBooks", "why can't you see my calendar", "what's connected",
  or when doctor reports a connector is missing.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: workforce
  jobs: [Connector Setup]
  capabilities: []
  version: 1.0.0
---

# Connector setup

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

Skills talk to capabilities ("the CRM", "email"); `workspace.json → stack` says which product fills each one, and `connectors/catalog.json` says how to connect each product. Your job is to make each connection work, with the minimum permissions, and prove it with a read before any job relies on it.

## Read first

- `references/playbook.md`: templates, a worked example and the edge cases for this job. Read it before your first run.
- `workspace.json → stack` (which product per slot).
- `connectors/catalog.json` (route, endpoint or package, auth, docs link, notes, verified date) and `connectors/status.json` (what's already verified).
- `.mcp.json` (servers configured in this workspace).
- `docs/connectors.md` for the owner-facing explanation you can quote.

## Routes, in order of preference

1. **`remote-mcp`** — the vendor's hosted MCP server. Add it to `.mcp.json` with the catalog's `mcp` block. OAuth happens in the browser the first time it's used (`/mcp` in Claude Code shows status and lets the owner sign in).
2. **`claude-connector`** — connect the app in claude.ai Settings → Connectors (available on paid plans; some need an admin on Team/Enterprise). Claude Code signed in with the same claude.ai account can use those connectors. No `.mcp.json` entry needed.
3. **`local-mcp`** — an official server that runs on the owner's computer (e.g. Xero, QuickBooks). Add the `stdio` block; secrets come from the keychain as `${NAME}` (stored with `wf secrets set`, loaded by `wf start`).
4. **`vendor-mcp`** — the vendor publishes an MCP server but the endpoint must be confirmed. Open the `docs` link (WebFetch), find the current endpoint and auth, then configure as route 1 or 3. Record what you found in `connectors/status.json → notes`.
5. **`zapier`** (or Make / n8n) — the universal adapter. Connect `zapier` once, then in Zapier's MCP settings expose only the actions the jobs need for that app.
6. **No connector** — every skill also works from exports and pasted data. Tell the owner which CSV export to drop into `data/imports/` for that capability.

## Connect one product

1. **Look it up** in the catalog. If `verified` is older than 90 days or the route is `vendor-mcp`, re-check the docs link before configuring.
2. **Explain to the owner** in three lines: what the agents will be able to read, what they'll be able to change, and that every send/post/pay/delete still goes through the outbox.
3. **Least privilege.** Prefer read-only scopes or a restricted key first (Stripe restricted key with read access; Xero `XERO_SCOPES` limited; Zapier exposing only needed actions). Add write access later, per job.
4. **Configure.**
   - Remote MCP: add the server to `.mcp.json` under `mcpServers.<server>` using the catalog's `mcp` block. Replace `<..._CLIENT_ID>` placeholders with the real client ID (client IDs aren't secret). Never write a client secret or token into a file; Claude Code prompts for client secrets and stores them in the system keychain. Show the owner the exact JSON you're adding.
   - Local MCP: same, with `${NAME}` for every secret; then have the owner run `node bin/wf.mjs secrets set NAME` for each (they type the value; you never see it), and start Claude with `node bin/wf.mjs start` so the secrets load.
   - Claude connector: give the owner the click path and wait for them to confirm.
   - Zapier: connect the `zapier` server, then list which actions to enable in Zapier for this product.
5. **Authenticate.** The owner opens `/mcp` in Claude Code (or restarts the session) and completes the sign-in. For servers that need a fixed redirect, the catalog's `callbackPort` gives the redirect `http://localhost:<port>/callback` to register in the vendor's app settings.
6. **Verify with a harmless read**: list one recent item (one contact, one invoice, today's calendar). Never verify with a write. If it fails, read the error, check scopes and the region-specific endpoint (e.g. Intercom EU), and retry once; then report the exact error and the fix.
7. **Record** in `connectors/status.json` (merge by product):
   ```json
   { "products": { "<product>": { "verified": "<ISO date>", "route": "<route>", "server": "<server name or claude-connector>", "access": "read | read-write", "notes": "<what was tested>" } } }
   ```
   and update `workspace.json → stack` if the product changed (owner confirms the edit).
8. **Re-run** `node bin/wf.mjs doctor --quick --problems` and report.

## "What's connected?"

Read `connectors/status.json`, `.mcp.json` and doctor's connector lines; answer with a table: capability, product, status (verified date / configured, not verified / missing), access level, how to fix.

## Guardrails

- Never ask the owner to paste a password, API key, token or client secret into the chat. Secrets go through `wf secrets set` or Claude Code's own prompt.
- Never weaken a security setting to make a connection work (e.g. turning off 2FA, sharing an admin account).
- Configure only products in the stack or that the owner names; never connect to third-party servers that aren't the vendor's or a well-known adapter without the owner's explicit approval, and point out the risk (a server can see what it processes).
- Remove access cleanly when asked: delete the `.mcp.json` entry, `wf secrets rm`, and tell the owner to revoke the app in the vendor's settings.

## Quality checklist

- [ ] Route chosen in preference order; vendor docs re-checked when stale.
- [ ] Scopes are the minimum needed; write access only where a job needs it.
- [ ] No secrets in any file; `${NAME}` references only.
- [ ] A read succeeded and is recorded in `connectors/status.json`.
- [ ] Doctor shows the capability as connected.

## Record the run

```
node bin/wf.mjs log --skill connector-setup --job "Connector Setup" --status done --summary "<product> connected via <route> (<access>), verified with <read>"
```
