# Job playbooks · Customer success manager

One section per job on the map. Each gives what the job needs, the decisions in detail, the exact
output, a short worked example (fictional), and who gets what. The steps in `SKILL.md` still apply; this
is the detail behind them. Names in the examples are invented.

---

## Onboarding Journeys

**Needs:** the offer (`knowledge/offers.md`), the customer's goals from the sales call or kickoff notes
(`data/meetings/calls.json`, the deal's `nextStep`), who owns the account (`knowledge/team.md`).
Missing goals → ask the account owner for one sentence: "they'll call this a success when …".

**Decide first value per offer.** It must be observable and dated, not a feeling.

| Offer type | Good first value | Not first value |
|---|---|---|
| Done-for-you service | First deliverable approved by the client | "Kickoff held" |
| Software / tool | Agreed number of users active twice in a week | "Account created" |
| Coaching / programme | First agreed action completed and reviewed | "Attended session 1" |
| Retainer | First monthly report reviewed in a call | "Invoice paid" |

**Journey rules.** Each touch has a trigger (date or event), owner, channel, and a draft. No more than
one customer-facing touch in 48 hours unless they asked. A missed step for 3+ days becomes a nudge to
the account owner, not an automated chase to the customer.

**Output:** `output/customer/onboarding-journeys/<offer>-journey.md`

```markdown
# Onboarding journey · <offer>
First value: <observable outcome> by day <n>
| Day | Trigger | Touch | Owner | Channel | Draft |
|---|---|---|---|---|---|
| 0 | contract signed | Welcome + what happens next | <name> | email | [below] |
| 2 | — | Kickoff call (agenda attached) | <name> | meeting | … |
| 7 | setup step 1 done | Check-in: "anything blocking?" | … | … | … |
| 30 | — | Day-30 review: goals vs results | … | meeting | agenda |
## Stall rules
## Drafts
```

Per customer, add to `data/customers/accounts.json`: `onboarding: { offer, firstValue, steps: [{ name, due, done }], stalled: false }`.

**Worked example.** *Bright Harbor Studio* buys the "Growth retainer". First value: "first monthly
growth report reviewed on a call by day 35". Day 0 welcome (queued email), day 3 kickoff, day 10 data
access confirmed (the account owner nudges at day 13 if not), day 33 report sent, day 35 review call.

**Hand-offs:** drafts → outbox (`--type email`); stalled steps → account owner note; first value
reached → Health Scoring picks it up as "outcomes delivered".

---

## Health Scoring

**Needs:** at least two of the six components in `health-model.md`. Fewer → score "insufficient data"
and list what to connect (support tool, CRM activity, invoices).

**Decision rules.**
- Use only components with data; re-normalise weights; never fill a gap with a guess.
- A champion change or an overdue invoice > 30 days caps the score at 60 whatever else says.
- Trend compares with 4 weeks ago; ±5 is "flat".
- New accounts (< 30 days) are scored on onboarding progress only, labelled "onboarding".

**Output:** `output/customer/health-scoring/<YYYY-MM-DD>-health.md`

```markdown
# Account health · <date>
<n> scored · <n> high risk · <n> medium · <n> data gaps
## High risk
| Account | Score (Δ4w) | Top drivers | Suggested play | Owner |
## Biggest movers
## Data gaps (what to connect or ask)
```

Write back `healthScore`, `healthTrend`, `risk` and `healthDrivers: [..]` on each account.

**Worked example.** *Northwind Dental*: usage −40% over 4 weeks (engagement 20), last contact 70 days
(relationship 50), one negative ticket resolved (support 60), payments on time (100). No NPS → weight
re-normalised over five components. Score 52 (−18), medium risk, drivers "usage drop" and "no contact
in 70 days"; play "low usage: working session".

---

## Churn Prediction

**Needs:** this week's health output, contracts (renewal dates), support tickets and call notes.

**Leading indicators and weight of evidence.**

| Signal | Evidence needed | Weight |
|---|---|---|
| Usage down > 30% over 4 weeks | the numbers | strong |
| Champion left | email bounce, LinkedIn change, "I'm moving on" | strong |
| "Cancel", "alternatives", "budget cut" mentioned | quote + date | strong |
| Invoice overdue > 30 days | invoice id | medium |
| No meeting in 90 days | last meeting date | medium |
| Renewal within 90 days, no renewal conversation | contract end date | medium |

Two strong, or one strong + two medium → "likely within 90 days". One medium alone → "watch".

**Output:** `output/customer/churn-prediction/<date>-at-risk.md`: a table of account, renewal date,
evidence (quoted, dated), likely cause, save play from `playbooks.md`, owner, "talk by" date.
The list is internal: nothing about a prediction goes to the customer.

---

## Renewals & Expansion

**Needs:** renewal dates; value evidence (QBRs, outcomes report, delivered work); pricing changes in
`offers.md`.

**Timeline.** 90 days: brief + internal review. 60 days: renewal conversation booked. 30 days:
paperwork. Missing the 90-day mark → flag at the top of the weekly review.

**Renewal brief:** `output/customer/renewals-expansion/<account>-<renewal-date>.md`

```markdown
# Renewal · <account> · renews <date> · <value>
Health <score> (<trend>) · owner <name>
## Value delivered (each with a source)
## Open issues and how they're being handled
## Pricing: current → proposed (owner decides)
## The ask, and the fallback
## Expansion signals (if any)
## Draft opener for the account owner
```

**Expansion qualification:** a signal becomes an opportunity only with a named need and a person who
can decide. Pass to deals-lead with the evidence; never quote a price that isn't in `offers.md`.

---

## Advocacy & Referrals

**Eligibility (all must be true):** health ≥ 70 and not falling; a success in the last 60 days with
evidence; no open ticket or complaint; not asked in the last 6 months; not in a renewal negotiation.

**One ask at a time, in this order of effort:** review → referral → quote → case study. Never tie an
incentive to a positive review; if any incentive is offered for a review, it's for leaving one, of any
rating, and disclosed per the platform's rules (compliance-check reviews these drafts).

**Output:** a queued email per candidate from the account owner, and
`output/customer/advocacy-referrals/<date>-asks.md` listing who was asked for what and why they
qualified. When someone agrees to a quote or case study, record in `knowledge/proof.md`: who, what
exactly may be used, where, until when.

---

## QBR Prep

**Needs:** last quarter's agreed goals (previous QBR file or call notes), results data, usage, tickets,
invoices.

**Output:** `output/customer/qbr-prep/<client>-<YYYY>-Q<n>.md`

```markdown
# <client> · Quarterly review · Q<n> <year>
## Goals we agreed  ·  ## Results (each number with its source)
## How you're using it  ·  ## Support this quarter
## What's next quarter (proposed goals)  ·  ## Risks and asks
```

Any number without a source is marked "(to confirm)" and listed for the account owner. If results
missed a goal, say so plainly with the reason and the fix: QBRs that hide misses cost renewals.

---

## Log each job

```
node bin/wf.mjs log --skill customer-success-manager --job "Onboarding Journeys" --status done --summary "Journey for <offer>; <n> customers scheduled" --minutes-saved 45
node bin/wf.mjs log --skill customer-success-manager --job "Renewals & Expansion" --status draft --summary "<n> renewal briefs (90 days)" --minutes-saved 40
node bin/wf.mjs log --skill customer-success-manager --job "Advocacy & Referrals" --status queued --summary "<n> asks queued" --minutes-saved 20
```
