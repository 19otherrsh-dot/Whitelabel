# Health model

Score 0–100 = weighted sum of component scores (each 0–100). Use only components with data; re-normalise weights over those, and list missing components as data gaps.

| Component | Weight | 100 | 50 | 0 |
|---|---|---|---|---|
| Engagement / usage | 30 | At or above expected use for the plan; growing | Flat or slightly below | Down > 30% over 4 weeks, or no use in 30 days |
| Outcomes delivered | 20 | Agreed goals met on time | Partly met | Missed or not defined |
| Relationship | 15 | Contact in last 30 days; champion engaged; exec sponsor known | 30–90 days | > 90 days, or champion left |
| Support | 15 | Few tickets, positive/neutral | Some negative, resolved | Open complaint, repeated issues, escalations |
| Payments | 10 | On time | Occasionally late | Overdue > 30 days, disputes |
| Sentiment (NPS/CSAT/feedback) | 10 | Promoter / high | Passive | Detractor / low |

Risk: ≥ 70 low · 45–69 medium · < 45 high. Trend: compare with the score 4 weeks ago (±5 = flat).

Calibrate quarterly: compare last quarter's high-risk accounts with who actually churned; adjust weights (record in lessons) and say so in the report.
