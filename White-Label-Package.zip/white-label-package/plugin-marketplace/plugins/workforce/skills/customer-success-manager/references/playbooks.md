# Plays

## Save plays (by cause)

| Cause | Play |
|---|---|
| Low usage / not adopted | Offer a short working session to re-set goals; share 2 quick wins others in their segment get; simplify setup |
| Champion left | Find the new owner; offer a re-onboarding; send a one-page "what you have and what it's delivered" |
| Value unclear | Value recap with evidence; agree one measurable goal for the next 30 days |
| Product/service problem | Acknowledge, fix plan with dates from the owner, follow up personally |
| Price pressure | Owner decides: right-size the plan, adjust scope, or hold; never offer discounts without approval |
| Switching to competitor | Understand why (competitors.md); owner call within 48 hours |

## Expansion plays

- Usage near limits → right-size conversation with the numbers.
- New team or location → offer onboarding for them.
- Out-of-scope requests → package as an add-on (offers.md) or a new SOW.

## Advocacy asks (one at a time, personal, easy to say no)

- Referral: "Is there someone in your network dealing with {{problem}} who'd benefit from a chat?"
- Review: link to the platform, honest feedback welcome, no incentive tied to rating.
- Case study: what's involved (30-minute interview, they approve the text), what they get (visibility, if they want it).
