# Job playbooks · Competitive intelligence analyst

The detail behind each job in `SKILL.md`. Only public information gathered honestly: no posing as a
customer to get pricing or demos, and no use of leaked or confidential material.

---

## Competitor Teardown

**Battlecard template:**

```markdown
# Battlecard · <competitor> · <date>
They say: "<homepage headline>" · Best for: … · Typical price: … (source, date)
Where they're strong (be honest): …
Where we're different (true, specific, provable): …
When they come up, say: "<one or two sentences, no knocking>"
Ask the prospect: "<question that brings out our strength>" · "<…>"
Traps: don't claim <x> (they do it too) · don't discuss <y> without the facts
Recent moves: <launch / hire / price change, with dates>
Review themes: praise "<…>" (n) · complaints "<…>" (n), from <sites, dates>
```

**Alternatives always included:** in-house (a spreadsheet, a part-time hire) and "do nothing", each with
what it costs the prospect.

**Worked example.** A call-answering service vs our missed-call recovery: they're strong on live voice;
we're different on booking directly into the calendar and price per site. Question to ask: "When a call
is answered after hours, how does it end up in your booking system today?"

---

## Pricing Research

**Comparison table** (normalised to one unit):

| Provider | Offer | Price | Unit | Normalised (£/site/month) | Setup | Source, date |
|---|---|---|---|---|---|---|
| A | Starter | £99 | per month, 1 site | 99 | £0 | pricing page, 20 Oct |
| B | Pro | £1,500 | per year, 3 sites | 42 | £250 | pricing page, 20 Oct |

**Summary:** range, median, clusters (e.g. "£40–60 self-serve, £90–150 with set-up help"), packaging
patterns and anchors; where this business sits; 2–3 options for pricing-analyst, not a decision.

---

## Log each job

```
node bin/wf.mjs log --skill competitive-intelligence-analyst --job "Competitor Teardown" --status done --summary "<competitor>: battlecard ready" --minutes-saved 120
node bin/wf.mjs log --skill competitive-intelligence-analyst --job "Pricing Research" --status done --summary "<offer>: <n> providers, median <price>" --minutes-saved 90
```
