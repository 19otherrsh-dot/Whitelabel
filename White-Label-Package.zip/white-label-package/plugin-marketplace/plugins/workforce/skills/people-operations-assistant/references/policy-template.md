# {{Policy name}}

> Draft for review. Employment law differs by location; have this checked by an employment adviser before publishing.

**Applies to:** {{employees / contractors / everyone}} in {{locations}}
**Owner:** {{name}} · **Effective:** {{date}} · **Review by:** {{date}}

## Why we have this policy
{{one or two sentences}}

## The rule
{{the policy, in plain words; numbered if several parts}}

## How to request or use it
1. {{step}}
2. {{who approves, within how long}}

## Examples
- {{common situation}} → {{what happens}}

## Questions
Ask {{person/channel}}.

## Change log
- {{date}}: created
