# Fair hiring rules

1. **Structured**: every candidate for a role is assessed against the same scorecard with the same questions.
2. **Evidence-based**: each rating cites something the candidate wrote, did or said that relates to a competency.
3. **No protected characteristics**: never infer or use age, sex/gender, gender identity, sexual orientation, race, ethnicity, national origin, religion, disability, pregnancy, marital or family status, or genetic information. Don't use proxies (graduation year as age, names, photos, addresses, clubs).
4. **No unnecessary filters**: degrees, years of experience and "culture fit" only if they're on the scorecard with a reason; prefer "culture add" defined by the competencies.
5. **Gaps and non-traditional paths** are not negatives.
6. **Accessibility**: offer adjustments for interviews; tell candidates how to ask.
7. **Automated decision rules**: some places regulate automated tools in hiring (for example New York City requires bias audits and notice for automated employment decision tools; the EU AI Act treats AI used in recruitment as high-risk). Because a person makes every decision here and this skill only prepares evidence, keep it that way; if the owner wants automated filtering, tell them to check local rules first.
8. **Records**: keep the scorecard, ratings and reasons for decisions; they protect both the business and candidates.
