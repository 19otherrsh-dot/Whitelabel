# Job playbooks · Talent coordinator

The detail behind each job in `SKILL.md`. Read `fair-hiring.md` first. Employment law differs by
country and state: where this file says "check", the owner confirms with their adviser.

---

## Candidate Sourcing

**Scorecard template:** `output/back-office/candidate-sourcing/<role>/scorecard.md`

```markdown
# <Role> · scorecard
Mission (one sentence): …
## Outcomes in the first 12 months (measurable)
1. … by …
## Competencies (4–6), with what "good" looks like
| Competency | Strong evidence looks like | Must-have? |
## Practicalities
Salary range · location / remote · hours · start date · reporting to
```

**Job description rules:** lead with the mission and outcomes; list only requirements on the scorecard;
include the salary range (required by law in many US states, and in EU countries as they apply the
Pay Transparency Directive from June 2026; check for the role's location); describe the interview steps and timeline; say how to ask for
adjustments.

**Sourcing plan:** 3–5 channels ranked by where people with this scorecard actually are, with what to
post or search. Personal outreach references something specific the person made or did, says the
salary range, and makes "no" easy.

**Worked example.** "Operations coordinator, part-time, remote (UK)": outcomes "invoices out within 2
days of month end", "client onboarding checklist used for 100% of new clients"; competencies:
organisation, written clarity, tool comfort, discretion; must-haves: right to work in the UK, 20 h/week.

---

## Screening & Scheduling

**Evidence table per applicant** (scorecard rows only):

| Must-have / competency | Evidence (quote or reference) | Rating |
|---|---|---|
| Right to work | "UK citizen" (application Q2) | strong |
| Written clarity | Cover note: clear, specific, no errors | strong |
| Tool comfort | Mentions Xero, Notion, Google Sheets | some |

Ratings: strong / some / none / unclear. "Unclear" means ask, not reject.

**Never consider:** name, photo, age or dates that imply it, gender, ethnicity, nationality (beyond the
right to work), disability, family status, religion, school prestige, gaps in employment. If an
application mentions any of these, ignore it and don't repeat it in the notes.

**Shortlist note:** who meets all must-haves, ordered by evidence strength, with "why" in one line
each. The owner decides; nobody is rejected automatically.

**First-call questions** (5–7), each tied to a competency, with what a good answer contains.

**Scheduling:** propose 3 slots within 5 working days; include the panel, the agenda, what to prepare,
how long, and accessibility ("tell us if you need anything to take part comfortably").

**Closing the loop:** every candidate gets an answer within the promised time. Decline drafts are kind,
short and don't give reasons that create legal risk; offer brief feedback only if the owner agrees.

---

## Onboarding & Training

**30-day plan:** `output/back-office/onboarding-training/<name>/30-day-plan.md`

| Window | Contents |
|---|---|
| Before day 1 | Accounts and equipment (owner of each), welcome email, first-week calendar, contract and policy acknowledgements |
| Week 1 | People to meet (why each), SOPs to read, one small real win |
| Weeks 2–4 | Responsibilities added in order, weekly 30-min check-ins, the day-30 review date |
| Day 30 | Review questions: what's clear, what isn't, what to change, goals for days 31–90 |

**Checklist:** `data/people/onboarding.json` item per hire with `checklist: [{ item, owner, due, done }]`;
nudge owners of overdue items weekly (internal message).

**Reading list:** the role's SOPs and the knowledge files they'll use. Any task in the plan without an
SOP → request to playbook-writer.

---

## Log each job

```
node bin/wf.mjs log --skill talent-coordinator --job "Candidate Sourcing" --status draft --summary "Scorecard, JD and sourcing plan for <role>" --minutes-saved 120
node bin/wf.mjs log --skill talent-coordinator --job "Screening & Scheduling" --status draft --summary "<n> applications screened, <n> shortlisted" --minutes-saved 60
node bin/wf.mjs log --skill talent-coordinator --job "Onboarding & Training" --status draft --summary "30-day plan for <name>" --minutes-saved 60
```
