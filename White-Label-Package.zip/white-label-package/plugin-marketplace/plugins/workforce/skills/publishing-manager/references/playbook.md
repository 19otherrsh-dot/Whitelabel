# Playbook · Publishing manager

`SKILL.md` has the steps. This file has the weekly plan layout, the pre-publish checklist, the outbox
item format and what to do when something goes wrong after publishing.

## Weekly plan

| Day | Time (audience TZ) | Platform | Item | Status | Clash check |
|---|---|---|---|---|---|
| Tue | 08:30 | LinkedIn | "5 places missed calls go" carousel | ready | ok |
| Thu | 12:00 | Instagram | voicemail myth-bust reel | approved | ok |

## Pre-publish checklist

- [ ] Copy final: no typos, names and mentions correct
- [ ] Links open, UTM tags on own links
- [ ] Asset size and format right for the platform; first frame/cover set
- [ ] Alt text and captions present
- [ ] Disclosures: paid partnership / #ad; AI-generated media labelled where required
- [ ] compliance-check PASS for claims, testimonials and endorsements
- [ ] Nothing scheduled near a sensitive event (check the news the day before)

## Outbox item

```
node bin/wf.mjs queue --skill publishing-manager --job "Publishing" --type post \
  --title "LinkedIn Tue 08:30: 5 places missed calls go" --file output/marketing/publishing/<date>-<slug>.md
```

The draft file holds the exact text, asset paths, platform, account and scheduled time.

## After publishing goes wrong

| Problem | Do |
|---|---|
| Typo or broken link | edit if the platform allows; otherwise tell the owner (delete + repost is their call) |
| Wrong image or missing disclosure | tell the owner immediately; propose the fix |
| Post didn't go live | check the scheduler; re-queue, don't post twice |
| Negative comments pile up | hand to community-manager; don't delete criticism |

## Log

```
node bin/wf.mjs log --skill publishing-manager --job "Publishing" --status queued --summary "<n> posts queued for <week>" --minutes-saved 45
```
