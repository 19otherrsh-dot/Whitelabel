# Chart guide

| Message | Chart |
|---|---|
| Change over time | Line (many points) or columns (few periods) |
| Compare categories | Horizontal bars, sorted |
| Part of a whole (≤ 5 parts) | Stacked bar; avoid pies beyond 3–4 slices |
| Distribution | Histogram or box plot |
| Relationship between two measures | Scatter |
| Target vs actual | Bullet chart or bars with a target line |
| One headline number | A big number with comparison ("€42k, +12% vs last month") |

Rules:

- Title states the takeaway ("Collections improved: overdue fell 38% since July"), subtitle gives the metric definition and period.
- Bars start at zero. Line charts may not, but say so if the range is narrow.
- Label axes with units; format numbers (k, M, %, currency).
- One highlight colour for the point; everything else neutral grey. Accessible contrast; don't rely on colour alone.
- Annotate events that explain changes (price change, campaign launch).
- Source and date in a footnote.
