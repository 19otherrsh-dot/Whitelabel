---
name: skill-builder
description: >-
  Writes, tests and improves skills for this workforce: turns a job the map doesn't cover, or a process the owner
  describes, into a SKILL.md that follows the workspace standard, with references, test prompts and evidence that
  it works. Also improves an existing skill from rejected outputs and owner feedback. Use when the owner says
  "make a skill for…", "teach the agents to…", "turn this process into a skill", "this skill keeps getting X wrong",
  or when the audit finds work with no matching job.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: workforce
  jobs: [Skill Building]
  capabilities: []
  version: 1.0.0
---

# Skill builder

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

A skill is a specialist's playbook written for an AI: when to act, what to read, the exact steps, what the output looks like and how to check it. A good one produces work the owner would have been happy to do themselves. You write skills to the standard in `docs/skill-standard.md`, test them on realistic prompts, and only hand them over when the tests pass.

## Read first

- `references/playbook.md`: templates, a worked example and the edge cases for this job. Read it before your first run.
- `docs/skill-standard.md` (structure and front matter) and `docs/data-model.md` (if the skill saves records).
- Two existing skills in the same department, to match tone and depth.
- `knowledge/company.md` and the relevant knowledge files, so the skill reads the right ones.
- For improvements: the skill, its `evals/evals.json`, `data/feedback/lessons/<skill>.md`, and recent rejections for it in `data/feedback/rejections.jsonl`.

## New skill

1. **Capture the job.** With the owner: what triggers it, inputs, what "done" looks like, an example of great output (ask for a real one), common mistakes, what must never happen, who approves. If the conversation already shows the process (the owner just did it with you), extract it from there first and confirm.
2. **Decide the boundaries.** One skill = one role. If the process has distinct stages owned by different people, it may be two skills. Check no existing skill already covers it (`ls .claude/skills`, read descriptions).
3. **Write the front matter.** `name` matches the folder, lowercase-hyphenated. The `description` says what it does *and* the phrases that should trigger it; be slightly pushy, because agents under-use skills with vague descriptions. Max 1024 characters. `metadata.jobs` uses exact job names; add the job to the map with `department-builder` if it is new.
4. **Write the body** in the standard order: Role, Read first, Jobs (numbered steps, output path and template, outbox action, done-when), Connectors (with and without), Guardrails, Quality checklist, Record the run. Explain *why* behind non-obvious rules. Keep SKILL.md under ~400 lines; move templates and long rules to `references/` and say exactly when to read each.
5. **Add scripts only for deterministic work** (calculations, file conversion, validation) in Node with no dependencies, with a usage line at the top.
6. **Write tests**: `evals/evals.json` with at least three realistic prompts (one normal, one edge case, one where it should refuse or ask), each with an `expected_output` and checkable `assertions`.
7. **Run the tests.** For each prompt, run the skill on it (in a subagent if available, so the run is independent) and save outputs to `output/workforce/skill-building/<skill>/<date>/eval-<id>/`. Check each assertion and record pass/fail with evidence in `grading.json` beside the output. If a headless run is possible, the owner can also run: `claude -p "<prompt>" --output-format json` from the workspace.
8. **Iterate** until all assertions pass and the outputs read well. When outputs fail, fix the instructions by explaining the reasoning better, not by adding rigid MUSTs for one example.
9. **Hand over** with a short note: what the skill does, how to trigger it, test results, and any lessons the owner should add.

## Improve an existing skill

1. Collect evidence: rejected items and reasons, the owner's lessons, failed runs (`wf runs --skill <name> --failed`), and the outputs that were edited heavily.
2. Find the general cause (missing context, wrong default, unclear step), not the single instance.
3. If the fix is business-specific, it belongs in lessons, not the skill. If it is general, edit the skill, bump `metadata.version`, and add an eval that would have caught the problem.
4. Re-run all evals; nothing that passed before may now fail.

## Guardrails

- Skills never instruct agents to bypass the outbox, the approval guard or the never-allow list.
- No invented facts, sample "results" or fake testimonials in templates; use placeholders filled from the knowledge base.
- No secrets in skill files. Reference `wf secrets` names instead.
- Don't overwrite a kit skill's folder with a business-specific fork; create a new skill with a distinct name and say when to use it instead.

## Quality checklist

- [ ] Front matter valid: name = folder, description ≤ 1024 chars with trigger phrases, jobs exist on the map.
- [ ] Every job section has steps, an output path and template, and a done-when.
- [ ] Works with no connector (file or paste fallback).
- [ ] Guardrails and the approval rule are explicit for any external action.
- [ ] Quality checklist items are specific and testable.
- [ ] ≥ 3 evals, all passing, with outputs saved.
- [ ] `node bin/wf.mjs doctor --quick --problems` shows no skill errors.

## Record the run

```
node bin/wf.mjs log --skill skill-builder --job "Skill Building" --status done --summary "<new|improved> skill <name>: <n>/<n> evals passing"
```
