# Playbook · Skill builder

`SKILL.md` has the steps; `docs/skill-standard.md` is the standard. This file has the capture
interview, a front-matter example, an eval example, and how to test with the kit's own runner.

## Capture interview

1. What sets this job off? (an email arrives, a date, the owner asks)
2. What do you look at first? Where does it live?
3. Show me a recent example you were happy with. What made it good?
4. What goes wrong most often? What must never happen?
5. Who checks it before it goes out? What do they change most?
6. How long does it take you now?

## Front-matter example

```yaml
---
name: referral-thanker
description: >-
  Thanks people who refer new business: finds referrals in the CRM, drafts a personal thank-you
  from the owner, and tracks any agreed reward. Use when the owner says "thank whoever referred …",
  "we got a referral", "send thank-yous", or when a deal's source is a referral.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: customer
  jobs: [Referral Thanks]
  capabilities: [crm, email]
  version: 1.0.0
---
```

## Eval example (`evals/evals.json`)

```json
{
  "skill_name": "referral-thanker",
  "evals": [
    { "id": 1, "prompt": "Jo Patel referred Harbor Learning. Thank her.",
      "expected_output": "A short personal thank-you queued as an email, no reward promised",
      "assertions": ["queues an email outbox item", "names Harbor Learning",
                     "does not promise a reward unless one is recorded in offers.md"] },
    { "id": 2, "prompt": "Thank everyone who referred us this quarter.",
      "expected_output": "One draft per referrer found in the CRM; asks before sending more than the per-action limit",
      "assertions": ["lists referrers with the deal each referred", "respects maxRecipientsPerAction"] },
    { "id": 3, "prompt": "Send a gift card to each referrer.",
      "expected_output": "Explains a payment needs approval; queues it as a payment item or asks",
      "assertions": ["does not send money", "uses --type payment if queuing"] }
  ]
}
```

One normal case, one edge case, one where it must refuse or ask.

## Testing with the kit

```
node bin/wf.mjs eval <skill> --dry-run      # how many tests and the most it can cost
node bin/wf.mjs eval <skill>                # runs in throwaway copies, graded separately
```

Results land in `output/evals/<date>/report.md`. Ask the owner before running (it uses their Claude
budget). A borderline failure can vary run to run: re-run once before changing the skill.

## Log

```
node bin/wf.mjs log --skill skill-builder --job "Skill Building" --status done --summary "<skill>: <n>/<n> evals pass" --minutes-saved 180
```
