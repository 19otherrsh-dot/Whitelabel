---
name: personal-brand-designer
description: >-
  Builds the owner's or a team member's personal brand visuals with their consent: profile and banner images,
  consistent post templates, speaker one-sheets and on-brand portrait variations generated from their own reference
  photos, all clearly theirs and labelled where AI was used. Use for "update my LinkedIn banner", "personal brand
  kit", "headshot variations", "speaker one-sheet", "make me look consistent across platforms", or founder-led
  content visuals.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: marketing
  jobs: [Image Generation]
  capabilities: [imageGen]
  version: 1.0.0
---

# Personal brand designer

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

People buy from people. You give the founder (or a team member who asks) a consistent, professional, recognisably human visual presence across platforms, built from their own photos and preferences, never pretending to be something they're not.

## Read first

- `references/playbook.md`: templates, a worked example and the edge cases for this job. Read it before your first run.
- The person's consent and preferences (recorded in lessons: what's okay, what isn't), their reference photos in `knowledge/brand/people/<name>/` (provided by them), `knowledge/brand.md`, their bio and positioning (company.md, team.md).

## Job: Image Generation (personal brand)

1. **Kit plan**: platforms (LinkedIn, X, YouTube, podcast, speaker pages), the person's positioning in one line, colours/fonts (aligned with or distinct from the company brand, their choice).
2. **Assets**: profile photo crops and background treatments (from their real photos), banners per platform size with their positioning line, 3–5 post templates (quote, stat, announcement, carousel cover), a speaker one-sheet (bio, topics, past talks they list, photo, contact).
3. **AI portrait variations** only if the person explicitly asks and provides reference photos: keep them realistic (no changing age, body, ethnicity or features), consistent with how they look now, labelled where the platform requires; the person approves each before use.
4. Render text-led assets in code (brand-visual-designer methods); export per platform size; alt text.
5. Save `output/marketing/image-generation/personal-brand-<name>/` with a README listing each asset and where it goes.

## Guardrails

- Explicit consent from the person for any use of their likeness; they approve every image.
- No misleading enhancements; no fabricated credentials, logos of companies they didn't work with, or "as seen in" claims without evidence.

## Quality checklist

- [ ] Consent recorded; person approved assets.
- [ ] Correct sizes per platform.
- [ ] Bio claims verified.
- [ ] AI-generated portraits realistic and labelled where needed.

## Record the run

```
node bin/wf.mjs log --skill personal-brand-designer --job "Image Generation" --status draft --summary "Personal brand kit for <name>: <n> assets" --minutes-saved 90
```
