# Playbook · Personal brand designer

`SKILL.md` has the steps. This file has the consent record, platform sizes and the kit README layout.
Sizes change: check each platform's current guidance before export and note the date.

## Consent record (`data/feedback/lessons/personal-brand-designer.md`)

```markdown
Person: <name> · Recorded: <date> · By: <how, e.g. email from them>
OK: crops and background changes of my photos; banners; templates
Not OK: AI portraits | OK only with my approval of each image
Never: changing age, body, skin, features; putting me in places I haven't been
Photos provided: knowledge/brand/people/<name>/ (n files)
```

## Common sizes (verify before export)

| Asset | Typical size |
|---|---|
| Profile photo | 400×400 minimum, square, face centred |
| LinkedIn banner | 1584×396 |
| X header | 1500×500 |
| YouTube banner | 2560×1440, safe area centre 1546×423 |
| Post templates | 1080×1350 portrait, 1080×1080 square |
| Speaker one-sheet | A4 / US Letter PDF |

## Kit README layout

| Asset | File | Where it goes | Notes |
|---|---|---|---|
| Profile photo | profile-800.png | LinkedIn, X, podcast | from photo 03, warm crop |
| LinkedIn banner | linkedin-banner.png | LinkedIn profile | positioning line: "<line>" |
| Quote template | quote.html | posts | edit text in the file, render |

## Log

```
node bin/wf.mjs log --skill personal-brand-designer --job "Image Generation" --status draft --summary "<name>: <n> assets" --minutes-saved 120
```
