# Vertical scorecard (each 0–5, total /30)

| Dimension | 0 | 3 | 5 |
|---|---|---|---|
| Pain intensity | Nice to have | Recurring cost/annoyance | Costly, frequent, or regulation-driven |
| Budget | Can't afford our price | Some can | Routinely spend this much on similar |
| Reachability | No channels/data | Some communities and data | Strong associations, events, clean data |
| Competition | Entrenched specialists, high switching cost | Fragmented | Underserved |
| Fit / proof | Nothing similar | Adjacent proof | Direct wins in this vertical |
| Regulation & risk | Makes delivery hard/risky | Manageable | Creates demand we serve well |

≥ 22 go · 15–21 test · < 15 no-go (unless strategic reasons the owner states).
