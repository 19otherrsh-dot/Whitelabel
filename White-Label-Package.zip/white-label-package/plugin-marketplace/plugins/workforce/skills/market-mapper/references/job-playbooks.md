# Job playbooks · Market mapper

The detail behind each job in `SKILL.md`. Every count has a source, a date and the filters used.

---

## Market Mapping

**Segment grid** (counts per cell, with the source):

| Sub-vertical \ size | 2–10 staff | 11–50 | 51–200 |
|---|---|---|---|
| Dental groups | 1,240 (A) | 410 (A, B) | 60 (B) |
| Physio clinics | 2,100 (A) | 230 (A) | 15 (B) |

Sources: (A) lead database with filters `industry=…, employees=…, country=UK`, pulled <date>;
(B) national business statistics by industry code and size band, <year>. Where they differ by more than
30%, say so and explain why (database coverage, sole traders, definitions).

**Starting segment score** (1–5 each): size · fit with the offer · reachability (contact data, channels,
communities) · urgency signals · competition. Recommend the top 1–2 cells with the reasons.

**Worked example.** "UK multi-site dental": 470 groups with 2–5 sites (two sources within 12% of each
other); 74% have a findable practice-manager contact; trade association with a newsletter. Recommend
starting with groups of 2–5 sites in England; hand filters to lead-sourcing-manager.

---

## TAM / Market Sizing

**Inputs table:**

| Input | Low | Base | High | Source | Confidence |
|---|---|---|---|---|---|
| Companies (broad definition) | 1,800 | 2,100 | 2,400 | grid above | medium |
| Value per customer / year | £2,400 | £3,600 | £4,800 | price list × typical plan | high |
| Serviceable share | 55% | 65% | 75% | England only, 2–50 staff | medium |
| Achievable penetration (3 yrs) | 1.5% | 3% | 5% | current win rate × capacity | low |

Base: TAM £7.6m · SAM £4.9m · SOM ~£150k/year. "The goal of 60 customers needs ~4.4% of SAM, above base
penetration: either widen geography or lift the win rate." The 2–3 assumptions that move the number
most are named.

---

## Log each job

```
node bin/wf.mjs log --skill market-mapper --job "Market Mapping" --status done --summary "<segment>: <n> companies, start with <cell>" --minutes-saved 120
node bin/wf.mjs log --skill market-mapper --job "TAM / Market Sizing" --status done --summary "<segment>: SOM <range>" --minutes-saved 90
```
