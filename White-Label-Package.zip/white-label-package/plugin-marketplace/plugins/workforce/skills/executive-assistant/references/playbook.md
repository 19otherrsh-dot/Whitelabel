# Playbook · Executive assistant

`SKILL.md` has the jobs. This file has the scheduling-rules record, message templates, the agenda
layout and the time-zone pitfalls.

## Scheduling rules (saved as lessons once agreed)

```markdown
- Meetings between 10:00 and 17:00 (owner's time zone); none on Friday afternoons
- Max 4 meetings a day; 15-minute buffer after any client call
- Focus blocks: Tue and Thu 09:00–12:00 (only VIPs override: <names>)
- In person: add travel time both ways from the address
```

## Proposing times

```text
Subject: <topic>: times for <length> minutes

Hi <name>, here are three options (your time first):
• Tue 4 Nov, 10:00 New York / 15:00 London
• Wed 5 Nov, 11:30 New York / 16:30 London
• Thu 6 Nov, 09:00 New York / 14:00 London
I'll send an invite with a video link as soon as you pick one.
```

## Rescheduling

```text
Hi <name>, something has come up on my side for <day>. I'm sorry for the change.
Would <option 1> or <option 2> work instead? Everything else stays the same.
```

## Daily agenda layout

```markdown
# <weekday date>
| Time | Meeting | With | Where | Prep |
|---|---|---|---|---|
| 10:00–10:30 | Proposal review | Jo Patel (Harbor Dental) | Zoom | brief: output/…/call-prep · decide: start date |
Conflicts: none · No agenda yet: 14:00 "Catch up" (suggest asking for one)
Focus time left: 2h 30m (13:00–15:30)
```

## Time-zone pitfalls

- Daylight-saving dates differ: the US and Europe change on different weekends in March and
  October/November, so the gap between New York and London is 4 hours for a week or two. State both
  zones on any meeting in those weeks.
- Some zones are offset by 30 or 45 minutes (India, Nepal, parts of Australia).
- "Next Tuesday" said on a Sunday is ambiguous: write the date.

## Log

```
node bin/wf.mjs log --skill executive-assistant --job "Calendar Management" --status queued --summary "<meeting>: 3 times proposed" --minutes-saved 15
```
