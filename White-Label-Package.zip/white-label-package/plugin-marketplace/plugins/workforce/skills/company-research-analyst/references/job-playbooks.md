# Job playbooks · Company research analyst

The detail behind each job in `SKILL.md`. Research standards (`docs/research-standards.md`) apply:
every claim has a source and date; estimates are labelled with their method.

---

## Company Deep-Dive

**Report:** `output/intelligence/company-deep-dive/<company>-<YYYY-MM-DD>.md`

```markdown
# <Company> · deep-dive · <date>
## In one paragraph (what they do, size, momentum, why they matter to us)
## Fit and angle
ICP fit: <strong | partial | weak> because … · Likely needs our offers address: … · Entry points: …
Timing signals: … · Risks: …
## Basics  ·  ## Size and growth  ·  ## People  ·  ## Strategy and recent moves
## Open questions (what we couldn't find and how to find it)
## Sources (numbered; every claim above cites one)
```

**Source priority:** the company's own materials (site, filings, press releases, leaders' interviews)
→ registries and regulators → reputable press → professional networks and job posts → review sites.
Aggregator "estimates" are the last resort and labelled.

**Estimating revenue for a private company (when asked):** show the method, e.g. employees × typical
revenue per employee for the sector (with the source of that ratio), cross-checked with any public
signal (registry accounts, pricing × customer count). Give a range, never a single number.

**Worked example.** *Harbor Learning Ltd*: UK registry shows small-company accounts (no revenue
disclosed); 18 employees (+6 in 12 months from job posts); estimate £1.2–2.0m using £70–110k per employee
for UK education services (cited) and their published price × cohort sizes. Fit: strong (cohort business,
enrolment pain on careers page).

---

## Tech-Stack Detection

**Evidence types and confidence:**

| Evidence | Confidence |
|---|---|
| Script or tag on their site for the tool | high (dated) |
| MX/DNS records for email or verification | high |
| Job post asks for experience with the tool | medium |
| Vendor case study names them | medium (check the date) |
| Integration listed on their site | medium |
| One mention in a forum or old article | low |

**Output table:** category (CRM, email, scheduling, payments, analytics, CMS, support, chat), tool,
evidence, date, confidence; then "gaps relevant to our offers".

Look only at what anyone can see: page source, public DNS, public posts. Never probe their systems.

---

## Funding & Financials Lookup

**Output section:**

```markdown
## Funding and financials
Ownership: <private | VC-backed | PE-backed | public | subsidiary of …>
Rounds: | Date | Round | Amount | Lead | Source |
Total raised: … (as of <date>) · Months since last round: …
Public filings (if listed): revenue, growth, guidance, segment notes, with links
Registry filings (if private): what's disclosed, with links
What it suggests: <budget, pressure for growth or efficiency, likely priorities>, labelled as interpretation
```

---

## Log each job

```
node bin/wf.mjs log --skill company-research-analyst --job "Company Deep-Dive" --status done --summary "<company>: fit <level>" --minutes-saved 90
node bin/wf.mjs log --skill company-research-analyst --job "Tech-Stack Detection" --status done --summary "<company>: <n> tools found" --minutes-saved 30
node bin/wf.mjs log --skill company-research-analyst --job "Funding & Financials Lookup" --status done --summary "<company>: <ownership>, last round <date>" --minutes-saved 30
```
