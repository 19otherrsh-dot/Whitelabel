# Job playbooks · Data enrichment specialist

The detail behind each job in `SKILL.md`, with `verification.md`. Business contact data only; every
value carries its source and date.

---

## Contact Enrichment

**Order of sources per missing field:**

| Field | 1st | 2nd | 3rd |
|---|---|---|---|
| Email | lead-data provider | company website (team/contact page) | pattern guess → must verify |
| Phone (business) | provider | website | none (don't guess phones) |
| Title | provider | public professional profile | website |
| Profile URL | provider | public search | none |

**Field record:** `{ value, source, date, confidence }`, e.g.
`email: { value: "jo.patel@harbordental.example", source: "pattern", date: "2026-10-20", confidence: "low" }`.
Pattern emails stay `low` until verification says `valid`.

**Coverage report:** per field, % filled before and after, and by which source.

---

## Email Verification

**Classes and what happens:**

| Class | Meaning | Campaign use |
|---|---|---|
| valid | mailbox exists | yes |
| risky | catch-all domain, role address, or soft signals | only small separate batches, with the owner's OK |
| invalid | doesn't exist / domain doesn't accept mail | removed |
| unknown | the check couldn't tell | not in bulk; retry later |

Never verify by sending a message to the person. Re-verify anything older than 90 days before reuse.

**Write:** `verified: { status, checkedAt, by }` on each lead; summary
`output/sales/email-verification/<date>-<list>.md` with counts per class and expected bounce rate.
A list over 3% invalid after cleaning is a sign the source is poor: say so.

---

## Account Enrichment

**Fields and how to label them:**

| Field | Source examples | Label |
|---|---|---|
| Industry | provider, website | fact |
| Employees and 12-month trend | provider, job-post volume | estimate (source) |
| Revenue band | provider | estimate (source) |
| Locations | website, maps | fact |
| Business model | website | fact |
| Tools / tech | job posts, website tags, public signals | signal (source) |
| Recent news | press, blog | fact with date |

**Worked example.** *Harbor Dental Group*: industry dental (website); employees ~35, +20% over 12 months
(estimate: provider + 4 open roles); revenue band £2–5m (estimate: provider); 3 locations (website);
tools: booking system named in a job post (signal); news: opened third practice in August (local press).

---

## Log each job

```
node bin/wf.mjs log --skill data-enrichment-specialist --job "Contact Enrichment" --status done --summary "<list>: email coverage <a>% → <b>%" --minutes-saved 45
node bin/wf.mjs log --skill data-enrichment-specialist --job "Email Verification" --status done --summary "<n> checked: <n> valid, <n> invalid" --minutes-saved 20
node bin/wf.mjs log --skill data-enrichment-specialist --job "Account Enrichment" --status done --summary "<n> accounts enriched" --minutes-saved 40
```
