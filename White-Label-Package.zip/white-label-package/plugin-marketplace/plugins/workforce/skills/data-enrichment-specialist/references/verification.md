# Verification thresholds

| Status | Meaning | Use |
|---|---|---|
| valid | Mailbox exists (SMTP check passed, not catch-all) | Send |
| risky | Catch-all domain, role address, or recently changed | Small separate batch only with owner OK; watch bounces |
| invalid | Mailbox doesn't exist, domain has no mail server, syntax error, known trap | Remove permanently |
| unknown | Server didn't answer | Retry later; don't send in bulk |

List health before launch: invalid < 1% after cleaning; expected bounce rate < 2%. If a source produces > 5% invalid, flag the source.
