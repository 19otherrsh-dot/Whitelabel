# Platform rules of thumb (check current limits; platforms change them)

| Platform | Visible before "more" | Length that works | Hashtags | Links | CTA |
|---|---|---|---|---|---|
| LinkedIn | ~2 lines (~200 chars) | 600–1,300 chars; short lines, white space | 0–3 relevant | Links in post may reduce reach; many put them in a comment | Question or soft CTA at end |
| Instagram | ~125 chars | Reels: short; carousels: up to ~2,200 chars for value posts | 3–5 specific | Not clickable in captions (bio/stories) | Save/share/comment keyword |
| X | 280 chars (longer for premium) | One idea; threads for depth | 0–1 | Fine | Reply/repost |
| Threads | 500 chars | Conversational | 0–1 topic tag | Fine | Question |
| Facebook | ~2–3 lines | Short | 0–2 | Fine | Comment/share |
| TikTok | Short caption | 1–2 lines + keywords (search) | 3–5 | Bio only (most accounts) | Follow/comment |
| YouTube description | First ~150 chars in search | 200–500 words with chapters | 3 max above title | Yes | Subscribe, link |

Always: alt text for images, captions for video, disclosure for sponsorships (#ad, paid partnership tools).
