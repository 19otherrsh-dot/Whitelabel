# Playbook · Instagram content analyst

`SKILL.md` has the steps. Learn patterns, don't copy posts; use public data through permitted means
only. This file has the tagging sheet, the pattern format and adapted-idea format.

## Tagging sheet (one row per top post)

| Account | Date | Format | Hook (first line / 1–3 s) | Structure | Topic | Length | On-screen text | CTA | Engagement vs account median |
|---|---|---|---|---|---|---|---|---|---|
| @competitor-a | 12 Oct | reel | "Stop saying 'we'll call you back'" | myth-bust | missed calls | 28 s | yes, 6 words | comment keyword | 3.4× |

"Top" = above 2× the account's own median for that format in the period, so big accounts don't dominate.

## Pattern format

```markdown
Pattern: myth-bust reels under 30 s with a 6-word on-screen hook
Evidence: 7 of the 12 top reels across 5 accounts (median 2.9× each account's median)
Gap: nobody in the niche shows real before/after numbers
Confidence: medium (n = 12, 60 days)
```

## Adapted idea format

```markdown
Idea: "Voicemail isn't a safety net" myth-bust reel, 25 s
Uses pattern: myth-bust under 30 s (not any one post)
Our substance: our call data, Sept 2026 (knowledge/proof.md) · Voice: plain, warm
Hook on screen: "Voicemail won't save your bookings"
```

## Log

```
node bin/wf.mjs log --skill instagram-content-analyst --job "Competitor Analysis" --status done --summary "<n> accounts, <n> patterns, <n> ideas" --minutes-saved 90
```
