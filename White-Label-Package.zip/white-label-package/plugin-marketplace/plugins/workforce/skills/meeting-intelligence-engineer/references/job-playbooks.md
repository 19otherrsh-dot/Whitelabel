# Job playbooks · Meeting intelligence engineer

The detail behind each job in `SKILL.md`. Recording law varies: some places need everyone's consent.
When in doubt, ask everyone and record only with a yes; the owner's lawyer has the final word.

---

## Call Capture

**Set-up record** (`knowledge/policies.md → Recording`):

| Meeting type | Recorded? | Tool | Retention | Stored in |
|---|---|---|---|---|
| Sales discovery | yes, with notice | Zoom cloud + transcript | 12 months | Drive / Deals / <deal> |
| Client check-ins | client opts in | Meet transcripts | contract + 6 months | Drive / Clients / <client> |
| Internal 1:1s | no | — | — | — |

**Notice wording:**

```text
Invite line: "We record this call to take accurate notes. Tell us any time if you'd rather we didn't."
Spoken at the start: "Before we start, we're recording so I can focus on you rather than my notes.
Is that OK?" → No: stop the recorder and take notes by hand.
```

**Filing rule:** match by attendee email domain → client/deal; by calendar event id → meeting. No match
→ "unfiled" list for a person, never guessed.

---

## Transcript Processing

**Record template** (`output/operations/transcript-processing/<date>-<meeting>.md`):

```markdown
# <Meeting> · <date> · <attendees>
Summary (5 lines): …
Decisions: …
Actions: | Owner | Action | Due |
Pains (quotes): "…" [12:40] · Objections: "…" [24:05] · Praise: "…" [31:10]
Questions they asked: … · Sentiment: <positive | mixed | negative> because …
Risks: … · Follow-up needed: <yes: what, by whom> | no
Consent: recording notice given <yes>; quotes usable in marketing <only with written OK>
```

**Worked example.** A 35-minute discovery call: 3 decisions, 4 actions (2 ours, 2 theirs), two pain quotes
on missed calls, one objection on price; routed to deal-debrief-analyst (deal update) and
followup-coordinator (recap email draft).

**Search answers** cite meeting, date and timestamp: "On 14 Oct (call with Jo Patel, 18:22) they said…".

---

## Log each job

```
node bin/wf.mjs log --skill meeting-intelligence-engineer --job "Call Capture" --status done --summary "<n> transcripts filed, <n> unfiled" --minutes-saved 15
node bin/wf.mjs log --skill meeting-intelligence-engineer --job "Transcript Processing" --status done --summary "<meeting>: <n> actions, routed" --minutes-saved 25
```
