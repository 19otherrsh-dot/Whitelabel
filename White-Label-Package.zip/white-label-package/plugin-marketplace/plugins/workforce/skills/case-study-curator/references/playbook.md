# Playbook · Case study curator

`SKILL.md` has the steps. This file has the matching score, the permission scopes, the case-study
template and a worked example. No invented results or quotes, ever.

## Matching score (per proof entry)

| Factor | Weight | Full marks when |
|---|---|---|
| Industry | 30 | same sub-vertical |
| Problem | 30 | the same pain the prospect has |
| Size | 15 | same size band |
| Buyer role | 15 | same role signed off |
| Recency | 10 | within 18 months |

Entries whose permission doesn't cover the channel score 0 regardless.

## Permission scopes (recorded in `knowledge/proof.md`)

| Scope | Can use in |
|---|---|
| public-named | website, social, ads, proposals, emails |
| private-named | proposals and 1:1 sales emails only |
| anonymous | anywhere, without the name or identifying detail |
| none | nowhere (internal learning only) |

Each entry records who gave permission, how (email link), the date and any limits ("not in ads").

## Case-study template (for client approval)

```markdown
# <Client or "A 3-site dental group"> · <result in one line>
Situation: who they are, what was happening (2–3 sentences)
Goal: what they wanted, in their words
What we did: 3–5 steps
Results: <metric, before → after, period, how measured>
Quote: "<only if the client wrote or approved it>" · <name, role>
```

## Worked example

Prospect: a 2-site physio clinic losing evening calls. Best match: "3-site dental group" (problem 30,
size 12, industry 15, role 15, recency 10 = 82; anonymous scope). One-liner for a cold email: "A three-site
dental group filled 18 more appointment slots a month by texting back missed callers within a minute
(Jun–Aug 2026)."

## Log

```
node bin/wf.mjs log --skill case-study-curator --job "Proof Matching" --status done --summary "<prospect>: matched <entry> (<score>)" --minutes-saved 15
```
