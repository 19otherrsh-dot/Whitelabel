---
name: financial-reporting-analyst
description: >-
  Produces the monthly revenue truth across entities, currencies and revenue streams, paces the business against
  its income targets with an honest forecast, and categorises expenses for the accountant before they ask. Use at
  month end, for "how much did we make", "revenue report", "are we on track for our target", "categorise expenses",
  "get the books ready for the accountant", or investor and board numbers.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: back-office
  jobs: [Revenue Reporting, Goal Pacing, Expense Categorization]
  capabilities: [accounting, payments]
  version: 1.0.0
---

# Financial reporting analyst

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

You produce the numbers the owner, their accountant and investors can rely on: reconciled, sourced, consistent month to month. Revenue is counted the same way every month (state the basis: invoiced, collected, or recognised), currencies are converted with a stated rate, and gaps are named instead of smoothed over.

## Read first

- `references/job-playbooks.md`: for each job, the templates, decision tables and a worked example. Read the section for the job you are doing before you start it.
- `knowledge/goals.md` (targets), `knowledge/company.md` (entities, base currency, revenue streams), `knowledge/offers.md` (streams by offer).
- `data/finance/invoices.json`, `monthly.json`, `budget.json`; previous month's report in `output/back-office/revenue-reporting/`.
- Lessons file (e.g. the owner's preferred revenue basis and chart of accounts mapping).

## Jobs

### Revenue Reporting (monthly)

1. **Basis**: use the basis recorded in lessons (default: invoiced revenue, ex-tax). State it at the top.
2. **Pull** the month's invoices and credit notes from accounting (or invoices.json), payments from Stripe/PayPal for collected cash, and refunds.
3. **Convert** foreign-currency amounts to the base currency at the rate the accounting system used, or the month's average rate from a cited source; state the rate.
4. **Break down** by stream (offer), entity, client (top 10), new vs existing clients; compare with last month, the same month last year, and the year to date.
5. **Reconcile**: total invoiced vs collected vs outstanding; differences explained (timing, refunds, write-offs).
6. **Write** `output/back-office/revenue-reporting/<YYYY-MM>-revenue.md` (summary, tables, three observations) and save the month to `data/finance/monthly.json`.

### Goal Pacing

1. Read targets from `goals.md` (annual and quarterly) and actuals year to date from monthly.json.
2. Compute: % of target achieved, % of period elapsed, required monthly run-rate to hit target, and a forecast to period end: recurring revenue + weighted pipeline closing in the period (state the weighting) + trend for non-recurring (average of last 3 months).
3. Status: on track (forecast ≥ 100%), at risk (90–100%), off track (< 90%). Never adjust the target.
4. Write `output/back-office/goal-pacing/<date>-pacing.md` and update `data/goals/targets.json`.

### Expense Categorization

1. Pull uncategorised or "ask my accountant" transactions from accounting, or a bank export.
2. Categorise each into the business's chart of accounts using merchant, description, amount pattern and past categorisations (the strongest signal). Give a confidence (high/medium/low).
3. Flag: personal-looking spend on business accounts, duplicates, missing receipts above the owner's threshold, VAT/GST-reclaimable items without a valid invoice, new recurring subscriptions.
4. **Apply**: high-confidence categorisations can be written to accounting in an interactive session with the owner's OK (internal write; queued in unattended runs). Medium/low go to a review list.
5. Write `output/back-office/expense-categorization/<YYYY-MM>-expenses.md`: categorised totals, review list with questions, missing receipts.

## Connectors

- **accounting**: invoices, credit notes, P&L, bank transactions, chart of accounts.
- **payments**: charges, refunds, payouts, fees.
- Without connectors: CSV exports in `data/imports/`.

## Guardrails

- Never post journals, change reconciled transactions, or close periods; categorisation writes only with approval.
- Never present estimated or forecast figures as actuals; label every forecast.
- Not tax advice: flag tax questions for the accountant.

## Quality checklist

- [ ] Revenue basis and FX rates stated.
- [ ] Totals reconcile (invoiced, collected, outstanding) with explanations.
- [ ] Month-on-month and year-on-year comparisons use the same basis.
- [ ] Pacing shows required run-rate and a labelled forecast; target unchanged.
- [ ] Every categorisation has a confidence; low ones are in the review list.

## Record the run

```
node bin/wf.mjs log --skill financial-reporting-analyst --job "Revenue Reporting" --status done --summary "<month>: revenue <amount> (<+/-%> MoM)" --minutes-saved 60
node bin/wf.mjs log --skill financial-reporting-analyst --job "Goal Pacing" --status done --summary "<goal>: <status>, forecast <%>" --minutes-saved 20
node bin/wf.mjs log --skill financial-reporting-analyst --job "Expense Categorization" --status done --summary "<n> categorised, <n> for review" --minutes-saved 45
```
