# Job playbooks · Financial reporting analyst

The detail behind each job in `SKILL.md`. These are management reports for the owner, not statutory
accounts or tax advice; the accountant's books win where they differ.

---

## Revenue Reporting

**Report:** `output/back-office/revenue-reporting/<YYYY-MM>-revenue.md`

```markdown
# Revenue · <Month YYYY>
Basis: <invoiced | collected>, ex-tax, in <base currency>. FX: <source and rate(s)>.
Revenue <amount> (Δ vs last month, vs same month last year) · YTD <amount>
## By stream  ·  ## By entity  ·  ## Top 10 clients (share of revenue)
## New vs existing clients
## Invoiced vs collected vs outstanding (reconciliation, differences explained)
## Three observations (each with the number behind it)
```

**Reconciliation rule:** invoiced − credit notes = net invoiced; collected = payments received in the
month (any invoice month); outstanding = open invoices at month end. Every difference over 2% gets a
named cause (timing, refund, write-off, FX).

**Concentration check:** if one client is > 25% of the month's revenue, say so in the observations.

**Data write:** `data/finance/monthly.json` item `{ id: 'YYYY-MM', revenue, byStream, byEntity, currency,
basis }`. If `wf sync` already wrote `byStream.stripe`/`byStream.shopify`, keep those and add the
accounting streams; don't double-count the same money (choose one source per stream, note it).

---

## Goal Pacing

**Formulas (state them in the report):**
- achieved % = actual YTD ÷ target
- elapsed % = days elapsed ÷ days in period
- required run-rate = (target − actual) ÷ months left
- forecast = actual + recurring × months left + Σ (deal value × probability) closing in period + average
  of last 3 months of non-recurring × months left

**Status:** on track (forecast ≥ 100%), at risk (90–100%), off track (< 90%).

**Worked example.** Annual target £480k; 9 months elapsed (75%); actual £330k (69%); recurring £28k/month;
weighted pipeline closing this year £36k; non-recurring averaging £6k/month. Forecast = 330 + 84 + 36 +
18 = £468k → 97.5%: at risk. Required run-rate £50k/month vs current £34k.

**Data write:** `data/goals/targets.json` item `{ id, goal, target, current, unit, by, status, updated, source }`.

---

## Expense Categorization

**Confidence rules:**

| Confidence | When | Action |
|---|---|---|
| high | same merchant categorised the same way 3+ times before | apply (interactive with OK; queued if unattended) |
| medium | merchant known but amount or description unusual | review list |
| low | new merchant, ambiguous description | review list with a question |

**Flags (always shown):** possibly personal spend, duplicates (same merchant, amount, within 3 days),
missing receipts above the threshold, tax-reclaimable items without a valid invoice, new recurring
subscriptions (and their annual cost).

**Report:** `output/back-office/expense-categorization/<YYYY-MM>-expenses.md`: totals by category vs last
month, the review list (transaction, suggested category, why, question), missing receipts, new
subscriptions.

---

## Log each job

```
node bin/wf.mjs log --skill financial-reporting-analyst --job "Revenue Reporting" --status done --summary "<Month>: <revenue> (<Δ>)" --minutes-saved 90
node bin/wf.mjs log --skill financial-reporting-analyst --job "Goal Pacing" --status done --summary "<status>: forecast <n>% of target" --minutes-saved 30
node bin/wf.mjs log --skill financial-reporting-analyst --job "Expense Categorization" --status done --summary "<n> categorised, <n> to review" --minutes-saved 45
```
