# Reply classification

| Class | Signals | Action |
|---|---|---|
| interested | Asks for times, pricing, details, "tell me more", "send info", forwards to a colleague with "let's talk" | Hot-Lead Routing |
| objection | Price, timing, "we already have X", "not a priority", "send it later", skepticism | Objection Response |
| referral | "Talk to {{name}}", "I'm not the right person, try…" | Referral Capture |
| not-now | "Reach out in Q2", "after our launch" | Record the date; schedule follow-up then |
| unsubscribe | "Remove me", "stop", "unsubscribe", "not interested, don't email" | Suppress + stop sequence |
| hostile | Angry, legal threats, "spam" | Suppress + stop; alert owner if legal/threatening |
| out-of-office | Auto-reply with dates | Pause until return |
| wrong-person | "Doesn't work here", "wrong address" | Mark contact invalid; ask for the right person only if polite |
| other | Anything else | Needs a person |

"Not interested" without asking to stop: treat as not-now with a long delay (6 months) unless the owner prefers suppression (lessons).
