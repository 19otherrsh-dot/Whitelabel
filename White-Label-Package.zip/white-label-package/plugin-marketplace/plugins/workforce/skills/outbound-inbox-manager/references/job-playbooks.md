# Job playbooks · Outbound inbox manager

The detail behind each job in `SKILL.md`, with `classification.md` (classes) and `objection-starter.md`
(the first rebuttals). Opt-outs are handled before anything else, every run.

---

## Reply Classification

**Order of operations per reply:**
1. Opt-out or hostile? → suppression list now (`data/compliance/suppression.json`, address; domain too
   if they say "anyone at our company"), stop the sequence, no reply. This step never waits for
   approval: honouring an opt-out is a legal duty, not an action on the owner's behalf.
2. Auto-reply (out of office, left the company)? → note the return date or the replacement contact.
3. Otherwise classify with a confidence; under 0.7 → "needs a person".

**Record** in `data/outreach/replies.json`:
`{ id, ts, campaign, from, company, classification, confidence, routedTo, draftPath, outboxId }`
and update the lead's `status` (`replied`, `opted-out`, `booked`…).

**Run summary:** `output/sales/reply-classification/<date-time>.md`: counts per class, opt-outs
processed, items needing a person.

**Worked example.** "Not right now, maybe in Q1 when we've hired." → `not-now`, confidence 0.9; lead
status `nurture`, follow-up date 15 Jan, no reply needed beyond a short thank-you if the owner's
lessons say so.

---

## Objection Response

**Reply shape (under 90 words):**

```text
<acknowledge their specific point in their words>
<the approved response, adapted to their situation, with one proof point if relevant>
<one easy next step, often a question>
```

**Matching:** pick the library entry by meaning, not keywords ("we use a freelancer for that" = "already
have a solution"). If two entries fit, use the one that progressed more deals.

**New objection:** best-attempt draft marked `NEW OBJECTION: needs approval`, and an entry appended to
the library's pending list with the prospect's words. It's queued like any reply; the owner sees the
mark in the outbox.

---

## Hot-Lead Routing

**Within the hour of an "interested" reply:**

| Output | Where |
|---|---|
| Reply with 2–3 times or the booking link | outbox (`--type email`) |
| Deal created/updated: stage `qualified`, source = campaign | CRM (internal write; queued if unattended) and `data/pipeline/deals.json` |
| Alert to the deal owner | internal message: who, company, quote, fit score, campaign, link to the draft |
| Meeting booked → brief request | call-prep-researcher |

**Alert template:**

```text
Hot reply · <name>, <title> at <company> (fit <score>, tier <A|B>)
"<their words>"
Campaign: <name> · Draft reply ready in approvals: <outbox id>
```

---

## Log each job

```
node bin/wf.mjs log --skill outbound-inbox-manager --job "Reply Classification" --status done --summary "<n> replies: <n> interested, <n> opt-outs" --minutes-saved 20
node bin/wf.mjs log --skill outbound-inbox-manager --job "Objection Response" --status queued --summary "<n> objection replies queued" --minutes-saved 15
node bin/wf.mjs log --skill outbound-inbox-manager --job "Hot-Lead Routing" --status queued --summary "<n> hot leads routed" --minutes-saved 15
```
