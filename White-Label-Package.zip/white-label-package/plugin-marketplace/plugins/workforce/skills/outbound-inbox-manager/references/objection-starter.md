# Objection starter (until the business's own library exists)

Approaches, not scripts: always adapt to the person and use only facts from the knowledge base.

| Objection | Approach |
|---|---|
| "We already use X" | Acknowledge X; ask what they'd change about it; mention the one difference that matters to their segment (competitors.md) |
| "No budget" | Ask when budgets are set; offer a smaller first step if offers.md has one; propose following up then |
| "Not a priority" | Ask what is the priority this quarter; connect only if there's a real link; otherwise agree a later date |
| "Send me info" | Send one short, specific resource (not a brochure) plus a question that qualifies |
| "How much?" | Give the price or range from offers.md if public; otherwise the starting price and what drives it |
| "Is this automated / spam?" | Honest: yes, they were contacted because {{reason}}; offer to stop |
