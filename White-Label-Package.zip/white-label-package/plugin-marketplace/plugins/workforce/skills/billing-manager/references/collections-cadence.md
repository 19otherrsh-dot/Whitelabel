# Collections cadence

Default schedule. If `knowledge/policies.md → Late payment process` defines one, use that instead.

| Stage | When | Tone | Content |
|---|---|---|---|
| 0. Friendly heads-up | 3 days before due (optional, for new clients) | Warm, helpful | Invoice n, amount, due date, pay link |
| 1. Gentle reminder | 1–3 days overdue | Friendly, assumes oversight | "Just a reminder that invoice n for X was due on D. Here's the link. If it's already on its way, thank you." |
| 2. Clear reminder | 7–10 days overdue | Polite, direct | Restate amount and due date; ask for an expected payment date; offer help if there's a problem with the invoice |
| 3. Firm reminder | 14–21 days overdue | Firm, professional | Note it's now N days overdue; ask for payment or a date by a specific day; mention late fees only if in the terms |
| 4. Person takes over | 30+ days overdue | — | No email from the agent. Draft a note to the owner: history, amounts, suggested next step (call, payment plan, pause work, formal notice) |

Rules:

- One reminder per stage; never two emails in the same week to the same client about the same invoice.
- Combine several overdue invoices for one client into one email listing each.
- If the client replied at any point (dispute, question, promise to pay on a date), stop the cadence and follow the reply: Payment Tracking records the promised date; if it passes, resume at the next stage.
- Thank the client when payment arrives (optional, owner's choice, recorded as a lesson).

## Example wording (stage 2, adapt to voice.md)

Subject: Invoice {{number}} — {{amount}} due {{due_date}}

Hi {{first_name}},

Invoice {{number}} for {{amount}} was due on {{due_date}} and I can't see payment yet. Could you let me know when it's scheduled? Here's the link to pay: {{pay_link}}.

If something on the invoice needs fixing, reply and I'll sort it straight away.

{{sign_off}}
