# INVOICE {{number}}

**From:** {{issuer_legal_name}} · {{issuer_address}} · {{tax_label}} {{issuer_tax_number}}
**To:** {{client_legal_name}} · {{client_billing_address}} {{client_tax_number_if_required}}
**Issue date:** {{issue_date}} · **Due date:** {{due_date}} · **Reference / PO:** {{po_or_reference}}

| Description | Qty | Unit price | Tax | Amount |
|---|---|---|---|---|
| {{line_description}} | {{qty}} | {{unit_price}} | {{tax_rate}} | {{line_total}} |

| | |
|---|---|
| Subtotal | {{subtotal}} |
| Less deposit / previous instalment ({{ref}}) | −{{deposit}} |
| Tax | {{tax_total}} |
| **Total due ({{currency}})** | **{{total}}** |

**Payment terms:** {{payment_terms}}
**How to pay:** {{pay_link_or_bank_details_from_accounting_system}}
{{tax_note_if_any}}

Questions about this invoice: {{billing_contact}}

---

Email to send with it (queued for approval):

Subject: Invoice {{number}} from {{trading_name}} — {{total}} {{currency}}

Hi {{first_name}},

Please find invoice {{number}} for {{short_description}}, {{total}} {{currency}}, due on {{due_date}}. {{pay_link_sentence}}

Thank you, and let me know if anything needs changing.

{{sign_off}}
