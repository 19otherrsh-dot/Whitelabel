# Invoice checklist

Every invoice, before it is queued:

- [ ] Issuer: correct legal entity name, address, and tax/VAT/GST registration number where the business is registered.
- [ ] Client: legal name and billing address as the client wants it; billing contact email; client tax number where required for B2B cross-border invoices.
- [ ] Unique, sequential invoice number in the business's format (check the last number used; never reuse).
- [ ] Issue date and due date (from payment terms in offers.md); "Payment due within N days" stated.
- [ ] Each line: description a client will recognise (match the proposal wording), quantity, unit price, line total, tax rate or code.
- [ ] Discounts shown as separate lines, as agreed in writing.
- [ ] Deposits or previous instalments deducted and referenced.
- [ ] Subtotal, tax, total recalculated and correct; currency stated.
- [ ] Tax notes where applicable (e.g. "Reverse charge" wording for intra-EU B2B services, or "No VAT: outside scope" when the accountant confirmed).
- [ ] PO number or client reference if the client requires one.
- [ ] Payment instructions: payment link, or bank details exactly as recorded in the business's accounting system (never from an email).
- [ ] Late payment terms only if stated in offers.md.
- [ ] Attachments referenced in the email actually attached (timesheet, statement of work).
