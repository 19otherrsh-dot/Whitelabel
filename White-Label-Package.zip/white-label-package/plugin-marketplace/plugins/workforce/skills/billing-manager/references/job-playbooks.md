# Job playbooks · Billing manager

`SKILL.md` already has the steps; `invoice-checklist.md`, `invoice-template.md` and
`collections-cadence.md` have the rules. This file adds a worked example per job and the edge cases that
come up most.

---

## Invoice Generation · worked example

*Bright Harbor Studio* signed a 3-month retainer at £2,400/month (proposal v2, 14 Oct), plus a one-off
setup fee of £900. Deposit: none. Terms: 14 days. UK client, UK VAT-registered business.

| Check | Result |
|---|---|
| Client legal name and billing contact | from the signed proposal: "Bright Harbor Studio Ltd", accounts@… |
| Items | Setup £900 (one-off); Retainer October £2,400 |
| Prices match the source | yes (proposal v2, section 4) |
| Already invoiced? | search invoices.json for the deal: none |
| Tax | UK B2B: VAT 20% on both lines (owner's accountant confirmed the treatment) |
| Total | £3,300 + £660 VAT = £3,960, due 14 days from issue |

Outputs: draft invoice in accounting; outbox item `--type invoice --amount 3960` to accounts@…; record in
`data/finance/invoices.json` as `draft`.

**Edge cases**
- **Cross-border B2B:** tax treatment varies (e.g. reverse charge within the EU, or no UK VAT for many
  services to non-UK businesses). Ask the owner/accountant once per client country; record the answer
  in lessons.
- **Client requires a PO number:** don't send without it; ask the client contact (queued) and hold.
- **Partial month:** pro-rate only if the agreement says so, and show the calculation on the invoice.

---

## Payment Tracking · worked example

Bank export shows £3,960 from "BRIGHT HARBOR ST" with reference "INV-1042". Matches invoice INV-1042 by
reference and amount → `paid`, `paidDate` = bank date. A second payment of £1,200 with reference "Oct"
from an unknown payer matches nothing → "needs a person" list with the full line.

**Edge cases:** one payment for two invoices (match by sum and reference; record both); overpayment
(record `paidAmount`, flag the credit for the owner); bank fees deducted by the payer (small shortfall:
`partial` with a note, the owner decides whether to write it off).

---

## Collections · worked example

Invoice INV-1031, £1,800, 17 days overdue, one reminder already sent at day 3 → stage "15–30 days:
second reminder" in the cadence. Draft: invoice number, amount, original due date, payment link, "If
there's a problem with this invoice, reply and we'll sort it out." Client has no dispute or payment plan
noted → queue.

**Edge cases:** client disputes the work → stop reminders, note to the account owner; client on a payment
plan → remind only of missed instalments; an invoice reaching the "person takes over" stage → a note to
the owner with the history, no more automated emails.

---

## Log each job

```
node bin/wf.mjs log --skill billing-manager --job "Invoice Generation" --status queued --summary "INV-<n> <client> <amount>" --minutes-saved 20
node bin/wf.mjs log --skill billing-manager --job "Payment Tracking" --status done --summary "<n> matched, <n> unmatched; overdue <amount>" --minutes-saved 20
node bin/wf.mjs log --skill billing-manager --job "Collections" --status queued --summary "<n> reminders queued, <n> to the owner" --minutes-saved 20
```
