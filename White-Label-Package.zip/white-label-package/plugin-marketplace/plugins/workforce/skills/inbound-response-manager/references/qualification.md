# Inbound qualification

Score each criterion 0–2 using customers.md:

| Criterion | 2 | 1 | 0 |
|---|---|---|---|
| Segment fit (industry, size, model) | Core segment | Adjacent | Outside / red flag |
| Role | Decision-maker or champion | Influencer | Unrelated / student / vendor |
| Need | Specific problem we solve | Vague interest | No need stated / wants something we don't do |
| Timing | Now / this quarter | Later this year | No timeline |
| Budget signal | Matches our price range | Unknown | Clearly below minimum |

Tier: A = 8–10 with no red flag · B = 5–7 · C = 0–4 or any red flag.
