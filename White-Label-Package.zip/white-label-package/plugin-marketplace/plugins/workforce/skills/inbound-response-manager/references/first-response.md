# First-response templates (draft with the owner, then save to output/deals/speed-to-lead/templates.md)

## A-tier

Subject: Re: {{their subject}}

Hi {{first_name}},

Thanks for getting in touch about {{their need in their words}}. {{One-sentence specific answer to their question, from the knowledge base.}}

The quickest way to see if we can help is a {{length}}-minute call. {{Booking link}} — or reply with a couple of times that suit you.

{{sign_off}}

## B-tier

Hi {{first_name}},

Thanks for reaching out. {{Answer to their question.}} {{One relevant resource link.}}

To point you in the right direction: {{one qualifying question, e.g. "what prompted you to look at this now?"}}

{{sign_off}}

## C-tier (not a fit)

Hi {{first_name}},

Thanks for thinking of us. {{Honest reason we're not the right fit, kindly.}} {{If known, a better alternative or resource.}}

{{sign_off}}
