# Job playbooks · Inbound response manager

The detail behind each job in `SKILL.md`: inputs, decision rules, output, a worked example (fictional
names), and hand-offs.

---

## Inbox Triage

**Needs:** new messages from the sales inbox, contact forms and DMs (connector or export);
`data/customers/accounts.json` to recognise existing clients; `knowledge/team.md` for routing.

**Classify in this order** (first match wins):

| Check | Class | Route |
|---|---|---|
| Sender's domain or email matches an account | client | customer-lead (support or account owner) |
| Mentions a referral by name | lead (referral) | Referral Capture + Lead Qualification |
| Asks about buying, pricing, availability, a proposal | lead | Lead Qualification |
| Offers a partnership, sponsorship, collaboration | partnership | owner / brand deals |
| Sells something to the business | vendor pitch | archive suggestion, no reply unless the owner wants one |
| Applying for a job, sending a CV | job seeker | talent-coordinator |
| Newsletters, notifications, auto-replies, spam | noise | archive suggestion |

**Output:** `output/deals/inbox-triage/<date-time>-triage.md` (table: from, subject, class, route,
one-line summary) and new leads in `data/pipeline/leads.json` with `source: inbound`, `status: new`.
Never delete or archive; propose it.

---

## Lead Qualification

**Needs:** the message; `knowledge/customers.md` (ICP and red flags); `references/qualification.md`.

**Enrichment limit:** company website, size range, industry, location. Don't look up personal social
profiles or private data; it isn't needed to answer an enquiry.

**Tiering** (from `qualification.md`), with a reason per tier:

| Tier | Rule of thumb | First response |
|---|---|---|
| A | ICP fit + clear need + timing or budget signal | Answer + booking link or two times |
| B | ICP fit, need or timing unclear | Answer + one qualifying question + a useful resource |
| C | Outside the ICP, or a red flag | Polite, helpful redirect; no booking push |

Red flags (from `customers.md`) are listed, not judged: the owner decides on borderline ones.

**Write back on the lead:** `fitScore` (0–100), `tier`, `reasons: [..]`, `redFlags: [..]`,
`enrichment: { website, size, industry }`.

**Worked example.** "Hi, we're a 12-person dental group in Leeds, our front desk can't keep up with
calls, can you help before September?" → ICP fit (local service business, 10–50 staff), clear need
(call handling), timing (September). Tier A, fitScore 86.

---

## Speed-to-Lead

**Needs:** the approved templates (`output/deals/speed-to-lead/templates.md`); the knowledge base for
the specific answer; the booking link (`workspace.json → provider` or `knowledge/team.md`).

**Rules for the first reply.**
- Under 120 words. Answer their actual question first, from the knowledge base, or say who will.
- One question only. One next step only.
- No prices that aren't in `offers.md`; no availability promises the owner hasn't set.
- Sent from the person the lead will deal with, in the house voice.
- Outside business hours, the reply can still be queued; the guard decides when it goes.

**Template skeleton** (fill per tier):

```text
Hi {{first_name}},

Thanks for getting in touch about {{their_need}}. {{direct_answer_from_knowledge}}

{{one_question}}

{{next_step}}

{{signature}}
```

**Output:** an outbox item per lead (`--type email`), and for tier A an internal alert to the deal
owner with the summary and the draft. Record `firstResponseAt` on the lead when sent.

**Measure:** median minutes from enquiry to first reply, weekly, in the deals report.

---

## Referral Capture

**Needs:** the message naming the colleague; the referrer's relationship (client, partner, friend).

**Two drafts, in order:**
1. To the referrer: thank them; ask whether they're happy to introduce, or to be mentioned. No
   message to the colleague until they say yes.
2. After the yes: either a short double-opt-in intro for the referrer to forward, or a first message
   to the colleague that names the referrer and says why they were mentioned.

**Write back:** `referredBy` on the new lead; on the referrer's record, `referralsGiven += 1`.
Thank the referrer again when the referral books a call (a queued, personal note).

---

## Log each job

```
node bin/wf.mjs log --skill inbound-response-manager --job "Inbox Triage" --status done --summary "<n> messages: <n> leads, <n> clients" --minutes-saved 15
node bin/wf.mjs log --skill inbound-response-manager --job "Lead Qualification" --status done --summary "<n> leads tiered (A <n>)" --minutes-saved 10
node bin/wf.mjs log --skill inbound-response-manager --job "Speed-to-Lead" --status queued --summary "<n> first replies queued" --minutes-saved 10
node bin/wf.mjs log --skill inbound-response-manager --job "Referral Capture" --status queued --summary "Referral from <referrer>" --minutes-saved 10
```
