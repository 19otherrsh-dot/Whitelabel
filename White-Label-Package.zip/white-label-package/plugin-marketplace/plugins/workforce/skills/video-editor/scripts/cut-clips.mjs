#!/usr/bin/env node
// Cut clips from a source video with ffmpeg, optionally crop to vertical 9:16 and burn captions.
// Usage: node cut-clips.mjs <clips.json> <source-video> <out-dir> [--vertical] [--srt <file.srt>] [--font "Inter"]
// clips.json: [{ "start": 125.4, "end": 172.0, "title": "why-replies-matter" }, ...]   (seconds, or "mm:ss.s" / "hh:mm:ss.s")
// Needs ffmpeg on PATH (ffmpeg -version). Source is never modified.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const args = process.argv.slice(2);
const flag = (n) => { const i = args.indexOf(n); return i > -1 ? args.splice(i, 2)[1] : null; };
const vertical = args.includes('--vertical'); if (vertical) args.splice(args.indexOf('--vertical'), 1);
const srt = flag('--srt');
const font = flag('--font') || 'Arial';
const [clipsFile, source, outDir] = args;
if (!clipsFile || !source || !outDir) { console.error('Usage: node cut-clips.mjs <clips.json> <source> <out-dir> [--vertical] [--srt file.srt] [--font Name]'); process.exit(1); }
if (spawnSync('ffmpeg', ['-version']).status !== 0) { console.error('ffmpeg not found. Install it (macOS: brew install ffmpeg; Windows: winget install ffmpeg; Linux: apt install ffmpeg).'); process.exit(1); }

const toSec = (t) => typeof t === 'number' ? t : String(t).split(':').reverse().reduce((a, v, i) => a + parseFloat(v) * 60 ** i, 0);
const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50) || 'clip';
const clips = JSON.parse(fs.readFileSync(clipsFile, 'utf8'));
fs.mkdirSync(outDir, { recursive: true });

// Shift an SRT so a clip's captions start at 0.
function clipSrt(srtText, start, end) {
  const fmt = (s) => { const ms = Math.max(0, Math.round(s * 1000)); const h = Math.floor(ms / 3600000), m = Math.floor(ms / 60000) % 60, sec = Math.floor(ms / 1000) % 60, r = ms % 1000; return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')},${String(r).padStart(3, '0')}`; };
  const parse = (t) => { const [h, m, rest] = t.split(':'); const [s, ms] = rest.split(','); return +h * 3600 + +m * 60 + +s + +ms / 1000; };
  const out = []; let n = 1;
  for (const block of srtText.replace(/\r/g, '').split(/\n\n+/)) {
    const lines = block.trim().split('\n'); const tl = lines.find((l) => l.includes('-->')); if (!tl) continue;
    const [a, b] = tl.split('-->').map((x) => parse(x.trim()));
    if (b <= start || a >= end) continue;
    out.push(`${n++}\n${fmt(Math.max(a, start) - start)} --> ${fmt(Math.min(b, end) - start)}\n${lines.slice(lines.indexOf(tl) + 1).join('\n')}`);
  }
  return out.join('\n\n') + '\n';
}

const srtText = srt ? fs.readFileSync(srt, 'utf8') : null;
clips.forEach((c, i) => {
  const start = toSec(c.start), end = toSec(c.end);
  if (!(end > start)) { console.error(`Clip ${i + 1}: end must be after start`); return; }
  const name = `${String(i + 1).padStart(2, '0')}-${slug(c.title || 'clip')}`;
  const out = path.join(outDir, `${name}.mp4`);
  const filters = [];
  if (vertical) filters.push("crop='min(iw,ih*9/16)':'ih',scale=1080:1920");
  let subFile = null;
  if (srtText) {
    subFile = path.join(outDir, `${name}.srt`);
    fs.writeFileSync(subFile, clipSrt(srtText, start, end));
    const esc = subFile.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "\\'");
    filters.push(`subtitles='${esc}':force_style='FontName=${font},FontSize=${vertical ? 14 : 22},Bold=1,Outline=2,MarginV=${vertical ? 120 : 40}'`);
  }
  const ff = ['-y', '-ss', String(start), '-to', String(end), '-i', source, ...(filters.length ? ['-vf', filters.join(',')] : []), '-c:v', 'libx264', '-preset', 'medium', '-crf', '20', '-c:a', 'aac', '-b:a', '160k', '-af', 'loudnorm=I=-14:TP=-1.5:LRA=11', '-movflags', '+faststart', out];
  const r = spawnSync('ffmpeg', ff, { encoding: 'utf8' });
  console.log(r.status === 0 ? `✓ ${out} (${(end - start).toFixed(1)}s)` : `✗ ${name}: ${r.stderr.split('\n').slice(-3).join(' ')}`);
});
