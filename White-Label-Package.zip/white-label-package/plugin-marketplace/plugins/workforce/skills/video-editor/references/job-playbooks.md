# Job playbooks · Video editor

The detail behind each job in `SKILL.md`. Rendering uses `scripts/cut-clips.mjs` (ffmpeg); nothing is
posted from here: publishing goes through the content calendar and the outbox.

---

## Clip Extraction

**Moment scoring** (1–5 each; keep clips scoring 14+ of 20):

| Criterion | 5 looks like | 1 looks like |
|---|---|---|
| Hook | first sentence is a claim, number or question | "So, um, yeah, another thing…" |
| Standalone | makes sense with no context | refers to "what I said earlier" |
| Value | the viewer learns or can do something | general chat |
| Emotion | surprise, humour, conviction, a story | flat delivery |

**`clips.json` entry:**

```json
{ "id": "c03", "start": 412.4, "end": 461.0, "title": "Why most follow-ups fail",
  "hook": "Most follow-ups fail in the first line.", "platform": ["shorts", "reels"],
  "context_card": null, "permission": "host only" }
```

**Caption checks:** every proper noun, number and acronym checked against the audio; max ~32 characters
per line, 2 lines; keep out of the bottom ~15% and right ~10% of a vertical frame.

**Worked example.** A 48-minute webinar transcript gives 11 candidate moments; 6 score 14+; one (a
guest's story) needs the guest's permission → `permission: "ask guest"` and it isn't rendered until a
yes is recorded. Output: 5 vertical clips with burned captions, 5 SRT files, and a calendar entry each.

---

## Video Production

**Edit plan template** (`output/marketing/video-production/<slug>/plan.md`):

```markdown
# <Title> · <platform> · <length>
| Beat | Time | Script line | Visual (A-roll / B-roll / screen) | On-screen text | Sound |
|---|---|---|---|---|---|
| Hook | 0–3s | … | face, tight crop | 6-word hook | music in |
| Problem | 3–12s | … | B-roll: … | … | … |
| … | | | | | |
Music: <track, licence and where it's recorded> · Disclosure: <AI used? how labelled>
Exports: 9:16 1080×1920 · 16:9 1920×1080 · loudness −14 LUFS
```

**Export check before hand-off:** resolution and frame rate as planned; audio peaks below −1 dBTP;
captions on; first frame works as a thumbnail; file named `<date>-<slug>-<ratio>.mp4`.

**Licensing:** only music and footage with a commercial licence recorded in `knowledge/assets.md`;
stock from the business's own subscriptions. No celebrity likeness or voice imitation.

---

## Log each job

```
node bin/wf.mjs log --skill video-editor --job "Clip Extraction" --status draft --summary "<source>: <n> clips rendered" --minutes-saved 90
node bin/wf.mjs log --skill video-editor --job "Video Production" --status draft --summary "<title>: <ratios> exported" --minutes-saved 120
```
