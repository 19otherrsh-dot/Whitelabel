# {{Question}}

{{date}} · for {{decision}} · confidence: {{overall}}

## Answer
{{2–4 sentences: the answer, how sure we are, and the single most important reason.}}

## What this means for {{company}}
- {{implication / recommended action}}

## Findings
### 1. {{Sub-question}}
{{Finding}} — *{{confidence}}* [{{n}}]

### 2. …

## Where sources disagree
{{conflict, which source we trust and why}}

## What we don't know
- {{gap}} — how to find out: {{…}}

## What would change this answer
- {{evidence}}

## Method
{{search approach, sources types, date range, limitations}}

## Sources
[1] {{Title}} — {{publisher}}, {{date}}. {{URL}}
