# Job playbooks · Brand deal producer

The detail behind each job in `SKILL.md`. Sponsored content is always disclosed clearly and at the start;
claims are only the sponsor's substantiated, approved ones.

---

## Deal Scripting

**Fit check:**

| Question | Answer needed |
|---|---|
| Has the creator used the product? | yes (how long) / trial in progress / no → say so or pass |
| Fits the audience's needs? | yes, because … |
| Conflicts with exclusivity or a recent sponsor? | none / list |
| Claims in the brief substantiated? | each claim with its source |
| Restricted category (health, finance, alcohol, gambling, children)? | rules that apply |

**Script structure (60–90 s mid-roll):**

```text
Disclosure (first line): "This part of the video is sponsored by <brand>."
Transition in: tie to what the video was just about.
Experience: what the creator actually did with it, in their words.
Key messages (2–3): from the brief, accurate.
Offer: code/link, what it gives, expiry.
Transition out: back to the topic.
Caption: "#ad · Paid partnership with <brand>" + platform's paid-partnership label on.
```

---

## Approval Docs

**Approval document outline:**

```markdown
# <Brand> × <creator> · approval pack · <date>
Deliverables: | Platform | Format | Length | Post date | Status |
Script / talking points: …
Visual notes: shots, product on screen, what won't be shown
Captions, links, codes: …
Disclosure wording: …
Usage rights: where the brand can reuse it, for how long (from the agreement)
Contact: … · Changes requested: <round 1: …>
```

Approvals and change requests are recorded with dates; posting waits for written approval if the
agreement requires it.

---

## Log each job

```
node bin/wf.mjs log --skill brand-deal-producer --job "Deal Scripting" --status draft --summary "<brand>: script v<n>" --minutes-saved 60
node bin/wf.mjs log --skill brand-deal-producer --job "Approval Docs" --status queued --summary "<brand>: approval pack queued" --minutes-saved 45
```
