# Technical SEO audit checklist

## Crawl and index
- [ ] robots.txt reachable; doesn't block important pages or assets
- [ ] XML sitemap exists, listed in robots.txt, contains only indexable canonical URLs
- [ ] No accidental `noindex`; canonicals self-referencing or correct
- [ ] One version of the site (https, www or not) with 301s from the others
- [ ] No 4xx/5xx on internal links; redirect chains ≤ 1 hop

## Page basics (each page)
- [ ] Unique title ≤ 60 chars with the primary topic first
- [ ] Unique meta description ≤ 155 chars that earns the click
- [ ] One H1; logical H2/H3 structure
- [ ] Answer-first intro for the page's main question
- [ ] Descriptive internal links; no orphan pages
- [ ] Images: alt text, modern formats, sized, lazy-loaded below the fold

## Performance and mobile
- [ ] Mobile layout works; tap targets spaced; no horizontal scroll
- [ ] Large images compressed; few render-blocking scripts; fonts preloaded or system
- [ ] Core Web Vitals checked where data is available

## Structured data (JSON-LD, validated)
- [ ] Organization (name, logo, sameAs profiles) on the home page
- [ ] LocalBusiness with address, hours, phone (if local)
- [ ] Service/Product for offer pages; Offer with price if public
- [ ] FAQPage for genuine FAQ sections; Article/Person for posts and authors
- [ ] BreadcrumbList

## Trust
- [ ] About page with real people, contact details, policies (privacy, terms)
- [ ] Consistent name/address/phone across the site and directories
