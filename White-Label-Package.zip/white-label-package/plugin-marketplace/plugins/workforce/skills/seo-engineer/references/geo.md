# Visibility in AI answers (GEO)

AI assistants answer questions by drawing on content they can crawl or retrieve, and often cite sources. What helps a business get mentioned and cited:

1. **Clear, quotable facts** on the site: what the business does, for whom, where, prices or price ranges, how it works, in plain sentences near the top of the page.
2. **Pages that answer real questions** in the words people use, with the answer first, then detail.
3. **Consistency** of the business's facts across the website, Google Business Profile, directories, LinkedIn, review sites and press. Contradictions reduce confidence.
4. **Original evidence**: data, case studies (with permission), named experts with credentials, and first-hand experience.
5. **Third-party mentions** from credible sources (industry publications, associations, podcasts, partner pages) earned honestly.
6. **Structured data** that makes entities and relationships explicit.
7. **Crawler access**: the owner decides whether to allow AI crawlers (e.g. via robots.txt). Blocking them may reduce visibility in AI answers; record the decision and revisit.
8. **Measurement**: weekly, ask the priority questions in available AI assistants and search; record whether the business is mentioned or cited and which competitors appear. Treat as directional, not exact.
