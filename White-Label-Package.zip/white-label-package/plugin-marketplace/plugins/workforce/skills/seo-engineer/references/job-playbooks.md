# Job playbooks · SEO engineer

The detail behind each job in `SKILL.md`, alongside `audit-checklist.md` (technical checks) and
`geo.md` (AI answers). This file adds the prioritisation, the templates and worked examples.

---

## SEO & GEO

**Prioritising issues** (fix in this order):

| Priority | Kind of issue | Examples |
|---|---|---|
| P1 | stops pages being found | `noindex` on a money page, blocked in robots.txt, 5xx, broken canonical |
| P2 | wastes what's found | missing/duplicate titles, thin or duplicate pages, redirect chains, slow LCP |
| P3 | improves the answer | intro answers, FAQs, schema, internal links, alt text |

**Topic map** (`output/marketing/seo-geo/<date>-topics.md`):

| Topic | Example queries (customers' words) | Intent | Page | Status |
|---|---|---|---|---|
| Missed-call follow-up for clinics | "patients don't call back", "missed call text" | problem | /missed-calls | brief needed |

**On-page template for one page:**

```markdown
URL: /missed-calls
Title (≤60): Missed calls cost clinics bookings · how to win them back
Meta (≤155): …
H1: …  · Intro answer (2–3 sentences): …
H2s: … · FAQ (3–5, phrased as asked): …
Internal links in: from /pricing, /blog/… · out: to /book
Schema: Service + FAQPage (JSON-LD attached)
```

**GEO check record** (`data/web/visibility.json`): question, where checked, date, whether the business
was named, which source was cited, and what to change. Facts across site and profiles must match
exactly (name, address, prices).

**Worked example.** Audit of a 14-page site: P1 none; P2: 6 pages share one title, 2 redirect chains;
P3: no FAQ or schema anywhere. Plan: queue new titles/metas for 6 pages (diffs attached), fix chains,
add Service + FAQ schema to the 3 offer pages, brief 2 missing topics.

---

## OG & Share Surface

**Checks per page:** tags present and absolute URLs; image 1200×630, under ~300 KB, text readable at
small size, safe area (no key text in the outer 60 px); title ≤ 60 chars, description ≤ 110 chars for
share cards; canonical matches the shared URL.

**Verification note:** for each page, the tags found by fetching it and whether the image URL returns
200 with an image type. Platform caches can show old cards: list the pages to re-scrape after changes.

---

## Log each job

```
node bin/wf.mjs log --skill seo-engineer --job "SEO & GEO" --status queued --summary "<n> P1, <n> P2 fixes queued" --minutes-saved 120
node bin/wf.mjs log --skill seo-engineer --job "OG & Share Surface" --status done --summary "<n> pages: share tags verified" --minutes-saved 30
```
