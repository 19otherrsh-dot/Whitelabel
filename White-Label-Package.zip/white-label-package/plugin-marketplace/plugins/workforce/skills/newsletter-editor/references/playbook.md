# Playbook · Newsletter editor

`SKILL.md` has the steps. This file has an issue skeleton, subject-line examples, the pre-send check and
the report format.

## Issue skeleton

```markdown
Subject: <≤ 50 chars> · Preview: <≤ 90 chars, adds to the subject>

<Hook: 2–3 sentences that make the main idea matter this week>

## <Main piece title>
<insight, story or how-to, 300–600 words>

## Quick ones
- <resource with one line on why>
- <tip>
- <client win, with permission>

<One CTA: reply / read / book / buy>
<Sign-off in the owner's voice>
Footer: sender · postal address · unsubscribe · "You're getting this because you signed up for …"
```

## Subject lines (good vs weak)

| Good | Why | Weak |
|---|---|---|
| "3 in 4 missed callers leave no voicemail" | specific, true, curious | "October newsletter" |
| "The 60-second rule for missed calls" | promise the issue keeps | "You won't BELIEVE this" |
| "What we learned from 4 clinics' call logs" | honest, concrete | "Quick update!!!" |

## Pre-send check

| Check | Pass when |
|---|---|
| Rendering | test email reads well on phone and desktop, dark mode included |
| Links | all open; UTM tags on own links |
| Personalisation | fallback set ("Hi there" if no first name) |
| Footer | sender, address, unsubscribe present |
| Segment | the right list, count stated in the outbox item |
| Claims | numbers sourced; client wins have permission |

## Report (48 h after)

Opens (directional only), clicks and top links, replies (themes), unsubscribes, conversions with evidence;
one lesson for the next issue.

## Log

```
node bin/wf.mjs log --skill newsletter-editor --job "Newsletter & Broadcast" --status queued --summary "Newsletter <date>: <n> recipients" --minutes-saved 120
```
