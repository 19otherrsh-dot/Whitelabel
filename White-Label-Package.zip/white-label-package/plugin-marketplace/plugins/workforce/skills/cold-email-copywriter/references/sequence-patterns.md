# Sequence patterns

## Default 4-step (business days)

| Step | Day | Purpose | Shape |
|---|---|---|---|
| 1 | 0 | Relevance + problem | Personal line → the problem people in their role have (their words) → what we do about it in one line → soft question |
| 2 | 3 | Proof | One short proof story (permitted) with a number → "worth a look for {{company}}?" |
| 3 | 7 | New angle | An insight, mistake to avoid, or resource relevant to their trigger; no ask beyond "useful?" |
| 4 | 12 | Close the loop | Courteous permission to stop: "Should I close this off, or is {{problem}} on your list for {{quarter}}?" |

Stop immediately on any reply, booking, bounce or opt-out.

## Email 1 skeleton (adapt to voice)

Subject: {{2–5 honest words, e.g. "front desk calls"}}

{{personal_line}}

Most {{role}}s at {{segment}} we talk to {{problem in their words}}. {{One line: what we do and the outcome.}}

{{Soft question, e.g. "Is that on your radar this quarter?"}}

{{sign_off}}

{{sender name}} · {{business}} · {{postal address}}
{{unsubscribe line}}

## Asks that work (low friction)

- "Worth a quick chat?" (yes/no)
- "Want me to send the 1-page breakdown?"
- "Who's the right person for this?"

## Avoid

"I hope this finds you well" · "just following up" · "quick question" subject with no question · fake "Re:" · walls of text · three links · attachments in email 1.
