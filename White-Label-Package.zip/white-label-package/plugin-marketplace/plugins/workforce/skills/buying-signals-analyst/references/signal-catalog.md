# Signal catalog

| Signal | Why it creates need | Detect via | Strength |
|---|---|---|---|
| Funding round | New budget, growth pressure | Funding news, press releases, investor announcements | Strong for growth services |
| Hiring for a relevant role | The problem exists and is being staffed | Job boards, careers pages | Strong (esp. first hire in a function) |
| Hiring surge | Scaling pains (ops, onboarding, tooling) | Count of open roles over time | Medium |
| New leader in buyer role | New leaders review vendors in first 90 days | Press, company news pages | Strong |
| New location / expansion | New process, systems, staffing needs | Press, local news, registries | Medium–strong |
| Product launch | Marketing and support load | Company blog, press | Medium |
| Tech change (adopted/dropped a tool) | Integration, migration, gaps | Job posts mentioning tools, tech-detection | Medium |
| Regulation affecting the vertical | Compliance work | Regulator announcements | Strong where relevant |
| Negative reviews about a competitor | Switching intent | Review sites | Medium |
| Website/brand relaunch | Investment in growth | Site changes | Weak–medium |
| Contract/renewal season in the vertical | Budget cycle | Industry knowledge (customers.md) | Medium |
