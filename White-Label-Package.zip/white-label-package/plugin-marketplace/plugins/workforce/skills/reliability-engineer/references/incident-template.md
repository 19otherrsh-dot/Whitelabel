# Incident: {{short title}} · {{date}}

**Status:** resolved / monitoring · **Severity:** {{customer-facing / internal}} · **Owner:** {{name}}

## Summary
{{two sentences: what broke, impact, how it was fixed}}

## Timeline ({{time zone}})
- {{time}} — {{event}}

## Impact
{{who/what was affected, for how long, what didn't happen that should have}}

## Root cause
{{the actual cause, and why it wasn't caught earlier}}

## Fix
{{what was changed}}

## Prevention
- [ ] {{monitor/check/test added}}
- [ ] {{SOP or skill updated}}

## Customer communication
{{what was said, by whom, when}}
