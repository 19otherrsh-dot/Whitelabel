# Job playbooks · Reliability engineer

The detail behind each job in `SKILL.md`. Every check here reads from `wf` commands and files in the
workspace; nothing in this skill changes another job's output.

---

## Monitoring & Alerting

**Inputs (run all, in this order):**

```
node bin/wf.mjs doctor --json
node bin/wf.mjs autopilot list --json
node bin/wf.mjs runs --days 1 --json
node bin/wf.mjs outbox approved --json
node bin/wf.mjs sync status --json
```
plus `runs/.guard.jsonl` (last 24h) and the tail of `runs/.autopilot.log`.

**Traffic lights per area:**

| Area | Green | Amber | Red |
|---|---|---|---|
| Schedules | all due runs ran | one missed run, cause known | 2+ missed, or the timer isn't installed while schedules are on |
| Runs | no failures | 1 failure, retried fine | repeated failures of one job, or any failure touching a client |
| Approvals | approved items dispatched within a tick | approved > 6h waiting | approved > 24h waiting |
| Safety | ≤ 2 guard denials | 3–9 denials | 10+ denials for one job, or any suspicious-content event |
| Data feeds | syncs ok within 24h | one sync failed | data older than 3 days |
| Budget | under forecast | forecast above cap | cap reached (work is stopping) |
| Setup | doctor clean | warnings | doctor `fail` |

**Report:** `output/operations/monitoring-alerting/<date>-health.md`: the light per area, then for
each amber/red item: what, since when, likely cause, the fix or next step, who.

Alert the owner only for red (internal message). Amber goes in the report.

---

## Cost & Usage Tracking

**Numbers to show** (from `wf budget --json` and `wf sessions --json`):
- spend this month, cap, forecast; by job, by department, by source (autopilot, dispatch, eval…);
- cost per completed run, per job, and hours saved per dollar (`minutesSaved / 60 / cost`);
- interactive sessions in tokens (not money: the plan covers them).

**Recommendations, each with the expected saving:**

| Pattern | Recommendation |
|---|---|
| Routine job on the reasoning model | move to the routine tier (`--model routine`) |
| A schedule whose output is rarely kept (rejected/ignored) | lower frequency or switch off |
| One job > 30% of spend with low hours saved | per-job budget, or review the skill |
| Spend rising week on week with flat runs | look for longer prompts / growing context (knowledge files) |

The owner applies changes. Never change budgets or schedules yourself.

---

## Incident Response

**Severity:**

| Sev | Meaning | Response |
|---|---|---|
| 1 | Clients affected (wrong message sent, data exposed, service down for them) | Tell the owner now with a holding-message draft; contain within the hour |
| 2 | Internal work blocked (schedules failing, approvals stuck) | Same day |
| 3 | Degraded (slow, partial data) | Next working day |

**Containment you may do:** `wf autopilot disable <schedule>`. Everything wider (pause all, revoke a
connector, rotate a key) is the owner's call: say exactly what to run.

**Diagnosis checklist:** recent `wf backup` commits and kit updates; connector changes or expired
tokens (`wf doctor`); rate limits or vendor outages (vendor status page); budget caps; a changed
knowledge file that a skill now misreads.

**Note:** `output/operations/incident-response/<date>-<slug>.md` from `incident-template.md`, blameless,
with at least one prevention item that's a check, not a promise ("doctor now warns when…").

**Worked example.** Monday's weekly review didn't run. `autopilot list` shows the schedule enabled,
`lastRun` Friday; `.autopilot.log` has no ticks since Saturday; the laptop was asleep. Sev 2. Fix: run it
now (`wf autopilot run weekly-review`); prevention: move unattended work to the hosted runtime or set
the computer not to sleep while plugged in.

---

## Log each job

```
node bin/wf.mjs log --skill reliability-engineer --job "Monitoring & Alerting" --status done --summary "<green|amber|red>: <n> red items" --minutes-saved 15
node bin/wf.mjs log --skill reliability-engineer --job "Cost & Usage Tracking" --status done --summary "$<spent> of $<cap>; <n> recommendations" --minutes-saved 20
node bin/wf.mjs log --skill reliability-engineer --job "Incident Response" --status done --summary "Sev <n>: <one line>" --minutes-saved 60
```
