# Playbook · Red team reviewer

`SKILL.md` has the steps; `docs/research-standards.md` has the source rules. This file has the claim
table, rating examples and the report layout.

## Claim table

| # | Claim (as written) | Type | Source given | Check done | Rating | Why |
|---|---|---|---|---|---|---|
| 1 | "The UK has 2,100 multi-site dental groups" | fact | lead database, Oct 2026 | opened; filters include single-site owners with two addresses | weakened | true count of groups ~1,650–1,800 |
| 2 | "Text-back lifts bookings 4×" | causal | our 4-clinic data | recomputed: 4.1× but n = 4 clinics, one month | weakened | small sample, no control |
| 3 | "Competitor X has no API" | fact | none | their docs list an API (dated Sept 2026) | false | contradicted |
| 4 | "Clinics will pay £40/site/month" | prediction | 3 calls | — | unsupported | three conversations aren't a price test |

## Rating guide

- **Holds**: the source says it, is credible and recent, and the arithmetic checks out.
- **Weakened**: directionally right but overstated, narrower than stated, or a small sample.
- **Unsupported**: plausible but no adequate source; needs evidence or softer wording.
- **False**: contradicted by better evidence (cite it).

## Report layout

```markdown
# Red team · <document> · <date>
Verdict: <the conclusion survives | survives with changes | doesn't survive>, in one sentence
Must change: 1. … 2. … 3. …
Claims: <n> holds · <n> weakened · <n> unsupported · <n> false  (table)
Strongest counter-argument: <steel-manned, 1 paragraph>
Assumptions that matter most: <assumption → how sensitive the conclusion is>
Evidence that would settle it: …
```

Attack claims, not the author; say clearly what survives.

## Log

```
node bin/wf.mjs log --skill red-team-reviewer --job "Adversarial Verification" --status done --summary "<doc>: <verdict>, <n> claims checked" --minutes-saved 90
```
