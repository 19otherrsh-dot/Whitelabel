# Landing page structure

1. **Hero** — Headline (the outcome, for whom, ≤ 12 words) · Subhead (how, and the main objection pre-empted, ≤ 25 words) · Primary CTA · Proof cue (a number, a recognisable client with permission, a rating with source)
2. **Problem** — 3 pains in the customer's words; the cost of doing nothing
3. **Solution** — what it is, in one paragraph; "how it works" in 3 steps
4. **Outcomes** — 3–5 benefits as results, not features
5. **Proof** — 1–3 stories or quotes (permitted), with specifics
6. **Offer** — what's included, price or "from" price (if public), terms, guarantee (only if real)
7. **Objections / FAQ** — 5–8 real questions with direct answers
8. **Final CTA** — restate the outcome; the same CTA; what happens after clicking
9. **Footer trust** — contact, privacy, terms

Awareness level changes the order: cold traffic needs more problem and proof before the offer; warm traffic can see the offer earlier.
