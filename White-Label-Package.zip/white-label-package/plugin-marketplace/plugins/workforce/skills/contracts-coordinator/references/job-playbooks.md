# Job playbooks · Contracts coordinator

The detail behind each job in `SKILL.md`, alongside `sow-structure.md`. This role fills approved
templates and tracks dates; it does not give legal advice, and legal clauses are never rewritten here.

---

## Agreement Drafting

**Deviation table** (in the cover note; each row is the owner's decision):

| Term | Standard (template / offers.md) | This deal | Risk in plain English | Decision |
|---|---|---|---|---|
| Payment terms | 14 days | 30 days | cash arrives ~2 weeks later | owner |
| Revisions | 2 rounds | "unlimited" | open-ended work | owner (suggest: 3 rounds) |
| Liability cap | 12 months' fees | client asks for uncapped | large exposure | owner + lawyer |

**Cover note template:**

```markdown
# <Client> · <agreement type> · draft <v> · <date>
Parties: <legal names> · Signatories: <names, titles>
Summary: <scope in 2 lines> · Fees: … · Term: … · Renewal: … · Notice: …
Deviations needing approval: (table above)
Open questions for the client: …
Checked by reviewer against proposal v<n>: names ✓ numbers ✓ dates ✓
Personal data processed for the client? <yes → DPA attached | no>
```

**Worked example.** *Bright Harbor Studio* retainer: template MSA + SOW; 2 deviations (30-day terms,
3 revision rounds) approved by the owner; DPA attached (we handle their customer emails); signature
envelope created as a draft and queued to the client's director.

---

## Review a contract we received

**Key-terms extract** goes into the register shape; flags read like "Clause 9.2: auto-renews for 12
months unless notice is given 90 days before the end date. Unusually long notice; worth negotiating to
30 days." Anything material → "get legal advice before signing".

---

## Contract Lifecycle

**Deadline table** (sorted by the earliest date):

| Contract | Counterparty | End | Notice by | Auto-renews | Next action | By |
|---|---|---|---|---|---|---|
| Call-tracking software | vendor | 31 Jan | 2 Nov | yes | decide: renew or notice | owner, 2 Nov |
| Retainer | Bright Harbor | 14 Jan | 14 Dec | no | renewal talk (customer-lead) | 15 Nov |

A notice deadline within 14 days goes to the top of the owner's next brief.

---

## Log each job

```
node bin/wf.mjs log --skill contracts-coordinator --job "Agreement Drafting" --status queued --summary "<client> <type>: <n> deviations approved" --minutes-saved 90
node bin/wf.mjs log --skill contracts-coordinator --job "Contract Lifecycle" --status done --summary "<n> deadlines in 45 days" --minutes-saved 20
```
