# Statement of work: structure

> DRAFT STRUCTURE FOR LEGAL REVIEW. This outline organises the commercial terms the parties agreed. It is not a contract template and has not been reviewed by a lawyer. Use the business's own approved agreement for legal terms.

1. **Parties and reference** — this SOW is issued under the master agreement dated {{msa_date}} between {{business_legal_name}} and {{client_legal_name}}.
2. **Background** — the client's goal in two sentences (from the proposal).
3. **Scope** — deliverables, each with a description and acceptance criteria.
4. **Out of scope** — explicit exclusions (from offers.md "What's not included" and the proposal).
5. **Assumptions and client responsibilities** — access, approvals, materials, response times.
6. **Timeline** — milestones with dates or durations from start.
7. **Fees and payment schedule** — amounts, currency, invoicing triggers, payment terms.
8. **Change control** — how scope changes are requested, priced and approved (change order).
9. **Acceptance** — how and when deliverables are accepted.
10. **Term and termination** — start, end, notice (refer to the master agreement).
11. **Contacts** — each side's project lead and approver.
12. **Signatures** — names, titles, dates.
