# Playbook · Carousel designer

`SKILL.md` has the steps; `scripts/render-carousel.mjs` has the `slides.json` format. This file has a
worked story, copy rules and the final check.

## Worked story (8 slides, fictional)

| # | Role | Headline (≤ 8 words) | Body (≤ 25 words) |
|---|---|---|---|
| 1 | Hook | 1 in 5 clinic calls go unanswered | (none: big number, source line small) |
| 2 | Why it matters | Each missed call is a missed booking | Most callers don't leave a voicemail. They ring the next clinic. |
| 3 | Point | Busiest hours, fewest hands | 8–10am and 5–6pm: front desk is checking people in. |
| 4 | Point | Voicemail isn't a safety net | Our data: 3 in 4 missed callers left no message. |
| 5 | Point | Speed beats everything | A text back within 60 seconds booked 4× more than next-day calls. |
| 6 | Point | Make the reply useful | Link straight to booking, not "we'll call you back". |
| 7 | Payoff | Fewer gaps, same team | Clinics that did this filled 18 more slots a month. |
| 8 | CTA | Save this for your next team meeting | @handle · logo |

Every number traces to a source in the notes (the business's own data or a cited study); slide 7 uses a
client result only with recorded permission (`knowledge/proof.md`).

## Copy rules

- One idea per slide; the headline alone should make sense.
- Parallel grammar across point slides ("Busiest hours…", "Speed beats…").
- Numbers as digits; units and timeframes stated.
- No hashtags or links on slides; they go in the caption.

## Final check

| Check | Pass when |
|---|---|
| Readable on a phone | body ≥ 32 px at 1080 wide, headline ≥ 64 px |
| Contrast | text vs background ≥ 4.5:1 |
| Overflow | no text clipped on any slide in the HTML |
| Brand | colours and fonts from brand.md only |
| Alt text | one line per slide, saying what it says |
| Files | PNGs + PDF, or HTML only with a note that Chromium wasn't available |

## Log

```
node bin/wf.mjs log --skill carousel-designer --job "Carousel Production" --status draft --summary "<slug>: <n> slides" --minutes-saved 60
```
