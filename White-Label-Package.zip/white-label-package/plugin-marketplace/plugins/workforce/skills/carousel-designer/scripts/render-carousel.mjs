#!/usr/bin/env node
// Render a branded carousel from slides.json.
// Usage: node render-carousel.mjs <slides.json> <out-dir>
// Always writes <out-dir>/carousel.html (open in a browser; each slide is a fixed-size frame).
// If Playwright is installed (npm i -D playwright, browsers available), also writes slide-01.png… and carousel.pdf.
//
// slides.json:
// {
//   "size": [1080, 1350],
//   "brand": { "bg": "#0F172A", "fg": "#F8FAFC", "accent": "#22C55E", "muted": "#94A3B8",
//              "headingFont": "Inter", "bodyFont": "Inter", "logo": "knowledge/brand/logo-white.svg", "handle": "@yourbrand" },
//   "slides": [
//     { "type": "hook", "title": "5 signs your inbox is costing you clients", "kicker": "Swipe →" },
//     { "type": "point", "n": 1, "title": "Replies take > 4 hours", "body": "Leads contacted within the hour are far likelier to book." },
//     { "type": "quote", "text": "We lost two clients before we noticed.", "by": "Client, logistics" },
//     { "type": "cta", "title": "Want the checklist?", "body": "Comment INBOX and I'll send it." }
//   ]
// }
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const [, , input, outDir] = process.argv;
if (!input || !outDir) { console.error('Usage: node render-carousel.mjs <slides.json> <out-dir>'); process.exit(1); }
const spec = JSON.parse(fs.readFileSync(input, 'utf8'));
const [W, H] = spec.size || [1080, 1350];
const b = { bg: '#0F172A', fg: '#F8FAFC', accent: '#22C55E', muted: '#94A3B8', headingFont: 'Inter', bodyFont: 'Inter', ...(spec.brand || {}) };
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
let logo = '';
if (b.logo && fs.existsSync(b.logo)) {
  const ext = path.extname(b.logo).slice(1).replace('svg', 'svg+xml').replace('jpg', 'jpeg');
  logo = `data:image/${ext};base64,${fs.readFileSync(b.logo).toString('base64')}`;
}
const total = spec.slides.length;
const frame = (inner, i, s) => `
<section class="slide ${s.type}" style="width:${W}px;height:${H}px">
  ${inner}
  <footer>${(i === 0 || i === total - 1) && logo ? `<img src="${logo}" alt="">` : ''}<span>${esc(b.handle || '')}</span><span class="pg">${i + 1}/${total}</span></footer>
</section>`;
const body = spec.slides.map((s, i) => {
  if (s.type === 'hook') return frame(`<div class="wrap"><h1>${esc(s.title)}</h1>${s.kicker ? `<p class="kicker">${esc(s.kicker)}</p>` : ''}</div>`, i, s);
  if (s.type === 'quote') return frame(`<div class="wrap"><blockquote>“${esc(s.text)}”</blockquote>${s.by ? `<p class="by">— ${esc(s.by)}</p>` : ''}</div>`, i, s);
  if (s.type === 'cta') return frame(`<div class="wrap"><h2>${esc(s.title)}</h2>${s.body ? `<p>${esc(s.body)}</p>` : ''}</div>`, i, s);
  return frame(`<div class="wrap">${s.n != null ? `<div class="n">${esc(s.n)}</div>` : ''}<h2>${esc(s.title)}</h2>${s.body ? `<p>${esc(s.body)}</p>` : ''}</div>`, i, s);
}).join('\n');
const css = `
*{box-sizing:border-box;margin:0;padding:0}
body{background:#777;display:flex;flex-direction:column;align-items:center;gap:40px;padding:40px}
.slide{position:relative;background:${b.bg};color:${b.fg};font-family:'${b.bodyFont}',system-ui,-apple-system,Segoe UI,Roboto,sans-serif;overflow:hidden}
.wrap{position:absolute;inset:${Math.round(W * 0.09)}px ${Math.round(W * 0.09)}px ${Math.round(H * 0.14)}px;display:flex;flex-direction:column;justify-content:center;gap:${Math.round(W * 0.035)}px}
h1{font-family:'${b.headingFont}',system-ui,sans-serif;font-size:${Math.round(W * 0.095)}px;line-height:1.05;font-weight:800;letter-spacing:-0.02em}
h2{font-family:'${b.headingFont}',system-ui,sans-serif;font-size:${Math.round(W * 0.07)}px;line-height:1.1;font-weight:800;letter-spacing:-0.01em}
p{font-size:${Math.round(W * 0.038)}px;line-height:1.35;color:${b.fg};opacity:.92}
.kicker{color:${b.accent};font-weight:700}
.n{font-size:${Math.round(W * 0.06)}px;font-weight:800;color:${b.accent}}
blockquote{font-size:${Math.round(W * 0.062)}px;line-height:1.2;font-weight:700}
.by{color:${b.muted}}
.cta h2{color:${b.accent}}
footer{position:absolute;left:${Math.round(W * 0.09)}px;right:${Math.round(W * 0.09)}px;bottom:${Math.round(H * 0.045)}px;display:flex;align-items:center;gap:16px;color:${b.muted};font-size:${Math.round(W * 0.026)}px}
footer img{height:${Math.round(W * 0.045)}px}
footer .pg{margin-left:auto}
@media print{body{background:none;padding:0;gap:0}.slide{page-break-after:always}}
@page{size:${W}px ${H}px;margin:0}`;
const html = `<!doctype html><html><head><meta charset="utf-8"><title>Carousel</title><style>${css}</style></head><body>${body}</body></html>`;
fs.mkdirSync(outDir, { recursive: true });
const htmlPath = path.join(outDir, 'carousel.html');
fs.writeFileSync(htmlPath, html);
console.log(`Wrote ${htmlPath}`);

try {
  let pw;
  try { pw = await import('playwright'); }
  catch { pw = await import(pathToFileURL(createRequire(path.join(process.cwd(), 'noop.js')).resolve('playwright')).href); } // workspace-level install
  const { chromium } = pw.default?.chromium ? pw.default : pw;
  const browser = await chromium.launch(process.env.PLAYWRIGHT_CHROMIUM ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM } : {});
  const page = await browser.newPage({ viewport: { width: W + 80, height: H + 80 } });
  await page.goto('file://' + path.resolve(htmlPath));
  const slides = await page.$$('.slide');
  for (let i = 0; i < slides.length; i++) {
    const p = path.join(outDir, `slide-${String(i + 1).padStart(2, '0')}.png`);
    await slides[i].screenshot({ path: p });
  }
  await page.pdf({ path: path.join(outDir, 'carousel.pdf'), width: `${W}px`, height: `${H}px`, printBackground: true });
  await browser.close();
  console.log(`Wrote ${slides.length} PNGs and carousel.pdf`);
} catch (e) {
  console.log(`PNG/PDF export skipped (${['ERR_MODULE_NOT_FOUND', 'MODULE_NOT_FOUND'].includes(e.code) ? 'Playwright not installed' : e.message.split('\n')[0]}). Open carousel.html and export, or install Playwright.`);
}
