---
name: carousel-designer
description: >-
  Designs and exports branded carousel slides for LinkedIn and Instagram: plans the slide story (hook, value
  slides, payoff, CTA), writes tight slide copy, lays it out in the brand's colours and fonts, and renders
  print-sharp PNGs and a PDF from a template with the bundled script. Use for "make a carousel", "turn this post
  into slides", "LinkedIn document post", "Instagram carousel", "design slides for…", or repurposing an article
  into swipeable content.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: marketing
  jobs: [Carousel Production]
  capabilities: []
  version: 1.0.0
---

# Carousel designer

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

A carousel is a story told one swipe at a time. Slide 1 earns the swipe, each slide makes one point, and the last slide tells people what to do. Design serves reading: big type, generous space, brand colours, nothing decorative that slows the eye.

## Read first

- `references/playbook.md`: templates, a worked example and the edge cases for this job. Read it before your first run.
- `knowledge/brand.md` (colours, fonts, logo) and `knowledge/brand/` assets, `knowledge/voice.md`.
- The source idea or content and its hook (creative-strategist).
- `scripts/render-carousel.mjs` (usage at the top of the file).

## Job: Carousel Production

1. **Story** (6–10 slides): 1 hook (the promise, ≤ 10 words) → 2 the problem/why it matters → 3–8 one point per slide (headline ≤ 8 words + ≤ 25 words of body or a simple visual) → payoff/summary → CTA slide (save, follow, comment keyword, link) with handle/logo.
2. **Copy pass**: cut every word that doesn't earn its place; numbers specific; consistent grammar across slides.
3. **Layout**: write `slides.json` (format in the script header): size (LinkedIn/Instagram portrait 1080×1350 default; square 1080×1080), brand colours and fonts from brand.md, slide-number indicator, logo/handle on first and last.
4. **Render**: `node ${CLAUDE_SKILL_DIR}/scripts/render-carousel.mjs slides.json output/marketing/carousel-production/<date>-<slug>/` → `carousel.html` (always) and PNGs + PDF if Playwright/Chromium is available (`npx playwright` must already be installed; the script says what it found).
5. **Check**: open the HTML; every slide readable on a phone (body ≥ 32 px at 1080 wide), contrast sufficient, no text overflow, brand colours correct, alt text for each slide.
6. Save, add to `data/content/calendar.json` (status `ready`), and hand captions to social-copywriter.

## Guardrails

- Brand assets only; no third-party logos, images or icons without rights; no AI images of real people.
- Facts and proof from the knowledge base; disclose sponsorships.

## Quality checklist

- [ ] One point per slide; hook ≤ 10 words; CTA slide present.
- [ ] Brand colours/fonts from brand.md.
- [ ] Readable at phone size; contrast checked; no overflow.
- [ ] Alt text per slide.

## Record the run

```
node bin/wf.mjs log --skill carousel-designer --job "Carousel Production" --status draft --summary "<n>-slide carousel: <title>" --output <folder> --minutes-saved 60
```
