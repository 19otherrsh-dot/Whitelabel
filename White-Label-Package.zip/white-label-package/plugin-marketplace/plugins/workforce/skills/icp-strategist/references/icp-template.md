# ICP — {{vertical}}

Status: {{evidence-based from N deals | hypothesis}} · Approved by {{owner}} on {{date}}

## In one sentence
{{Role}} at {{type of company, size, model, where}} who {{trigger}} and need {{outcome}}.

## Company profile
| Attribute | Best fit | Acceptable | Disqualify |
|---|---|---|---|
| Industry / sub-vertical | | | |
| Size (employees / revenue) | | | |
| Model | | | |
| Geography | | | |
| Tools / tech signals | | | |
| Growth stage | | | |

## Buyers
| Role | Cares about | Typical objection | Message angle |
|---|---|---|---|

## Triggers (why now)
- {{trigger}} — how to detect: {{signal source}}

## Pains in their words
- "{{quote}}" — {{client, date}}

## Disqualifiers (anti-ICP)
- {{trait}} — because {{evidence}}

## Search filters
- Database: {{fields and values}}
- Keywords: {{…}}
- Exclude: {{…}}

## Universe
~{{n}} companies (source: market-mapper, {{date}})
