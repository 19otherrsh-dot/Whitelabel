# The autonomy ladder

Each job moves up one rung at a time, on evidence, and always by the owner's decision.

| Level | What the agent does | Owner's part | Move up when |
|---|---|---|---|
| `draft` | Prepares the work and saves it. Nothing leaves the workspace. | Reads and uses the output | 5+ runs used with only light edits |
| `approve` | Prepares the exact action and queues it in the outbox | Approves or rejects each item | 20+ items approved, under 10% rejected in the last 30 days, no serious mistakes |
| `autonomous` | Carries out the action inside the guardrails, logs it | Reviews the log and outcomes weekly | — |

## Never autonomous

Regardless of track record, these stay at `approve`, and the approval guard enforces it:

- Payments, refunds, transfers, payouts, voiding invoices
- Deleting or archiving records, revoking or granting access, sharing files externally
- Changing ad budgets or launching campaigns to new audiences
- Anything on the never-allow list in `workspace.json`

## Moving down

Drop a job one level immediately when it causes a mistake a customer saw, when the business changes (new offer, new policy), or when its rejection rate rises above 20%. Record why with `wf feedback`.

## Reading the evidence

```
node bin/wf.mjs runs --job "<Job>" --days 30 --json     # runs and statuses
node bin/wf.mjs outbox all --json                        # approvals and rejections (filter by job)
```

The weekly review lists jobs that meet the "move up" criteria.
