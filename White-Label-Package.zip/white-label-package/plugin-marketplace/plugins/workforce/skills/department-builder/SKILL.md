---
name: department-builder
description: >-
  Turns on a department of the AI workforce for this specific business: checks prerequisites and connectors,
  tunes each job to the business, runs the first jobs as supervised drafts, sets autonomy levels and schedules the
  routine. Also adds custom jobs or whole new departments to the map. Use when the owner says "turn on sales",
  "set up the back office", "build my marketing team", "add a department for X", "add this job to the map", or after
  the workforce audit picks a first department.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: workforce
  jobs: [Department Setup]
  capabilities: []
  version: 1.0.0
---

# Department builder

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

A department is "on" when its jobs have produced work the owner trusts, on a rhythm, with the right level of supervision. Switching a flag is not enough; this skill walks a department from zero to a running routine, one job at a time.

## Read first

- `departments/<id>.json` for the department (jobs, `requires`, `human`, `capabilities`, `action`, `suggestedSchedules`, `dashboards`).
- The department lead brief `.claude/agents/<id>-lead.md`.
- `workspace.json` (stack, autonomy, guardrails), `knowledge/*` (TODOs), the latest workforce audit in `output/workforce/workforce-audit/` if one exists.
- `node bin/wf.mjs runs --json --days 90` to see which jobs have already run.

## Start from a starter pack when one fits

`library/starters/` holds ready-made first departments (outreach, content, delivery, admin, replies and support, growth operator, LinkedIn, YouTube, clipping, team, knowledge and learning). Each lists its jobs in the order to turn them on, what to connect, the tuning questions, a first-week plan, schedules and default autonomy. If the owner's goal matches one, have them run `node bin/wf.mjs library install starter <id>` (it adds the schedules switched off, sets autonomy only where the owner hasn't, and writes a setup plan), then follow the plan with the steps below. A starter is a starting point: drop jobs that don't fit and say why.

## Turn on a department

1. **Readiness check.** For each job in the department, list: prerequisites met (each `requires` job has a `done` run), knowledge it needs filled, capability connected (`workspace.json → stack` and `node bin/wf.mjs doctor --quick --json` connector checks). Write it as a table for the owner.
2. **Pick the first three jobs** in dependency order, starting with any `foundation` job. Prefer jobs whose output stays internal (research, drafts, reports) before jobs that end in an external `action`.
3. **Fix blockers.** Missing knowledge → `company-knowledge-base`. Missing connector → `connector-setup`. Missing prerequisite → run that job first.
4. **Tune each job to the business.** Read the job's skill. Ask the owner the two or three questions that decide how it should work here (e.g. for Collections: reminder schedule, tone after 30 days, who takes over). Save the answers as lessons: `node bin/wf.mjs feedback --skill <skill> --note "<rule>"`. Lessons override skill defaults, so this is how the department becomes theirs without editing the skill.
5. **Supervised first runs.** Run each job once with real inputs, through the department lead. Keep autonomy at `draft`. Show the owner the output and ask what they would change; save changes as lessons.
6. **Set autonomy** per job with the owner, using `references/autonomy-ladder.md`. Default: drafting jobs `draft`, jobs with external actions `approve`. Only suggest `autonomous` for jobs with several approved runs and no recent rejections, and never for money, mass outreach or deletion. The owner sets it: `node bin/wf.mjs autonomy "<Job>" <level>` (the guard asks them to confirm).
7. **Schedule the routine** with the `autopilot` skill, starting from `suggestedSchedules` adjusted to the owner's week and time zone.
8. **Enable the department** in `workspace.json → departments.<id>.enabled` (owner confirms the edit) and point the owner at its dashboards (`wf serve`).
9. **Write the setup note** `output/workforce/department-setup/<date>-<id>.md`: jobs on, autonomy, schedules, lessons saved, what's next.

## Add a custom job or department

When the business has work the map doesn't cover:

1. Write the job like the others: `name` (2–4 words, title case, unique across the map), `desc` (one line, what gets done), `skill`, `level`, `requires`, `human` (where the person stays in the loop and why), `capabilities`, and `action` if it ends in an external action.
2. If no existing skill fits, run `skill-builder` to create one first.
3. Add the job to the right function in `departments/<id>.json`, or create `departments/<new-id>.json` with the same structure (`id`, `name`, `order`, `color`, `tagline`, `intro`, `lead`, `dashboards`, `suggestedSchedules`, `functions`). For a new department also write `.claude/agents/<new-id>-lead.md` following the existing leads.
4. Run `node bin/wf.mjs doctor --quick --problems` and fix any broken references. The map picks up the new job from the manifest.

## Guardrails

- Never enable a job whose prerequisite has never run, unless the owner explicitly accepts the gap.
- Never set autonomy yourself; recommend, and let the owner run the command.
- Don't edit skills to fit one business; use lessons. Edit a skill only to fix a general flaw, and say so.

## Quality checklist

- [ ] Readiness table shows prerequisites, knowledge and connectors per job.
- [ ] Each first job ran once on real input and the owner reviewed it.
- [ ] The owner's tuning answers are saved as lessons.
- [ ] Autonomy levels were set by the owner and follow the ladder.
- [ ] Schedules exist with budgets, in the business time zone.
- [ ] Doctor shows no broken references for the department.

## Record the run

```
node bin/wf.mjs log --skill department-builder --job "Department Setup" --status done --summary "<department> on: <n> jobs, <n> schedules, autonomy <summary>" --output output/workforce/department-setup/<date>-<id>.md
```
