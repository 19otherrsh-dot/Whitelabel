# Job playbooks · Relationship mapper

The detail behind each job in `SKILL.md`. Use public professional information and data the business
already holds, nothing more. People's private lives, home details and personal social accounts are out
of scope.

---

## Buying-Committee Mapping

**Typical committees by deal size** (adjust from the company deep-dive):

| Deal size for them | Roles to map |
|---|---|
| Small (owner decides) | owner/founder (economic buyer + champion), the person who'd use it daily |
| Mid (team lead + finance) | economic buyer, champion, 1–2 users, finance/procurement |
| Large (formal process) | economic buyer, champion, users, IT/security, legal, procurement, potential blocker |

**Per person, record:** name, title, role in the decision, what they care about (from what they've said
publicly or in calls), likely objection, how to engage, source, confidence (high/medium/low).

**Output:** `output/intelligence/buying-committee-mapping/<account>.md`

```markdown
# Buying committee · <account>
Deal: <name, value> · Stage: <…> · Our champion: <name or "none yet">
| Role | Person (title) | Cares about | Likely objection | Engage by | Source | Confidence |
## Gaps (roles with no named person) and how to find them
## Suggested sequence of conversations
```

A role with no person is a gap to close, not a guess to make.

---

## Network Mapping

**Sources (owner approves each):** CRM contacts and companies; past clients and where they work now;
partners, investors, advisers; team members' professional connections they choose to share.

**Strength:**
- strong: worked together, or spoke in the last 6 months and would take a call;
- medium: know each other professionally, some recent contact;
- weak: connected online, met once.

**Record:** `data/records/relationships.json` items `{ id, person, company, knownBy, strength,
context, lastContact, source }`. Refresh `company` when people move (a moved past client is a warm
path into their new company).

---

## Warm-Path Finding

**Path types, best first:** past client now at the target → our team member with a strong tie →
partner serving the target → shared investor/adviser → mutual connection (medium) → cold with a trigger.

**Intro request draft** (for the person who owns the relationship to send):

```text
Hi <connector>,

Would you be comfortable introducing me to <target> at <company>? <one line: why it's useful for them, not us>.

Here's a short blurb you can paste:
"<two sentences about who we are and the specific reason to talk>"

No problem at all if it's not a good fit.
```

**Honesty rule:** never describe a weak tie as a relationship. If the best path is weak, recommend a
trigger-based cold approach instead and say why.

**Worked example.** Target: CFO of *Harbor Freight Partners*. Path found: a past client's former
operations lead now works there (strength medium, last contact 4 months ago). Draft for our account owner
to ask her for an intro, plus the blurb.

---

## Log each job

```
node bin/wf.mjs log --skill relationship-mapper --job "Buying-Committee Mapping" --status done --summary "<account>: <n> roles mapped, <n> gaps" --minutes-saved 45
node bin/wf.mjs log --skill relationship-mapper --job "Network Mapping" --status done --summary "<n> relationships recorded" --minutes-saved 60
node bin/wf.mjs log --skill relationship-mapper --job "Warm-Path Finding" --status draft --summary "<target>: best path <type>" --minutes-saved 20
```
