# Data migration runbook

1. **Inventory**: objects (companies, contacts, deals, notes, files…), record counts per object, custom fields, picklist values, owners/users, relationships.
2. **Mapping**: object → object, field → field, picklist value → value, user → user. Decide what not to migrate (and archive it).
3. **Cleanup** (before moving): duplicates merged in the source or flagged, junk records excluded by rule, formats normalised.
4. **Dry run** in a sandbox or a test import of a sample (≥ 100 records per object including edge cases).
5. **Reconcile**: counts per object source vs destination; 20 records spot-checked field by field; relationships intact (contact ↔ company ↔ deal).
6. **Sign-off** by the owner on the dry run.
7. **Cut-over**: announce a freeze window; export a full backup of the source; migrate in dependency order (users → companies → contacts → deals → activities → files); keep a log of IDs (source ID ↔ destination ID).
8. **Reconcile again**; fix discrepancies.
9. **Rollback plan**: how to revert (restore from backup / delete imported records by import ID) until sign-off.
10. **Acceptance**: owner confirms; only then may the source be retired (never deleted by the agent).
