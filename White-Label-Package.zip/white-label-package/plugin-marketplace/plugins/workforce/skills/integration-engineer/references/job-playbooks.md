# Job playbooks · Integration engineer

The detail behind each job in `SKILL.md`, alongside `integration-spec.md` and `migration-runbook.md`.
This file adds route choice, a worked build, and the reconciliation sheet.

---

## Integration Builds

**Choosing the route:**

| Need | Route |
|---|---|
| Both tools have a built-in connection that covers the fields | native integration |
| A few steps, under ~5,000 runs/month, no complex logic | Zapier / Make / n8n |
| Scheduled batch, logic, or the platform cost would be high | small script run by autopilot |
| Real-time from a webhook | hosted runtime endpoint |

**Worked example.** "New paid order (Stripe) → client record (CRM) + welcome task." Spec: trigger
`checkout.session.completed`; mapping email → contact email, product → deal product, amount → deal
value; filter: live mode only; idempotency key: the session id stored on the deal; errors: retry 3×
then alert reliability-engineer. Route: automation platform (low volume). Tests: 3 test payments (new
customer, existing customer, refunded) → all records correct, no duplicates on replay. Go-live queued.

**README skeleton** (`output/operations/integration-builds/<name>/README.md`):
what · why · route · trigger · mapping table · how to test · how to pause · alerts go to · owner · last change.

---

## Data Migration

**Reconciliation sheet** (before and after each run):

| Object | Source count | Target count | Difference | Explained by |
|---|---|---|---|---|
| Companies | 4,120 | 3,980 | −140 | 140 duplicates merged (list attached) |
| Contacts | 9,870 | 9,870 | 0 | — |
| Deals | 1,204 | 1,204 | 0 | — |

**Spot check:** 20 random records, every mapped field compared; any mismatch stops the cut-over until
explained. Owner signs off in writing (outbox approval); source data is kept read-only until then.

---

## Log each job

```
node bin/wf.mjs log --skill integration-engineer --job "Integration Builds" --status queued --summary "<name>: tested, go-live queued" --minutes-saved 120
node bin/wf.mjs log --skill integration-engineer --job "Data Migration" --status done --summary "<n> records migrated, reconciled" --minutes-saved 240
```
