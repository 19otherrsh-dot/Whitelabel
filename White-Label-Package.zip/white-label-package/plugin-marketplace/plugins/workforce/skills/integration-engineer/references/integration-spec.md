# Integration spec — {{name}}

- **Purpose:** {{business outcome}}
- **Owner:** {{person}} · **Requested by:** {{person}} · **Date:** {{date}}
- **Trigger:** {{event, e.g. "new form submission in Typeform 'Enquiry'"}} or schedule {{cron}}
- **Source:** {{system, object}} · **Destination:** {{system, object}}
- **Route:** {{native / Zapier / Make / n8n / script / webhook}} — because {{reason}}

## Mapping
| Source field | Transform | Destination field | Required |
|---|---|---|---|

## Rules
- Filters: {{only when …}}
- Deduplication / idempotency key: {{external id}}
- Volume: {{per day}} · Rate limits: {{…}}

## Errors
- Retry: {{n}} times with backoff for {{transient errors}}
- On failure: log to {{place}}, alert {{person/channel}}
- Data that fails validation: {{held in review queue}}

## Test plan
- {{test case → expected result}}

## How to pause
{{exact steps}}
