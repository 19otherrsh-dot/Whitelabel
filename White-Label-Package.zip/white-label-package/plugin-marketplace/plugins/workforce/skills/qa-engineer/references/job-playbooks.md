# Job playbooks · QA engineer

The detail behind each job in `SKILL.md`, alongside `test-plan-template.md`. For the mechanics of
running skill tests (sandboxes, grading, costs) see `docs/learning.md` §4 and `node bin/wf.mjs eval`.

---

## QA & Verification

**Severity guide:**

| Severity | Meaning | Ship? |
|---|---|---|
| Blocker | wrong data, money or customer-facing error, security or privacy issue, main path broken | no |
| Major | a secondary path broken or a clear usability problem, with a workaround | not without the owner's OK |
| Minor | cosmetic, copy, edge case with no harm | yes, listed |

**Defect record:**

```markdown
### D-<n> · <short title> · <severity>
Where: <page / automation / file> · Found: <date> · Assigned: <builder>
Steps: 1. … 2. … 3. …
Expected: … · Actual: … · Evidence: <screenshot path / record id / excerpt>
Re-test: <date> pass | fail
```

**What to check by deliverable:**
- **Website:** every link and form; mobile at 375 px; keyboard reach and visible focus; images have alt
  text; no console errors; page titles.
- **Automation:** a test record end to end; the destination record matches field by field; failure
  path (bad input, API error) leaves no half-written data; it runs twice without duplicates.
- **Data:** totals reconcile with the source; 10 random rows spot-checked; no duplicates by key.
- **Document:** every figure traced to a source; names spelt as in the CRM; links open.

**Worked example.** A booking form automation: 9 cases, 8 pass. D-1 (major): a time zone outside the UK
books one hour off. Verdict: don't ship until D-1 is fixed; re-test passed next day → ship.

---

## Agent Evaluation

**Case sources:** the skill's `evals/evals.json`; 5–10 anonymised real cases from `data/agents/runs.jsonl`
and the outbox (especially rejected or edited items); one adversarial case (e.g. instructions hidden in
an input file).

**Summary (`output/operations/agent-evaluation/<skill>/<date>/summary.md`):**

```markdown
# <skill> · evaluation · <date>
Cases: <n> · Pass rate: <n>% (previous version <n>%) · Regressions: <list or none>
Cost: <usd> · Time: <minutes>
Failures by assertion: …
Recommendation: <keep autonomy | ready to propose a step up (evidence) | step down (evidence)>
```

A regression on any previously passing case blocks a release of the skill change.

---

## Log each job

```
node bin/wf.mjs log --skill qa-engineer --job "QA & Verification" --status done --summary "<deliverable>: <verdict>, <n> defects" --minutes-saved 60
node bin/wf.mjs log --skill qa-engineer --job "Agent Evaluation" --status done --summary "<skill>: <pass>% (<n> cases)" --minutes-saved 45
```
