# Test plan — {{deliverable}} · {{date}}

Acceptance criteria: {{from SOW/spec}}

| # | Case | Type | Steps | Expected | Result | Evidence |
|---|---|---|---|---|---|---|
| 1 | {{…}} | happy | {{…}} | {{…}} | pass/fail | {{screenshot / id}} |
| 2 | {{empty input}} | edge | | | | |
| 3 | {{permission missing}} | error | | | | |
| 4 | {{previous feature still works}} | regression | | | | |

## Defects
| # | Severity | Steps to reproduce | Expected | Actual | Owner | Status |
|---|---|---|---|---|---|---|

## Verdict
{{ship / ship with known issues / don't ship}} — {{reason}}
