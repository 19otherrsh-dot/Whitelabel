# Job playbooks · Campaign operations manager

The detail behind each job in `SKILL.md`, with `launch-checklist.md`. Volumes, inbox limits and the
ramp exist to protect the business's domain reputation: the guard and these rules don't bend for a
deadline.

---

## Campaign Orchestration

**Cadence template:** `output/sales/campaign-orchestration/<campaign>-cadence.md`

```markdown
# <Campaign> · cadence
Segment(s): … · Contacts: … · Owner: … · Start: …
| Day | Channel | Step | Owner | Copy ref | Stop if |
|---|---|---|---|---|---|
| 0 | email | intro (specific trigger) | auto | E1 | reply, bounce, opt-out |
| 2 | LinkedIn | connect (no pitch) | <name> | L1 | reply anywhere |
| 4 | email | value follow-up | auto | E2 | … |
| 7 | phone | call + voicemail | <name> | C1 | … |
| 12 | email | breakup / not-now ask | auto | E3 | … |
Stop rules: any reply on any channel, a booking, a bounce, an opt-out, or a "not now" date.
Manual quotas: <name> <n> calls/day, <n> LinkedIn/day
```

Copy refs point to the approved copy from cold-email-copywriter / outbound-scriptwriter.

---

## Campaign Launch

**Readiness (from `launch-checklist.md`), recorded with evidence in the launch draft:**
- domain authentication (SPF, DKIM, DMARC) passes for every sending inbox;
- each inbox warmed and under its daily limit;
- list verified (≤ 2% risky, 0 invalid), suppression list applied;
- every merge field filled in 3 test renders from different segments;
- unsubscribe works and the footer has the sender's legal name and postal address where the law
  requires them (compliance-check);
- tracking choices, schedule window, time zones set.

**Launch outbox item:** title `Launch <campaign>: <n> contacts, <per day>/day, starts <date>`; the draft
holds the checklist results, the 3 renders and the ramp plan.

**Ramp:** days 1–3 at ~20% of the target daily volume; step up by ~25% every 2 days while bounces < 2%,
complaints 0, and replies look human.

**Worked example.** "UK dental · front desk", 893 contacts, target 120/day across 3 inboxes → days 1–3:
24/day; day 4–5: 30; … reaching 120 by about day 15 if healthy.

---

## Send Optimization

**Daily monitor** (`output/sales/send-optimization/<date>.md`), per campaign:

| Metric | Healthy | Act |
|---|---|---|
| Bounce rate | < 2% | > 3% → pause, re-verify the list |
| Spam complaints | 0 | any spike → pause, tell the owner |
| Reply rate | segment-dependent | < 1% after 300 sends → review copy/targeting |
| Positive replies → meetings | — | report weekly |

Pausing to protect deliverability is allowed (then tell the owner). Raising volume, adding inboxes, or
restarting a paused campaign needs approval.

---

## Log each job

```
node bin/wf.mjs log --skill campaign-operations-manager --job "Campaign Orchestration" --status draft --summary "<campaign>: <n>-step cadence" --minutes-saved 45
node bin/wf.mjs log --skill campaign-operations-manager --job "Campaign Launch" --status queued --summary "Launch <campaign> queued (<n> contacts)" --minutes-saved 60
node bin/wf.mjs log --skill campaign-operations-manager --job "Send Optimization" --status done --summary "<campaign>: bounce <n>%, replies <n>" --minutes-saved 15
```
