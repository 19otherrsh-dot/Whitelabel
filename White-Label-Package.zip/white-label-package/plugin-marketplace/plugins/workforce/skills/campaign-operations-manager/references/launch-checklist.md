# Launch checklist

## List
- [ ] 100% verified within 90 days; invalid removed; risky separated
- [ ] Suppression list (emails + domains) synced to the platform and applied
- [ ] Existing clients and open deals excluded (unless intended)
- [ ] Segments mapped to the right sequence variant

## Copy
- [ ] compliance-officer PASS, reviewer SHIP
- [ ] Every merge field has data or a fallback for every contact
- [ ] Footer: sender, business, postal address, opt-out
- [ ] Links resolve; no tracking domain errors

## Platform
- [ ] Sending domains authenticated (SPF, DKIM, DMARC) and healthy (deliverability-manager)
- [ ] Per-inbox daily limit set; total within workspace dailySendLimit
- [ ] Schedule window in recipients' time zones; weekends off unless intended
- [ ] Reply detection and stop-on-reply on; unsubscribe handling on
- [ ] Open tracking decision recorded

## Test
- [ ] Rendered test emails for 3 leads from different segments read correctly
- [ ] Test sent to the owner's own inbox lands in the inbox (not spam)

## Ramp
- [ ] Days 1–3 at ~20% target volume; criteria to step up: bounces < 2%, no complaints
