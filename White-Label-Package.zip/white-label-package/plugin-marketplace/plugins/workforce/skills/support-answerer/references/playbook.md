# Playbook · Support answerer

`SKILL.md` has the steps. This file has the escalation triggers, a reply example with sources, the
escalation note and the gap record.

## Escalate instead of answering when

- the customer asks for a refund, credit or exception beyond policy;
- it's a complaint, the customer is angry, or they mention leaving;
- legal words (lawyer, complaint to a regulator, data request) or safety;
- several customers report the same fault (possible incident → reliability-engineer);
- any claim in the answer has no source.

## Reply example

```text
Hi Sam,
Yes, texts go out after hours too: the system replies to a missed call within a minute, any time.
To change the evening message:
1. Open Settings → Messages.
2. Choose "After hours" and edit the text.
3. Save; it applies to the next missed call.
More detail: <help article link>
Thanks for asking, <name>

Sources (internal):
- faq.md → "Do texts go out after hours?"
- help/messages.md → "Editing the after-hours message"
```

## Escalation note

```markdown
Ticket <id> · <customer> · escalated <date>
Asked: <one line> · Sentiment: angry (mentions cancelling)
Checked: policies.md → Refunds (30 days; they're at day 45); no exception rule
Suggested next step: owner calls today; possible goodwill credit is the owner's decision
```

## Gap record

```
echo '[{"question":"Can we use two numbers per site?","ticket":"T-4412","docNeeded":"help/numbers.md"}]' \
  | node bin/wf.mjs data put support gaps --mode append --source support-answerer
```

## Log

```
node bin/wf.mjs log --skill support-answerer --job "FAQ & Self-Serve" --status queued --summary "<n> replies drafted, <n> escalated, <n> gaps" --minutes-saved 30
```
