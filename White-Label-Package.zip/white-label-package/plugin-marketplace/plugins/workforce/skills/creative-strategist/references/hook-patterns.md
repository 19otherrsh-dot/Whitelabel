# Hook patterns

| Pattern | Shape | Example (generic) |
|---|---|---|
| Specific result | Number + timeframe + who | "How a 6-person firm answered every call for 30 days" |
| Mistake | "The mistake that…" | "The invoicing mistake that delays every payment" |
| Contrarian | Challenge a belief | "You don't need more leads. You need faster replies." |
| Question in their words | Their exact question | "Why do clients always pay late?" |
| Before/after | Contrast | "From 40 unread emails to zero by 9am" |
| List | Number + promise | "3 emails every service business should automate" |
| Story open | Mid-action | "Our biggest client almost left on a Tuesday…" |
| POV / identity | "If you're a…" | "If you run a clinic and still take bookings by phone…" |
| Myth-bust | "X is a myth" | "'Just follow up more' is bad advice. Here's why." |
| Demonstration | Show it | "Watch this inbox sort itself" |

Rules: specific beats clever; the content must pay the hook off in the first third; use the audience's words; no fake urgency.
