# Job playbooks · Creative strategist

The detail behind each job in `SKILL.md`, alongside `hook-patterns.md`. Claims in hooks and ads must be
true and provable; reviews and testimonials are only real ones, used with permission.

---

## Hook Writing

**Scoring sheet** (1–5 each, keep 18+ of 25):

| Hook | Specific | Tension | Relevant | Credible | Platform fit | Total |
|---|---|---|---|---|---|---|
| "Your front desk misses 1 in 5 calls. Here's where they go." | 5 | 4 | 5 | 4* | 4 | 22 |
| "The secret clinics don't want you to know" | 1 | 3 | 2 | 1 | 3 | 10 (cut) |

\* only if the content shows where the "1 in 5" comes from (the business's own call data or a cited study).

**Return format:** top 5 ranked with a one-line reason; 2 wildcards; for video, the first-second visual
and on-screen text for each.

---

## Ad Creative

**Angle → concept grid:**

| Angle | Concept | Format | Hook | Proof used |
|---|---|---|---|---|
| Pain | "The 6pm voicemail pile" | UGC-style video | "It's 6pm and there are 14 voicemails." | the owner's own story |
| Outcome | "Calls back in 60 seconds" | demo video | "Watch a missed call turn into a booking." | product demo, real timing |
| Proof | case study card | static | "+18 bookings in a month at <client>" | client's written OK + the data |
| Objection | "Not another tool" | carousel | "Works with the booking system you have." | integration list |

**Test plan:**

```markdown
Budget: £600 over 14 days · Metric: cost per qualified lead (booked call, fits ICP)
Structure: 2 angles × 2 hooks each (concept held constant within an angle)
Judge after: ≥ £100 spend or 7 days per variant, whichever comes later
Kill: CPQL > 2× target after the minimum · Scale: CPQL < target with ≥ 5 leads → +30% budget (approval)
```

Launching, pausing or changing budgets → `ad-change` outbox item with the plan attached.

---

## Log each job

```
node bin/wf.mjs log --skill creative-strategist --job "Hook Writing" --status draft --summary "<piece>: top 5 hooks" --minutes-saved 30
node bin/wf.mjs log --skill creative-strategist --job "Ad Creative" --status draft --summary "<campaign>: <n> concepts, test plan" --minutes-saved 120
```
