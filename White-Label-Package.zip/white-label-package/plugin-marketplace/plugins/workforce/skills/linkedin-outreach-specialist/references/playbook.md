# Playbook · LinkedIn outreach specialist

`SKILL.md` has the sequence. This file has examples of each message, the volume ramp and what not to do.
Use only tools LinkedIn permits and the owner approved; check LinkedIn's current limits before a new
campaign.

## Example sequence (fictional)

```text
Connection note (≤ 200 chars):
"Hi Jo, your talk at the October dental ops meetup on front-desk overload was spot on. I work with
multi-site practices on the same thing. Would be good to connect."

After acceptance (day 0):
"Thanks for connecting, Jo. Curious: with Leeds open, are calls still going to each front desk, or
have you centralised them?"

Value (day 5–7):
"Thought of you: we looked at four clinics' call logs and 3 in 4 missed callers left no voicemail.
Short write-up here if useful: <link>"

Soft ask (day 12–14):
"If missed calls are on your list this quarter, open to comparing notes for 15 minutes? If not,
no problem at all."

Close the loop (day 20):
"I'll leave it there, Jo. Good luck with the Leeds launch, and happy to help if it comes up."
```

## Volume ramp (new or quiet accounts)

| Week | Connection requests/week | Messages/day |
|---|---|---|
| 1 | 20 | 10 |
| 2 | 35 | 15 |
| 3+ | owner's cap (often 50–80) | 20–25 |

Pending invitations older than 3 weeks are withdrawn so the queue stays healthy.

## Don't

- Pitch or link in the connection note.
- Pretend to have read something you haven't, or invent a mutual connection.
- Message people who declined or asked not to be contacted.
- Automate likes, comments or profile visits with unapproved tools.

## Log

```
node bin/wf.mjs log --skill linkedin-outreach-specialist --job "LinkedIn Messaging" --status queued --summary "<campaign>: <n> notes, <n> follow-ups" --minutes-saved 45
```
