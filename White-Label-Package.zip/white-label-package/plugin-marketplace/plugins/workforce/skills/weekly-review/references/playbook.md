# Playbook · Weekly review

`SKILL.md` has the gathering commands and the six sections. This file has a worked example of the full
review (fictional figures) and the checks before it's saved.

## Worked example (≈ 400 words)

```markdown
# Weekly review · 2026-10-23

## Decisions for you
1. **Approve 3 overdue-invoice reminders (£4,350 total).** Options: approve / edit / hold.
   Recommend: approve today. If nobody decides: cash arrives a week later (forecast low point W7).
2. **Retainer price rise from 1 Nov?** (from last week, still open) Options: £2,400 / keep £2,200.
   Recommend: £2,400 for new clients only. If nobody decides: proposals keep quoting £2,200.
3. **Make "no Saturday" lesson part of support-answerer** (corrected twice). Recommend: yes.

## Waiting for approval
11 items: 6 email, 3 invoice (high-risk), 2 post. Oldest: invoice INV-1031 reminder (3 days),
post "5 places missed calls go" (2 days), email to Harbor Learning (2 days).
Review: `node bin/wf.mjs outbox` or the Approvals dashboard.

## What the workforce did
48 runs, 44 completed, 4 failed (2 connector timeouts, retried OK; 2 budget stops, prompts narrowed).
Logged estimates: 19.5 hours saved. AI spend $11.40. Last week: 41 runs, 16 hours, $9.80.

## Against the goals
- New clients this quarter: target 6 · now 3 (CRM) · at risk · two proposals stalled.
- Overdue invoices < £2,000: now £4,350 (accounting) · off track · reminders waiting.
- Newsletter list 1,000: now 846 (platform) · on track · lead magnet adding ~25/week.

## Next week
Scheduled: morning agenda (weekdays), inbox triage (2× daily), collections (Mon, Thu), knowledge refresh (Fri).
Recommended: reactivation run for Q2 lost deals (sales: 9 eligible); win/loss for Q3 (sales);
case-study draft from Bright Harbor (customer: strong results).

## Earned more autonomy
- inbound-response-manager · Inbox Triage: 34 approved, 3% rejected, no serious mistakes.
  Command (you run it; the guard asks you to confirm): `node bin/wf.mjs autonomy "Inbox Triage" autonomous`
```

## Checks before saving

- Every number names its source; hours are "logged estimates".
- At most 5 decisions, each with a recommendation and the cost of not deciding.
- Missing data is named with how to get it, never filled in.
- Under ~600 words; no sections beyond the six.
- Goal values saved to `data/goals/targets.json`.

## Log

```
node bin/wf.mjs log --skill weekly-review --job "Weekly Review" --status done --summary "<n> decisions, <n> waiting, <hours> h logged" --minutes-saved 60
```
