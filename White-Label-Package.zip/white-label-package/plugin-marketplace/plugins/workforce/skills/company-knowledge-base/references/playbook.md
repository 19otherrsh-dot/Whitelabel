# Playbook · Company knowledge base

`SKILL.md` has the rules. This file has the diff format for business-defining changes, a worked example
and the weekly refresh layout.

## Before/after diff (for the owner's confirmation)

```markdown
File: knowledge/offers.md → Retainer → Price
Before: £2,200/month, 3-month minimum
After:  £2,400/month from 2026-11-01, 3-month minimum (existing clients keep £2,200 until renewal)
Other places that mention the old price: knowledge/faq.md (Q4), output/sales/proposals/… (draft)
Waiting in the outbox with the old price: 1 proposal (Harbor Learning) → suggest reject and re-run
Source: owner in session, 2026-10-22
```

## Worked example

The owner says: "We don't do Saturday appointments any more." Home: `policies.md → Opening hours`.
Grep finds "Saturday" in `faq.md` (Q7) and `offers.md` (an add-on). Business-defining? Yes (affects what
customers are told), but the owner just stated it → apply. Edits: three lines; change-log entry in each
file; one pending support reply mentions Saturdays → listed for the owner.

## Weekly refresh layout

```markdown
# Knowledge refresh · <date>
| # | File → section | Proposed text | Evidence | Needs owner? |
|---|---|---|---|---|
| 1 | faq.md → new Q | "Do texts go out after hours? Yes, …" | 4 support tickets this week (ids) | no (applied) |
| 2 | competitors.md → <name> | "Now offers a free trial" | call 2026-10-20 [14:02] | yes |
Applied: 1, 3 · Waiting for the owner: 2
```

## Log

```
node bin/wf.mjs log --skill company-knowledge-base --job "Context Maintenance" --status done --summary "<n> facts applied, <n> proposed" --minutes-saved 30
```
