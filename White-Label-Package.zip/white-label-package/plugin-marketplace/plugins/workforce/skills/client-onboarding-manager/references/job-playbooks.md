# Job playbooks · Client onboarding manager

The detail behind each job in `SKILL.md`, with `kickoff-pack.md` and `access-checklist.md`.

---

## Kickoff Pack

**Inputs:** the signed proposal/SOW (scope, out-of-scope, milestones, price), the deal record (contacts,
goals), `knowledge/team.md` (who's on the account), `knowledge/policies.md` (response times, change
process).

**Welcome email (from the account lead, under 200 words):**

```text
Subject: Welcome, <client> · what happens this week

Hi <name>,
We're glad to be working with you. This week:
1. Kickoff call: <two proposed times with time zone> (45 minutes, agenda attached)
2. Access: a short checklist of what we need (link). Nothing by email, please; the checklist explains how.
3. Your team on our side: <name (role)>, <name (role)>.
You'll hear from us <cadence> with a short update. For anything urgent: <channel>, we reply within <time>.
<signature>
```

**Pack contents:** goals and measures (copied from the proposal, not reinvented), scope and out-of-scope,
milestones with dates, roles (RACI-lite: who decides, who does, who's informed), communication rhythm,
change requests (how they're asked for and priced), the access checklist.

**Worked example.** *Bright Harbor Studio*, 3-month growth retainer: measures "+30% qualified enquiries by
month 3"; milestones: audit (week 2), plan approved (week 3), first campaign live (week 5); weekly email
update on Fridays, fortnightly call; change requests via a short form, quoted within 2 days.

---

## Access Collection

**Least-privilege table** (per item in scope):

| Access | Level | How granted | Verified by |
|---|---|---|---|
| Google Analytics | Viewer | they invite our team account | we open the property |
| Ad account | Standard (not admin) | partner access request from our business manager | we see campaigns |
| Website CMS | Editor (not admin) | invite to our named user | we save a draft |
| Brand assets | read | shared folder link | files open |

**Never:** passwords by email or chat, shared personal logins, admin when editor works.

**Tracking:** each item `requested → granted → verified` with dates in the project record
(`data/delivery/projects.json → access`). Chase day 2 (friendly reminder), day 4 (what's blocked and its
effect on the timeline), then the account lead calls. A blocked dependency moves the plan's dates, said
openly in the next status update.

---

## Project Scaffolding

**Folder structure** (adapt to the business's convention):

```text
<Client>/
  01 Admin (contract, SOW, invoices)
  02 Kickoff (pack, notes)
  03 Inputs (from the client)
  04 Work in progress
  05 Delivered
```

**Plan rules:** every milestone broken into tasks of ≤ 3 days, each with one owner and a date; tasks that
depend on client access start after the access is verified; 10–20% buffer before each client-facing
milestone.

**Client context file** (`knowledge/clients/<client>.md`): goals, stakeholders and what each cares about,
preferences (tone, channels, meeting times), constraints (brand rules, approvals, compliance), history.

**Hand-off:** notify the delivery owners with the plan and context file; schedule the first status update
with delivery-status-reporter.

---

## Log each job

```
node bin/wf.mjs log --skill client-onboarding-manager --job "Kickoff Pack" --status queued --summary "<client>: welcome + kickoff queued" --minutes-saved 90
node bin/wf.mjs log --skill client-onboarding-manager --job "Access Collection" --status done --summary "<client>: <n>/<m> access verified" --minutes-saved 30
node bin/wf.mjs log --skill client-onboarding-manager --job "Project Scaffolding" --status done --summary "<client>: plan with <n> tasks" --minutes-saved 60
```
