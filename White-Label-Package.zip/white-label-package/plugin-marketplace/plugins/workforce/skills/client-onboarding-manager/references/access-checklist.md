# Access checklist — {{client}}

| # | What | Why we need it | Access level | How to grant (secure) | Status |
|---|---|---|---|---|---|
| 1 | {{e.g. Google Analytics property}} | {{reporting}} | Viewer | Add {{team account}} as a user in Admin → Property access | requested |
| 2 | {{CRM}} | {{integration}} | API/integration user with limited scope | Create an integration user; share credentials via {{password manager}} | |
| 3 | {{Brand assets}} | {{design}} | Read | Share the folder with {{team account}} | |

Never email passwords or API keys. If a tool has no user invitations, use a password-manager share or a one-time secret link, then change the password after the project.
