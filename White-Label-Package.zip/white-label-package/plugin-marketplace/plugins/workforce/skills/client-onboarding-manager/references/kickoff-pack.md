# Welcome to {{company}}, {{client}}

## What we're here to achieve
{{goal in their words}} — we'll know it's working when {{success measures}}.

## What's included
{{scope bullets}}

## Not included (ask us if you need it)
{{out of scope bullets}}

## The plan
| Milestone | What you get | Target date | Depends on |
|---|---|---|---|

## Who's who
| Us | Role | Contact |
|---|---|---|
| Them | Role | Contact |

## How we'll work together
- Status update every {{cadence}} by {{channel}}
- Check-in call {{cadence}}
- Questions: {{channel}}, we reply within {{response time}}
- Approvals: {{who approves deliverables, within how long}}
- Changes to scope: we'll send a short change note with cost and timing before doing anything extra

## What we need from you this week
See the access checklist. Please use the secure methods listed; never send passwords by email.
