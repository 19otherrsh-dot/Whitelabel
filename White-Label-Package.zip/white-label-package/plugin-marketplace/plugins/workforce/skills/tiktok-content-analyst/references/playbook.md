# Playbook · TikTok content analyst

`SKILL.md` has the steps. Permitted data only; learn patterns, don't copy videos. Sounds: only those
cleared for business use (the commercial sound library). This file has the tagging sheet, retention
devices and the idea format.

## Tagging sheet

| Account / search | Date | Length | Hook (visual + words, 0–2 s) | Format | Retention devices | Sound | CTA | Views vs account median | Comment themes |
|---|---|---|---|---|---|---|---|---|---|
| @competitor-b | 9 Oct | 22 s | phone ringing on an empty desk + "Nobody's picking up" | POV | open loop, countdown | original | follow | 4.1× | "what app is this?" |

## Retention devices to look for

Open loop ("the third one surprised us") · countdown or numbered list · pattern interrupt every 2–4 s
(cut, zoom, text change) · on-screen text that adds to what's said · payoff held to the end · a loop
where the end leads back to the start.

## Idea format

```markdown
Concept: "Where your 6pm calls go"
Hook (0–2 s): ringing phone, empty reception · text "It's 6:01pm"
Beats: 1. the call rings out · 2. the caller books elsewhere (text overlay) · 3. what a 60-second text-back looks like
Length: 20–25 s · Format: POV · CTA: "Follow for part 2: the text that works"
Pattern applied: POV + open loop (8 of 14 top videos) · Unanswered comment theme: "what do you text back?"
Sound: original voice + commercial library track
```

## Log

```
node bin/wf.mjs log --skill tiktok-content-analyst --job "Competitor Analysis" --status done --summary "<n> accounts, <n> patterns, <n> ideas" --minutes-saved 90
```
