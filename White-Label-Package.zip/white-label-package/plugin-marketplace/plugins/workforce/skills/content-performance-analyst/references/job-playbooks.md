# Job playbooks · Content performance analyst

The detail behind each job in `SKILL.md`. Comparisons are normalised; small samples are labelled; what
people said is used without names or personal details.

---

## Performance Mining

**Normalised table** (per piece):

| Piece | Platform | Days live | Impr. | Saves /1k | Shares /1k | Qual. comments | Leads | Score vs median |
|---|---|---|---|---|---|---|---|---|
| "1 in 5 calls" carousel | LinkedIn | 21 | 8,400 | 6.1 | 2.4 | 9 | 2 | 2.3× |

Score = weighted goal metric ÷ the account's median for that platform and format. Boosted posts are
marked and compared only with boosted posts.

**Pattern record:**

```markdown
Pattern: posts opening with a number from our own data beat the median 2.1× (7 of 9 such posts above
median; 4 of 14 others). Tags compared: hook type, format, pillar, length, posting time.
Confidence: medium (n = 23). Action: 2 more data-led posts next fortnight; test on Instagram.
```

**Re-hash list:** top 5 with the suggested new angle/format/platform; bottom 5 with "retire" or "rework
because…".

---

## Audience Analysis

**Cluster table:**

| Cluster | Type | Count | Channels | Example (anonymised) | Turn into |
|---|---|---|---|---|---|
| "Will patients find texts pushy?" | objection | 11 | DMs, calls | "our patients are older, would they mind?" | FAQ + post; objection library |
| "What happens after hours?" | question | 8 | comments | … | how-it-works video |

The exact phrases people use go into `knowledge/customer-language.md` so copy uses their words.

---

## Log each job

```
node bin/wf.mjs log --skill content-performance-analyst --job "Performance Mining" --status done --summary "<n> pieces ranked, <n> patterns" --minutes-saved 60
node bin/wf.mjs log --skill content-performance-analyst --job "Audience Analysis" --status done --summary "<month>: <n> clusters, <n> ideas" --minutes-saved 60
```
