# Playbook · Presentation designer

`SKILL.md` has the steps. This file has a storyline example, slide-type guide, notes format and the
final check.

## Storyline example (QBR, 10 slides, fictional)

1. Q3 filled 54 more appointment slots than Q2
2. Missed calls fell from 21% to 9% after text-back went live
3. Evening calls are now the biggest remaining gap
4. Bookings from text-back peak within 2 minutes of the missed call
5. The Leeds practice lags because its line isn't connected yet
6. Connecting Leeds would add about 15 slots a month
7. Next quarter: connect Leeds and test a Saturday auto-reply
8. What we need from you: line access by 15 Nov
9. Timeline
10. Decision today: approve the Leeds connection

Read alone, the headlines tell the whole story.

## Slide-type guide

| Point | Visual |
|---|---|
| One headline number | big number + one-line context |
| Change over time | line chart, takeaway as the title |
| Comparison | bar chart, sorted |
| Process or plan | 3–5 step diagram or timeline |
| Options | 2–3 columns with the trade-off |
| A quote (permitted) | the quote large, name and role small |

## Speaker notes format

```text
[~1 min] Say: "<the point in the presenter's words>"
Detail if asked: … · Source: <file, date>
Transition: "Which brings us to…"
Likely question: "<…>" → "<answer>"
```

## Final check

Headlines are full sentences; every number has a source in the notes; one idea per slide; nothing
overflows; fonts embedded or safe; slide numbers; the closing slide carries the ask; total timing fits the
slot.

## Log

```
node bin/wf.mjs log --skill presentation-designer --job "Deck Production" --status draft --summary "<deck>: <n> slides" --minutes-saved 180
```
