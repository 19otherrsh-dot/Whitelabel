# Job playbooks · Client portal manager

The detail behind each job in `SKILL.md`. A portal shows the client their project; nothing internal
ever goes in it.

---

## Portal Provisioning

**Page outline** (works in Notion, a shared Drive folder with a front page, or the client tool the
business uses):

```markdown
# <Client> · <project>
## Overview
Goal: … · How we'll measure it: … · Your team: … · Our team: … · Contacts and hours: …
## Plan
| Milestone | Date | Status |
## Deliverables
| Item | Version | Link | Status (draft / for approval / approved) |
## Meetings
<date> · summary · decisions
## Needed from you
| Request | Why it matters | Due | Status |
## Updates
<newest first>
```

**Never in the portal:** costs, margins, rates of individual people, internal notes, other clients'
names or work, draft commentary not yet approved.

**Access record:** each named person, their access level (view / upload), date granted. Removing a
person who left the client company happens the day we hear.

---

## Portal Sync

**What syncs without review (when the owner made Portal Sync autonomous):** a task marked done, a
meeting summary already sent to the client, a deliverable link that's already approved.
**What waits for the account lead:** a date moving, anything about budget or scope, an issue or risk,
a new deliverable version.

**Weekly check:** every link opens for a client account; plan statuses match `projects.json`; requests
past due are raised in the next status update; superseded versions moved to an "Archive" section.

---

## Log each job

```
node bin/wf.mjs log --skill client-portal-manager --job "Portal Provisioning" --status queued --summary "<client>: portal built, sharing queued" --minutes-saved 60
node bin/wf.mjs log --skill client-portal-manager --job "Portal Sync" --status done --summary "<client>: <n> updates synced, <n> waiting" --minutes-saved 15
```
