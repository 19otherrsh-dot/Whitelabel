# Scoring model (default; tune from outcomes)

| Criterion | Points |
|---|---|
| Industry: core vertical / adjacent / other | 25 / 10 / 0 |
| Size in best-fit band / acceptable / outside | 20 / 10 / 0 |
| Geography served / possible / not served | 10 / 5 / 0 |
| Contact role: decision-maker / champion / influencer / other | 20 / 15 / 8 / 0 |
| Tech or model signal matches ICP | 10 |
| Active buying signal in last 30 days (strong / medium) | 15 / 8 |
| Engagement (visited site, opened before, inbound) | up to 10 |

Cap at 100. Any disqualifier from the ICP → excluded regardless of points.

Calibration record:

| Date | Change | Evidence |
|---|---|---|
| | | |
