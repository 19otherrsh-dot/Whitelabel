# Job playbooks · Lead scoring analyst

The detail behind each job in `SKILL.md`. The weights and criteria live in `scoring-model.md`; this
file shows how to apply and test them.

---

## Fit Scoring

**Worked example** (with the model's example weights):

| Criterion | Lead data | Points |
|---|---|---|
| Core vertical | dental group | 30 / 30 |
| Size 20–200 | 45 staff | 20 / 20 |
| Region served | England | 15 / 15 |
| Decision-maker role | practice manager | 10 / 15 |
| Tech signal | booking system: unknown | 0 / 10 (listed "unknown") |
| Signal points | ops hire 3 weeks ago | +10 |
| **Total** | | **85 → A** |

`scoreReason`: "A: core vertical, 45 staff, ops hire last month; booking system unknown."

**Distribution report:** tiers count and %; how many have each criterion "unknown" (an enrichment job);
top 50 with reasons. A list with more than 40% unknown on any criterion goes back to enrichment first.

---

## Lookalike Modeling

**From best customers to filters:**

```markdown
Best cohort (n=12, top revenue and retention): dental 9, physio 3; 20–80 staff; 2–5 sites;
England 11; booking system X 7.
Filters: industry in (dental, physio) · employees 20–80 · locations ≥ 2 · country UK/England
Exclude: existing clients (CRM export), competitors, anti-ICP list
Not used as a filter: owner age, names, or anything that stands in for a protected characteristic
```

**Hand check:** sample 20 from the list; each marked "looks like our best" yes/no with a reason. Below
14/20 → tighten filters and repeat.

---

## Calibration (quarterly)

| Tier | Leads | Replied | Meetings | Won |
|---|---|---|---|---|
| A | 210 | 9.0% | 3.8% | 1.4% |
| B | 340 | 8.5% | 3.5% | 1.2% |
| C | 280 | 2.1% | 0.4% | 0% |

B converting like A → find the criterion separating them least (e.g. size band) and re-weight. Record the
change, the evidence and the date in `scoring-model.md` and `knowledge/lessons.md`.

---

## Log each job

```
node bin/wf.mjs log --skill lead-scoring-analyst --job "Fit Scoring" --status done --summary "<n> scored: A <n>, B <n>, C <n>" --minutes-saved 45
node bin/wf.mjs log --skill lead-scoring-analyst --job "Lookalike Modeling" --status done --summary "<n> lookalikes, hand check <n>/20" --minutes-saved 60
```
