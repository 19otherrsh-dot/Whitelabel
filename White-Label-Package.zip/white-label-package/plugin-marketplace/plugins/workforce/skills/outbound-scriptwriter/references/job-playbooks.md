# Job playbooks · Outbound scriptwriter

The detail behind each job in `SKILL.md`. Scripts are guides for a person to speak naturally from, not
lines to read; honesty rules (who we are, why we're calling, where we got the number) are on every page.

---

## Cold-Call Scripting

**Worked example script** (fictional; segment "UK dental groups, 2–5 sites, practice manager"):

```text
OPENER
"Hi Jo, it's Sam from <business>. I'm calling because you've just opened the Leeds practice,
and I work with groups going from two sites to three. Have you got 30 seconds for why I called?"

PROBLEM
"Groups at that stage tell us calls that ring out at the front desk turn into lost bookings.
Is that something you're seeing, or is it under control?"

DISCOVERY (pick 3)
- "Roughly how many calls a day come into each site?"
- "What happens today when a call isn't answered?"
- "Who looks after the booking system across the sites?"
- "If you fixed this, what would it be worth over a month?"

OBJECTIONS
- Not interested → "Fair enough. Is that because it's handled, or just not a priority this quarter?"
- Send me an email → "Happy to. So it's useful, what's the one thing you'd want to see in it?"
- We have someone → "Good to hear. What made you choose them? … Anything you'd change?"
- No budget → "Understood. Is it worth 15 minutes to see what it costs you now, and decide later?"
- How did you get my number? → "From <source>, a business directory. If you'd rather I didn't call, I'll take you off our list now."

CLOSE
"Would Tuesday at 10 or Thursday at 2 work for 15 minutes?"

VOICEMAIL (≈ 20 s)
"Hi Jo, Sam from <business>, about missed calls now that the Leeds practice is open. One idea that's
worked for three-site groups. I'm on 0113 000 0000, and I'll send a short email too."
```

**Rules box on every script:** call 9:00–17:30 in their time zone, weekdays; TPS/CTPS (UK) or DNC
(US) checked on the day; identify the business; "don't call again" → suppression list immediately.

**Call outcome codes** for the dialler/CRM: connected-meeting, connected-follow-up, connected-not-now
(date), connected-no, voicemail, wrong person (who's right), do-not-call.

---

## Video Prospecting

**Script template (≤ 200 words):**

```text
[0–5s · their website on screen] "Hi <name>, I was looking at <specific page>."
[5–20s] Personal line: <trigger or their content, cited in the notes>
[20–60s] One idea: "I noticed <observation>. <What could change and what that's worth>."
[60–80s] CTA: "If it's useful, reply 'yes' and I'll send the two-minute version / 15 minutes next week?"
```

**Recording notes:** under 90 seconds; the first frame shows their site or name (that's the thumbnail);
one take is fine; no fake "I was just passing" scenes. The carrying email is queued with the video link
and a one-line text summary for people who won't play it.

---

## Log each job

```
node bin/wf.mjs log --skill outbound-scriptwriter --job "Cold-Call Scripting" --status draft --summary "<campaign>: script + <n> objection branches" --minutes-saved 60
node bin/wf.mjs log --skill outbound-scriptwriter --job "Video Prospecting" --status draft --summary "<campaign>: <n> video scripts" --minutes-saved 40
```
