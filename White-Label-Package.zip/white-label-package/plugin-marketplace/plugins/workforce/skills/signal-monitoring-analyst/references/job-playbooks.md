# Job playbooks · Signal monitoring analyst

The detail behind each job in `SKILL.md`. Research standards (`docs/research-standards.md`) apply to
every signal: a source, a date, and "verified" or "single source".

---

## Account Monitoring

**Needs:** `data/signals/watchlists.json`. If it's missing, create it with the owner:

```json
{ "accounts": [{ "name": "Acme Dental Group", "domain": "acmedental.example", "type": "prospect", "owner": "Sam" }],
  "competitors": [{ "name": "…", "domain": "…" }], "topics": ["patient no-shows"], "brand": ["Pellmark", "Pellmark Growth"] }
```

**Event types and why they matter:**

| Event | Usually means | Typical action |
|---|---|---|
| Funding round | budget for growth | timely, specific outreach |
| Hiring for a role our offer replaces or supports | the pain is real now | reference the hire |
| New leader in the buyer's seat | a 90-day window for change | congratulate, offer a useful insight |
| Expansion / new location | new needs | offer onboarding for the new site |
| Layoffs / restructuring | budget pressure or new priorities | careful: no opportunistic outreach |
| Acquisition | decision-makers may change | map the new buying committee |
| Regulatory action | risk to them; maybe a need | owner decides; never exploit |

**Rules:** an event counts once (match by URL and by company+type+date within 7 days). Old news
resurfacing (published > 30 days ago) is ignored unless new facts appear. Unverified rumours are
labelled as such and never routed as high priority.

---

## News & Mention Tracking

**Search set per run:** brand terms, founders' names together with the company (professional
mentions only), product names, priority topics.

**Classify each mention:**

| Sentiment | Response might be wanted? | Example |
|---|---|---|
| positive | share or thank | a client praises the work on a podcast |
| neutral | usually none | listed in an industry roundup |
| negative | answer the person, privately first | a review complaining about response time |
| inaccurate | correct, politely, with a source | an article states the wrong price |

Nothing is posted in reply automatically: draft the response for the owner when one is wanted.

---

## Alert Routing

**Priority score** (0–9) = relevance (0–3) + urgency (0–3) + account value (0–3). 7+ high, 4–6
medium, 0–3 low. Anything reputational (negative press, a complaint going viral) is high regardless.

**Alert format** (one per signal, also the digest row):

```text
<Company> · <event in one line>
Source: <publication>, <date> (<verified | single source>)
Why it matters: <one line tied to our offer or the account's situation>
Suggested action: <one line> · Owner: <name>
```

**Digest:** `output/intelligence/alert-routing/<date>-digest.md`, grouped by owner, high first.

**Tuning:** when the owner dismisses alerts of the same kind three times, propose a rule change (a
lesson) rather than continuing to send them.

**Worked example.** Watched prospect *Acme Dental Group* posts a job for "Patient experience manager"
(company careers page, 2 days ago, verified). Relevance 3 (our front-desk offer), urgency 2 (hiring
window), value 2 → 7, high. Alert to Sam with a suggested opener referencing the role.

---

## Log each job

```
node bin/wf.mjs log --skill signal-monitoring-analyst --job "Account Monitoring" --status done --summary "<n> accounts checked, <n> new events" --minutes-saved 30
node bin/wf.mjs log --skill signal-monitoring-analyst --job "News & Mention Tracking" --status done --summary "<n> mentions (<n> negative)" --minutes-saved 20
node bin/wf.mjs log --skill signal-monitoring-analyst --job "Alert Routing" --status done --summary "<n> alerts: <n> high" --minutes-saved 15
```
