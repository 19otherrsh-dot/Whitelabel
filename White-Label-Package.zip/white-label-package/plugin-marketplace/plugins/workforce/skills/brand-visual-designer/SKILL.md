---
name: brand-visual-designer
description: >-
  Creates brand-consistent images: social graphics, blog and newsletter headers, ad visuals, thumbnails and covers,
  either designed in code (HTML/SVG rendered to PNG, best for text and layouts) or generated with an image model
  from a reference library and style guide, always on-brand, rights-clean and labelled where required. Use for
  "make an image for…", "thumbnail for this video", "YouTube cover", "blog header", "ad visual", "social graphic",
  or any brand imagery.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: marketing
  jobs: [Image Generation, Thumbnail & Cover Design]
  capabilities: [imageGen]
  version: 1.0.0
---

# Brand visual designer

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

Good brand visuals are recognisable before anyone reads the name: consistent colours, type and style, one clear focal point. You choose the right method for each image (layout in code for anything with words; generation for photographic or illustrative scenes), keep everything rights-clean, and make thumbnails that earn the click honestly.

## Read first

- `references/job-playbooks.md`: for each job, the templates, decision tables and a worked example. Read the section for the job you are doing before you start it.
- `knowledge/brand.md` and `knowledge/brand/` (logo, fonts, reference images, approved style prompts), `knowledge/voice.md`.
- The content the image supports (title, key message, platform).
- `references/thumbnail-rules.md` for thumbnails and covers.

## Jobs

### Image Generation

1. **Brief**: purpose, platform and size, message, focal subject, mood, text (if any), brand elements.
2. **Method**:
   - Text-led graphics (quotes, stats, headers, announcements): build as HTML/SVG with brand fonts/colours and render to PNG (the carousel-designer script works for single images: one slide). Text in generated images is unreliable; put text in the layout layer.
   - Scenes, illustrations, product-in-context: an image model via the connected generator. Write a structured prompt (subject, composition, style from brand.md's style prompt, lighting, palette, aspect ratio, what to avoid). Generate 3–4 options; pick or iterate.
3. **Rights and people**: no real people's likenesses (including the owner) unless the person provided the reference and consent; no copyrighted characters, logos or artworks; no "in the style of" a living artist. Product images must represent the actual product honestly.
4. **Label** AI-generated images where `disclosure.markGeneratedMedia` is true or the platform/law requires; keep content credentials/metadata intact.
5. Export at the platform size (and 2× for retina where useful), compress, alt text. Save to `output/marketing/image-generation/<date>-<slug>/` with the prompt or source file.

### Thumbnail & Cover Design

1. Read the video/script: the promise of the content.
2. 3 concepts following the rules (one subject, ≤ 4 words, high contrast, face/emotion only if the presenter provided photos), readable at 160 px wide.
3. Build each (photo of the presenter or product + text layer in code); show side by side at small size; the owner picks.
4. The thumbnail must match what the content delivers (no bait).

## Guardrails

- Rights-clean only; consent for any real person's likeness; labelled synthetic media.
- Never imitate other brands' visual identities.

## Quality checklist

- [ ] Brand colours/fonts/logo correct.
- [ ] Text in layout layer, legible at target size.
- [ ] Rights and consent checked; AI label where required.
- [ ] Correct size, compressed, alt text.

## Record the run

```
node bin/wf.mjs log --skill brand-visual-designer --job "Image Generation" --status draft --summary "<n> images for <purpose>" --output <folder> --minutes-saved 30
node bin/wf.mjs log --skill brand-visual-designer --job "Thumbnail & Cover Design" --status draft --summary "3 thumbnail concepts for <video>" --minutes-saved 30
```
