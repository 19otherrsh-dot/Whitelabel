# Job playbooks · Brand visual designer

The detail behind each job in `SKILL.md`, alongside `thumbnail-rules.md`. Brand rules come from
`knowledge/brand.md`.

---

## Image Generation

**Brief template:**

```markdown
Purpose: … · Platform and size: e.g. LinkedIn 1200×1200 · Message (one line): …
Focal subject: … · Mood: … · Text on image (≤ 8 words): …
Brand: palette <tokens>, fonts <names>, logo <yes/no, position>
Method: layout (HTML/SVG) | generated scene | both (scene + text layer)
```

**Generated-scene prompt structure:**

```text
Subject: <what, doing what> · Composition: <framing, angle, negative space for text on the left>
Style: <brand.md style prompt> · Lighting: … · Palette: <brand colours by name>
Aspect: 1:1 · Avoid: text, logos, real people's faces, recognisable brands, extra fingers
```

**Delivery checklist:** right size (and 2× where useful); under ~500 KB for social; alt text written
(what it shows and why it matters, not "image of"); AI label applied if required; the prompt or source
file saved alongside.

**Worked example.** A stat post "1 in 5 calls go unanswered": layout method (text-led), brand navy
background, number at 220 px, source line at the bottom ("Our call data, Sept 2026, 4 clinics"), alt text
"Large figure: one in five calls go unanswered at clinic front desks, from our September call data."

---

## Thumbnail & Cover Design

**Concept sheet:** three concepts side by side at 160 px and 320 px wide; each with the ≤ 4-word text,
the subject, the contrast check (text vs background at least 4.5:1) and how it matches the video's
promise. The owner picks; the others are kept for an A/B test if the platform supports it.

---

## Log each job

```
node bin/wf.mjs log --skill brand-visual-designer --job "Image Generation" --status draft --summary "<slug>: <n> images" --minutes-saved 40
node bin/wf.mjs log --skill brand-visual-designer --job "Thumbnail & Cover Design" --status draft --summary "<video>: 3 thumbnail concepts" --minutes-saved 30
```
