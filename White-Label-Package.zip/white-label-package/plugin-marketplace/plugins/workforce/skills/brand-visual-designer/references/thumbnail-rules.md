# Thumbnail and cover rules

1. **One idea**: one subject, one emotion or tension, ≤ 4 words of text (often 0–3).
2. **Complement the title**, don't repeat it: title says the promise, thumbnail shows the stakes or result.
3. **Legible at 160 px wide**: big type, bold weight, high contrast, no thin fonts.
4. **Contrast**: subject separated from background (outline, blur, colour block).
5. **Faces**: real expressions from the presenter's own photos (provided by them); eyes visible.
6. **Safe zones**: avoid the bottom-right corner (video length overlay).
7. **Honest**: shows what the video delivers; no fake arrows at things that aren't there, no shock imagery.
8. **Series consistency**: same layout family so the channel looks like one brand.
9. Sizes: YouTube 1280×720 (16:9), podcast covers 3000×3000, LinkedIn video cover 1920×1080.
