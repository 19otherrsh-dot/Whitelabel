# Job playbooks · Prospect research analyst

The detail behind each job in `SKILL.md`. Public, professional information only: nothing about family,
health, home address or private social accounts, even if it can be found.

---

## Person Research

**Brief template** (`output/intelligence/person-research/<name>-<company>.md`):

```markdown
# <Name> · <title>, <company> · <date>
Remit: what they own and decide · Tenure: … · Before: …
Recent public content (last 12 months):
- <date> · <format> · <title> · <one-line point> · <link>
Stated priorities/challenges (their words, cited): …
Shared ground (public only): …
How to open: <one suggested first line, tied to a cited item>
Don't: <topics to avoid, e.g. a recent layoff they haven't spoken about>
```

---

## Personalization Research

**Hook quality:**

| Hook | Example | Use |
|---|---|---|
| Their own words | "Your post on reminder no-shows (12 Oct)…" | best |
| Company event in their remit | "With the Leeds practice opening…" | good |
| Role challenge in the segment | "Practice managers at 3+ sites tell us…" | fine |
| Flattery or vague ("love what you're doing") | — | never |

**Personal line rules:** ≤ 25 words; true and checkable from `hook_source`; about them, not us;
no assumptions about feelings ("you must be stressed").

**Worked example (A-tier):**
`personal_line`: "Your talk at the October dental ops meetup on front-desk overload matched what three-site
groups tell us about missed calls." · `hook_source`: event page link, 2026-10-08 · `angle`: missed-call
recovery · `confidence`: high.
B-tier: one check of the company news page → a company-event hook or the segment line. C-tier: segment line.

---

## Log each job

```
node bin/wf.mjs log --skill prospect-research-analyst --job "Person Research" --status done --summary "<name>: brief ready" --minutes-saved 20
node bin/wf.mjs log --skill prospect-research-analyst --job "Personalization Research" --status done --summary "<n> leads: <n> personal hooks" --minutes-saved 60
```
