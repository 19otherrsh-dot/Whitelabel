# Job playbooks · Records administrator

The detail behind each job in `SKILL.md`, with `filing-convention.md` for names and folders.

---

## CRM Sync

**Mismatch checks and the default source of truth:**

| Check | Source of truth | Proposed fix |
|---|---|---|
| Deal won in CRM, no invoice in accounting | CRM (deal) | flag to billing-manager: invoice due? |
| Invoice paid, deal still open | accounting (money) | move the deal to won (with the owner's OK) |
| Client in accounting, not in CRM | accounting | create the company/contact in CRM |
| Contact email differs | the most recent signed document or email | update the older record |
| Duplicate companies (same domain) | the record with more activity survives | merge proposal |
| Deal amount differs from the signed contract | the signed contract | update the CRM amount |

Owner overrides go in lessons ("for us, the spreadsheet is the source for retainers").

**Output:** `output/back-office/crm-sync/<date>-sync.md`

```markdown
# Records sync · <date>
Workforce copy updated: <n> records  ·  Proposed changes to CRM/accounting: <n>  ·  Conflicts: <n>
## Proposed changes (applied after OK / queued as crm-update)
| System | Record | Field | From → To | Why (source) |
## Conflicts that need a person
```

---

## Document Filing & Retrieval

**Classify each document:** type (contract, invoice, receipt, proposal, statement, HR, legal, other),
party, date (the document's date, not the download date), entity (which company of the owner's).

**Name:** per `filing-convention.md`, e.g. `2026-10-14_Contract_Bright-Harbor-Studio_Retainer-v2_signed.pdf`.

**Index row** in `data/records/documents.json`:
`{ id, title, type, party, date, entity, path, retentionUntil, sensitive: true|false }`.
Retention from `knowledge/policies.md` (common defaults the accountant should confirm: tax records 6–7
years; HR records per local law).

**Retrieval answer format:** the path or link, the document's date and party, one line on what it is,
and the clause or page if they asked about something specific.

**Monthly hygiene list:** duplicates, misnamed, past retention (deletion is the owner's), externally
shared files (review). Never delete, never share.

---

## Entity Compliance

**Obligations register** (`data/records/deadlines.json`), only what the owner or accountant confirmed:
`{ id, entity, obligation, due, recurrence, owner, status, notes, confirmedBy }`.

**Questions, not guesses.** If you think an obligation probably applies (e.g. an annual return for a
UK company, a state annual report for a US LLC), write it as a question for the accountant in the
report, with why you think it applies. Nothing is added to the register until confirmed.

**Weekly report:** `output/back-office/entity-compliance/<date>-deadlines.md`: due in 60 days (by date),
overdue, without an owner, and open questions for the accountant.

**Worked example.** *Pellmark Growth Ltd* (UK): confirmation statement due 14 Nov (owner: founder,
confirmed by accountant), VAT return due 7 Dec (accountant). Report shows both as "due in 60 days";
one question: "Is the US LLC set up in March registered for a state annual report?"

---

## Log each job

```
node bin/wf.mjs log --skill records-administrator --job "CRM Sync" --status done --summary "<n> updated, <n> proposed, <n> conflicts" --minutes-saved 30
node bin/wf.mjs log --skill records-administrator --job "Document Filing & Retrieval" --status done --summary "<n> filed" --minutes-saved 20
node bin/wf.mjs log --skill records-administrator --job "Entity Compliance" --status done --summary "<n> due in 60 days, <n> overdue" --minutes-saved 15
```
