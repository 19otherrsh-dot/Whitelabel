# Filing convention (default)

Use the owner's own convention if recorded in lessons; otherwise this one.

## File names

`YYYY-MM-DD_<type>_<party>_<short-description>.<ext>`

- Date = the document's own date (signature date, invoice date), not the filing date.
- Type from: `contract`, `sow`, `nda`, `proposal`, `invoice`, `receipt`, `bill`, `statement`, `tax`, `payroll`, `policy`, `hr`, `report`, `minutes`, `other`.
- Party = the other company or person, lowercase-hyphenated.
- Example: `2026-10-14_contract_acme-dental_growth-retainer-signed.pdf`

## Folders

```
/<Entity>/
  01 Clients/<client>/          contracts, SOWs, proposals, deliverables
  02 Finance/<YYYY>/            invoices-out, bills-in, receipts, statements
  03 Tax & Compliance/<YYYY>/   filings, correspondence
  04 People/<person>/           (restricted) contracts, onboarding
  05 Suppliers/<supplier>/      agreements, invoices
  06 Company/                   registration, insurance, policies, minutes
```

People folders are restricted to the owner and HR; never share them.

## Retention (defaults to confirm with the accountant)

- Financial and tax records: keep as long as local law requires (often 6–7 years or more).
- Contracts: term + the limitation period.
- Personal data of candidates who weren't hired: short, per the privacy policy.
