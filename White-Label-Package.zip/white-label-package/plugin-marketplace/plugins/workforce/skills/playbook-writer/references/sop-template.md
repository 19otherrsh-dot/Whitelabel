# SOP: {{process name}}

**Purpose:** {{why this exists, what good output looks like}}
**Trigger:** {{when to run it}} · **Owner:** {{role}} · **Time:** {{typical minutes}} · **Last reviewed:** {{date}}

## Inputs
- {{what you need before starting}}

## Tools and access
- {{tool}} — {{access level}} (credentials: {{where they live, not the secret}})

## Steps
1. {{One action.}} [Screenshot: {{…}}]
2. {{One action.}}
   - If {{condition}} → {{do this}}; otherwise → {{do that}}.
3. …

## Quality checks before you finish
- [ ] {{check}}

## Common mistakes
- {{mistake}} → {{how to avoid}}

## Automation notes
| Step | Agent could do it? | Skill |
|---|---|---|

## Change log
- {{date}}: created from {{source}}
