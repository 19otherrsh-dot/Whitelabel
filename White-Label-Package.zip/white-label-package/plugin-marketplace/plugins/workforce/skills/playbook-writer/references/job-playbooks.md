# Job playbooks · Playbook writer

The detail behind each job in `SKILL.md`, alongside `sop-template.md`.

---

## SOP Generation

**Capture questions** (ask while the doer walks through the last real instance):
1. What sets this off, and how do you know it's your turn?
2. What do you open first, and what do you need in front of you?
3. At this step, how do you decide between options? What would make you stop?
4. What goes wrong most often? What did a new person get wrong last time?
5. How do you check it's right before it leaves you?
6. How long does each part take on a normal day and on a bad one?

**Step-writing rules:** one action per step, starting with a verb; name the exact screen, field or file;
decisions as "If … then … otherwise …"; a check after any step that's easy to get wrong; no step depends
on knowledge that isn't written down or linked.

**Automation column** (added to each step): `agent: <skill>` · `agent with approval` · `person`
(and why: judgement, relationship, physical).

**Worked example.** "Monthly client report", captured from a 20-minute recording: 14 steps, 3 decision
points (missing data, a metric dropping more than 20%, a client asking for changes). Tested by a second
person: they stuck at step 6 (which date range); fixed by naming the exact setting. Automation: 10 steps
`agent: delivery-status-reporter`, 3 `agent with approval`, 1 `person` (the commentary call).

---

## Handoff Docs

**Template** (`output/operations/handoff-docs/<client>-<system>.md`):

```markdown
# <System> · handoff for <client> · <date>
What it does (2–3 sentences) · Who it's for
Day to day: <the 3–5 things they'll actually do, step by step>
Changing common things: <e.g. edit an email template, add a user>
Monitoring: <what's watched, by whom, how they hear about problems>
Access and ownership: <account, owner, admin(s)>; secrets live in <their password manager>, not here
Known limitations: …
Support: <contact>, <hours>, <response time>; warranty until <date> per SOW §<n>
Walkthrough call agenda (45 min): demo · their turn to drive · questions · sign-off
```

---

## Log each job

```
node bin/wf.mjs log --skill playbook-writer --job "SOP Generation" --status done --summary "SOP: <process> (<n> steps, <n> automatable)" --minutes-saved 90
node bin/wf.mjs log --skill playbook-writer --job "Handoff Docs" --status queued --summary "<client> <system> handoff queued" --minutes-saved 60
```
