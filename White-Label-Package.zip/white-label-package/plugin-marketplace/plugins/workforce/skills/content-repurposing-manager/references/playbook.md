# Playbook · Content repurposing manager

`SKILL.md` has the steps. This file has the idea-to-format map, a brief template and a worked plan.

## Idea type → formats that suit it

| Idea type | LinkedIn | Instagram | Short video | Newsletter | Blog |
|---|---|---|---|---|---|
| Framework / steps | carousel | carousel | 60 s explainer | section | article (SEO) |
| Story | text post | reel (clip) | clip | lead story | — |
| Number / finding | text post + graphic | single image | 20 s clip | stat box | supporting stat |
| Contrarian take | text post | reel | clip | opinion section | — |
| Quote | graphic | story | — | pull quote | — |

## Specialist brief (one per piece)

```markdown
To: <carousel-designer | video-editor | social-copywriter | newsletter-editor | seo-engineer | brand-visual-designer>
Idea: <one line> · Source: <piece, timestamp or section>
Platform and format: … · Audience segment: … · CTA: …
Must keep: <the claim / number / story beat, exactly> · Avoid: <repeating the hook used elsewhere that week>
Due: <date> · Calendar slot: <date, platform>
```

## Worked plan (fictional source: a 30-minute podcast episode)

| Week | Day | Platform | Piece | Idea |
|---|---|---|---|---|
| 1 | Tue | LinkedIn | carousel | "5 places missed calls go" framework (12:40) |
| 1 | Thu | Instagram | reel | the 6pm voicemail story (04:15) |
| 1 | Fri | Newsletter | section | episode summary + framework |
| 2 | Tue | LinkedIn | text post | contrarian: "voicemail isn't a safety net" (19:02) |
| 2 | Wed | Short video | clip | the 60-second stat (22:30) |
| 3 | Mon | Blog | article | full framework, optimised for "missed calls clinic" |

No two pieces on the same idea on the same day; the strongest idea goes on each platform's best day
(from the performance report).

## Log

```
node bin/wf.mjs log --skill content-repurposing-manager --job "Cross-Platform Adaptation" --status draft --summary "<source>: <n> pieces over <n> weeks" --minutes-saved 90
```
