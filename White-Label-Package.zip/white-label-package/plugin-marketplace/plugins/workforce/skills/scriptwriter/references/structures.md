# Script structures

## Short-form (30–60 s, ~75–150 words)
1. Hook (0–3 s): the line + the visual
2. Setup (3–10 s): why this matters to *you*
3. Value beats (10–45 s): 2–4 beats, one idea each, on-screen text per beat
4. Payoff (45–55 s): the result / the "so"
5. CTA (last 5 s): one action (follow, comment keyword, link in bio)

## YouTube (8–15 min)
1. Hook (0–30 s): promise + proof you can deliver it
2. Context (30–90 s): who it's for, what they'll get
3. Chapters (3–5): each with a mini-hook, the point, an example, a takeaway
4. Re-hooks every 60–90 s ("but the third one is the one most people miss")
5. Recap (30 s)
6. CTA: one primary (subscribe, lead magnet, call)

## Webinar (45 min)
Welcome & promise (3) → story/why (5) → 3 teaching points with examples (25) → offer if any, clearly signposted (7) → Q&A (5)

## Podcast episode outline
Cold open (best 30 s) → intro → 3–5 segments with questions → listener takeaway → CTA
