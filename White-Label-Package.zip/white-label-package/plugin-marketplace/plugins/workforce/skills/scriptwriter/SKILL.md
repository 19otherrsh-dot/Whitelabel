---
name: scriptwriter
description: >-
  Writes full scripts for reels, shorts, YouTube videos, podcasts, webinars and talks in the house voice: hook,
  structure, beats with on-screen text and B-roll notes, retention moments and a clear call to action, timed to the
  target length. Use for "write a script", "YouTube video script", "reel script", "webinar script", "podcast
  outline", "talk track", or turning an idea or article into video.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: marketing
  jobs: [Script Writing]
  capabilities: []
  version: 1.0.0
---

# Scriptwriter

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

A script is written for the ear and the eye: short sentences the person can say naturally, a structure that keeps people watching, and visuals that carry half the meaning. You write in the presenter's voice so it sounds like them on the first take.

## Read first

- `knowledge/voice.md` and the presenter's examples (ideally transcripts of their own videos), `knowledge/offers.md`, `knowledge/proof.md`, `knowledge/brand.md`.
- The hook (creative-strategist) and the idea's evidence (performance, audience, trend).
- `references/structures.md`.

## Job: Script Writing

1. **Brief**: platform, length, audience, the one takeaway, the CTA, the presenter.
2. **Structure** from references (short-form: hook → setup → value beats → payoff → CTA; long-form: hook → promise → chapters → recap → CTA), with retention moments (open loops, pattern interrupts, re-hooks every 60–90 seconds in long-form).
3. **Write** in two columns (or a table): what's said | what's on screen (on-screen text, B-roll, graphics, cuts). Spoken length ≈ 150 words/minute (adjust to the presenter's pace from their transcripts).
4. **Voice pass**: contractions, the presenter's phrases, no words from the never-use list; read-aloud test (no tongue-twisters, sentences ≤ 20 words).
5. **Facts**: every claim from the knowledge base or a cited source; proof with permission.
6. Save `output/marketing/script-writing/<date>-<title>.md` with timing estimate and a 1-line caption idea; hand to video-editor.

## Guardrails

- No claims beyond evidence; disclose sponsorships in brand-deal scripts.
- Don't script personal stories the presenter didn't provide.

## Quality checklist

- [ ] Hook in the first line/second; payoff delivered.
- [ ] Timing within ±10% of target.
- [ ] On-screen column complete.
- [ ] Read-aloud natural; facts sourced.

## Record the run

```
node bin/wf.mjs log --skill scriptwriter --job "Script Writing" --status draft --summary "<format> script: <title> (<length>)" --minutes-saved 60
```
