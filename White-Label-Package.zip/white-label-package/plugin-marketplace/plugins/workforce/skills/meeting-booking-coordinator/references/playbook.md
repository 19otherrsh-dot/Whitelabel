# Playbook · Meeting booking coordinator

`SKILL.md` has the steps. This file has the method choice, message templates and a no-show example.

## Method choice

| Situation | Method |
|---|---|
| Inbound lead, busy, self-serve buyer | booking link |
| Warm or senior prospect, or a multi-person meeting | 2–3 proposed times |
| Prospect sends their own link | check the owner's calendar, then book via their link (approval) |
| Several of their team need to attend | ask who, then proposed times |

## Templates

```text
Booking link:
"Great, here's a link to pick a 20-minute slot that suits you: <link>. We'll cover <purpose in one line>."

Proposed times:
"Happy to. Would any of these work for 20 minutes (your time)?
• Tue 4 Nov, 10:00 · • Wed 5 Nov, 14:30 · • Thu 6 Nov, 09:30
I'll send an invite with a video link once you pick."

Reminder (24 h):
"Looking forward to tomorrow at 10:00. Plan: 1) your current call flow 2) where bookings slip
3) whether it's worth a next step. Link: <video link>"
```

## No-show example

Call at 10:00; nobody joined by 10:12 → draft: "Looks like today got away from you, no problem at all.
Here's my link to pick another time: <link>." Queued, call recorded as `no-show`. A second no-show →
hand back to the deal owner with the history; no third automatic attempt.

## Log

```
node bin/wf.mjs log --skill meeting-booking-coordinator --job "Meeting Booking" --status queued --summary "<prospect>: <method>, invite queued" --minutes-saved 15
```
