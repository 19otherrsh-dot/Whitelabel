# Mutual action plan — {{client}} × {{company}}

Goal: {{outcome}} · Target start: {{date}}

| # | Step | Owner | By | Status |
|---|---|---|---|---|
| 1 | Discovery call | Both | {{date}} | Done |
| 2 | Proposal shared | {{our name}} | {{date}} | Done |
| 3 | Proposal review with {{their stakeholders}} | {{their champion}} | {{date}} | |
| 4 | Questions answered (security/finance) | {{our name}} | {{date}} | |
| 5 | Decision | {{their decision-maker}} | {{date}} | |
| 6 | Agreement signed | Both | {{date}} | |
| 7 | Kickoff | Both | {{date}} | |
