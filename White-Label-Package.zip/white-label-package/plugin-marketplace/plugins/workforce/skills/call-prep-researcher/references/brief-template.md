# {{Company}} — {{call type}} · {{date, time, time zone}} · {{duration}}

**Objective:** {{what a great outcome of this call is}}
**Next step to aim for:** {{e.g. proposal review on <date> with the decision-maker}}

## Who
| Name | Role | Notes (sourced) |
|---|---|---|
| {{name}} | {{title}} | {{tenure, what they care about publicly, source}} |

## Them
- What they do: {{one line}} · Size: {{employees/revenue band, source}}
- Recently: {{news with date and source}}
- Segment match: {{segment from customers.md}} — {{why}}

## Us and them so far
- {{date}}: {{touch}} ({{source}})

## What they probably need (hypotheses)
- {{hypothesis}} — because {{evidence}}

## Questions to ask
1. {{question}}

## Likely objections → approved answer
- {{objection}} → {{answer}}

## Proof to use
- {{story from proof.md, permission: <scope>}}

## Watch-outs
- {{e.g. they're evaluating {{competitor}}; budget cycle ends in March}}
