# CRM hygiene rules

| Check | Rule | Fix |
|---|---|---|
| Duplicate company | Same domain, or names equal after removing Inc/Ltd/LLC/punctuation | Merge into the record with more activity; keep both contacts |
| Duplicate contact | Same email; or same name + company | Merge; keep the most recent title/phone |
| Missing amount | Open deal past "qualified" with no value | Fill from proposal; else ask owner |
| Missing next step | Open deal without next step or date | Ask the deal owner; flag as stalled |
| Stale | No logged activity 21+ days | Flag; suggest re-engage or close-lost |
| Past close date | Close date < today and still open | Ask owner for a new date or close |
| Stage mismatch | Stage requires evidence that's missing (proposal stage without proposal sent) | Propose the correct stage |
| Naming | Deal name not "<Company> — <Offer>" | Rename |
| Lost without reason | Closed-lost with empty reason | Ask owner; never guess |

Default stage probabilities (only when history is too thin): qualified 10%, discovery 20%, proposal 40%, negotiation 70%, verbal yes 90%.
