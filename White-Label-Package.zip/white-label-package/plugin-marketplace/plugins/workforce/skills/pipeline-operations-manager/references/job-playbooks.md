# Job playbooks · Pipeline operations manager

The detail behind each job in `SKILL.md`, with `hygiene-rules.md` for the checks. When deals come from
a CRM sync (`wf sync`), the CRM is the source: propose changes there, and the next sync brings them in.

---

## CRM Hygiene

**Fix proposals carry evidence:**

| Problem | Evidence to attach | Proposed fix |
|---|---|---|
| Duplicate | both records, matching domain/email | merge into the one with more activity |
| Missing amount | proposal sent (output file, email) | amount from the proposal |
| Missing next step | last call notes | next step + date from the notes |
| Stale (21+ days) | last activity date | ask the deal owner: still alive? |
| Close date in the past | the date | new date from the owner, or move to lost |
| Stage ahead of activity | e.g. "proposal" but no proposal | move back, or attach the proposal |

**Output:** `output/deals/crm-hygiene/<date>-hygiene.md`: score (% of open deals passing all checks),
then the change list grouped by deal owner.

---

## Pipeline Reporting

**Report:** `output/deals/pipeline-reporting/<date>-pipeline.md`

```markdown
# Pipeline · week of <date>
Open: <n> deals · <value> · weighted <value> (Δ <value> vs last week)
| Stage | Deals | Value | Weighted |
## Moved this week (advanced · won · lost with reason)
## Stalled (no activity 14+ days or next step overdue) → suggested action
## Closing in the next 30 days
| Deal | Value | Stage | Probability | Next step | Risk |
## New this week by source
## Last 90 days: stage conversion and average cycle
```

Numbers come from `data/pipeline/deals.json` (refreshed by the sync or hygiene run); say which, and
when it was last updated.

---

## Forecasting

**Stage probabilities:** use historical stage-to-win rates when there are 20+ closed deals in the last
6–12 months; otherwise these defaults, labelled as defaults:

| Stage | new | qualified | discovery | proposal | negotiation |
|---|---|---|---|---|---|
| Default probability | 5% | 15% | 30% | 50% | 75% |

**Per-deal adjustments** need evidence and are listed: verbal yes (+), budget confirmed (+), slipped
twice (−), champion left (−).

**Output:** `output/deals/forecasting/<period>-forecast.md`: commit (≥ 80% and closing in period), best
case, pipeline; vs target in `knowledge/goals.md`; the gap and what would close it; last period's
forecast vs actual and the bias.

**Worked example.** Q4 target $120k. Commit $64k (three deals in negotiation with verbal yes), best case
$98k, pipeline $210k. Gap to target $22k beyond best case → recommend two specific stalled deals to
revive and the reactivation list. Last quarter's forecast was 18% high; probabilities for "proposal"
lowered from 50% to 40% (lesson recorded).

---

## Log each job

```
node bin/wf.mjs log --skill pipeline-operations-manager --job "CRM Hygiene" --status done --summary "<n>% clean; <n> fixes proposed" --minutes-saved 30
node bin/wf.mjs log --skill pipeline-operations-manager --job "Pipeline Reporting" --status done --summary "Open <value>, <n> stalled" --minutes-saved 45
node bin/wf.mjs log --skill pipeline-operations-manager --job "Forecasting" --status done --summary "Commit <value>, best <value> vs target <value>" --minutes-saved 40
```
