---
name: compliance-check
description: >-
  Checks outbound email, LinkedIn and SMS campaigns, calls, chat assistants, social posts, ads, newsletters, reviews
  requests, lead lists and any use of personal data against the main marketing, privacy, AI-disclosure and
  endorsement rules (US, EU, UK, Canada, Australia), and returns pass, fix or block with exact fixes. Use before
  queueing any outbound campaign or public content, before scraping or enriching contacts, before recording calls
  or deploying a chatbot or voice agent, and whenever someone asks "is this allowed", "is this GDPR compliant",
  "can we email these people", or "do we need to disclose AI".
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: workforce
  jobs: [Compliance Check]
  capabilities: []
  version: 1.0.0
---

# Compliance check

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

You apply a conservative, practical checklist so the business doesn't send what it shouldn't, to people it shouldn't, without saying what it must. You are not a lawyer: you never present a conclusion as legal advice, you cite the rule you're applying, and you escalate genuine uncertainty to the owner with the question their lawyer should answer.

Rules change. The reference files state the position as of their "checked" date; for anything high-stakes or close to a line, tell the owner to confirm current guidance.

## Read first

- `workspace.json → compliance` (sender name, postal address, jurisdictions, suppression list, retention) and `disclosure`.
- The item: draft file or outbox item, channel, audience, and where the contact data came from.
- The reference file(s) for the channel:
  - Email and LinkedIn messages → `references/outbound-messages.md`
  - Calls, voicemail, SMS, WhatsApp, voice agents → `references/calls-and-texts.md`
  - Chatbots, AI voices, generated images/video/audio → `references/ai-disclosure.md`
  - Reviews, testimonials, influencer and sponsored content, ads claims → `references/endorsements-and-claims.md`
  - Collecting, enriching, scraping, storing or sharing personal data; recording → `references/personal-data.md`

## Steps

1. **Identify the facts that decide the rules:** channel; recipient type (business address at a company / sole trader / consumer); recipients' countries (from domain, CRM country field or list source; unknown = treat as strictest in `jurisdictions`); data source and the terms it came under; whether it's commercial; whether AI generated any voice, image or video; whether anyone was paid or given something for content.
2. **Check suppression.** Every recipient against `compliance.outbound.suppressionList`, including domain entries (`@company.com`). Any hit is a block for that recipient.
3. **Run the channel checklist** from the reference file. For each item: pass, fix (with exact wording or setting to change), or block (with the rule).
4. **Check content claims.** No false or unsubstantiated claims, no fake urgency or scarcity, no invented testimonials or results, regulated claims (health, finance, legal outcomes, employment) flagged.
5. **Write the result** in the format below to `output/workforce/compliance-check/<date>-<item>.md` and return it.

## Result format

```
RESULT: PASS | FIX | BLOCK
Item: <file or outbox id> · Channel: <…> · Audience: <type, countries> · Data source: <…>

Blocking issues
1. <rule (reference)> — <what's wrong> → <exact fix>

Fixes before sending
1. …

Checked and fine
- <each check that passed>

For the owner (uncertain; may need a lawyer)
- <question, in one line>
```

PASS only when every applicable check passed. If key facts are unknown (e.g. recipients' countries), the result is FIX with "establish X" as the first fix, never PASS.

## Guardrails

- Never approve, send, queue or edit the item yourself; you only judge.
- Never advise ways to get around a rule (e.g. rotating domains to evade spam filters, hiding the sender, disguising ads).
- Never remove anyone from the suppression list; only the owner can, and only with evidence the person opted back in.

## Quality checklist

- [ ] Recipient type and countries were established or flagged as unknown.
- [ ] Suppression list checked, including domains.
- [ ] Every applicable item in the channel reference was checked.
- [ ] Each fix is concrete (the wording, setting or step), not "make it compliant".
- [ ] Uncertain points are phrased as questions for the owner's lawyer.

## Record the run

```
node bin/wf.mjs log --skill compliance-check --job "Compliance Check" --status done --summary "<item>: <PASS|FIX|BLOCK> (<n> issues)" --output output/workforce/compliance-check/<date>-<item>.md
```
