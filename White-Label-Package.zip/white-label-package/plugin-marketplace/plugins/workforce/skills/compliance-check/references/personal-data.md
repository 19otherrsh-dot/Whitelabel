# Personal data: collecting, enriching, storing, sharing

Checked: October 2026. A practical summary, not legal advice.

## Principles that apply almost everywhere (GDPR-style)

- **Purpose**: collect and use personal data only for a stated business purpose (e.g. "B2B outreach about bookkeeping services to practice managers").
- **Minimum**: collect only fields the job needs. A cold email needs name, role, company and business email; not home address, age or personal social accounts.
- **Lawful basis** (EU/UK): consent, contract, legal obligation or legitimate interests (with a documented balancing test). Special-category data (health, religion, ethnicity, politics, sexuality, union membership, biometrics) is off-limits for marketing.
- **Transparency**: people must be told who has their data, why, where it came from and how to object or delete, at the latest in the first message.
- **Accuracy**: verify and correct; remove bounced or wrong records.
- **Retention**: delete when no longer needed; default `workspace.json → compliance.dataRetentionDays`.
- **Security**: keep data inside this workspace or approved tools; never paste personal data into public content or unapproved tools.

## Sources

- **Data providers** (lead databases, enrichment): use only providers whose terms allow this use; keep a note of the source per list (`data/pipeline/leads.json → source`).
- **Scraping**: respect the site's terms and robots rules; never scrape behind logins without permission; don't scrape personal social profiles for consumer marketing. Public does not mean free to use for any purpose under GDPR.
- **Purchased lists**: treat as high risk; in the EU/UK most purchased consumer lists can't be emailed.

## Requests from people

Access, correction and deletion requests: pass to the owner the same day; respond within one month in the EU/UK (shorter windows apply under some US state laws for acknowledgement). Add deletion and objection requests to the suppression list so they are never re-imported.

## Sharing with processors

Tools that store or process personal data for the business (CRM, email platform, transcription, the AI provider) need a data processing agreement; for transfers outside the EU/UK, an approved transfer mechanism. The owner keeps a list in `knowledge/policies.md → Data and privacy`.

## US state privacy laws

Many states (e.g. California, Colorado, Connecticut, Virginia, Texas and others) give residents rights to know, delete, correct and opt out of "sale"/"sharing" and targeted advertising. Thresholds decide whether they apply to a small business; check them before large-scale consumer data use.

## Checklist

- [ ] Purpose stated; fields limited to the purpose.
- [ ] Source recorded and allowed this use.
- [ ] Lawful basis identified for EU/UK people; no special-category data.
- [ ] First contact says where the data came from and how to opt out.
- [ ] Retention and deletion handled; suppression list updated.
- [ ] Processors have agreements; nothing shared with unapproved tools.
