# Calls, voicemail, SMS, messaging apps and voice agents

Checked: October 2026. A practical summary, not legal advice.

## United States

- **TCPA**: marketing calls or texts to mobile numbers using an autodialer, or calls using an artificial or prerecorded voice, need the recipient's **prior express written consent**. The FCC has ruled (February 2024) that AI-generated voices count as "artificial" voices under the TCPA, so an AI voice agent making outbound marketing calls needs that consent.
- **Do Not Call**: check the National Do Not Call Registry and the business's internal do-not-call list before telemarketing; honour opt-outs.
- **Calling hours**: federal rule 8 am–9 pm in the recipient's local time; several states are stricter (narrower hours, fewer attempts per day). Use the stricter rule.
- **Identification**: say who is calling and for which business at the start; provide a call-back number.
- **Texts**: include the business name and opt-out instructions ("Reply STOP to opt out"); honour STOP immediately. A2P 10DLC registration is needed for business texting through US carriers.

## Recording and transcription

- Some US states require **every party's consent** to record (including California, Florida, Illinois, Maryland, Massachusetts, Montana, New Hampshire, Pennsylvania and Washington); others need one party. Calls across states: follow the stricter rule.
- EU/UK and many other countries: tell participants before recording, say why and how long it is kept; rely on a lawful basis; let them object.
- Safe default for every recorded call: announce the recording at the start, and stop if anyone objects. Meeting bots should be visible by name.

## EU and UK

- Marketing calls: UK requires screening against the Telephone Preference Service (TPS/CTPS) unless the person consented; automated (recorded or AI voice) marketing calls need prior consent. EU countries vary, many requiring consent or opt-out registry checks.
- Marketing texts follow the email rules (consent or soft opt-in for individuals).
- AI voice agents must say they are AI at the start of the conversation (see ai-disclosure.md).

## WhatsApp and similar

Business messaging through WhatsApp requires the platform's Business API rules: user opt-in for business-initiated messages, approved templates outside the 24-hour customer service window, and honouring opt-outs.

## Checklist

- [ ] Consent recorded for every number (date, method, wording) where required.
- [ ] DNC / TPS screening done where required.
- [ ] Calls within allowed hours in the recipient's time zone.
- [ ] Caller identifies the business and, for AI voices, that it is an AI.
- [ ] Recording announced; consent from all parties where required.
- [ ] Opt-out honoured immediately and added to the suppression list.
