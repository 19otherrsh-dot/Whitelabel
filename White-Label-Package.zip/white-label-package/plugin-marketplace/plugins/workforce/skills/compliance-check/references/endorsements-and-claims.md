# Reviews, testimonials, endorsements and advertising claims

Checked: October 2026. A practical summary, not legal advice.

## Never

- Write, generate or post reviews or testimonials that don't reflect a real customer's real experience, including AI-written "reviews".
- Buy reviews, or offer anything in return for a review that is conditioned on it being positive.
- Post reviews by the owner, staff or their relatives without clearly disclosing the relationship.
- Suppress or selectively hide negative reviews while presenting the rest as all reviews.
- Use a testimonial or case study without the customer's permission for that use (see `knowledge/proof.md` permission status).
- Claim results the business can't substantiate, or present typical results that aren't typical.

In the US these are covered by the FTC's rule on consumer reviews and testimonials (16 CFR Part 465, in force since October 2024, with civil penalties) and the FTC Endorsement Guides. The UK's Digital Markets, Competition and Consumers Act 2024 bans fake reviews and concealed incentivised reviews (from April 2025), and EU consumer law prohibits fake reviews and requires traders to say how they check reviews are genuine.

## Asking for reviews (allowed)

- Ask all customers, or a fair sample, not only the happy ones (asking only happy customers to review publicly can be "review gating", which several platforms forbid).
- Any incentive must not depend on the review being positive, must be disclosed, and must be allowed by the platform (many, including Google, prohibit incentives).

## Sponsored content and influencers

- Clearly disclose paid partnerships, free products or affiliate links in the content itself ("Ad", "Paid partnership with…"), at the start, in the platform's disclosure tool where one exists.
- The business is responsible for what creators say about it in sponsored content.

## Claims

- Every factual claim (numbers, "fastest", "#1", "guaranteed") needs evidence on file before publishing.
- Regulated claims (health outcomes, financial returns, legal outcomes, employment or income claims) go to the owner, and usually their adviser, before use.
- Comparisons with competitors must be accurate, verifiable and fair.

## Checklist

- [ ] Every testimonial and case study has permission recorded for this channel.
- [ ] No AI-written or invented reviews or quotes.
- [ ] Incentives (if any) are disclosed, not conditional on sentiment, and allowed by the platform.
- [ ] Sponsored content is labelled at the start.
- [ ] Each claim has evidence; regulated claims flagged.
