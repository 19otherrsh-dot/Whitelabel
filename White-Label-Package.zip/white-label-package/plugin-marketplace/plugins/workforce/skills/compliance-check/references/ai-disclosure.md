# AI disclosure and generated media

Checked: October 2026. A practical summary, not legal advice.

## EU AI Act, Article 50 (transparency)

Applies from **2 August 2026**:

- **Talking to an AI**: systems that interact directly with people (chat assistants, voice agents) must tell people they are interacting with an AI, unless that is obvious from the context. Put it at the start of the conversation: `workspace.json → disclosure.chatbotDisclosure`.
- **Deepfakes**: deployers who publish AI-generated or manipulated images, audio or video that resemble real people, places or events must disclose that the content is artificially generated or manipulated. Lighter treatment applies to evidently artistic, satirical or fictional work, but disclosure is still expected in a way that doesn't spoil the work.
- **AI-generated text on matters of public interest** published to inform the public must be disclosed as AI-generated unless it was human-reviewed and a person holds editorial responsibility.
- **Machine-readable marking** of AI outputs is the duty of the model/system providers; providers whose systems were on the market before 2 August 2026 have until 2 December 2026. When the business uses a generator, keep the provider's watermark/metadata intact and don't strip content credentials.

The Digital Omnibus agreed in 2026 delayed several high-risk-system obligations but did not postpone the chatbot or deepfake disclosure duties.

## United States

- No single federal AI-disclosure law, but the FTC treats misleading people about whether they're dealing with a human, or using AI to fake reviews, endorsements or likenesses, as deception.
- Some states have bot-disclosure laws (e.g. California's law on bots used to sell or influence) and AI rules for regulated professions (e.g. Utah). Safe default: disclose AI in customer-facing chat and voice everywhere.
- Synthetic voice or likeness of a real person needs their written permission; several states protect name, image, voice and likeness.

## Platforms

Major platforms (YouTube, Meta, TikTok, LinkedIn) require labelling realistic AI-generated or altered content and may label it automatically from content credentials. Follow each platform's current policy when publishing.

## Checklist

- [ ] Chat and voice assistants disclose they are AI at the start, in the user's language.
- [ ] People can reach a human, and are told how.
- [ ] Realistic generated or altered images, audio and video are labelled where `disclosure.markGeneratedMedia` is true, the law applies, or the platform requires it.
- [ ] No synthetic likeness or voice of a real person without written permission on file.
- [ ] Generator watermarks and content credentials are left intact.
