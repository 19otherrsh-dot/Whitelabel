# Outbound email and direct messages

Checked: October 2026. A practical summary, not legal advice. Where a rule differs by country, apply the strictest one that could cover the recipient.

## Every commercial email, everywhere

- [ ] **Truthful sender**: the From name and address identify the real person or business. No look-alike domains of other brands.
- [ ] **Honest subject line** that reflects the content. No "Re:" or "Fwd:" on a first message.
- [ ] **Identifies the sender** in the body: business name (`compliance.outbound.senderLegalName`).
- [ ] **Postal address** of the sender (`compliance.outbound.physicalAddress`). Required in the US for commercial email; good practice everywhere.
- [ ] **Easy opt-out** in every marketing email (`compliance.outbound.unsubscribeLine` or a link), honoured promptly and recorded in the suppression list. For bulk senders, mailbox providers also expect one-click unsubscribe headers.
- [ ] **No one on the suppression list**, including domain-level entries.
- [ ] **Content is honest**: no fake urgency, invented results, or claims the business can't substantiate.

## United States (CAN-SPAM)

Applies to commercial email to anyone, including businesses. Consent is not required, but: no deceptive headers or subject lines; identify the message as an ad where it is one (unless the recipient opted in); include a valid physical postal address; provide an opt-out that works for at least 30 days after sending and honour requests within 10 business days; don't sell or transfer opted-out addresses. Penalties are per email and run to tens of thousands of dollars (adjusted for inflation annually), and the business remains responsible when an agency or tool sends for it.

## European Union (GDPR + ePrivacy rules, set per country)

- You need a **lawful basis** under GDPR for using the person's data (often legitimate interests for B2B, which requires a documented balancing test, a relevant message and an easy objection route) **and** you must meet the national ePrivacy rule for electronic marketing.
- National rules differ for **cold B2B email**: some countries allow it to professional addresses when relevant to the recipient's role with an opt-out (e.g. France); others require prior consent even for B2B (e.g. Germany). Email to **consumers** generally needs prior consent, except the "soft opt-in" for existing customers about similar products, with an opt-out each time.
- Tell people where you got their data and how to object (a short privacy line and link) — GDPR's transparency duty applies even when the data came from a third party.
- If the country is unknown or strict, result is FIX: "confirm recipients' countries and the national rule".

## United Kingdom (UK GDPR + PECR)

- **Corporate subscribers** (limited companies, LLPs, public bodies): unsolicited marketing email is allowed without prior consent if you identify yourself and offer an opt-out, and you still need a UK GDPR lawful basis for the personal data.
- **Individuals, sole traders and some partnerships**: need prior consent, or the soft opt-in (existing customer, similar products, opt-out offered at collection and every time).
- The Data (Use and Access) Act 2025 raised maximum PECR fines to UK GDPR levels and extended the soft opt-in to charities; check the ICO's current guidance for what is in force.

## Canada (CASL)

Commercial electronic messages need **consent** (express, or implied in limited cases: an existing business relationship within the time limits; or the address was conspicuously published, without a "no unsolicited messages" statement, and the message relates to the person's role). Every message must identify the sender with contact details and include an unsubscribe mechanism honoured within 10 business days. If implied consent can't be shown for each contact, BLOCK for Canadian recipients.

## Australia (Spam Act)

Needs consent (express, or inferred, e.g. a conspicuously published business address where the message is relevant to the role and there's no statement refusing marketing), accurate sender identification and a functional unsubscribe honoured within 5 business days.

## LinkedIn and other platform messages

- Follow the platform's terms: no automation the platform prohibits, no fake profiles, respect connection and message limits. Breaches risk the owner's account, which is a business asset.
- The same honesty rules apply: real sender, no misleading claims, stop when asked.

## Deliverability guardrails (not law, but they protect the business)

- Ramp volume gradually; keep bounces under ~2% and spam complaints well under 0.3% (aim for under 0.1%).
- Authenticate sending domains (SPF, DKIM, DMARC) and send cold outreach from a separate domain from the main business domain.
- Never use tricks to evade filters (hidden text, rotating look-alike domains to escape blocks).
