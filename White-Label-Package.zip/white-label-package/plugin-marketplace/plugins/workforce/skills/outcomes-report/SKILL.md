---
name: outcomes-report
description: >-
  Writes the monthly outcomes report: what the AI workforce actually did, hours saved from logged estimates,
  value at the owner's hourly rate, AI cost, approval rates, results by department and against the audit baseline,
  with every number traceable. Use at month end (scheduled), for investor or client updates about the workforce,
  or when the owner asks "is this worth it", "what's the ROI", "how much time has this saved", "show results".
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: workforce
  jobs: [Outcomes Report]
  capabilities: []
  version: 1.0.0
---

# Outcomes report

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

This is the honest scorecard. It counts only what the records show: jobs in the run ledger, items in the outbox, costs from headless runs, and the hours agents estimated per run (which the owner can audit). It never extrapolates a good week into a year or presents an estimate as a measurement.

## Read first

- `references/playbook.md`: templates, a worked example and the edge cases for this job. Read it before your first run.
- `workspace.json → valuation` (hourly rate, audit baseline) and `knowledge/goals.md`.
- Last month's report in `output/back-office/outcomes-report/` for comparison.
- `docs/data-model.md` for the collections that hold business results.

## Steps

1. Generate the numbers:
   ```
   node bin/wf.mjs outcomes --month <YYYY-MM> --json
   ```
   This also writes `output/back-office/outcomes-report/<month>-outcomes.md` and `.json` with the standard tables.
2. Check the estimates. Open the runs with the largest `minutesSaved` (`node bin/wf.mjs runs --days 31 --json`) and sanity-check five of them: is the estimate plausible for what the run did? If one looks inflated, say so in the commentary and show the total with and without it. The owner can correct an estimate by logging a correction run note; never edit the ledger.
3. Add business results where the data exists and the link is fair: meetings booked from campaigns the workforce ran, invoices collected after reminders, tickets answered from docs. Attribute only with evidence (an outbox item id, a campaign id); otherwise describe as "associated with".
4. Write a commentary of up to 200 words at the top of the generated markdown file: the headline, what improved, what didn't, the one change recommended for next month.
5. For an external audience (investors, a client): produce a copy in `output/back-office/outcomes-report/<month>-outcomes-external.md` that removes customer names, internal costs if the owner asks, and anything confidential. Ask the reviewer subagent to check it.

## Guardrails

- Never edit the run ledger or outbox records; corrections are new log entries.
- Hours saved are always labelled "logged estimates" with the share of runs that carried an estimate.
- Show AI cost next to value. Note that interactive sessions are covered by the owner's Claude plan and aren't metered.
- Compare with the audit baseline (`valuation.auditEstimate`) when it exists, as "estimated vs measured".
- No trend lines from fewer than three months of data.

## Quality checklist

- [ ] All numbers match the `wf outcomes --json` output or cite another record.
- [ ] Five large estimates were spot-checked.
- [ ] Attribution claims have ids as evidence.
- [ ] The external version (if made) passed the reviewer.

## Record the run

```
node bin/wf.mjs log --skill outcomes-report --job "Outcomes Report" --status done --summary "<month>: <runs> runs, <h> h saved (logged), <value>, cost <cost>" --output output/back-office/outcomes-report/<month>-outcomes.md
```
