# Playbook · Outcomes report

`SKILL.md` has the steps; `node bin/wf.mjs outcomes` produces the standard tables. This file has the
estimate-check sheet, attribution language and a commentary example. Every figure comes from the records.

## Estimate-check sheet (five biggest `minutesSaved` runs)

| Run | Job | Estimate | What it did | Plausible? | Note |
|---|---|---|---|---|---|
| r-1042 | Company Deep-Dive | 90 min | 12-source brief with fit analysis | yes | |
| r-1077 | Data Migration | 600 min | migrated 4,120 records with reconciliation | partly | a person also spent ~3 h; show total with and without |

## Attribution language

| Evidence | Wording |
|---|---|
| Outbox item id → reply → meeting in CRM with the same campaign id | "booked from" |
| Reminder sent, invoice paid within 7 days | "paid after a reminder" |
| Timing overlap only | "associated with" |
| No link | not claimed |

## Commentary example (≤ 200 words, fictional)

```text
October: 214 jobs ran, an estimated 61 hours saved (58 without one generous migration estimate), at
$41 in model costs. Approvals averaged 6 hours; 9% of items were rejected, mostly cold emails (tone).
Six meetings were booked from workforce-run campaigns (CRM-linked); £7,950 was paid within a week of
reminders. What didn't improve: reply rate on the dental segment stayed at 1.1%. One change for
November: rework the dental opening line and test it against the current one.
```

## External copy

Remove customer names (or use "a UK dental group"), internal costs if the owner asks, anything marked
confidential; keep the method notes; reviewer checks before sharing.

## Log

```
node bin/wf.mjs log --skill outcomes-report --job "Outcomes Report" --status done --summary "<month>: <hours> h saved, $<cost>" --minutes-saved 60
```
