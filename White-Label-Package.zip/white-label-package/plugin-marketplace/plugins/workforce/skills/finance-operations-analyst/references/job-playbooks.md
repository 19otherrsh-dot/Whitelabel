# Job playbooks · Finance operations analyst

The detail behind each job in `SKILL.md`, alongside `forecast-method.md`. Figures are estimates for the
owner's planning, not accounting or tax advice.

---

## Cash-Flow Forecasting

**Table layout** (13 columns, one per week; three cases below):

| Line | W1 | W2 | … | W13 |
|---|---|---|---|---|
| Opening balance | 18,400 | … | | |
| Invoices expected (adjusted for lateness) | 3,960 | … | | |
| Recurring revenue | 2,400 | … | | |
| Pipeline (weighted, separate) | — | … | | |
| Payroll | −7,800 | … | | |
| Contractors · rent · software · tax · loans · one-offs | … | | | |
| **Closing balance** | | | | |

**Top-of-report summary:**

```markdown
Lowest balance: base £6,200 (W7) · downside £1,100 (W7) · upside £9,800 (W5)
Minimum buffer (goals.md): £5,000 → downside breaks it in W6–W8
Why: VAT payment W7 (£5,400) + INV-1031 (£1,800) likely 20 days late
Actions: chase INV-1031 now (billing-manager) · move the laptop purchase to W9 · ask the client on
payment plan to keep the W6 instalment
Last forecast accuracy: 4-week error 6% (inflows late by ~9 days on average → method adjusted)
```

---

## Budget Tracking

**Monthly table:**

| Category | Budget | Actual to date | Run-rate to month end | Status |
|---|---|---|---|---|
| Software | 600 | 540 | 690 | over by ~90 |
| Contractors | 3,000 | 1,900 | 2,900 | on track |
| Ads | 1,500 | 1,520 | 1,520 (paused) | at budget |

**Subscription watch:** new recurring charges this month, duplicates (two tools doing one job, or two
seats for one person), annual renewals in the next 60 days with the amount, each with a suggested
action for the owner. Cancelling anything is the owner's decision.

---

## Log each job

```
node bin/wf.mjs log --skill finance-operations-analyst --job "Cash-Flow Forecasting" --status done --summary "Low point base £<n> (W<n>), downside £<n>" --minutes-saved 90
node bin/wf.mjs log --skill finance-operations-analyst --job "Budget Tracking" --status done --summary "<month>: <n> categories over, <n> new subscriptions" --minutes-saved 40
```
