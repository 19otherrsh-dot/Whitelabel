# 13-week cash forecast method

## Table layout

| Week (start) | Opening | Invoices due (expected) | Recurring in | Pipeline (weighted, optional) | Payroll | Contractors | Rent & fixed | Software | Tax | Other | Closing |
|---|---|---|---|---|---|---|---|---|---|---|---|

Closing = Opening + inflows − outflows. The next week's opening is this week's closing.

## Expected payment date per invoice

```
client_delay = median(days paid after due date) over the client's last 6 paid invoices (0 if none)
expected     = due_date + client_delay   (downside: + 30 days)
```

Invoices already 60+ days overdue: exclude from base, show in a "doubtful" note.

## Variable costs

Average of the last 3 complete months per category. Seasonality: if the same month last year was ±20% different, mention it.

## Accuracy

```
error_week = forecast_closing − actual_closing
MAPE (4 weeks) = mean(|error| / actual) × 100%
```

Report it; if over 15%, say which line caused most of the error.

## What to tell the owner (top of the report)

1. Lowest balance in base and downside, and the week.
2. The two biggest risks (e.g. a single client's late payment, a tax bill).
3. Up to three actions with their effect (e.g. "chasing invoices 1042 and 1047 now moves the low point from −2,100 to +6,400").
