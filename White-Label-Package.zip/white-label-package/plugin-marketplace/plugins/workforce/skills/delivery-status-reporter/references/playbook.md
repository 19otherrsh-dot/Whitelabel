# Playbook · Delivery status reporter

`SKILL.md` has the steps. This file has the health rules, update templates for each health, and the
internal digest layout.

## Health rules

| Health | When |
|---|---|
| Green | every milestone on its date; no blocker older than 2 working days |
| Amber | a dependency late, slippage under a week, a client input overdue, or a risk without a plan yet |
| Red | a client-facing milestone will be missed, a scope or budget problem, or the client is unhappy |

Move to amber early; never jump from green to red between two updates if the warning signs were visible.

## Client update · green (≤ 200 words)

```text
Subject: <project> · update <date>

Done: … (2–4 items, specific)
Next: … by <date>; … by <date>
Needed from you: <item> by <date> (so we can <reason>) | nothing this week
Anything changing: nothing
```

## Client update · amber or red (lead with it)

```text
Subject: <project> · <milestone> date change, and our plan

The <milestone> will now land on <new date> instead of <old date>, because <honest reason>.
What we're doing: <plan, 1–2 lines>. What it affects: <later dates or nothing>.
What would help: <client action by date>.
Done this week: … · Next: …
```

Amber/red updates are flagged for the account lead to review personally before they're queued.

## Internal digest

| Project | Health | Change | Next milestone | Blocker | Needs the owner |
|---|---|---|---|---|---|
| Bright Harbor · retainer | amber ↓ | ad access 4 days late | first campaign live 12 Nov | ad account access | call their director? |

## Log

```
node bin/wf.mjs log --skill delivery-status-reporter --job "Status Updates" --status queued --summary "<n> updates queued: <g> green, <a> amber, <r> red" --minutes-saved 45
```
