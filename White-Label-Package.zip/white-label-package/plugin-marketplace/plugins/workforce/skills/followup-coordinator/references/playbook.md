# Playbook · Follow-up coordinator

`SKILL.md` has the steps. This file has the recap template, the chase ladder and a worked example.

## Recap template (sent within one working day)

```text
Subject: <meeting> · recap and next steps

Thanks for today. What we agreed:
Decisions
• <decision> (<who decided>)
Actions
| Who | What | By |
| <name> | … | <date> |
| <name> | … | to confirm |
Open questions: …
Next meeting: <date, time, time zone> | to schedule
```

Items marked "to confirm" are raised in the recap so nobody assumes.

## Chase ladder

| Overdue by | Our item | Client item |
|---|---|---|
| 1 working day | reminder to the owner of the task | — |
| 3 working days | flagged in the internal digest | gentle nudge in the next update |
| 5+ working days | to the account lead | short direct note (queued), with what it's blocking |

## Worked example

A 40-minute client check-in: 2 decisions (move the launch a week; use the new logo), 5 actions (3 ours, 2
theirs), one item outside the SOW ("also do the Spanish version") → flagged to the account lead and
contracts-coordinator for a change order, not added as a task. Recap queued; 3 tasks created in the PM
tool; client items tracked in the project record.

## Log

```
node bin/wf.mjs log --skill followup-coordinator --job "Meeting Follow-Ups" --status queued --summary "<meeting>: recap + <n> actions" --minutes-saved 25
```
