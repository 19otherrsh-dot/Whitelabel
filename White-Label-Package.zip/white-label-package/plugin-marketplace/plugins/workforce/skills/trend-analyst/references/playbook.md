# Playbook · Trend analyst

`SKILL.md` has the steps. This file has the verification test, the fit check, the trend record and a
worked example.

## Is it a trend? (label it)

| Label | Evidence |
|---|---|
| Rising | 3+ independent mentions over 3+ days, growing discussion or search interest, ICP talking about it |
| Peaking | everyone covered it this week; late angles need something new |
| Evergreen-recurring | returns every year or season (tax deadlines, January planning) |
| Noise | one viral post, one source, or not relevant to the ICP |

## Fit check (all yes to keep)

- We have something true and useful to say (expertise, own data, a permitted client story).
- It fits the brand's pillars and voice.
- It's safe: not tragedy-adjacent, not divisive without a clear reason the owner agrees with.

## Trend record

```markdown
## <Trend> · <label> · window: <48 h | this week | evergreen>
Evidence: <link, date> · <link, date> · <link, date>
Why it matters to our ICP: …
Angles:
1. <angle> · format: <post / carousel / video / newsletter> · uses: <our data / story>
2. …
Score: <1–5> (timeliness × fit × evidence)
```

## Worked example

A regulator announces new patient-communication guidance (official page, 2 trade outlets, forum threads
over 4 days) → rising, window "this week". Fit: yes (the business helps clinics reply to patients).
Angles: "What the new guidance means for missed-call texts" (carousel); "3 questions to ask your provider"
(newsletter section). Saved to ideas with the links.

## Log

```
node bin/wf.mjs log --skill trend-analyst --job "Trend Monitoring" --status done --summary "<n> trends kept, <n> angles" --minutes-saved 45
```
