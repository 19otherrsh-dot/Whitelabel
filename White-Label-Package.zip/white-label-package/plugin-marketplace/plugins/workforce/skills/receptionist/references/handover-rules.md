# Handover rules

Hand over to a person immediately when any of these is true:

1. The enquirer asks for a person.
2. Complaint, anger, or a threat to leave or to review badly.
3. Anything about money already paid or owed: refunds, billing disputes, failed payments.
4. Legal, regulatory, safety, health or emergency topics.
5. The enquirer seems distressed or vulnerable.
6. Two questions in a row the knowledge base can't answer.
7. A high-value lead (matches segment 1 in customers.md and has budget or urgency).
8. Anything involving personal data requests (access, deletion).

## How

- **Who**: from `knowledge/team.md → Escalation` (urgent customer issue / money / legal / technical).
- **Channel**: team chat message if chat is connected, otherwise an email to the owner, queued as a `message`/`email` outbox item marked urgent in the title. If a job is autonomous for Front Desk alerts, the guard allows the internal alert.
- **Content**: one line on who and what, the enquirer's details, the conversation transcript, what was promised and by when.
- **Tell the enquirer**: who will reply, by which channel, and the expected time from `policies.md`. Never promise a time the policy doesn't support.
