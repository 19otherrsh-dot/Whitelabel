# Workforce audit — {{company}}

{{date}} · prepared by the workforce · estimates, not promises

## In one paragraph

{{The team spends about X hours a week on repeat work. About Y of those (Z%) can move to agents within 90 days, worth roughly V a month at R per hour. Start with DEPARTMENT because … The first job is JOB.}}

## Where the hours go today

| Person | Recurring work (hours/week) | Biggest items |
|---|---|---|
| {{name/role}} | {{h}} | {{top 3 tasks}} |

## Ranked opportunities

| # | Job (department) | Hours/week now | Share | Recoverable h/week | Value/month | Readiness | Risk |
|---|---|---|---|---|---|---|---|
| 1 | {{job}} ({{dept}}) | {{h}} | {{share}} | {{rh}} | {{v}} | {{0–3}} | {{low/med/high}} |

Total recoverable: {{total}} h/week {{(capped at 35% of paid hours: yes/no)}}.

## Start here: {{department}}

Why: {{value, readiness, foundation job, link to the top goal}}.

Jobs, in order:
1. {{job}} — needs {{inputs/connector}}; the human {{human role}}.
2. …

## 30-day plan

| Week | What runs | Owner's part | Done when |
|---|---|---|---|
| 1 | {{foundation job; connector setup}} | {{approve knowledge, connect tool}} | {{first output reviewed}} |
| 2 | {{next jobs as drafts}} | {{review drafts daily, 10 min}} | {{n drafts approved without big edits}} |
| 3 | {{schedule the routine}} | {{approve outbox items}} | {{autopilot running, no failures}} |
| 4 | {{measure; pick the next department}} | {{read outcomes report}} | {{hours saved measured vs this audit}} |

## Work that has no job yet

{{tasks that didn't map, with a one-line skill idea each}}

## Assumptions and what would change this

- Hourly rate {{R}} from {{source}}.
- Shares from the map levels (autonomous 0.7, assisted 0.45, manual 0.2), adjusted for {{…}}.
- Inventory sources: {{calendar 4 weeks, email counts, interviews with …}}.
- {{Would change if …}}
