# Scoring model

The same model the public audit quiz uses, applied to real numbers instead of averages.

## Inputs per job

| Input | Source |
|---|---|
| `hours` – hours per week spent today | Inventory (sum of mapped tasks: frequency × minutes ÷ 60) |
| `level` – map level | `departments/<id>.json → jobs[].level` |
| `rate` – loaded hourly cost | `workspace.json → valuation.hourlyRate` (owner may give per-person rates) |

## Automatable share

| Map level | Base share | Meaning |
|---|---|---|
| autonomous | 0.70 | Agents can do nearly all of it; a human checks outcomes |
| assisted | 0.45 | Agents draft and prepare; a human decides or finishes |
| manual | 0.20 | Agents support; the human does the core work |

Adjust down by 0.1–0.2 when the business's version needs unusual judgement (bespoke technical scoping, sensitive relationships). Never adjust up.

## Formulas

```
recoverable_hours_job = hours × share
total_recoverable     = min( Σ recoverable_hours_job , 0.35 × team_paid_hours_per_week )
value_per_month       = total_recoverable × 4.33 × rate
```

If the cap applies, scale each job's recoverable hours proportionally and say so.

## Readiness (0–3, one point each)

1. **Knowledge**: the knowledge files the job reads have no blocking TODOs.
2. **Data**: the inputs exist (e.g. CRM has deals; invoices exist in accounting).
3. **Connection**: the stack slot the job needs is connected, or the job works well from files.

Subtract one if any `requires` job has never run successfully.

## Risk

- **Low**: output stays internal (reports, research, drafts).
- **Medium**: output goes to customers after approval (emails, proposals, posts).
- **High**: money, legal, mass outreach, deletion, or anything hard to undo.

## Priority

Rank by `value_per_month × (readiness / 3)`, then break ties by lower risk. Present the top 10.
