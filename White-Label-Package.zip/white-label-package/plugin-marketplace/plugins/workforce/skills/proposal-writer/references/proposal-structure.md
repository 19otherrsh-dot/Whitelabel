# Proposal structure

1. **Cover**: "{{Outcome}} for {{Client}}" · prepared for {{name, role}} · {{date}} · valid until {{date}}
2. **Where you are** (½ page): their situation, in their words. "You told us…" Quote 2–3 lines from the call.
3. **Where you want to be**: the outcome and how we'll both know it's achieved.
4. **How we'll get there**: 2–4 phases. For each: what happens, what you get, how long.
5. **What's included / not included**: two short lists. Assumptions and what we need from you.
6. **Timeline**: a simple table of phases and weeks.
7. **Investment**: options table (what's in each, price, payment terms). Recommend one and say why in one sentence.
8. **Why us**: one or two relevant proof stories (with permission), and the one difference that matters to them.
9. **Next steps**: 1) reply "yes" to {{option}} / sign here, 2) kickoff on {{date}}, 3) what week one looks like.
10. **Terms**: refer to the agreement; payment terms; validity.

Keep it under 6 pages. Their name appears more often than ours.
