# Playbook · Solutions engineer

`SKILL.md` has the steps. This file has the format choice, the README and talk-track templates, and a
worked example.

## Format choice

| Their "aha" is about… | Fastest convincing format |
|---|---|
| seeing their numbers | dashboard on sample data shaped like theirs |
| a smoother workflow | before/after diagram, or a clickable HTML mockup |
| "can it really do X?" | a short script or automation run on sample inputs |
| a complex process | an annotated walkthrough document |

## README template (`output/deals/demo-prototyping/<client>/README.md`)

```markdown
# Demo for <client> · <date>
Shows: <the aha in one sentence>
Open: double-click demo.html (no internet needed)
Real: <what works as the delivered product would>
Illustrative: <what's mocked: sample data, fixed responses>
Full solution adds: <what delivery would build next>
Data: sample data shaped like theirs; no other client's data
```

## Talk track (5 minutes)

```text
0:00 Their problem, in their words: "<quote from the call>"
0:45 The demo: <the 2–3 clicks that show the aha>
3:00 What changes for them: <time, money, effort, with their numbers>
4:00 What's real vs illustrative (say it plainly)
4:30 Next step: <the proposal / a pilot / a second call with their colleague>
```

## Worked example

Discovery: a dental group's practice manager can't see missed calls across sites. Aha: "When they see
yesterday's missed calls per site and which were won back, they'll know we understand the
multi-site problem." Format: single-file HTML dashboard on 30 days of sample data shaped like their call
volumes. README states what's illustrative. Shared after approval as `file-share`.

## Log

```
node bin/wf.mjs log --skill solutions-engineer --job "Demo Prototyping" --status queued --summary "<client>: <format> demo ready" --minutes-saved 180
```
