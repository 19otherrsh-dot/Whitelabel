# Playbook · Social prospecting specialist

`SKILL.md` has the steps. This file has the source ranking, the ICP filter, the lead record and a worked
funnel. Permitted collection only: the platform's exports, approved tools, or the owner's own export.

## Source ranking (warmest first)

1. People who commented on or messaged about the owner's own posts.
2. The owner's followers who match the ICP.
3. Attendees of the business's own events (with the notice they were given at sign-up).
4. Commenters on industry voices' posts about the problem.
5. Members of relevant public groups who posted about the problem.

## ICP filter

| Keep | Drop |
|---|---|
| role in the ICP (e.g. practice manager, ops lead) | students, job seekers |
| company size and industry in range | competitors, vendors, agencies (unless they're the target) |
| region served | people on the suppression list |
| engaged with the problem, not just the creator | engagement that's criticism of the topic |

## Lead record

```json
{ "id": "soc-0193", "name": "Jo Patel", "title": "Practice Manager", "company": "Harbor Dental Group",
  "source": "social:linkedin:post-2026-10-12", "context": "commented: 'evenings are the worst for this'",
  "contextLink": "<post link>", "contextDate": "2026-10-12" }
```

Only what's needed for a relevant opener; no personal details beyond their professional profile.

## Worked funnel

A post on missed calls: 140 engaged → 38 fit the ICP → 31 recorded (7 already in the CRM, merged) →
handed to linkedin-outreach-specialist with the context lines.

## Log

```
node bin/wf.mjs log --skill social-prospecting-specialist --job "Social Mining" --status done --summary "<source>: <engaged> → <fit> → <recorded>" --minutes-saved 45
```
