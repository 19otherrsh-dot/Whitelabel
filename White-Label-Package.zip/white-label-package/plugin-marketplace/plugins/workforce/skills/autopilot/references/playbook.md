# Playbook · Autopilot

`SKILL.md` has the commands. This file has a starter timetable, how to explain cost, a worked example,
and what to do when runs go wrong.

## Starter timetable (adjust with the owner)

| Name | When | Skill · job | Tier | Budget/run |
|---|---|---|---|---|
| morning-agenda | weekdays 07:30 | executive-assistant · Calendar Management | drafting | $0.40 |
| inbox-triage | weekdays 08:00, 13:00 | inbound-response-manager · Inbox Triage | routine | $0.25 |
| overdue-invoices | Mondays 09:00 | billing-manager · Collections | drafting | $0.40 |
| weekly-review | Fridays 16:00 | weekly-review · Weekly Review | reasoning | $1.00 |
| knowledge-refresh | Fridays 15:00 | company-knowledge-base · Context Maintenance | drafting | $0.50 |
| cash-forecast | 1st of month 09:00 | finance-operations-analyst · Cash-Flow Forecasting | reasoning | $1.00 |

Monthly cost estimate = Σ (runs per month × budget). For the table: ≈ 22×0.40 + 44×0.25 + 4×0.40 +
4×1.00 + 4×0.50 + 1×1.00 ≈ **$28/month at most** (budgets are ceilings; most runs cost less). Show this
sum to the owner with the cap from `budgets.monthlyUsd`.

## Worked example

Owner: "Every Monday morning, chase anything more than two weeks overdue."

```
node bin/wf.mjs autopilot add --name overdue-invoices --cron "0 9 * * 1" --skill billing-manager \
  --job "Collections" --prompt "Only invoices more than 14 days overdue; skip clients with a dispute or payment plan" \
  --model drafting --budget-usd 0.40
node bin/wf.mjs autopilot run overdue-invoices
```

Test result shown to the owner: "3 reminders drafted and waiting for your approval; cost $0.18. From now
on this runs Mondays 09:00 (Europe/London), about $1.60 a month at most."

## When runs go wrong

| Symptom | Likely cause | Fix |
|---|---|---|
| Nothing ran overnight | computer asleep or timer missing | `autopilot list` → "Timer: installed"? ask the owner to run `autopilot install`; mention the hosted runtime |
| A run stopped early | budget ceiling reached | read the run record; raise the budget only with the owner, or narrow the prompt |
| Run "blocked" entries | the guard refused an external action | expected: the item is in the outbox; nothing to fix |
| Same item drafted twice | the job isn't checking what's already queued | add "skip anything already in outbox/pending" to the prompt; report to skill-builder |
| Runs in quiet hours | schedule time inside `quietHours` | move the schedule; quiet hours only hold notifications |

## Log

```
node bin/wf.mjs log --skill autopilot --job "Schedule Setup" --status done --summary "<name>: <when>, ~$<n>/month" --minutes-saved 10
```
