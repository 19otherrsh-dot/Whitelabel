---
name: autopilot
description: >-
  Puts recurring jobs on a schedule so the workforce runs without being asked: creates, changes, pauses and
  explains schedules, sets per-run budgets and quiet hours, installs the computer's timer, and reads what
  unattended runs did. Use when the owner says "do this every Monday", "run this daily", "set up my weekly
  routine", "automate this", "schedule", "stop running X", "what runs automatically", "pause everything", or after
  a department is set up.
license: Proprietary. See LICENSE.md in the workspace root.
metadata:
  department: workforce
  jobs: [Schedule Setup]
  capabilities: []
  version: 1.0.0
---

# Autopilot

> **Outside a workforce workspace?** This skill is written for a workspace that has `workspace.json`, a `knowledge/` folder and the `bin/wf.mjs` tool. If they are missing here: ask the owner for the facts the knowledge files would hold (company, offer, customers, voice) before producing anything, save outputs in the current folder, queue nothing (show the owner what you would send and let them send it), and skip the "Record the run" step.

Autopilot runs jobs on a timetable in unattended Claude Code sessions. One timer on the owner's computer calls `node bin/wf.mjs autopilot tick` every five minutes; the tick runs whatever is due in `autopilot/schedules.json`, sends approved outbox items, and notifies the owner of new approvals. Unattended runs can draft, research, analyse and queue, but every external action waits for approval unless the job is explicitly autonomous; the approval guard enforces this.

## Read first

- `references/playbook.md`: templates, a worked example and the edge cases for this job. Read it before your first run.
- `workspace.json` (time zone, budgets, quiet hours, autonomy, `autopilot` settings).
- `departments/*.json → suggestedSchedules` for sensible defaults.
- `node bin/wf.mjs autopilot list --json` for what exists.

## Create or change a schedule

1. **Agree the rhythm** in plain words ("weekdays at 7:30", "every other Friday" is not possible in cron, so use "Fridays" and say so). Times are in `company.timezone`.
2. **Choose the skill and job** (exact job name from the map), and a one-line prompt with anything specific ("only clients with invoices over 14 days overdue").
3. **Pick the model tier**: `routine` for sorting, tagging and monitoring; `drafting` for writing; `reasoning` for strategy and analysis. Use the cheapest tier that does the job well.
4. **Set a budget** per run (`--budget-usd`) that fits `budgets.perRunUsd` and the monthly cap; estimate monthly cost = runs per month × budget, and tell the owner.
5. **Create it:**
   ```
   node bin/wf.mjs autopilot add --name <kebab-name> --cron "<m h dom mon dow>" --skill <skill> --job "<Job>" --prompt "<specifics>" --model <routine|drafting|reasoning> --budget-usd <n>
   ```
   Cron help: `30 7 * * 1-5` weekdays 07:30 · `0 8 * * 1` Mondays 08:00 · `0 9 1 * *` 1st of month 09:00 · `0 */4 * * *` every 4 hours · `0 9 * * 1,4` Mon and Thu 09:00.
6. **Test it once now:** `node bin/wf.mjs autopilot run <name>` and show the owner the result and cost.
7. **Make sure the timer is installed:** check `node bin/wf.mjs autopilot list` (it says "Timer: installed"). If not, ask the owner to run `node bin/wf.mjs autopilot install` themselves; it registers a launchd agent (Mac), a scheduled task (Windows) or a crontab line (Linux). The computer must be on and awake at run time; runs missed while it was off catch up once on the next tick (at most a day back).

## Explain or adjust

- "What runs automatically?" → `autopilot list`, translated into a plain table (name, when, job, last result, next run).
- Pause one: `autopilot disable <name>`. Remove: `autopilot rm <name>`. Pause everything: ask the owner to run `node bin/wf.mjs autopilot pause` (resume with `resume`).
- "What did autopilot do?" → `node bin/wf.mjs runs --days 7 --json` filtered to `source: autopilot`, plus `output/autopilot/needs-attention.md`.
- Notifications: if the owner wants phone or chat alerts for new approvals, set `autopilot.notifyChannel` (`ntfy`, `slack` or `teams`) and have the owner store the webhook or topic URL with `node bin/wf.mjs secrets set WF_NOTIFY_URL`, then `node bin/wf.mjs notify "test"`.

## Always-on alternative

If the owner's computer isn't on reliably, the workspace can run on a small server or in the hosted runtime (see `docs/hosted-runtime.md`). The schedules file is the same.

## Guardrails

- Never schedule a job whose prerequisites haven't run successfully, or a job that ends in external actions without telling the owner they will be queued (or, if autonomous, done).
- Respect quiet hours and the monthly budget; never raise budgets yourself.
- Never install or uninstall the timer, or pause/resume, on the owner's behalf in an unattended run.

## Quality checklist

- [ ] Each schedule has a clear name, the exact job, a model tier and a budget.
- [ ] The owner heard the rhythm in plain words and the estimated monthly cost.
- [ ] A test run succeeded.
- [ ] The timer is installed (or the owner was told how).

## Record the run

```
node bin/wf.mjs log --skill autopilot --job "Schedule Setup" --status done --summary "<n> schedules: <names>; est. <cost>/month"
```
