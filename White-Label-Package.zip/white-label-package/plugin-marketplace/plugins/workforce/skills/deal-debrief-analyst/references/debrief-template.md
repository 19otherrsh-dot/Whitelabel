# Debrief — {{company}} · {{date}} · {{call type}}

**In one line:** {{where the deal stands after this call}}
**Next step:** {{what}} · **Owner:** {{who}} · **By:** {{date}}

## What they said
- Goal: "{{quote}}" ({{timestamp}})
- Pain: "{{quote}}" ({{timestamp}})
- Current approach: {{…}}
- Decision process: {{who decides, who else, how}} ({{timestamp}})
- Budget: {{stated / range / unknown}} ({{timestamp}})
- Timeline: {{…}} ({{timestamp}})

## Objections
| Objection (their words) | Our response | Landed? |
|---|---|---|

## Commitments
- We: {{…}} by {{date}}
- They: {{…}} by {{date}}

## Assessment
- Stage: {{from → to}} because {{evidence}}
- Probability: {{%}} because {{…}}
- Risks / missing: {{…}}

## For the recap email
- {{bullets in their words}}
