# Job playbooks · Deal debrief analyst

The detail behind each job in `SKILL.md`, with `debrief-template.md` for the debrief itself. Only the
transcript and notes count as evidence: if it isn't in them, it's "unknown", not inferred.

---

## Post-Call Debrief

**Extraction checklist** (quote with a timestamp for each item found):

| Item | Look for |
|---|---|
| Goals and pains | "we're trying to…", "the problem is…", numbers they mention |
| Current solution | tools, people, agencies they use now; what they like and don't |
| Decision process | "I'd need to run it by…", sign-off, procurement, timing of decisions |
| Budget | ranges, "what does it usually cost", what they spend now |
| Timeline | events driving urgency (launch, hire, season, renewal of the current tool) |
| Objections | worries, pushback, "but…" |
| Commitments | ours ("I'll send…") and theirs ("I'll check with…"), each with a date |
| Next step | the agreed meeting/action and date; "none agreed" is a finding |

**Honest assessment:** stage by the business's definitions; probability; the single biggest risk; what's
missing to move to the next stage. If the call didn't advance the deal, say so.

**Worked example.** 32-minute discovery with *Harbor Learning*: pain "enrolment emails go out a week
late" (04:12); current: a part-time admin; decision: founder + ops lead (19:40); budget: "under £2k a
month" (24:05); timeline: spring cohort in March; objection: "we tried automation and it sounded robotic"
(27:30); next step: demo Thursday 10:00 with the ops lead. Stage: discovery → demo booked; probability
30%; risk: ops lead not yet engaged.

---

## Follow-Up Drafting

**Recap email (same day, under 180 words):**

```text
Subject: <their goal in a few words> · next steps

Hi <name>,

Thanks for the time today. What I heard:
• <their pain, in their words>
• <what matters to them>
• <a constraint: budget, timeline, people>

Agreed: <who does what by when>.
Next: <the meeting/step, date and time with time zone>.

<only the resources promised on the call>
<signature>
```

Anything ambiguous in the transcript is marked `[CHECK: …]` for the person who ran the call; the outbox
item can't be approved until those marks are resolved.

---

## Objection Library

**Entry format** (`output/deals/objection-library/library.md`):

```markdown
### "<objection in the prospect's words>"
Category: price | timing | trust | fit | authority | status quo · Seen: <n> times · Stages: <…>
Responses used and outcome:
- <response> → progressed (<deal>, <date>)
- <response> → stalled
Proposed best response (pending approval): <grounded in offers.md / proof.md>
```

**Monthly ranking:** frequency × impact (share of deals that stalled after the objection). The top 5
get proposed responses; approved ones move to the "approved" section that outbound-inbox-manager uses.

---

## Log each job

```
node bin/wf.mjs log --skill deal-debrief-analyst --job "Post-Call Debrief" --status done --summary "<company>: <stage>, next <step>" --minutes-saved 25
node bin/wf.mjs log --skill deal-debrief-analyst --job "Follow-Up Drafting" --status queued --summary "Recap to <company>" --minutes-saved 15
node bin/wf.mjs log --skill deal-debrief-analyst --job "Objection Library" --status done --summary "<n> objections added, <n> proposed responses" --minutes-saved 30
```
