# Playbook · Document extraction engineer

`SKILL.md` has the steps. This file has a schema example, the pilot accuracy sheet, and the review-queue
format.

## Schema example (supplier invoices)

```json
{
  "fields": [
    { "name": "supplier", "type": "string", "required": true, "where": "header, top left" },
    { "name": "invoiceNumber", "type": "string", "required": true, "validate": "unique per supplier" },
    { "name": "issueDate", "type": "date", "format": "YYYY-MM-DD", "required": true, "validate": "not in the future" },
    { "name": "currency", "type": "string", "format": "ISO 4217", "required": true },
    { "name": "subtotal", "type": "number", "required": true },
    { "name": "tax", "type": "number", "required": true },
    { "name": "total", "type": "number", "required": true, "validate": "total = subtotal + tax (±0.01)" },
    { "name": "vatNumber", "type": "string", "required": false, "validate": "GB + 9 or 12 digits" }
  ]
}
```

## Pilot accuracy sheet (10 documents)

| Field | Correct | Accuracy | Note |
|---|---|---|---|
| supplier | 10/10 | 100% | |
| invoiceNumber | 10/10 | 100% | |
| issueDate | 9/10 | 90% | US date format on one → parse by supplier country |
| total | 10/10 | 100% | |
| vatNumber | 7/10 | 70% | scans: OCR misses → optional field, review if absent |

Required fields must reach ≥ 98% before the full run; issueDate fixed and re-tested at 10/10.

## Review queue (`review.csv`)

| file | page | field | value | reason |
|---|---|---|---|---|
| inv-0412.pdf | 1 | total | 1,240.00 | subtotal + tax = 1,204.00 (validation failed) |
| inv-0419.pdf | 2 | issueDate | — | not found (low-quality scan) |

## Log

```
node bin/wf.mjs log --skill document-extraction-engineer --job "Document Extraction" --status done --summary "<n> documents: <n> extracted, <n> to review" --minutes-saved 120
```
