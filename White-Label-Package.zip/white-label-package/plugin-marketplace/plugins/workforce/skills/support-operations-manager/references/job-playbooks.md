# Job playbooks · Support operations manager

The detail behind each job in `SKILL.md`, with `triage-matrix.md` for priorities.

---

## Ticket Triage

**Needs:** new and unassigned tickets; accounts (plan, value, health); support promises in
`knowledge/policies.md`.

**Category cues:**

| Category | Typical words | Route |
|---|---|---|
| How-to | "how do I", "where is", "can I" | support-answerer |
| Bug | "error", "broken", "doesn't work", screenshot of an error | owner's product/ops contact, with steps to reproduce |
| Billing | "invoice", "charged", "receipt", "VAT" | support-answerer (documented) or billing owner (disputes) |
| Account / access | "log in", "password", "add a user" | support-answerer; security concerns → Escalations |
| Feature request | "it would be great if", "can you add" | logged to ideas; polite reply |
| Complaint | dissatisfaction without a specific bug | account owner; often Escalations |
| Cancellation | "cancel", "close my account", "switching" | customer-success-manager (save play) |

**Priority:** impact × urgency from the matrix, then +1 level for top-tier or high-risk accounts.

**Output:** `output/customer/ticket-triage/<date-time>-triage.md`

```markdown
# Triage · <date time>
SLA at risk: <n>  ·  New: <n>  ·  Escalated: <n>
## Near or past first-response promise
| Ticket | Customer (tier) | Waiting | Category | Priority | Assigned |
## New tickets
## Clusters (3+ similar in 24h)
```

**Worked example.** Ticket "invoice shows wrong VAT number" from a top-tier account, 5h old (promise
4h): category billing, priority high (+1 for tier), SLA past → top of the note; route to billing owner;
draft holding reply for approval.

---

## Escalations

**The message** (internal, to the named person in `team.md`):

```text
ESCALATION · <customer> (<plan>, <value>) · <one-line issue>
Why now: <rule that fired>
They want: <outcome in their words>
Done so far: <…>
Suggested next step: <…> by <deadline>
Ticket: <link or id>
```

**Rules that fire:** angry or threatening language; legal or regulator mention; data or security
concern; safety; negative message from a top-tier account; cancellation words; 3+ similar bug tickets
in 24h; past SLA. Note which rule fired: it makes the weekly report useful.

**After:** record the outcome on the ticket (`escalated: true`, `escalationOutcome`) when known.

---

## Macro Authoring

**Candidate:** a cluster of 5+ similar human replies in 30 days. Show the cluster (ticket ids) in the
proposal.

**Macro format:** `output/customer/macro-authoring/<slug>.md`

```markdown
# Macro · <name>
Use when: <the exact situation>
Don't use when: <close cases where it would be wrong>
Source: <policy section or help article>
---
Hi {{first_name}},
<answer first, in voice>
<one line for anything specific to their plan: {{plan}}>
<next step or link>
<signature>
```

**Review trigger:** any change log in `knowledge/` touching the source policy → list affected macros
for re-approval.

---

## Weekly support report

**Output:** `output/customer/ticket-triage/<YYYY>-W<nn>-report.md`: volume by category (vs last week),
first-response and resolution times vs promise, % answered from docs, top 5 drivers with a suggested
fix each (doc, product, policy), escalations and outcomes, macros proposed and approved.

---

## Log each job

```
node bin/wf.mjs log --skill support-operations-manager --job "Ticket Triage" --status done --summary "<n> triaged, <n> at SLA risk" --minutes-saved 20
node bin/wf.mjs log --skill support-operations-manager --job "Escalations" --status done --summary "<n> escalations sent" --minutes-saved 10
node bin/wf.mjs log --skill support-operations-manager --job "Macro Authoring" --status draft --summary "<n> macros proposed" --minutes-saved 30
```
