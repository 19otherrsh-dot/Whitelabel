# Triage matrix

| | Blocks work for many | Blocks one customer | Inconvenience | Question / request |
|---|---|---|---|---|
| **Now** (losing money, safety, security, data) | Urgent | Urgent | High | High |
| **Today** (deadline, angry) | Urgent | High | High | Normal |
| **This week** | High | Normal | Normal | Low |
| **Whenever** | Normal | Normal | Low | Low |

Raise one level when: top-tier or high-value account; account health "high risk"; repeated contact on the same issue; public complaint.

Default first-response targets (use policies.md if it states others): Urgent 1 business hour · High 4 business hours · Normal 1 business day · Low 2 business days.
