# Job playbooks · Lead sourcing manager

The detail behind each job in `SKILL.md`. Sourcing follows the law where the prospects are (for example
GDPR/PECR in the UK and EU, CAN-SPAM in the US, CASL in Canada) and each data source's terms; the
compliance-check skill reviews a campaign before it sends.

---

## Database Mining

**ICP → filters worksheet** (show it to the owner before pulling):

| ICP statement (from `customers.md`) | Provider filter |
|---|---|
| "Dental practices, 5–50 staff, UK" | Industry: dental; Employees: 5–50; Country: UK |
| "Owner or practice manager decides" | Titles: owner, principal, practice manager; Seniority: owner, manager |
| "Growing (hiring)" | Job postings in last 90 days: yes (if the provider has it) |

**Credit budget:** estimate credits before pulling (companies × contacts per company); ask above the
owner's threshold (lessons; default 500 credits).

**Record per lead:** `source: leadData:<provider>`, `sourcedAt`, and the filter set id.

---

## Web & Maps Scraping

**Source check (before collecting):**

| Question | If "no" |
|---|---|
| Is the information public without logging in? | skip |
| Do the terms or robots rules allow automated collection? | skip, or ask the owner to export by hand |
| Is it business information (not a private individual's)? | skip that field |

**Collect:** business name, website, address, phone, category, rating/review count. Named contacts only
where published as business contacts (e.g. "Practice manager: Jo Patel, jo@…" on the practice's own
site).

**Record:** `sourceUrl` and `sourcedAt` per row.

---

## List Building

**Funnel report** (always show every step):

```text
Pulled 1,240 (database 980 · maps 260)
→ after dedupe 1,105 (135 duplicates by domain/email)
→ excluded 212: suppressed 31 · clients 18 · open deals 9 · competitors 4 · anti-ICP 96 · personal emails 41 · wrong role 13
→ final 893 in 4 segments
```

**Segment by what changes the message:** vertical × size band × trigger × role. A segment of 40 with a
specific angle beats 900 with a generic one.

**Output:** `data/pipeline/leads.json` (merge by id; `list`, `segment`, `status: new`) and
`output/sales/list-building/<date>-<list>.csv` with columns: name, title, company, domain, email,
phone, segment, source, sourcedAt. Then hand to data-enrichment-specialist (verification) and
lead-scoring-analyst.

**Worked example.** List "UK dental · front desk" from a database pull and maps listings: 893 final, 4
segments (independents 5–15 staff; groups 16–50; practices hiring receptionists; practices with < 4.0
rating on reviews mentioning phones).

---

## Log each job

```
node bin/wf.mjs log --skill lead-sourcing-manager --job "Database Mining" --status done --summary "<n> companies, <n> contacts from <provider>" --minutes-saved 60
node bin/wf.mjs log --skill lead-sourcing-manager --job "Web & Maps Scraping" --status done --summary "<n> businesses from <n> sources" --minutes-saved 90
node bin/wf.mjs log --skill lead-sourcing-manager --job "List Building" --status done --summary "<list>: <n> final in <n> segments" --minutes-saved 60
```
