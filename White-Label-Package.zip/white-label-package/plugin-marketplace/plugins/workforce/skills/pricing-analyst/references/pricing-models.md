# Pricing models and arithmetic

## Formulas

```
delivery_cost   = Σ(hours × loaded_hourly_cost) + tools + contingency(15%)
margin          = (price − delivery_cost) / price
annual_value    = client's estimate (time saved × their hourly cost, revenue gained, costs avoided)
first_year_roi  = (annual_value − first_year_price) / first_year_price
payback_months  = first_year_price / (annual_value / 12)
discount_effect = profit_after / profit_before − 1      # a 10% discount at 40% margin cuts profit by 25%
```

## Structures

| Structure | Use when |
|---|---|
| Good / better / best | Most deals; the middle is the recommendation |
| Paid discovery → build → run | Uncertain scope; reduces risk for both sides |
| Retainer with tiers | Ongoing work; tiers by outcome or capacity |
| Fixed fee per deliverable | Well-defined repeatable work |
| Performance component | Only if outcomes are measurable and in the business's control; owner decision |

## Price-protecting trades (owner approves)

Longer commitment · upfront payment · reduced scope · faster decision · case study permission · referral introduction.
