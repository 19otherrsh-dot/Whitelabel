# {{Question, as customers ask it}}

{{Direct answer in one or two sentences.}}

## How to {{do the thing}}

1. {{step}}
2. {{step}} [Screenshot: {{what to capture}}]
3. {{step}}

## Good to know

- {{edge case or limit, sourced}}
- {{what happens if …}}

## Still stuck?

{{How to contact support, hours and response time from policies.md.}}

Related: {{links to related articles}}

<!-- meta: confirmed by {{person}} on {{date}} · sources: {{files}} · last reviewed {{date}} -->
