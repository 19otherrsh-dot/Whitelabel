# Playbook · Lead magnet producer

`SKILL.md` has the steps. This file has the choice test, format guide, opt-in copy, nurture outline and
a worked example.

## Choice test (all four must be yes)

1. **Specific**: one problem for one segment ("missed evening calls at multi-site clinics").
2. **Proven interest**: evidence in the performance or audience reports (saves, questions, replies).
3. **Quick win**: usable in under 15 minutes.
4. **Adjacent**: solving it makes the offer the obvious next step.

## Format guide

| Problem shape | Format |
|---|---|
| "Am I doing this right?" | checklist |
| "How much is this costing me?" | calculator (single-file HTML or spreadsheet) |
| "Where do I start?" | template or 5–12 page guide |
| "What do I say?" | swipe file |
| "Teach me over a week" | email mini-course (5 emails) |

## Opt-in page copy

```text
Headline: <the result, specific> · Sub: for <who>, in <time>
What's inside: 3 bullets
Fields: first name, email
Consent: "You'll get the <asset> and a short email each week with practical tips. Unsubscribe any time."
(Marketing consent as a separate unticked box where the law requires it.)
Button: Send me the <asset>
```

## Nurture outline (after the delivery email)

| Day | Email | Purpose |
|---|---|---|
| 0 | delivery | the link + how to use it in 3 lines |
| 2 | quick win | one extra tip that builds on the asset |
| 5 | story | a real (permitted) example of the problem solved |
| 8 | the offer, once | what we do, who it's for, one easy next step |
| 12 | question | "what's the one thing you're stuck on?" (replies go to inbound) |

## Worked example

Evidence: "how many calls are we missing?" asked 11 times in a month. Asset: "Missed-call cost
calculator" (HTML): calls/day, % missed, booking value → monthly cost, with a short method note. Leads to
the missed-call recovery offer. Comment-CTA keyword "CALC" handed to dm-fulfillment-specialist.

## Log

```
node bin/wf.mjs log --skill lead-magnet-producer --job "Lead-Magnet Builds" --status draft --summary "<slug>: asset + page + <n> emails" --minutes-saved 240
```
