# Playbook · Dashboard builder

`SKILL.md` has the steps; `dashboards/lib.js` has the helpers. This file has the measure-definition card,
a worked panel and the check list.

## Measure definition card (write before any code)

```markdown
Question: Are we collecting cash fast enough? · Who acts: owner, weekly
Measure: Days sales outstanding (DSO)
Formula: (open receivables ÷ revenue invoiced in the last 90 days) × 90
Filters: invoices with status sent | overdue | partial; currency = base currency
Window: rolling 90 days · Unit: days · Good direction: down
Source: data/finance/invoices.json (amount, status, issueDate, paidDate)
Written by: billing-manager (Invoice Generation, Payment Tracking)
```

## Worked panel (sketch)

```js
const inv = await api.data('finance', 'invoices');
const since = Date.now() - 90 * 864e5;
const billed = inv.filter(i => Date.parse(i.issueDate) >= since).reduce((s, i) => s + i.amount, 0);
const open = inv.filter(i => ['sent', 'overdue', 'partial'].includes(i.status))
               .reduce((s, i) => s + (i.amount - (i.paidAmount || 0)), 0);
const dso = billed ? Math.round(open / billed * 90) : null;
card.innerHTML = dso == null
  ? empty('No invoices in the last 90 days', 'Run "billing-manager: Invoice Generation"')
  : kpi('Days to get paid', `${dso} days`, { note: 'last 90 days' }) + freshness(inv);
```

Helpers escape values; never build HTML from record text without `esc()`.

## Check list

| Check | How |
|---|---|
| Numbers right | recompute one figure by hand from the JSON |
| Empty state | rename the data file temporarily; the card names the job that fills it |
| Light and dark | toggle the theme |
| Phone width | 375 px: no horizontal scroll, tables scroll inside their card |
| Keyboard | tab through filters and table headers; focus visible |
| Tooltips | hover each chart mark |
| Docs | field added to `docs/data-model.md`; tool listed in `docs/os-tools.md` |

## Log

```
node bin/wf.mjs log --skill dashboard-builder --job "Dashboard Build" --status done --summary "<view>: <panel> added" --minutes-saved 60
```
