# Deliverability health checks

## DNS lookups (no login needed)

Use a DNS-over-HTTPS JSON endpoint, for example:
- `https://dns.google/resolve?name=<domain>&type=TXT` (SPF, DMARC at `_dmarc.<domain>`)
- `https://dns.google/resolve?name=<selector>._domainkey.<domain>&type=TXT` (DKIM)
- `https://dns.google/resolve?name=<domain>&type=MX`

## Record shapes

- SPF: `v=spf1 include:_spf.google.com ~all` (one SPF record only; ≤ 10 DNS lookups)
- DMARC: `v=DMARC1; p=none; rua=mailto:dmarc@<domain>; adkim=s; aspf=s` → move to `p=quarantine` once reports look clean
- DKIM: provider-generated public key at the selector

## Thresholds

| Metric | Green | Amber | Red → action |
|---|---|---|---|
| Bounce rate | < 2% | 2–3% | > 3% → pause, clean list |
| Spam complaints | < 0.05% | 0.05–0.1% | > 0.1% → pause, review targeting/copy |
| Reply rate trend | stable/up | down 25% | down 50% → placement test |
| Blocklist | none | minor list | major list → stop, investigate |

## Warmup (new inbox)

Week 1: 5–10/day · Week 2: 15–20/day · Week 3: 25–35/day · Week 4: up to target (30–50/day for cold).
