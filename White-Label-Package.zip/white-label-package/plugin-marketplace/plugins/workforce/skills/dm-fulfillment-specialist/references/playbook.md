# Playbook · DM fulfillment specialist

`SKILL.md` has the steps. Platform rules change often; check the platform's current messaging policy
before the first run of a campaign and note the date checked. This file has the matching and skip rules,
the DM template and a worked run.

## Keyword matching

| Comment | Match? |
|---|---|
| "GUIDE" / "guide!" / "guide 🙏" | yes |
| "gude pls" | yes (clear intent, typo) |
| "This guide idea is rubbish" | no (criticism, not a request) |
| "Can you send it to my colleague @…" | no automatic DM to the colleague; reply publicly to the commenter |

## Skip rules

Spam or bot accounts · already received this asset · on the suppression list or asked not to be
contacted · comment is a complaint · account appears to belong to a child · platform won't allow a DM
to someone who hasn't messaged first (then use the allowed public reply).

## DM template (≤ 50 words)

```text
Hi <first name>, thanks for commenting on the post. Here's the <asset>: <link>
Best way to use it: <one line>.
<Optional soft question: "What's the one thing you're hoping it helps with?">
— <name>, <business>
```

## Worked run

Post with CTA "comment GUIDE": 64 comments; 51 matched; skipped 6 (3 already sent, 2 spam, 1
complaint); 45 DMs queued in 3 batches inside the platform's limits; 45 leads recorded with source
`comment-cta:<post id>`; 9 replies handed to inbound-response-manager. Report sent to the owner.

## Log

```
node bin/wf.mjs log --skill dm-fulfillment-specialist --job "Comment-CTA Fulfillment" --status queued --summary "<post>: <n> DMs queued, <n> skipped" --minutes-saved 40
```
