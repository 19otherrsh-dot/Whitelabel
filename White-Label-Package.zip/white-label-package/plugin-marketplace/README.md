# workforce · private plugin marketplace

This folder is a Claude Code plugin marketplace with one plugin, **workforce** (90 skills, 10 subagents, version 1.0.0).

Keep it **private**. It is licensed to you for distribution to your own members only (see the licence in the workspace).

## Distribute

1. Push this folder to a private git repository you control (GitHub, GitLab, Bitbucket or a self-hosted server).
2. Members with access add it and install the plugin:
   ```
   claude plugin marketplace add <your-org>/<repo>
   claude plugin install workforce@workforce-marketplace
   ```
3. To ship an update, re-run `python3 build/package_plugin.py`, bump the version in `workspace.json → kitVersion`, commit and push. Members run `claude plugin marketplace update workforce-marketplace`.

Team workspaces can pre-register the marketplace for everyone by adding it to the project's `.claude/settings.json` (`extraKnownMarketplaces` and `enabledPlugins`); see the Claude Code documentation on plugin marketplaces.

## Workspace or plugin?

| | Workspace (zip) | Plugin |
|---|---|---|
| Skills and department leads | yes | yes (namespaced, e.g. `/workforce:proposal-writer`) |
| Knowledge base, approvals outbox, run log, autopilot, dashboards, map | yes | no |
| Approval guard hook | yes | no: Claude Code's normal permission prompts apply |

Don't install the plugin inside a workspace that already has the same skills in `.claude/skills/`; you would load every skill twice. Use the workspace's `wf update` instead.

## Check before pushing

```
claude plugin validate .
claude plugin validate plugins/workforce --strict
```
If you run `claude plugin eval`, add `--no-publish` so reports stay on your machine.
