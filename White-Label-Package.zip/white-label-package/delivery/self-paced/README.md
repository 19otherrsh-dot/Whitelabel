# The self-paced course

The same method as the live cohort, on demand: six modules, about 30 short lessons, an assignment
per module, and a final submission. For buyers who can't make live sessions, and as a lower price
point next to the cohort.

## How it differs from the cohort

| | Live cohort | Self-paced |
|---|---|---|
| Teaching | Six live sessions, two weeks | Six modules, at the member's pace (suggested: two weeks to a month) |
| Help | TAs in the room, clinics, support calls for 90 days | Community + written support (P2/P3 targets in `../support/sops.md`); optional group office hours |
| Proof of progress | Checkpoints checked live by TAs | Module submissions: command outputs and a short screen recording |
| Guarantee | Build guarantee (attend all six, complete the steps) | **Don't offer the build guarantee** (attendance can't be checked). Offer a plain money-back window instead, e.g. 14 days with no more than two modules completed, plus legal rights |
| Certificate | Demo-day result | Certificate of completion after the final submission is reviewed |

Pricing is the licensee's call. Price it clearly below the Founding seat; the gap is the live
help, not the content.

## Production

- **Videos:** screen recordings with voice-over, 4 to 10 minutes each. Record on the demo
  workspace (Pellmark Growth and demo data), never on a real business. Every video shows the
  commands on screen; captions on; a transcript under each.
- **Re-recording:** when a kit release changes a command or screen, re-record only the affected
  lessons. Keep a list of which lesson shows which command (`modules.md` does).
- **Platform:** the back end has the course built in (`/member/course`): lessons with their outline
  and your video links, the quizzes graded on the server, module submissions reviewed in Admin →
  Course, and a certificate with a public check. It's built from `modules.md`, `quizzes.md` and
  `submission-guide.md`, so edit those and run `node scripts/build-course.mjs` in `backend/`. Host
  the videos anywhere members can watch (unlisted or members-only) and paste the links in admin.
  Without the back end, use any course platform with modules, video, file downloads, quizzes and a
  completion rule (Kajabi, Teachable, Thinkific, Circle's courses, Skool's classroom…).
- **Selling it on its own:** in the back end, a cohort marked *Self-paced course* (no sessions, VIP
  seats 0) sells the course alone, with the money-back window below instead of the build guarantee.
- **Access:** the same kit download and library period (12 months) as the cohort, unless the
  licensee decides otherwise and says so on the pricing page.

## Completion rule

A member completes the course when:

1. All six module assignments are submitted and marked complete.
2. All six quizzes are passed (80%, retakes allowed).
3. The final submission (Module 6) passes the self-paced version of the rubric: B1–B6 from
   `../demo-day-rubric.md`, judged from the recording and outputs.

Then they get the certificate of completion and an invitation to the next live cohort's demo day
as a guest, if the licensee wants to offer it.

## Files

| File | What |
|---|---|
| `modules.md` | Every module and lesson: objective, length, script outline, on-screen steps, assignment |
| `quizzes.md` | Six quizzes with answers |
| `submission-guide.md` | What members submit for each module and how reviewers mark it |
