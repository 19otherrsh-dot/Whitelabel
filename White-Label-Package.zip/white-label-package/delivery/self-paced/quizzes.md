# Module quizzes

Five questions per module; pass mark 4 of 5; retakes allowed. Correct answers are **bold**.
The member area builds its quizzes from this file (`backend/scripts/build-course.mjs`): keep each
question numbered, the options as `a)`, `b)`…, and the one correct option in bold.

## Module 1

1. Where should the workspace folder live? a) Downloads b) a synced cloud folder **c) a normal
   folder you keep, e.g. Documents/Workforce** d) inside the zip
2. The installer asks to install the autopilot timer. In Module 1 you answer: a) Yes, so jobs start
   running tonight **b) No (it's set up in Module 5)** c) Yes, then pause it
3. Which command checks the setup and says how to fix problems? a) `bin/wf status` **b) `bin/wf
   doctor`** c) `bin/wf serve` d) `bin/wf runs`
4. The rule for a first department: **a) repeat work you'd pay to hand off this month that you can
   check in five minutes** b) the most impressive department c) the one with the most jobs
   d) whatever your biggest client asks for
5. True or false: the kit sends emails as soon as it's installed. **False**

## Module 2

1. When the owner's lesson disagrees with a vertical note, which wins? **a) the owner's lesson**
   b) the vertical note c) the skill's default d) whichever was written last
2. Installing a starter: a) turns its schedules on **b) adds its schedules switched off** c) deletes
   your edits d) asks Claude to run every job once
3. Your backup repository must be: a) public, so the community can help b) shared with the
   instructor **c) private** d) the same one as your website
4. Which command runs Claude with your stored keys loaded? **a) `bin/wf start`** b) `claude` c)
   `bin/wf serve` d) `bin/wf doctor`
5. In a department plan, an item that sends to many people should start at: a) autonomous **b)
   approve** c) skipped forever d) draft for a day, then autonomous

## Module 3

1. When the interview doesn't know something it: a) guesses **b) writes a TODO question for the
   owner** c) leaves it blank d) copies it from a competitor's site
2. A result in `proof.md` with no permission status is recorded as: a) public **b) not for use**
   c) usable in proposals only d) anonymous, so fine to quote
3. How many writing samples should you give, at least? a) 1 **b) 3** c) 20 d) none, the voice
   test writes them
4. A price is wrong in an output. You fix it: a) in the output only **b) in `offers.md`, by asking
   Claude** c) in the skill's `SKILL.md` d) by rejecting the run with no reason
5. Which never goes into the knowledge base? **a) passwords and API keys** b) your offers c) your
   voice rules d) your service areas

## Module 4

1. The safest first access for a new connector is: **a) read-only** b) full admin c) the same
   access your own login has d) write access, so jobs can finish
2. You store an API key with: a) a file in `knowledge/` b) pasting it into chat **c) `bin/wf secrets
   set NAME`** d) a note in `CLAUDE.md`
3. No connector for a tool? **a) put an export in `data/imports/`** b) skip the job c) give Claude
   your password for the tool d) wait for the next kit release
4. Which shows a queued action in full? a) `bin/wf runs` **b) `bin/wf show <id>`** c) `bin/wf
   status` d) `bin/wf budget`
5. When you reject an output you should: **a) give a reason, because it becomes a lesson** b) delete
   the file c) edit the output by hand and approve it d) switch the job to autonomous

## Module 5

1. Which of these is one of the four tests for scheduling? **a) it has run supervised at least
   three times with outputs you kept** b) it's the longest job c) it's the job you like least
   d) it has never been rejected
2. Which command stops all unattended work at once? **a) `bin/wf autopilot pause`** b) `bin/wf
   doctor --fix` c) `bin/wf demo clear` d) `bin/wf autopilot list`
3. Unattended runs can always: a) move money b) approve their own work **c) prepare drafts and
   queue actions for you** d) change their own permissions
4. Remote Control needs: **a) the laptop on and the Claude Code session running** b) nothing; it
   runs in the cloud c) an API key on your phone d) the autopilot timer installed
5. The weekly review is run by: **a) the chief of staff** b) the compliance officer c) the sales
   lead d) the instructor

## Module 6

1. A working department needs (choose the complete answer): **a) one job running end to end on your
   business, with usable output, runs logged, lit on the map, and nothing sent without approval**
   b) every job autonomous c) every job on a schedule d) a dashboard with sample data
2. In a stress test, the right fix is usually: **a) a change to knowledge, a lesson or a guardrail**
   b) editing the output by hand c) switching the job off d) a longer prompt typed each time
3. Before installing an update you run: **a) `bin/wf update --from <zip> --dry-run`** b) delete the
   old folder c) `bin/wf demo clear` d) nothing; updates are automatic
4. What does `bin/wf update` never change? **a) your knowledge, data, outputs, runs, outbox,
   schedules and settings** b) nothing; it replaces everything c) only the dashboards d) only
   the skills you never used
5. Where do the numbers in `bin/wf outcomes` come from? **a) the run log and the outbox** b) the
   audit's estimate c) industry averages d) your own guess, entered once
