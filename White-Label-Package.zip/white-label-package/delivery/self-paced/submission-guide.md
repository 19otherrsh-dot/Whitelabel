# Submissions: what members send and how reviewers mark them

## For members

- Paste command output as text, not screenshots, where you can. Never include passwords, keys,
  tokens, or other people's personal data. Blur them in any screenshot or recording.
- One submission per module. You can resubmit as often as you like.
- Reviewers reply within 5 business days with Complete, or with exactly what's missing.

## For reviewers

Mark against the module's assignment list and these checks. Write one line of evidence per check.

| Module | Complete when |
|---|---|
| 1 | `doctor` shows no failures except connectors and knowledge gaps; a first department named with a reason; ten-things worksheet with at least five lines that are repeat work |
| 2 | The starter setup plan and the member's department plan exist; a backup commit is visible; the business-type pack is installed |
| 3 | No unexplained knowledge gaps; 3+ voice examples; at least one run on their own business; one correction described |
| 4 | Every job in their plan has a run in the last 7 days; each needed tool connected or replaced by a named file; the map shows the department lit; a rejection with a reason |
| 5 | A schedule enabled that has run; the timer installed; a budget set; a notification received or approval given away from the laptop (or a stated plan limitation and the alternative used) |
| 6 | The recording shows B1–B6 from `../demo-day-rubric.md` passing on the member's own business |

If a submission shows something unsafe (a key, an outbound action without approval, customer data
pasted into knowledge files), mark it **Not yet**, explain the fix kindly, and point to the macro.

A second reviewer checks any Module 6 submission marked Not yet twice in a row, and offers a
written support thread to get it over the line.
