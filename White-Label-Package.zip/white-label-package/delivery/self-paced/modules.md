# Modules and lessons

Each lesson has: an objective, a target length, a script outline (what to say), the on-screen
steps (what to show), and the commands it relies on (so you know what to re-record after a kit
change). Record on the demo workspace only.

---

## Module 1 · Foundations (≈ 45 minutes of video)

**Module outcome:** the kit installed and healthy, Claude Code signed in, the interview started,
the first department chosen.

### 1.1 What you're building (6 min)
- **Say:** an AI department is skills + your knowledge + approvals + a record. It runs on your
  computer and your Claude account. Nothing leaves without you.
- **Show:** the demo workspace: `bin/wf status`, the map with lit jobs, one outbox item, one output.
- **Commands:** `bin/wf status`, `bin/wf serve`.

### 1.2 Before you install (4 min)
- **Say:** the requirements (macOS 13+ / Windows 10 1809+ or 11; a paid Claude plan or Console
  account; permission to install software); where to put the folder (not Downloads, not a synced
  folder).
- **Show:** downloading from the member area, unzipping to `Documents/Workforce`.

### 1.3 Install on a Mac (7 min) · 1.4 Install on Windows (7 min)
- **Say:** the installer checks Node.js, Claude Code and git, asks before installing anything, never
  needs admin rights, and is safe to run again. Answer the business questions; say **No** to the
  autopilot timer for now.
- **Show:** the full install on a clean machine, including the Gatekeeper / SmartScreen prompt and
  how to get past it; then `bin/wf doctor --problems`; then signing in to Claude Code.
- **Commands:** `Install on Mac.command`, `Install on Windows.bat`, `bin/wf doctor`, `claude`.

### 1.5 When the install goes wrong (6 min)
- **Show:** the five most common problems from the troubleshooting guides and their fixes.

### 1.6 Start the interview (8 min)
- **Say:** the knowledge base is what makes the agents yours. Research-first mode reads your site
  and documents and only asks about gaps.
- **Show:** `bin/wf start`, *"run the onboarding interview"*, the company and offers sections.

### 1.7 Choose your first department (7 min)
- **Say:** the rule (repeat work you'd pay to hand off this month, that you can check in five
  minutes); the five choices and their starters; or run the workforce audit.
- **Show:** `bin/wf library`, *"run the workforce audit"* summary.

**Assignment 1:** `bin/wf doctor --problems` output; your first-department choice and why; the
ten-things worksheet (`../curriculum/ten-things-worksheet.md`).

---

## Module 2 · Your workspace (≈ 40 minutes)

**Module outcome:** an editor, a private backup, the business-type pack and starter installed, a
department plan.

### 2.1 What lives where (8 min)
- **Show:** the folder tree in an editor, one line per folder (from Session 2's Demo A). The
  reading order and which source wins.

### 2.2 Three ways to run Claude (5 min)
- **Show:** `bin/wf start` in a terminal; the VS Code Claude Code panel; the desktop app's Code tab.
  Note that `bin/wf start` loads stored keys.

### 2.3 Backups (6 min)
- **Show:** a private repository; *"set my backup remote to …"*; `bin/wf backup`; the commit on
  the website. `backup.includeData`.

### 2.4 The library (7 min)
- **Show:** `bin/wf library`, `show starter`, `show vertical`, `install … --dry-run`, `install`. The
  guard asking for confirmation. Schedules arrive switched off.

### 2.5 Ten things → your department plan (12 min)
- **Show:** *"turn on this starter with the department builder. Here are my ten things: …"*; edit the
  plan: remove non-repeat work, merge duplicates, move high-risk items later.

**Assignment 2:** the starter's setup plan and your department plan (from
`output/workforce/department-setup/`); a screenshot of the backup repository's latest commit
(no secrets visible).

---

## Module 3 · Encode your business (≈ 45 minutes)

**Module outcome:** the knowledge base complete and corrected, voice matched, the first run logged.

### 3.1 Why the knowledge base matters (6 min)
- **Show:** the same prompt in an empty workspace and in Pellmark Growth; where each detail came
  from; the refusal to quote a "not for use" result.

### 3.2 Research first (10 min)
- **Show:** a `for-claude` folder; research-first mode; the summary; a contradiction flagged; a
  `TODO (owner to confirm: …)`.

### 3.3 The read-back (8 min)
- **Show:** the one-screen summaries; correcting a price by asking; the change log; `bin/wf status`
  knowledge gaps.

### 3.4 Your voice (8 min)
- **Show:** adding samples; the voice test; correcting `voice.md` with a specific note.

### 3.5 Your first real run (10 min)
- **Show:** the first job from the starter's first-week plan; reviewing the output; rejecting with a
  reason; `bin/wf runs --days 1`.

### 3.6 What never goes in (3 min)
- **Say:** no passwords, keys or bank details; customers' personal data only where needed; summarise,
  don't paste exports.

**Assignment 3:** `bin/wf status` (knowledge section); the list of files in `knowledge/examples/`;
`bin/wf runs --days 7`; one correction you made and why.

---

## Module 4 · Deploy your department (≈ 50 minutes)

**Module outcome:** tools connected or replaced, every job run, the department visible on the map
and a dashboard.

### 4.1 How tools connect (8 min)
- **Show:** the five routes (`docs/connectors.md`); *"connect HubSpot"* on a sandbox; read-only first;
  the harmless test read.

### 4.2 Keys, safely (5 min)
- **Show:** `bin/wf secrets set NAME`, `secrets list`, restarting with `bin/wf start`. What never to do.

### 4.3 No connection? Use files (4 min)
- **Show:** an export in `data/imports/` used by a job.

### 4.4 Running the department end to end (12 min)
- **Show:** asking the department lead to run the day's work; outputs; the outbox; `show`, `approve`,
  `reject --reason`, `dispatch --dry-run`. The autonomy levels.

### 4.5 See it: map, dashboard, Agent Ops (10 min)
- **Show:** `bin/wf serve`; the map; *"set up the Pipeline dashboard"*; empty panels naming their
  job; `bin/wf demo clear`.

### 4.6 Lessons (6 min)
- **Show:** a rejection reason becoming a lesson; `bin/wf learn`; the next run using it.

**Assignment 4:** `bin/wf runs --days 7` with every job in your plan; `bin/wf doctor --problems`
(connectors); a screenshot of your map showing the department lit; one rejection reason and the
lesson it created.

---

## Module 5 · Put it on a clock (≈ 40 minutes)

**Module outcome:** schedules with budgets, the timer, notifications, approvals away from the laptop,
the weekly review.

### 5.1 What deserves a clock (5 min) — the four tests.
### 5.2 Schedules and the timer (10 min)
- **Show:** *"set up my weekly routine"*; `autopilot list`, `enable`, `run`, `install`; budgets;
  `bin/wf budget`.
### 5.3 Safety on a timer (7 min)
- **Show:** what unattended runs can't do; guardrails; `bin/wf autopilot pause`.
### 5.4 Notifications (6 min)
- **Show:** ntfy on a phone; `secrets set WF_NOTIFY_URL`; `bin/wf notify`.
### 5.5 From your phone (8 min)
- **Show:** `bin/wf start --remote-control "Workforce"`; the session in the Claude app; assigning a
  job; approving with the confirmation on the phone. The limits (laptop on, session open; plan
  requirements).
### 5.6 The weekly review (4 min)
- **Show:** scheduling the chief of staff's weekly review; a sample report.

**Assignment 5:** `bin/wf autopilot list`; `bin/wf runs` showing at least one scheduled run; a
screenshot of a notification on your phone (blur anything private).

---

## Module 6 · Demo it, then the next department (≈ 25 minutes + your submission)

### 6.1 What "working" means (7 min) — the rubric, line by line.
### 6.2 Stress-test it yourself (8 min)
- **Show:** the stress tests for each department type; fixing through knowledge, lessons or
  guardrails, not by editing outputs.
### 6.3 Your next department (8 min) — the method alone; which starters usually come second.
### 6.4 Updates and outcomes (2 min) — `bin/wf update --from … --dry-run`; `bin/wf outcomes`.

**Final submission:** a screen recording of up to 10 minutes following the demo format (one
sentence; a job run live end to end on your business; the outbox decision; map, run log and
dashboard; one lesson), plus `bin/wf runs --week`. Reviewed against B1–B6 within 5 business days.
