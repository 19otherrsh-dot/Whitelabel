# Session 4 · Deploy your department

> Your department running end to end in the terminal. See it on your map. Put a dashboard on
> it, connect your real tools (CRM, inbox, calendar, sheets), and click through your own data.
> Review what it produced and fix the gaps together.
> **You leave with:** a department running on your machine, on your data, on your tools.

## Outcomes

1. The department's tools connected with the least access that works, or replaced by files.
   No key ever typed into chat.
2. Every job in the department run at least once on the member's business, and reviewed (**C4**).
3. The department lit on the map, its dashboard showing the member's own data.
4. At least one rejection with a reason, turned into a lesson.

## Before the session (instructor)

- [ ] Demo workspace with a **test** CRM or a sandbox account you control (HubSpot and Stripe both
      offer free test environments), or use files only. Never a real client account.
- [ ] Know the connection route for each member's tools: official hosted server, Claude connector,
      local server, Zapier/Make/n8n, or files (`docs/connectors.md`, `connectors/catalog.json`).
      Flag members whose tools need an admin they don't have; they use files today.
- [ ] TAs briefed: **no one ever asks a member for a key, password or token, and no one looks
      while they type one.**
- [ ] Slides: `slides/session-04.pptx`.

## Run sheet (120 minutes)

| Time | Block | Who | What happens |
|---|---|---|---|
| 0:00 | Recap and questions | Lead | The best and worst output from homework (with permission), and the lesson each rejection taught. |
| 0:10 | How tools connect | Lead | **Demo A**: connect a tool read-only, test it, store a key the safe way. |
| 0:25 | Connect yours | All + TAs | **Exercise 1**: members connect their department's tools, one at a time, read-only first. |
| 0:55 | Break | | 5 minutes |
| 1:00 | The department, end to end | Lead | **Demo B**: run the whole department in order, review, approve and reject. |
| 1:15 | Run yours | All | **Exercise 2**: every job in the department, in plan order. |
| 1:35 | See it | Lead + all | **Exercise 3**: the console, the map and the department's dashboard. |
| 1:50 | Homework and close | Lead | Run the department daily until Session 5; note what you'd want on a clock. |

## Demo A · Connecting a tool (15 minutes)

In Claude:

> connect HubSpot

Narrate what the connector-setup skill does: says which route it will use and why; asks for
the least access (read-only first); opens the vendor's sign-in in the browser (OAuth, so no key
is stored here); tests the connection with a harmless read ("how many contacts do you have?");
records it so `bin/wf doctor` and the dashboards know.

Then show a tool that needs a key:

```
bin/wf secrets set XERO_CLIENT_SECRET        # typed, hidden, into the system keychain
bin/wf secrets list                          # names only, never values
bin/wf start                                 # restart so local servers get the key
```

And a tool with no connection at all: drop an export into `data/imports/` and say
*"use data/imports/deals.csv as our pipeline"*.

## Exercise 1 · Connect yours (30 minutes)

Order: **email and calendar → the department's system of record (CRM, accounting, help desk,
project tool) → everything else.** For each:

1. *"connect <tool>"* and follow it.
2. Accept read-only first. Write access is turned on later, per job, when it has earned it.
3. Check: `bin/wf doctor --problems` shows the connector as working.

TAs check that nobody pastes a key into chat, and that members on a shared or company account
have permission to connect it. Members without admin access use files today and send the
"ask your admin" note (in `../support/macros.md`) to whoever can approve the app.

## Demo B · The department, end to end (15 minutes)

In the demo workspace, ask the department lead to run the first-week plan:

> ask the sales lead to run today's outreach work for the first segment

Show it calling the skills in order, each reading the knowledge it needs, each writing to
`output/` and logging a run. When something needs to go out, it lands in the outbox:

```
bin/wf outbox
bin/wf show <id>
bin/wf approve <id> --note "checked"          # or:
bin/wf reject <id> --reason "uses a claim that isn't in proof.md"
bin/wf dispatch --dry-run                     # what it would do, without doing it
```

Explain the autonomy levels: `draft` (prepare only), `approve` (queue for you), `autonomous`
(act within guardrails, only after a track record). **During the cohort everything stays at
`draft` or `approve`.**

## Exercise 2 · Run yours (20 minutes)

Each member runs every job in their department plan, in order, on their own business. For each
output: keep, edit, or reject with a reason. Anything that would go out goes to the outbox and
is approved only to the member's own address or a colleague who expects it. **Nothing goes to a
real prospect or customer in class.**

## Exercise 3 · See it (15 minutes)

```
bin/wf serve
```

1. **Workforce Map**: the department's jobs are lit (live) or half-lit (dev: drafts only). Click
   each lit node and check it shows the member's last run.
2. **The department's dashboard**: *"set up the Pipeline dashboard"* (or Outbound, Client
   Delivery, Billing, Support…, whichever the starter lists). The dashboard-builder skill
   connects the sources, runs the jobs that feed it and checks it shows real data. An empty panel
   names the job that fills it.
3. **Agent Ops**: runs, approvals, failures and cost for the department.

If the member loaded demo data earlier, run `bin/wf demo clear` now so the dashboards show only
their own business.

## Checkpoint C4

- Every job in the department plan has at least one run on the member's business
  (`bin/wf runs --days 7`), and the map shows them lit or half-lit.
- Each tool the department needs is connected (`bin/wf doctor`) **or** replaced by a named file.
- At least one rejection with a reason (`data/feedback/`).

## Common problems today

| Symptom | Fix |
|---|---|
| OAuth window never opens | Pop-up blocked; copy the URL from the terminal into the browser |
| "Admin approval required" | The tool's admin must approve the app; use files today, send the macro |
| Connector works in terminal, not in VS Code / desktop app | Keys loaded by `bin/wf start` only; start from the terminal or store the key where the app reads it |
| Dashboard empty | Run the job the panel names; or the data is still in demo mode, `bin/wf demo clear` |
| An outbox item went to a wrong address in a draft | That's why it's in the outbox. Reject with the reason; check `customers.md` and the CRM record |
| Gmail / Microsoft 365 not available as a connector | Plan-dependent; use the Claude connector route or files (`docs/connectors.md`) |

## Homework (email 08)

1. Run the department every working day until Session 5. Approve or reject everything in the
   outbox with reasons.
2. Write down which jobs you'd trust to run on a timer, and at what time.
3. Install the Claude app on your phone and sign in with the same account (for Session 5).
4. `bin/wf backup`.

## After the session

Recording posted the same day, attendance and C4 recorded, email 08 sent. VIP members' second
1-on-1 should land between Sessions 4 and 5; it's the best time to fix connector problems.
