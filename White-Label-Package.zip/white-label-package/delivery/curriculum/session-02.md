# Session 2 · Your workspace

> Set up the editor (Mac or Windows) and GitHub. Open the department library and pick your
> starter. Choose your runtime. Learn what the agent reads first and what lives where. Turn your
> ten things into the roles and skills of your department.
> **You leave with:** your workspace ready, the library unlocked and a plan for the jobs your
> department will handle.

## Outcomes

1. An editor open on the workspace folder, so members can read and change any file.
2. A private backup repository connected, and the first backup pushed.
3. The business-type pack and the first-department starter installed.
4. A department plan: each of the member's ten things matched to a job on the map (or a custom
   job), with its skill, what it needs first and where the member stays in the loop (**C2**).

## Before the session (instructor)

- [ ] Review the ten-things worksheets posted in the community. Pick two good ones (with
      permission) to use as worked examples; one that maps cleanly, one that needs a custom job.
- [ ] Demo workspace: empty workspace with the interview done (use Pellmark's knowledge copied
      in, or your own test business). No starter installed yet.
- [ ] A throwaway private repository ready for the backup demo.
- [ ] C1 list: who still needs the clinic. TAs take them first in breakouts.
- [ ] Slides: `slides/session-02.pptx`.

## Run sheet (120 minutes)

| Time | Block | Who | What happens |
|---|---|---|---|
| 0:00 | Recap and questions | Lead | What went wrong in installs and how it was fixed (normalise it). Questions from the community. |
| 0:10 | What lives where | Lead | **Demo A**: a guided tour of the folder in the editor, and the order an agent reads things. |
| 0:25 | Editor and runtime | Lead + TAs | **Exercise 1**: open the folder in an editor; pick the way you'll run Claude. |
| 0:40 | Backups | Lead + TAs | **Exercise 2**: private repo, `backup.remote`, first `bin/wf backup`. |
| 0:55 | Break | | 5 minutes |
| 1:00 | The library | Lead | **Demo B**: `bin/wf library`, show one starter and one vertical, install both. |
| 1:10 | Install yours | All | **Exercise 3**: members install their vertical and starter. |
| 1:20 | Ten things → jobs | Lead | **Demo C**: one worksheet turned into a department plan with the department builder. |
| 1:35 | Plan yours | All | **Exercise 4**: members run the same on their worksheet. TAs review plans in breakouts. |
| 1:50 | Homework and close | Lead | Finish the interview, collect the Session 3 documents, the clinic. |

## Demo A · What lives where (15 minutes)

Open the folder in the editor and walk the tree from top to bottom. One sentence each:

| Path | Say |
|---|---|
| `CLAUDE.md`, `AGENTS.md` | The workspace's instructions. Every session starts by reading them. |
| `workspace.json` | Your settings: company, tools, autonomy, guardrails, budgets, compliance. |
| `knowledge/` | Your business. Every agent reads it before it works. |
| `.claude/skills/` | The 90 specialists. Open one (`proposal-writer/SKILL.md`): steps, checklist, what it reads. |
| `.claude/agents/` | The department leads, chief of staff, reviewer and compliance officer. |
| `.claude/hooks/` | The safety guard. Nobody edits it during the cohort. |
| `departments/` | Each department's jobs, which skill does each, prerequisites, who stays in the loop. |
| `output/`, `outbox/`, `runs/` | What was made, what's waiting for you, what happened. |
| `data/` | Records the dashboards show, lessons, the suppression list. |

Then the reading order, which is the answer to "why did it do that?":

1. `CLAUDE.md` (the rules) → 2. the skill's own steps → 3. `knowledge/` → 4. the business-type
notes (`knowledge/vertical.md` and `knowledge/vertical/<skill>.md`) → 5. the member's own lessons
(`data/feedback/lessons/<skill>.md`). **When they disagree, the owner's lessons win, then the
vertical notes, then the skill's defaults.**

## Exercise 1 · Editor and runtime (15 minutes)

Editor: any editor that can open a folder works. Recommend **Visual Studio Code** (free, Mac and
Windows) because the Claude Code extension runs inside it. Members who prefer no terminal can use
the **Claude desktop app**: open the folder in its Code tab.

The three ways to run Claude on the workspace, all equivalent:

| Runtime | Start it | Good for |
|---|---|---|
| Terminal | `bin/wf start` | Everyone; loads your stored keys automatically |
| VS Code | Open the folder, open the Claude Code panel | Seeing files and chat side by side |
| Claude desktop app | Code tab → open folder | Members who'd rather not see a terminal |

Note for the desktop app and VS Code: keys stored with `bin/wf secrets` are loaded by
`bin/wf start`. In the other two, connectors that need a key may ask for it to be set up again
in Session 4; the connector-setup skill handles it.

## Exercise 2 · Backups (15 minutes)

1. Create a **private** repository on GitHub (or GitLab, Bitbucket). Name it `workforce`.
   Private is not optional: the workspace holds your business.
2. Sign Git in to it once (the Git installer's credential manager, or `gh auth login` if they use
   the GitHub CLI).
3. Ask Claude: *"set my backup remote to <the repository's https address>"*, or edit
   `workspace.json → backup.remote` directly.
4. Run `bin/wf backup --message "after session 2"`. Check the repository shows the files.

Say: backups are restore points. If anything goes wrong in the next two weeks, we can go back to
this one. Members who don't want their data in a repository at all can set
`backup.includeData` to `false`.

## Demo B · The library (10 minutes)

```
bin/wf library
bin/wf library show starter outreach
bin/wf library show vertical agency
bin/wf library install vertical agency --dry-run
bin/wf library install vertical agency
bin/wf library install starter outreach --dry-run
bin/wf library install starter outreach
```

Point out: schedules are added **switched off**; autonomy is set only for jobs the owner hasn't set;
the setup plan lands in `output/workforce/department-setup/`; nothing the owner wrote is overwritten.
If Claude runs the install for you, the approval guard asks you first: installing changes your
setup, so it's your decision.

## Exercise 3 · Install yours (10 minutes)

Each member installs the business-type pack that fits (`agency`, `saas`, `consulting`,
`professional`, `local`, `ecommerce`, `creator`) and the starter they chose in Session 1.
Members between two starters install the one closest to their worksheet's top three items.

## Demo C · Ten things → a department plan (15 minutes)

Use a member's worksheet (with permission). In Claude:

> turn on this starter with the department builder. Here are the ten things I want it to do: …

Walk through what comes back: each item matched to a job on the map with its skill, items that
don't match proposed as custom jobs, what each job needs first (a connector, a knowledge file,
an example), and where the owner stays in the loop. Then edit the plan live: drop one item that
isn't repeat work, merge two that are the same job, and move one that's high-risk (money, legal,
anything sent to many people) to a later week.

The rule to say: **start with jobs you can check in five minutes. Earn autonomy later.**

## Exercise 4 · Plan yours (15 minutes)

Members do the same. TAs check each plan in breakouts against three questions:

1. Is each item repeat work that happens at least monthly?
2. Can the member check the output in five minutes?
3. Does anything send, post or pay? If so, is it at `approve`?

## Checkpoint C2

- Starter installed: its setup plan `output/workforce/department-setup/<date>-starter-<id>.md`
  exists, and `bin/wf library` shows the business-type pack as installed.
- The member's own department plan (from the department builder) is saved in the same folder.
- `bin/wf backup` has pushed at least once (the repository shows today's commit).

## Common problems today

| Symptom | Fix |
|---|---|
| `git push` asks for a password | Use the credential manager or a personal access token; never paste a token into Claude |
| Install says "only a person can do it" | It was run inside an unattended session; run it in a normal terminal |
| Starter jobs don't match the member's business | Install the vertical first; it changes how every skill works; then add custom jobs |
| Member wants two departments | One now. The second is the homework after demo day. |

## Homework (email 06)

1. Finish the onboarding interview (all sections).
2. Gather for Session 3: website, a proposal, pricing, a call transcript or notes, and three to
   five pieces of your own writing. Put them in one folder.
3. Read your department plan and mark anything wrong.
4. `bin/wf backup`.

## After the session

Recording posted the same day, attendance recorded, C2 results to TAs, email 06 sent.
