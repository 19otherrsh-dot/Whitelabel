#!/usr/bin/env node
// Builds one slide deck per session from slides.json.
//
//   node build_slides.js                 writes session-01.pptx … session-06.pptx here
//   node build_slides.js --theme t.json  optional colour/font overrides (same keys as THEME below)
//   node build_slides.js --in other.json --out <dir>   build other decks with the same design
//        (each entry may set "kicker", "footer" and "file" instead of the session defaults)
//
// Needs pptxgenjs (npm install pptxgenjs). To rebrand: change "brand" and "cohort" in slides.json,
// and the colours or fonts below (or pass --theme). Slide text lives in slides.json only.
'use strict';
const fs = require('fs');
const path = require('path');
const pptxgen = require('pptxgenjs');

const HERE = __dirname;
const arg = (k) => { const i = process.argv.indexOf(k); return i > -1 ? process.argv[i + 1] : null; };
const data = JSON.parse(fs.readFileSync(arg('--in') ? path.resolve(arg('--in')) : path.join(HERE, 'slides.json'), 'utf8'));
const OUT = arg('--out') ? path.resolve(arg('--out')) : HERE;

// Site palette: ink #161618, page #F4F4F5, green #149655 / #087A45. Safe fonts so decks render the
// same everywhere (swap headFontFace for the brand's serif if it's installed on presenters' machines).
let THEME = {
  name: 'Cohort',
  headFontFace: 'Cambria',
  bodyFontFace: 'Calibri',
  colors: {
    dk1: '161618', lt1: 'FFFFFF', dk2: '4C4C54', lt2: 'F4F4F5',
    accent1: '149655', accent2: '087A45', accent3: 'DC4458', accent4: '6E6E76', accent5: 'E3F4EA', accent6: 'ECECEE',
    hlink: '087A45', folHlink: '0C6B3B',
  },
};
const ti = process.argv.indexOf('--theme');
if (ti > -1) {
  const o = JSON.parse(fs.readFileSync(process.argv[ti + 1], 'utf8'));
  THEME = { ...THEME, ...o, colors: { ...THEME.colors, ...(o.colors || {}) } };
}

// Optional: a theme writer (e.g. one that sets the file's theme colours to THEME.colors) can be
// plugged in with PPTX_APPLY_THEME=/path/to/apply_theme.js. Not needed: all colours are explicit.
let applyTheme = null;
if (process.env.PPTX_APPLY_THEME) ({ applyTheme } = require(process.env.PPTX_APPLY_THEME));

const W = 10, H = 5.625, M = 0.5;
const esc = (s) => String(s).replace(/&/g, '&amp;');
const pad = (n) => String(n).padStart(2, '0');

async function build(session) {
  const pres = new pptxgen();
  pres.layout = 'LAYOUT_16x9';
  pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
  pres.company = esc(data.brand);
  pres.author = esc(data.brand);
  pres.title = session.kicker ? session.title : `Session ${session.n} · ${session.title}`;
  // Colours are written as hex from THEME so the decks look right in any presentation app.
  const K = THEME.colors;
  const C = { text1: K.dk1, text2: K.dk2, background1: K.lt1, background2: K.lt2, accent1: K.accent1, accent2: K.accent2, accent3: K.accent3, accent4: K.accent4, accent5: K.accent5, accent6: K.accent6 };
  const footer = session.footer || `${data.brand} · Session ${pad(session.n)} · ${session.title}`;
  const sect = session.kicker ? session.title : `Session ${session.n}`;

  pres.defineSlideMaster({
    title: 'Dark title',
    background: { color: C.text1 },
    objects: [
      { placeholder: { options: { name: 'kicker', type: 'body', x: M, y: 1.15, w: 9, h: 0.4, fontSize: 14, bold: true, color: C.accent1, charSpacing: 4, margin: 0 }, text: '' } },
      { placeholder: { options: { name: 'title', type: 'title', x: M, y: 1.6, w: 9, h: 1.3, fontSize: 48, align: 'left', color: C.background1, fontFace: THEME.headFontFace, valign: 'top', margin: 0 }, text: '' } },
      { placeholder: { options: { name: 'body', type: 'body', x: M, y: 3.0, w: 7.6, h: 1.1, fontSize: 18, color: C.accent6, valign: 'top', margin: 0 }, text: '' } },
      { text: { text: esc(session.kicker ? data.brand : `${data.brand} · ${data.cohort}`), options: { x: M, y: 4.85, w: 9, h: 0.35, fontSize: 11, color: C.accent4, margin: 0 } } },
    ],
  });
  pres.defineSlideMaster({
    title: 'Content',
    background: { color: C.background2 },
    margin: [0.5, 0.5, 0.6, 0.5],
    objects: [
      { placeholder: { options: { name: 'title', type: 'title', x: M, y: 0.35, w: 9, h: 0.75, fontSize: 34, align: 'left', color: C.text1, fontFace: THEME.headFontFace, valign: 'middle', margin: 0 }, text: '' } },
      { text: { text: esc(footer), options: { x: M, y: 5.2, w: 7.5, h: 0.3, fontSize: 10, color: C.accent4, margin: 0 } } },
    ],
    slideNumber: { x: 9.0, y: 5.2, w: 0.5, h: 0.3, fontSize: 10, color: C.accent4, align: 'right' },
  });
  pres.defineSlideMaster({
    title: 'Statement',
    background: { color: C.text1 },
    objects: [
      { placeholder: { options: { name: 'title', type: 'title', x: M, y: 1.4, w: 9, h: 1.9, fontSize: 40, align: 'left', color: C.background1, fontFace: THEME.headFontFace, valign: 'bottom', margin: 0 }, text: '' } },
      { placeholder: { options: { name: 'body', type: 'body', x: M, y: 3.45, w: 9, h: 0.8, fontSize: 22, color: C.accent1, italic: true, valign: 'top', margin: 0 }, text: '' } },
      { text: { text: esc(footer), options: { x: M, y: 5.2, w: 9, h: 0.3, fontSize: 10, color: C.accent4, margin: 0 } } },
    ],
  });

  pres.addSection({ title: sect });
  const add = (master) => pres.addSlide({ masterName: master, sectionTitle: sect });
  const circle = (s, x, y, d, label, fill = C.accent1, size = 14) => {
    s.addShape(pres.shapes.OVAL, { x, y, w: d, h: d, fill: { color: fill }, line: { color: fill }, objectName: 'marker' });
    s.addText(String(label), { x, y, w: d, h: d, fontSize: size, bold: true, color: C.background1, align: 'center', valign: 'middle', margin: 0, isTextBox: true });
  };
  const card = (s, x, y, w, h, fill = C.background1) =>
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.12, fill: { color: fill }, line: { color: 'DCDCE0', width: 0.75 }, objectName: 'card' });
  const caption = (s, text, y = 4.72) => s.addText(text, { x: M, y, w: 9, h: 0.4, fontSize: 13, italic: true, color: C.text2, margin: 0, isTextBox: true });
  const mono = 'Courier New';

  for (const sl of session.slides) {
    let s;
    switch (sl.type) {
      case 'title': {
        s = add('Dark title');
        s.addText(session.kicker || `SESSION ${pad(session.n)}`, { placeholder: 'kicker' });
        s.addText(session.title, { placeholder: 'title' });  // keep title-slide titles to one line (about 26 characters)
        s.addText(session.promise, { placeholder: 'body' });
        if (!session.kicker) circle(s, 8.55, 0.5, 0.95, pad(session.n), C.accent1, 22);
        break;
      }
      case 'agenda': {
        s = add('Content');
        s.addText(sl.title, { placeholder: 'title' });
        const rows = sl.items.length, rh = Math.min(0.5, 3.75 / rows), y0 = 1.3;
        sl.items.forEach(([t, b], i) => {
          const y = y0 + i * rh;
          s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: y + 0.06, w: 0.95, h: rh - 0.12, rectRadius: 0.1, fill: { color: C.accent5 }, line: { color: C.accent5 }, objectName: 'time' });
          s.addText(t, { x: M, y: y + 0.06, w: 0.95, h: rh - 0.12, fontSize: 14, bold: true, color: C.accent2, align: 'center', valign: 'middle', margin: 0, isTextBox: true });
          s.addText(b, { x: M + 1.2, y, w: 7.8, h: rh, fontSize: 16, color: C.text1, valign: 'middle', margin: 0, isTextBox: true });
        });
        break;
      }
      case 'cards': {
        s = add('Content');
        s.addText(sl.title, { placeholder: 'title' });
        const n = sl.items.length, gap = 0.3, w = (9 - gap * (n - 1)) / n, y = 1.45, h = 3.2;
        sl.items.forEach((it, i) => {
          const x = M + i * (w + gap);
          card(s, x, y, w, h);
          circle(s, x + 0.3, y + 0.3, 0.5, i + 1);
          s.addText(it.h, { x: x + 0.3, y: y + 0.95, w: w - 0.6, h: 0.75, fontSize: 18, bold: true, color: C.text1, valign: 'top', margin: 0, isTextBox: true });
          s.addText(it.t, { x: x + 0.3, y: y + 1.7, w: w - 0.6, h: h - 1.9, fontSize: 14, color: C.text2, valign: 'top', margin: 0, isTextBox: true });
        });
        break;
      }
      case 'steps': {
        s = add('Content');
        s.addText(sl.title, { placeholder: 'title' });
        const wide = !sl.aside, lw = wide ? 9 : 5.7, n = sl.steps.length, rh = Math.min(0.6, 3.7 / n);
        sl.steps.forEach((t, i) => {
          const y = 1.3 + i * rh;
          circle(s, M, y + (rh - 0.38) / 2, 0.38, i + 1, C.accent1, 12);
          s.addText(t, { x: M + 0.55, y, w: lw - 0.55, h: rh, fontSize: 15, color: C.text1, valign: 'middle', margin: 0, isTextBox: true });
        });
        if (sl.aside) {
          s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 6.5, y: 1.3, w: 3.0, h: 2.6, rectRadius: 0.12, fill: { color: C.accent5 }, line: { color: C.accent5 }, objectName: 'aside' });
          s.addText(sl.aside, { x: 6.75, y: 1.5, w: 2.5, h: 2.2, fontSize: 14, color: C.accent2, valign: 'top', margin: 0, isTextBox: true });
        }
        break;
      }
      case 'code': {
        s = add('Content');
        s.addText(sl.title, { placeholder: 'title' });
        const ch = Math.max(1.4, 0.42 * sl.lines.length + 0.5);
        s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: M, y: 1.35, w: 5.5, h: ch, rectRadius: 0.1, fill: { color: C.text1 }, line: { color: C.text1 }, objectName: 'terminal' });
        s.addText(sl.lines.map((l, i) => ({ text: l, options: { breakLine: i < sl.lines.length - 1, color: l.startsWith('>') || l.startsWith('  ') ? 'B8E6CB' : 'FFFFFF' } })),
          { x: M + 0.25, y: 1.6, w: 5.0, h: ch - 0.5, fontFace: mono, fontSize: 13, valign: 'top', margin: 0, paraSpaceAfter: 6, isTextBox: true });
        (sl.points || []).forEach((p, i) => {
          const y = 1.35 + i * 0.75;
          circle(s, 6.35, y + 0.05, 0.36, '✓', C.accent1, 12);
          s.addText(p, { x: 6.85, y, w: 2.65, h: 0.7, fontSize: 14, color: C.text1, valign: 'top', margin: 0, isTextBox: true });
        });
        break;
      }
      case 'checkpoint': {
        s = add('Content');
        s.addText(sl.heading || `Checkpoint ${sl.code}`, { placeholder: 'title' });
        circle(s, M + 0.2, 1.55, 2.3, sl.code, C.accent1, 54);
        s.addText(sl.title, { x: 3.4, y: 1.45, w: 6.1, h: 0.7, fontSize: 24, bold: true, color: C.text1, margin: 0, isTextBox: true });
        sl.items.forEach((t, i) => {
          const y = 2.3 + i * 0.62;
          circle(s, 3.4, y + 0.07, 0.36, '✓', C.accent2, 12);
          s.addText(t, { x: 3.9, y, w: 5.6, h: 0.5, fontSize: 16, color: C.text1, valign: 'middle', margin: 0, isTextBox: true });
        });
        caption(s, sl.foot || 'Part of the setup steps for the build guarantee. Your TA records it.');
        break;
      }
      case 'table': {
        s = add('Content');
        s.addText(sl.title, { placeholder: 'title' });
        const cols = sl.head.length, colW = sl.colW || (cols === 2 ? [5.4, 3.6] : [2.4, 3.0, 3.6]);
        const rows = [sl.head.map((h) => ({ text: h, options: { bold: true, color: 'FFFFFF', fill: { color: THEME.colors.dk1 } } })),
          ...sl.rows.map((r, i) => r.map((c, j) => ({ text: c, options: { color: THEME.colors.dk1, fontFace: /^[a-z]+(-[a-z]+)*$/.test(c) ? mono : undefined, fill: { color: i % 2 ? THEME.colors.lt2 : 'FFFFFF' } } })))];
        s.addTable(rows, { x: M, y: 1.3, w: 9, colW, fontSize: 14, rowH: 0.42, border: { type: 'solid', pt: 0.75, color: 'DCDCE0' }, margin: [0.06, 0.12, 0.06, 0.12], valign: 'middle' });
        if (sl.foot) caption(s, sl.foot);
        break;
      }
      case 'compare': {
        s = add('Content');
        s.addText(sl.title, { placeholder: 'title' });
        [[sl.left, M, C.accent4, '–'], [sl.right, 5.15, C.accent1, '✓']].forEach(([side, x, col, mark]) => {
          card(s, x, 1.35, 4.35, 3.4);
          s.addText(side.h, { x: x + 0.3, y: 1.55, w: 3.75, h: 0.5, fontSize: 20, bold: true, color: col, margin: 0, isTextBox: true });
          side.items.forEach((t, i) => {
            const y = 2.2 + i * 0.6;
            circle(s, x + 0.3, y + 0.06, 0.32, mark, col, 11);
            s.addText(t, { x: x + 0.75, y, w: 3.35, h: 0.5, fontSize: 14, color: C.text1, valign: 'middle', margin: 0, isTextBox: true });
          });
        });
        break;
      }
      case 'flow': {
        s = add('Content');
        s.addText(sl.title, { placeholder: 'title' });
        const n = sl.items.length, gap = 0.35, w = (9 - gap * (n - 1)) / n, y = 1.8, h = 1.6;
        sl.items.forEach((t, i) => {
          const x = M + i * (w + gap);
          card(s, x, y, w, h);
          circle(s, x + w / 2 - 0.22, y - 0.22, 0.44, i + 1);
          s.addText(t, { x: x + 0.12, y: y + 0.35, w: w - 0.24, h: h - 0.5, fontSize: n > 5 ? 12 : n > 4 ? 14 : 16, bold: true, color: C.text1, align: 'center', valign: 'middle', margin: 0, isTextBox: true });
          if (i < n - 1) s.addShape(pres.shapes.RIGHT_ARROW, { x: x + w + 0.06, y: y + h / 2 - 0.12, w: gap - 0.12, h: 0.24, fill: { color: C.accent1 }, line: { color: C.accent1 }, objectName: 'arrow' });
        });
        if (sl.foot) caption(s, sl.foot, 3.8);
        break;
      }
      case 'homework': {
        s = add('Content');
        s.addText(sl.title || 'Before next time', { placeholder: 'title' });
        sl.items.forEach((t, i) => {
          const y = 1.35 + i * 0.66;
          circle(s, M, y + 0.08, 0.4, i + 1);
          s.addText(t, { x: M + 0.6, y, w: 5.2, h: 0.58, fontSize: 15, color: C.text1, valign: 'middle', margin: 0, isTextBox: true });
        });
        s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 6.6, y: 1.35, w: 2.9, h: 2.4, rectRadius: 0.12, fill: { color: C.text1 }, line: { color: C.text1 }, objectName: 'next' });
        s.addText([{ text: sl.nextLabel || 'NEXT', options: { fontSize: 12, bold: true, color: C.accent1, charSpacing: 3, breakLine: true } },
          { text: sl.next, options: { fontSize: 20, color: 'FFFFFF', fontFace: THEME.headFontFace } }],
          { x: 6.85, y: 1.6, w: 2.45, h: 1.9, valign: 'top', margin: 0, paraSpaceAfter: 8, isTextBox: true });
        caption(s, sl.foot || 'Stuck? Post in the community, or come to the clinic tomorrow.');
        break;
      }
      case 'statement':
      case 'closing': {
        s = add('Statement');
        s.addText(sl.text, { placeholder: 'title' });
        if (sl.sub) s.addText(sl.sub, { placeholder: 'body' });
        break;
      }
      default:
        throw new Error(`Unknown slide type: ${sl.type}`);
    }
    s.addNotes(sl.notes || (session.kicker ? session.title : `Run sheet: curriculum/session-${pad(session.n)}.md`));
  }

  const out = path.join(OUT, session.file || `session-${pad(session.n)}.pptx`);
  await pres.writeFile({ fileName: out });
  if (applyTheme) await applyTheme(out, THEME);
  return out;
}

(async () => {
  for (const s of data.sessions) console.log('wrote', path.relative(process.cwd(), await build(s)));
})().catch((e) => { console.error(e); process.exit(1); });
