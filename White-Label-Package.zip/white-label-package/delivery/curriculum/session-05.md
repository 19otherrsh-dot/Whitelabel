# Session 5 · Put it on a clock

> Turn the repeat work into workflows. Schedule them. Assign jobs from your phone, approve them
> in the morning. Agents draft, you send. Work starts running while you are not looking.
> **You leave with:** repeat work scheduled where appropriate, with approval steps and a record
> of each run.

## Outcomes

1. The department's routine jobs on schedules, each with a time, a per-run budget and quiet hours.
2. The computer's timer installed, a monthly budget set, and the pause switch understood.
3. Notifications to the member's phone or chat when something needs approval.
4. A job assigned and an approval given from the phone (**C5**).
5. The weekly review scheduled, so the chief of staff reports up every week.

## Before the session (instructor)

- [ ] Demo workspace: the starter's schedules present but switched off; no timer installed yet.
- [ ] Your phone mirrored on screen (or a second camera) for the phone demo. The Claude app signed
      in with the same account as the demo laptop. Remote Control works on Pro, Max, Team and
      Enterprise plans signed in through claude.ai, not with an API key; Team and Enterprise
      owners must switch it on first in Claude Code admin settings. Check members' plans now.
- [ ] An ntfy topic (or a Slack/Teams incoming webhook) for the notification demo.
- [ ] Slides: `slides/session-05.pptx`.

## Run sheet (120 minutes)

| Time | Block | Who | What happens |
|---|---|---|---|
| 0:00 | Recap and questions | Lead | Show `bin/wf runs --week` from a member (with permission): what ran, what was rejected, what was learned. |
| 0:10 | What deserves a clock | Lead | The four tests (below). Members pick their jobs. |
| 0:20 | Schedules | Lead + all | **Demo A** then **Exercise 1**: schedules, budgets, the timer. |
| 0:45 | Safety on a timer | Lead | **Demo B**: what unattended runs can and can't do; pause; budgets; quiet hours. |
| 0:55 | Break | | 5 minutes |
| 1:00 | Notifications | All | **Exercise 2**: ntfy, Slack or Teams. |
| 1:15 | From your phone | Lead + all | **Demo C** then **Exercise 3**: Remote Control, assign a job, approve from the phone. |
| 1:35 | The weekly review | All | **Exercise 4**: schedule the chief of staff's weekly review. |
| 1:45 | Demo-day prep | Lead | What demo day looks like and the rubric. |
| 1:55 | Close | Lead | Homework: let it run; prepare your demo. |

## What deserves a clock (the four tests)

A job goes on a schedule only if **all four** are true:

1. It happens on a rhythm (daily, weekly, month-end), not "when a client asks".
2. It has run supervised at least three times with outputs you kept.
3. Its output waits for you (it's a draft, a report, or goes to the outbox), or it's been given
   `autonomous` deliberately and within guardrails.
4. You know what it costs per run (`bin/wf runs` shows cost for unattended runs; start with a
   small per-run budget).

Good first schedules: the daily inbox triage, the Monday pipeline review, Friday client updates
(drafted, not sent), month-end numbers, the weekly content plan.

## Demo A · Schedules (10 minutes)

In Claude:

> set up my weekly routine for the outreach department

The autopilot skill proposes schedules in plain words, with budgets. Accept two. Then:

```
bin/wf autopilot list                        # in plain words, with next run
bin/wf autopilot enable <name>               # starter schedules arrive switched off
bin/wf autopilot run <name>                  # run one now, to see it work
bin/wf autopilot install                     # the computer's timer, every 5 minutes
```

Point out: times are in the workspace time zone; the computer has to be awake (missed runs
catch up once, up to a day late); the timer is launchd on Mac and Task Scheduler on Windows.

## Exercise 1 · Your schedules (15 minutes)

Each member puts **one to three** jobs on a schedule, runs one now with `autopilot run`, and
installs the timer. Set the monthly budget: *"set my monthly AI budget to $<amount> and $<amount>
per run"* (`workspace.json → budgets`). `bin/wf budget` shows spend so far.

## Demo B · Safety on a timer (10 minutes)

Show `bin/wf runs --days 1` for the run you just did, then what it was not allowed to do:

- Unattended runs **cannot** send, post, pay, refund, delete, share or book unless the job is
  `autonomous` and within guardrails. Money movement, deletion and browser actions always need a
  person, even then.
- Unattended runs can't approve their own work, change their own permissions, install library
  packs or edit the safety files.
- Guardrails: sends per day, recipients per action, quiet hours, the suppression list.
- The stop button: `bin/wf autopilot pause` stops all unattended work at once (`resume` to restart).
  The console has the same switch.

Say: **agents draft, you send.** That doesn't change because there's a clock.

## Exercise 2 · Notifications (15 minutes)

> send me a notification when something needs my approval

The autopilot skill sets `autopilot.notifyChannel` (`ntfy`, `slack` or `teams`). The member stores
the webhook or topic address themselves:

```
bin/wf secrets set WF_NOTIFY_URL
bin/wf notify "test from my workspace"
```

ntfy is the quickest for a phone: install the ntfy app, subscribe to a hard-to-guess topic name,
and use `https://ntfy.sh/<topic>` as the address. Treat the topic name like a password.

## Demo C and Exercise 3 · From your phone (20 minutes)

On the laptop, in the workspace:

```
bin/wf start --remote-control "Workforce"
```

(`bin/wf start` passes options to Claude Code. In an open session, `/remote-control` does the
same.) Scan the QR code or open the session in the Claude app.

From the phone:

1. Assign a job: *"draft tomorrow's follow-ups for this week's positive replies"*.
2. Approve: *"what's waiting in my outbox?"*, then *"approve <id>"*. Approving is the owner's
   decision, so Claude asks you to confirm; tap to allow on the phone.

What to say about the limits: the session runs on the laptop, so the laptop must be on and the
session open; if it sleeps, it reconnects when it wakes. This is a window onto your machine,
not a copy of it in the cloud.

Members whose plan doesn't support Remote Control: use notifications plus approving at the
laptop, or the console's Approvals screen, and note it for the support call.

## Exercise 4 · The weekly review (10 minutes)

> every Friday at 4pm, have the chief of staff run the weekly review

The weekly review reads the run log, outbox and dashboards across departments and writes a
one-page report: what ran, what was approved or rejected, hours saved, cost, what to change.
It's the habit that keeps the department improving after the cohort.

## Demo-day preparation (10 minutes)

Walk through `../demo-day-rubric.md` on screen. Each member gets **five minutes** on demo day:

1. One sentence: the department and the bottleneck it takes off you.
2. Run one job live, end to end, on your business.
3. Show the outbox item and approve or reject it.
4. Show the map, the run log and the dashboard.
5. One thing you changed because of a lesson.

The instructor then stress-tests it (a missing field, a weird input, a tool briefly offline) and
fixes what breaks with the room.

## Checkpoint C5

- At least one schedule enabled that has run at least once (`bin/wf autopilot list`, `bin/wf runs`).
- The timer installed and the monthly budget set.
- One approval given away from the laptop (Remote Control, or recorded as not available on the
  member's plan with the alternative used).

## Common problems today

| Symptom | Fix |
|---|---|
| Schedule never runs | Timer not installed, computer asleep, or workspace paused: `bin/wf autopilot list` says which |
| Mac asks for permissions after timer install | Allow the terminal/launchd prompt; re-run `bin/wf autopilot install` |
| Windows timer installed but nothing runs | The account must be logged in; check Task Scheduler for the task's last result |
| Remote Control says not available | API-key login, plan, or Team/Enterprise toggle off. Use notifications + console |
| "Unattended runs cannot …" in a run | Working as designed. The action is in the outbox |
| Budget stops a run | Raise the per-run budget only if the run's output was worth it |

## Homework (email 09)

1. Let the schedules run. Every morning: approve or reject with reasons.
2. Prepare your five-minute demo. Pick the job you'll run live and test it twice.
3. Read the rubric. If anything in it is red for you, book the clinic.
4. `bin/wf backup`.

## After the session

Recording posted the same day, attendance and C5 recorded, email 09 sent. TAs review the
checkpoint sheet: anyone missing two or more checkpoints gets a personal call before demo day.
