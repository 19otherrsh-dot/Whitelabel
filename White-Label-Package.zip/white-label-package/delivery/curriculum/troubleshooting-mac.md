# Troubleshooting on a Mac

For teaching assistants and members. Work top to bottom; most problems are in the first table.
Before anything else, ask the member to run this in Terminal **from the workspace folder** and
read you the output (never a screenshot of their keychain or a key):

```
bin/wf doctor --problems
```

`doctor` names each failing check and how to fix it. `bin/wf doctor --fix` repairs what it safely
can. To open Terminal in the folder: Finder → right-click the folder → Services → New Terminal at
Folder (or drag the folder onto the Terminal icon).

## Installing

| What the member sees | Cause | Fix |
|---|---|---|
| "Install on Mac.command can't be opened because it is from an unidentified developer" / "Apple could not verify…" | macOS Gatekeeper on a downloaded file | Right-click the file → **Open** → **Open**. If there's no Open button: System Settings → Privacy & Security → scroll to the message → **Open Anyway**. Or in Terminal: `bash setup/install.sh` |
| The window opens and closes at once | Run from inside the zip preview, or the folder is read-only | Unzip fully (double-click the zip), move the folder to `Documents/Workforce`, run again |
| "Permission denied" running `bin/wf` | Execute bit lost when copying | `chmod +x bin/wf setup/install.sh`, or use `node bin/wf.mjs …` |
| "Node.js is not installed" / "too old" and no Homebrew | Node missing | Install the **LTS** `.pkg` from https://nodejs.org, then **open a new Terminal window** and run the installer again |
| `brew install node` fails | Homebrew outdated or not set up for this user | `brew update`, then retry; or use the nodejs.org installer instead |
| "The Claude Code installer failed" | Network, proxy or a corporate device policy | Retry on another network; check https://code.claude.com/docs/en/setup; on a managed laptop, ask IT. Meanwhile the member can use the Claude desktop app's Code tab on the folder |
| `claude: command not found` after installing | Terminal opened before `~/.local/bin` was added to PATH | Open a **new** Terminal window. Still missing: `~/.local/bin/claude --version`; if that works, add it to PATH: `echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.zshrc` and open a new window |
| "git not found" | Command Line Tools not installed | `xcode-select --install` (about 10 minutes); git is optional on day one |
| Folder is in iCloud Drive (Desktop & Documents sync on) | Synced folders lock files and evict them to the cloud | Move the workspace to a folder outside iCloud, e.g. `~/Workforce`, then re-run the installer |

## Signing in

| What the member sees | Fix |
|---|---|
| Browser sign-in doesn't open | Copy the URL the terminal prints into the browser |
| Signed in to the wrong Claude account | In Claude Code: `/logout`, then `/login` with the right account |
| "Your plan doesn't include Claude Code" | Claude Code needs a paid plan (Pro, Max, Team, Enterprise) or a Console account |
| Team/Enterprise account: features missing | An owner may need to enable Claude Code or Remote Control in the organisation's admin settings |

## Running

| What the member sees | Fix |
|---|---|
| `doctor`: approval guard failing | The `.claude/` folder is missing (hidden files not copied). Re-unzip the kit; press Cmd+Shift+. in Finder to see hidden files |
| `doctor`: knowledge gaps | Expected until Session 3 |
| `doctor`: connector needs a key | Expected until Session 4. `bin/wf secrets set NAME` |
| Keychain prompt "node wants to use your confidential information" | Click **Always Allow** for the workspace's own keys. It's how `bin/wf start` loads them |
| `bin/wf serve`: port in use | `bin/wf serve --port 4801` |
| A console button fails with "Missing or wrong X-WF-Token" | `serve` was restarted, so the open tab has an old session token. Reload the page |
| The map is blank | Hard refresh (Cmd+Shift+R). The map file loads only from `bin/wf serve`, not by double-clicking it with a strict browser |
| Claude says it can't run a command | The approval guard is asking. Read the prompt; owner decisions (approve, autonomy, secrets, installs) need your OK |

## Autopilot (Session 5)

| What the member sees | Fix |
|---|---|
| Schedules never run | `bin/wf autopilot list`: is the timer installed, the schedule enabled, the workspace paused? The Mac must be awake |
| Runs fail with "claude not found" | The timer doesn't see the PATH: set `WF_CLAUDE_BIN` to the full path (`which claude`) and reinstall: `bin/wf autopilot uninstall && bin/wf autopilot install` |
| Mac asks about background items | Allow it in System Settings → General → Login Items → Allow in the Background |

## Escalate when

- The installer fails twice on a clean network: collect the full installer output (Terminal → Edit
  → Select All → copy) and the `doctor` output, and open a support ticket.
- Anything looks like a key or password in the output: **stop, don't copy it**, and ask the member
  to remove it.
