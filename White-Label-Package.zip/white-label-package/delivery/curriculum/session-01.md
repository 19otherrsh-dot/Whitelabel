# Session 1 · Foundations

> Watch a finished department run, then follow the guided setup on your laptop. Use the
> onboarding interview to start your company knowledge files and choose the first bottleneck.
> **You leave with:** the kit installed, your context built, your department chosen, and
> homework: the ten things it will do for you.

## Outcomes

By the end, every member has:

1. The kit unzipped in a folder they'll keep, installed, and `bin/wf doctor` passing (**C1**).
2. Claude Code signed in to their own Claude account.
3. Started the onboarding interview (company and offers at least).
4. Chosen one first department and written it down.

## Before the session (instructor)

- [ ] Kit release zip uploaded to the member area and tested from a fresh download that morning.
- [ ] Demo laptop, **demo workspace**: `bin/wf demo load` done (sample runs, outbox items and
      dashboard data, clearly marked as samples) and `bin/wf library install example growth-agency`
      done. A second, **empty workspace** for showing the installer and first run. Screen font
      at 18pt or larger.
- [ ] `bin/wf doctor` on the demo laptop passes. Notifications off. Real email and chat closed.
- [ ] Breakout rooms: one "Mac" and one "Windows" room per TA. Producer has the room list.
- [ ] TAs have the troubleshooting guides open and the checkpoint sheet (name, C1, notes).
- [ ] The member list with seat type; VIPs flagged (their first 1-on-1 is booked this week).
- [ ] Slides: `slides/session-01.pptx`.

## Run sheet (120 minutes)

| Time | Block | Who | What happens |
|---|---|---|---|
| 0:00 | Welcome | Lead | Who we are, how the two weeks work, how to get help (chat → TA → breakout), recording notice, the three ground rules (nothing real is sent during sessions; never share a key; the guarantee needs live attendance and the checkpoints). |
| 0:10 | The finished department | Lead | **Demo A** below: a working outbound department on Pellmark Growth. 12 minutes, then 3 for questions. |
| 0:25 | What you're installing | Lead | The folder is the product: `knowledge/`, skills, `outbox/`, `runs/`, map, console. Two minutes on the approval rule. |
| 0:30 | Guided install | Lead + TAs | **Exercise 1.** Everyone installs together, Mac and Windows in parallel, from the member-area download. TAs watch chat and pull anyone stuck into a breakout. |
| 0:55 | Checkpoint C1 | TAs | Everyone runs `bin/wf doctor --problems`. TAs record pass or the problem. |
| 1:00 | Break | | 5 minutes. Stuck installs continue in breakouts. |
| 1:05 | The interview | Lead | **Demo B**: start the onboarding interview on the empty workspace (3 minutes), then **Exercise 2**: everyone starts theirs. |
| 1:35 | Choose your first department | Lead | The five first-department choices and how to pick (**Exercise 3**). Members post their choice in chat. |
| 1:50 | Homework and close | Lead | The ten things worksheet, what to bring to Session 2, the clinic time, questions. |
| 2:00 | End | | Recording stops. TAs stay 15 minutes for anyone still installing. |

## Demo A · A finished department (12 minutes)

Show, don't explain. Keep the terminal and the console side by side. Everything on screen is
sample data or the fictional Pellmark Growth; say so once at the start.

1. In the demo workspace: `bin/wf status`. Point at departments live, runs this week, hours
   saved and the outbox count.
2. `bin/wf serve` and open the console. **Workforce Map**: the Sales department's lit jobs.
   Click one lit node: which skill does it, what it needs first, who stays in the loop.
3. **Approvals**: open a queued item. Show the draft, the recipients and the limits it will be
   held to. Reject it with a reason ("too long, cut to 80 words"). Say: *the reason becomes a
   lesson the skill reads every time it runs.*
4. Switch to the agency example: `bin/wf clients use example-growth-agency`, then `bin/wf start`
   and say *"prep me for my call with Tillwater tomorrow"*. While it works, open
   the example's `knowledge/offers.md` and `knowledge/voice.md` (under `clients/example-growth-agency/`) to show what it's reading. When it finishes,
   open the brief in `output/` and the new line in `bin/wf runs --days 1`.
5. Close on the map: *"a node lights when the job actually ran. Not installed. Earned."*
   Then `bin/wf clients use none`.

If anything fails live, say what you're doing to fix it. It's the most useful thing they'll see.

## Exercise 1 · Install (25 minutes)

On screen, step by step, and pasted into chat:

1. Download the kit from the member area. Unzip it into `Documents/Workforce` (Mac) or
   `Documents\Workforce` (Windows). Not the Downloads folder, not a synced cloud folder.
2. **Mac:** double-click **Install on Mac.command**. If macOS blocks it: right-click → Open → Open.
   **Windows:** double-click **Install on Windows.bat**. If SmartScreen appears: More info → Run anyway.
3. Answer the installer's questions. Say yes to Node.js and Claude Code if it offers them (and
   to Git for Windows). Fill in the short business questions (company, website, name, email,
   time zone, currency, tools). When it asks to **install the autopilot timer, answer No**: we
   switch it on in Session 5.
4. When it finishes, open a **new** terminal window in the folder and run `bin/wf doctor --problems`
   (Windows: `bin\wf doctor --problems`).
5. Sign in to Claude Code: `claude`, then follow the sign-in. Use the member's own account.

TAs: the most common problems and fixes are in `troubleshooting-mac.md` and
`troubleshooting-windows.md`. Anything not fixed in 10 minutes moves to the clinic, so the
member can keep up with the session on the recording.

## Demo B and Exercise 2 · Start the interview (30 minutes)

Demo on the empty workspace:

```
bin/wf start
> run the onboarding interview
```

Show that Claude asks for the website first and reads it, then asks short questions. Show that
answers can be typed or dictated, and that it's fine to say "I don't know yet".

Members then start their own. Goal for today: **company and offers** sections done. Ask them to
point it at their website and drop in one proposal or price list if they have it to hand.

> Tip to say out loud: the interview is better with three to five emails or posts you've written
> yourself. Find them before Session 3.

## Exercise 3 · Choose your first department (15 minutes)

Show the five first-department choices from the site and the library starters behind them:

| If your bottleneck is… | Starter |
|---|---|
| Not enough first conversations | `outreach` |
| Posting consistently | `content` |
| Client delivery (kickoffs, updates, recaps) | `delivery` |
| Inbox, invoicing, month-end | `admin` |
| Slow replies to leads and customers | `replies-support` |

Agency, creator and team starters exist too (`bin/wf library`). The rule for choosing:
**the repeat work you'd pay someone to take off you this month, that you can check in five
minutes.** Not the most impressive department; the most useful one.

Members who took the free audit: their result already suggests one. Members who can't decide
can run *"run the workforce audit"* as homework; it ranks the options.

Each member posts in chat: *"My first department is ___ because ___."* TAs note it.

## Checkpoint C1

`bin/wf doctor --problems` shows no failures, except connectors not yet set up and knowledge
gaps (both expected today). Recorded per member by the TA.

## Common problems today

| Symptom | Likely cause | Fix |
|---|---|---|
| Installer closes instantly (Mac) | Quarantine on the downloaded file | Right-click → Open; or `bash setup/install.sh` in Terminal |
| `claude: command not found` | Terminal opened before install finished | Open a new terminal window |
| Doctor fails "approval guard" | Folder opened from inside the zip | Unzip fully, then run the installer again |
| Sign-in loops | Browser blocked the pop-up, or signed in to a different Claude account | Copy the URL the terminal prints into the browser of the right account |
| Workspace in OneDrive/iCloud | Sync locks files | Move the folder to a non-synced location, then re-run the installer |

## Homework (send with email 05)

1. Finish the interview's company and offers sections if you didn't.
2. Fill in the **ten things worksheet** (`ten-things-worksheet.md`): ten pieces of repeat work
   your first department should do, each with how often, how long, and how you'd check it.
3. Collect for Session 3: your website, one proposal, your pricing, one call transcript or
   notes, and three to five emails or posts you wrote yourself.
4. Run `bin/wf backup` once.

## After the session

- Producer posts the recording the same day (`../support/community.md` has the steps).
- Attendance recorded (back end: `/admin/cohorts` → Attendance; or the sheet).
- C1 results shared with TAs; anyone without C1 gets a personal clinic invite.
- Email 05 (recording + homework) goes out.
