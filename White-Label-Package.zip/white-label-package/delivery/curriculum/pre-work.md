# Before Session 1 (pre-work)

Sent with email 02 about a week before the cohort. Thirty minutes, and it makes Session 1 smooth.

## 1. Check your computer (5 minutes)

- A Mac on macOS 13 or newer, or a PC on Windows 10 (version 1809 or newer) or Windows 11.
- You can install software on it. Work laptops sometimes block this: check with IT now, not on
  the day.
- At least 2 GB free disk space.
- A webcam and microphone are welcome but optional.

## 2. Your Claude account (10 minutes)

- A paid Claude plan (Pro, Max, Team or Enterprise), or an Anthropic Console account. It's paid
  separately to Anthropic; your plan and usage decide the cost.
- Sign in at claude.ai and check it works. On a Team or Enterprise plan, ask your admin whether
  Claude Code and Remote Control are switched on for you.
- Install the Claude app on your phone and sign in with the same account (used in Session 5).

## 3. Download the kit (5 minutes)

Sign in to your member area and download the kit. **Don't install it yet**: we do it together in
Session 1 so nobody gets stuck alone. If you want to look inside, unzip it and open `README.md`.

Then run the **computer check**: unzip the kit into `Documents/Workforce` and double-click
**Check my computer (Mac).command** or **Check my computer (Windows).bat**. It installs and changes
nothing; it checks your system, disk space, the folder's location, the software, and that your
network can reach Claude. If it ends with **NOT READY**, reply to the welcome email with the
`computer-check.txt` file it saved (no passwords or keys in it) and we'll sort it out before
Session 1. **READY with warnings** is fine: the installer handles missing software.

## 4. Gather your material (10 minutes, add to it over the week)

Make one folder called **for-claude** and put in it:

- Your website address (just write it in a text file).
- One recent proposal or quote.
- Your price list or rate card.
- One call transcript or your notes from a sales or client call.
- Three to five things you wrote yourself: emails, posts, a client update. Real ones, including
  casual ones. Voice matching depends on them.

Remove anything you'd never want an assistant to see. Don't include passwords or bank details.

## 5. Think about your first department

Read the five choices (outreach, content, delivery, admin, replies and support) on the How it
works page. If you took the free audit, look at its suggestion. Come with a first guess; we'll
decide in Session 1.

## The two weeks

- Six sessions of two hours, live, recorded the same day.
- One to two hours of homework between sessions.
- The build guarantee needs you to attend all six **live** and complete the setup steps. If you
  know you'll miss a session, tell us now.
