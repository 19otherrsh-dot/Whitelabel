# Troubleshooting on Windows

For teaching assistants and members. Work top to bottom. First, ask the member to open a terminal
**in the workspace folder** (File Explorer → open the folder → type `cmd` or `powershell` in the
address bar → Enter) and run:

```
bin\wf doctor --problems
```

`doctor` names each failing check and how to fix it. `bin\wf doctor --fix` repairs what it safely
can.

## Installing

| What the member sees | Cause | Fix |
|---|---|---|
| "Windows protected your PC" (SmartScreen) | Downloaded file | **More info → Run anyway** |
| The window flashes and closes | Run from inside the zip, or blocked by policy | Right-click the zip → **Extract All** to `Documents\Workforce`, then run **Install on Windows.bat** from the extracted folder. If it still closes: open PowerShell in the folder and run `powershell -ExecutionPolicy Bypass -File setup\install.ps1` to see the message |
| "running scripts is disabled on this system" | PowerShell execution policy | Use the `.bat` (it bypasses for this script only), or the command above. Don't change the machine-wide policy |
| "winget is not recognized" | Older Windows 10 or App Installer missing | Install Node.js LTS from https://nodejs.org (the `.msi`) and Git from https://git-scm.com, then **close and reopen** the terminal and run the installer again |
| "Node.js 18.17+ still not found" after installing | PATH not refreshed in that window | Close every terminal window, open a new one, run the installer again. Still failing: sign out of Windows and back in |
| "The Claude Code installer failed" | Network, proxy, antivirus or a managed device | Retry on another network; check https://code.claude.com/docs/en/setup; on a work laptop, ask IT to allow it. Meanwhile, use the Claude desktop app's Code tab on the folder |
| `'claude' is not recognized` | New PATH not loaded | Close and reopen the terminal. Then `claude --version` |
| Antivirus quarantines a file in the kit | Heuristic flag on scripts | Restore it and add the workspace folder as an exclusion, only if the member's IT policy allows; otherwise escalate |
| Folder is in OneDrive (Documents often is) | Sync locks and "files on demand" | Move the workspace to `C:\Users\<name>\Workforce` (not synced), run the installer again |
| Path too long errors | Deep folder path | Keep the workspace near the top of the drive, e.g. `C:\Users\<name>\Workforce` |

## Git for Windows

Claude Code on Windows works best with Git for Windows installed (it uses its Bash shell), and
backups need git. If the installer skipped it: `winget install --id Git.Git -e`, or download it from
https://git-scm.com. Accept the defaults, including the Git Credential Manager (used for backups in
Session 2).

## Signing in

| What the member sees | Fix |
|---|---|
| Browser doesn't open | Copy the URL the terminal prints into the browser |
| Wrong Claude account | In Claude Code: `/logout`, then `/login` |
| Plan doesn't include Claude Code | Needs Pro, Max, Team, Enterprise, or a Console account |

## Running

| What the member sees | Fix |
|---|---|
| `bin\wf` not recognized | Run it from the workspace folder; or `node bin\wf.mjs <command>` |
| `doctor`: approval guard failing | The `.claude` folder wasn't extracted (some unzip tools skip dot-folders). Use Windows' **Extract All**, then re-run |
| `doctor`: knowledge gaps / connectors | Expected until Sessions 3 and 4 |
| `bin\wf secrets set` warns about DPAPI | Keys are encrypted for the signed-in Windows account; a different Windows user can't read them, by design |
| `bin\wf serve`: port in use | `bin\wf serve --port 4801` |
| A console button fails with "Missing or wrong X-WF-Token" | `serve` was restarted; reload the page |
| Firewall prompt for Node.js on `serve` | The console listens on this computer only; **Cancel** is fine, it still works locally |
| Line-ending warnings from git | Harmless. `git config --global core.autocrlf true` silences most |

## Autopilot (Session 5)

| What the member sees | Fix |
|---|---|
| Schedules never run | `bin\wf autopilot list`. Task Scheduler runs only while the member is signed in and the PC is awake |
| Task Scheduler shows "last result 0x1" | Open the task's history; usually `claude` not on PATH for the task. Set `WF_CLAUDE_BIN` to the full path (`where claude`), then `bin\wf autopilot uninstall` and `install` |
| Laptop sleeps overnight | Settings → System → Power: keep awake on charger during the hours schedules run, or schedule for working hours |

## Escalate when

- The installer fails twice on a clean network: copy the whole terminal output (right-click the
  title bar → Edit → Select All, Enter) and the `doctor` output into a support ticket.
- Any output contains a key, token or password: stop, don't copy it, ask the member to remove it.
