# Session 3 · Encode your business

> Drag in your site, a proposal, your pricing, a call transcript, the work you already do by
> hand. The system reads it, drafts your company files, reads them back and asks what it got
> wrong. Your department learns from your real examples.
> **You leave with:** your business knowledge saved and your first real run logged.

## Outcomes

1. The knowledge base complete: company, offers, customers, voice (with 3+ real examples),
   goals, policies, proof, with every remaining gap written as a specific question (**C3**).
2. The member has read their files back and corrected at least one thing.
3. The first real job in their department has run on their business and is in the run log.

## Before the session (instructor)

- [ ] Prepare a "messy" document set for the demo: a fictional company's web page, a proposal
      PDF, a price list and a call transcript (Pellmark's material works; rename nothing).
- [ ] Know which first job each member will run today. It's the first job in their starter's
      first-week plan (`bin/wf library show starter <id>`), for example ICP Definition for
      outreach or Performance Mining for content.
- [ ] Pull up members with C2 missing; TAs take them first.
- [ ] Slides: `slides/session-03.pptx`.

## Run sheet (120 minutes)

| Time | Block | Who | What happens |
|---|---|---|---|
| 0:00 | Recap and questions | Lead | Show two department plans from Session 2 (with permission), what made them good. |
| 0:10 | Why the knowledge base matters | Lead | **Demo A**: the same job with an empty knowledge base and a full one. |
| 0:20 | Feeding it your documents | Lead | **Demo B**: research-first mode on the demo document set. |
| 0:35 | Your turn | All | **Exercise 1**: members feed their documents and finish the interview. TAs float. |
| 1:00 | Break | | 5 minutes |
| 1:05 | Read-back | Lead + all | **Exercise 2**: the read-back. Everyone corrects at least one fact. |
| 1:20 | Voice | Lead + all | **Exercise 3**: voice samples and the voice test. |
| 1:35 | First real run | All | **Exercise 4**: run the first job of the department, review it, log it. |
| 1:50 | Homework and close | Lead | Run two more jobs; reject with reasons; prepare tool logins for Session 4. |

## Demo A · Empty versus encoded (10 minutes)

In the empty workspace: *"write a cold email to a head of operations at a 40-person logistics
company"*. Read it out. It's generic.

In the Pellmark example (`bin/wf clients use example-growth-agency`, new session): the same
prompt. Point at what changed and where it came from: the segment and trigger from
`customers.md`, the offer and its price rules from `offers.md`, banned phrases from `voice.md`,
the proof it may quote from `proof.md`. Then ask it to quote a result marked "not for use" and
let it refuse.

Say: **the agents are only as good as what's in `knowledge/`. Today is the most important
session of the six.**

## Demo B · Research first, then fill gaps (15 minutes)

Put the demo documents in one folder (for example `~/Desktop/for-claude`). In Claude:

> run the onboarding interview in research-first mode. Read my website, and these documents:
> ~/Desktop/for-claude

(Members can also drag a file into the terminal to paste its path.)

Show: it says what it will read before reading; summarises what it learned in one paragraph and
asks for corrections; asks only about gaps; flags contradictions ("your site says from $2,000,
the proposal says $2,400; which is right?"); and writes `TODO (owner to confirm: …)` instead of
guessing.

## Exercise 1 · Feed yours and finish the interview (25 minutes)

Members run the same on their own documents and answer the remaining questions. TAs watch for:

- Members pasting **customer personal data** wholesale (a CRM export, a client's contract).
  Stop them; summarise instead.
- Members pasting **keys or passwords** into chat. Stop them; `bin/wf secrets set` in Session 4.
- Members accepting everything without reading. That's what the read-back fixes.

## Exercise 2 · Read-back (15 minutes)

> show me the one-screen summary of each knowledge file, starting with offers

Everyone must change at least one thing, and post in chat what it got wrong. (It always gets
something wrong: a price, an exclusion, who they don't serve.) Corrections are made by asking
Claude ("our setup fee is $500, not $750"), so the change log records them.

Then: `bin/wf status` shows the knowledge gaps left. Each remaining gap should read as a question
with an owner. Blanks are not allowed.

## Exercise 3 · Voice (15 minutes)

1. Members save their three to five samples: *"add these to my voice examples"* and paste or
   point to them. Other people's names and details get stripped.
2. The voice test. Ask for something short in their voice ("a two-line reply to a customer asking
   for a discount"). Members score it 1 to 5 in chat. Anything below 4: tell Claude exactly
   what's wrong ("I never say 'reach out'"; "shorter sentences"); it updates `voice.md`.

## Exercise 4 · The first real run (15 minutes)

Each member runs the first job of their starter's first-week plan on their own business. For
example:

| Starter | Day 1 job (from the starter) | Say |
|---|---|---|
| outreach | ICP Definition | *"run ICP Definition for our first segment"* |
| content | Performance Mining | *"mine what worked in our last 90 days of posts"* (paste or export them if the platform isn't connected) |
| delivery | Transcript Processing | *"process the transcripts of my last two calls with <client>"* |
| admin | Email Triage | *"triage the last two weeks of my inbox, read-only"* (Session 4 connects email; today use exported emails or skip to Payment Tracking from an invoice CSV) |
| replies-support | Inbox / Ticket Triage, then FAQ drafts | *"draft answers to our ten most common questions"* |
| Other starters | The first line of `firstWeek` | `bin/wf library show starter <id>` |

Jobs that need a tool not connected yet run on files today: an export, a CSV or pasted text.

Then: review the output in `output/`; if anything's wrong, say so with a reason (it becomes a
lesson); and check `bin/wf runs --days 1` shows the run.

## Checkpoint C3

- The interview is finished: `bin/wf status` shows no knowledge files with unexplained gaps
  (explicit owner questions are fine).
- At least three writing samples in `knowledge/examples/`.
- At least one run logged on the member's own business (`bin/wf runs`).

## Common problems today

| Symptom | Fix |
|---|---|
| "I can't read that PDF" | Scanned PDF without text. Ask for the original document, or paste the key parts |
| The website can't be read | Site blocks automated reading. Paste the important page text instead |
| Every output sounds the same | Too few or too formal samples. Add real emails, including casual ones |
| The interview restarts from scratch | It saves after each section; say "continue the onboarding interview" |
| Prices or claims wrong in outputs | Fix them in `offers.md` / `proof.md` by asking Claude; never in the output |

## Homework (email 07)

1. Run two more jobs from your first-week plan. Reject anything that's wrong, with a reason.
2. Make a list of the tools your department needs (from the plan's "connect" section). Make sure
   you can sign in to each, as an admin where needed. **Don't share any password with anyone.**
3. If a tool isn't available, decide what file will replace it (a CSV export, a folder of PDFs).
4. `bin/wf backup`.

## After the session

Recording posted the same day, attendance and C3 recorded, email 07 sent. The lead instructor
reads the C3 sheet and invites anyone without a logged run to the clinic personally.
