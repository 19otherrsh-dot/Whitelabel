# The ten things worksheet (Session 1 homework)

Your first department should take repeat work off your plate. Write down ten pieces of work it
should do for you. Be concrete: "write the Friday client update for each retainer client", not
"help with clients".

**My first department:** ______________________  **The bottleneck it removes:** ______________________

| # | The work, in one line | How often | Time it takes me now | How I'd check it in 5 minutes | Does it send, post or pay anything? |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |

**Then:**

1. Circle the three that would save you the most time *this month*.
2. Cross out anything that isn't repeat work (happens less than monthly) or that you couldn't
   check in five minutes. It can come later.
3. For each "sends, posts or pays": who should approve it, and how fast?
4. What examples could you give an assistant for the top three? (a past proposal, a good email,
   last month's report). Bring them to Session 3.

**Examples of good lines**

| The work | How often | Time now | How I'd check it |
|---|---|---|---|
| Turn call notes into a follow-up email with next steps | After every sales call (~8/week) | 15 min each | Read it, fix names and dates |
| Draft reminders for invoices 7+ days overdue | Weekly | 45 min | Check amounts against the invoice list |
| Find 50 companies that match our best-client profile | Weekly | 2 hours | Spot-check ten against the profile |
| Write the weekly LinkedIn post from a client win | Weekly | 1 hour | Read it aloud; does it sound like me? |
| Sort the inbox into needs-me, FYI and can-wait | Daily | 30 min | Look at the needs-me pile |

Post your worksheet in the community before Session 2 (remove anything confidential). Seeing other
members' lists is one of the most useful parts of the cohort.
