# Curriculum overview

**Promise (from the site):** six live sessions, one department, end to end. Each member leaves
with a working AI department on their own business, their own machine and their own tools, or
the build guarantee applies.

**Format:** two weeks, three sessions a week (the site's default is Monday, Wednesday and Friday),
two hours each, recorded and posted the same day. A free live training runs about ten days
before Session 1.

## What a member can do at the end

1. Install, update and back up the workspace on Mac or Windows, and fix the common problems
   themselves (`bin/wf doctor`).
2. Encode their business so every agent works from the same facts, offers, customers and voice,
   and correct it when it's wrong.
3. Choose a first department from real repeat work, and turn a list of "ten things" into jobs on
   the map with a skill, a prerequisite and a human checkpoint for each.
4. Connect the tools the department needs with the least access that works, or replace a tool
   with files.
5. Run the department end to end, review what it produced, approve or reject with reasons, and
   see the result on the map, the run log and a dashboard.
6. Put routine work on a schedule with budgets, quiet hours and approvals, and approve from a
   phone.
7. Show the department working (demo day) and repeat the method for the next department alone.

## The six sessions

| # | Title | The member leaves with | Guarantee checkpoint |
|---|---|---|---|
| 1 | Foundations | Kit installed and healthy, interview started, first department chosen, "ten things" homework | **C1** `bin/wf doctor` shows no failures (connectors may still be pending) |
| 2 | Your workspace | Editor and private backup repo set up, starter and business-type pack installed, department plan | **C2** Starter and business-type pack installed; department plan in `output/workforce/department-setup/`; backup pushed |
| 3 | Encode your business | Knowledge base complete and corrected, voice matched, first real run logged | **C3** Interview finished; no knowledge gaps in `bin/wf status`; one run in `bin/wf runs` |
| 4 | Deploy your department | Department running on their data and tools, visible on the map and a dashboard | **C4** Every job in the department run at least once; tools connected or replaced by files |
| 5 | Put it on a clock | Schedules with budgets and approvals, notifications, phone approvals | **C5** At least one schedule enabled and run; timer installed; budget set |
| 6 | Demo day | A working department (rubric), the next-department plan | **Rubric** in `../demo-day-rubric.md` |

The checkpoints are the "setup steps" the refund terms refer to. Teaching assistants verify
each one in the session (or in the catch-up clinic) and record it next to attendance.

## People

| Role | Ratio | Job |
|---|---|---|
| Lead instructor | 1 per cohort | Teaches, demos, runs demo day, decides guarantee questions |
| Teaching assistant (TA) | 1 per 12 to 15 members | Breakout help, checkpoint checks, chat questions, attendance |
| Producer (optional, recommended above 30) | 1 | Runs the meeting tool: rooms, recording, links, timekeeping, posting recordings |

A TA must hold at least the Associate certification (`../instructor/certification.md`).

## The demo business

All live demonstrations use **Pellmark Growth**, the fictional outbound agency in the kit
(`bin/wf library install example growth-agency`). It is fully encoded, has writing samples,
finished outputs and dashboard data, and is clearly fictional, so nothing real can be sent or
shown by mistake. The instructor also keeps a second, empty workspace to show first-run screens.

Never demo on a real client's workspace, and never on your own business with live connectors.

## Materials

| File | Use |
|---|---|
| `session-01.md` … `session-06.md` | Run sheets with the exact demo commands and prompts |
| `slides/session-0N.pptx` | One deck per session (built from `slides/slides.json` by `node slides/build_slides.js`; needs `npm install pptxgenjs`) |
| `pre-work.md` | What members do before Session 1 (sent by email 02) |
| `ten-things-worksheet.md` | Session 1 homework template |
| `troubleshooting-mac.md`, `troubleshooting-windows.md` | Install and first-run fixes |
| `../demo-day-rubric.md` | Session 6 pass/fail |
| `../emails/sequence.md` | Reminders, recordings and homework emails around each session |

## Timing rules

- Start on time. The first ten minutes are always recap and questions, so late joiners miss
  nothing they can't get from the recording.
- Every session has one break (5 minutes) near the hour.
- Every session ends with: homework, the next checkpoint, and where to get help. Never run over
  by more than five minutes; move unfinished work to the clinic.
- **Catch-up clinic:** a 45-minute open room the day after each session (TA-led) for anyone who
  missed a checkpoint. Clinic attendance does **not** count as session attendance, but completing
  a checkpoint there does count.

## Time between sessions

Members should expect 1 to 2 hours of homework between sessions. Say this at the free training
and in the welcome email, not for the first time in Session 1.
