# Session 6 · Demo day

> Show your department running end to end. We stress-test it live and fix what breaks. Then you
> learn exactly how to do the next department yourself.
> **You leave with:** a working department, or the guarantee applies.

## Outcomes

1. Every member demonstrates their department against the rubric (`../demo-day-rubric.md`), and
   the result is recorded.
2. Members who don't pass leave with a written fix plan and a date, or a clear route to the
   guarantee.
3. Everyone leaves with a plan for their second department, using the same method alone.
4. Everyone knows how support works for the next 90 days.

## Before the session (instructor)

- [ ] The demo order: members grouped by department type so the room learns from similar setups.
      With 50 members, run **parallel demo rooms** (one per instructor or certified TA, at most 12
      members a room), and bring everyone back for the last 30 minutes.
- [ ] One rubric sheet per member, pre-filled with C1 to C5 from the checkpoint sheet.
- [ ] Three stress tests ready per department type (below).
- [ ] The support-call dates for the next 90 days published in the community.
- [ ] Slides: `slides/session-06.pptx`.

## Run sheet (120 minutes)

| Time | Block | Who | What happens |
|---|---|---|---|
| 0:00 | Opening | Lead | How demo day works, the rubric, what happens if something breaks (good: we fix it live). |
| 0:05 | Demos in rooms | Room leads | Five minutes per member plus three minutes of stress test and fix. Rubric filled in live. |
| 1:25 | Back together | Lead | Patterns from the rooms: the three most common breakages and their fixes. |
| 1:35 | Your next department | Lead | The method, alone (below). |
| 1:50 | What happens now | Lead | Support calls, community, library updates, the guarantee window, feedback form. |
| 2:00 | End | | |

The timing assumes about 10 members per room. With fewer rooms, shorten to four minutes per demo.

## The demo (five minutes, the member drives)

1. One sentence: the department, and the bottleneck it takes off you.
2. Run one job live, end to end, on your own business.
3. Show what it produced and the outbox item; approve or reject it with a reason.
4. Show it on the map, in the run log (`bin/wf runs --week`) and on the dashboard.
5. One thing that changed because of a lesson or a correction.

## The stress test (three minutes, the room lead drives)

Pick one that fits the department. The point is to show the department fails safely and can be
fixed, not to make it fail.

| Department | Stress tests |
|---|---|
| Outreach | A contact on the suppression list; a list row with no email; a prospect whose site can't be read |
| Content | A topic outside the business's offers; a request to quote a result marked "not for use" |
| Delivery | A transcript with two clients mentioned; a client with no record in the CRM |
| Admin | An invoice in another currency; a duplicate invoice; an email in a language the owner doesn't use |
| Replies / support | A customer asking for a refund beyond policy; an angry message; a question with no answer in the FAQ |

What good looks like: the agent refuses, asks, or flags; nothing goes out; the fix is a change to
`knowledge/`, a lesson, or a guardrail, not a one-off edit to the output.

## Recording the result

The room lead marks each rubric line pass or fail with evidence, there and then. Results:

- **Pass**: a working department. Congratulate them by name.
- **Not yet**: one or two lines failed for reasons that can be fixed. Write the fix and a date
  (within 7 days, so the guarantee window is still open) and book a support slot.
- **Blocked**: something outside the member's control (a tool with no way to connect, an admin
  who won't approve). Record what, and what was tried. This is the case the refund terms promise
  to work around with the member.

Send the rubric to the member the same day (email 10).

## Your next department (15 minutes)

The method, which the member now runs alone:

1. `bin/wf runs --month` and the weekly review: what's working, what took the most time to check.
2. Pick the next bottleneck with the same rule: repeat work you'd pay to hand off, that you can
   check in five minutes. *"run the workforce audit"* again if unsure; it now has real run data.
3. Ten things worksheet → *"turn on the <starter> starter with the department builder"*.
4. Connect only what that department needs, read-only first.
5. Run it supervised for a week. Reject with reasons.
6. Schedule only what passes the four tests.
7. Ask in the support call if stuck.

Show the library again (`bin/wf library`) and point at the starters that usually come second:
replies-support after outreach, delivery after content, admin for almost everyone.

## What happens now (10 minutes)

- **Support:** a live support call every two weeks for 90 days (dates in the community), plus the
  support channel. Response targets are in `../support/sops.md`.
- **Library:** updates for 12 months. New releases appear in the member area;
  `bin/wf update --from <zip> --dry-run` first, then without `--dry-run`.
- **Guarantee:** if the department doesn't work, ask within 7 days after today, as the refund
  terms say. Say this plainly; it builds trust.
- **Feedback:** the form (email 10). It shapes the next cohort.
- **Results:** we'll ask in 30 days what the department did (`bin/wf outcomes`). With permission,
  that becomes the proof on the site.

## After the session

- Rubrics sent (email 10), recording posted, attendance recorded.
- Lead instructor reviews every "not yet" and "blocked" within one working day and confirms each
  member's fix plan.
- Outcomes: schedule the 30-day check-in (email 12).
