# Member and lead emails

Every email from free-training sign-up to library renewal, with timing. Placeholders are in
`{{double braces}}`. Plain text works best; keep the brand's sign-off.

**Who sends what**

- The back end (`product/backend`) sends these automatically: 01 (welcome with sign-in link), refund
  confirmations, support replies, the waitlist/training confirmations (T1, W1), and, once its email
  scheduler is switched on (admin → Emails), T2, T3, the replay part of T4, 02, 03, 04, 05–09 (when you
  add a session's recording link), 11 (from the support calls you add), 12, 13, 14a (with the renewal
  link) and 14b. Session reminders and homework use each session's own text if you add it in admin →
  Cohorts, otherwise the defaults below.
- What stays with you or your email tool (Kit, MailerLite, ActiveCampaign, HubSpot…): 10 (the
  individual demo-day result), W2 and T4's offer (marketing, consented contacts only), and anything you
  want to add. If you use the no-code route instead of the back end, send them all from your email tool. Members are transactional recipients for 01–14 (they bought a
  service; these emails deliver it). Marketing emails (T4's offer, W2, anything promotional
  after the course) go only to people with marketing consent.
- Times are in the cohort's time zone. Each email shows session times in that zone **and** links
  to the member area, which shows them in the member's own.

## Timeline

| # | When | To | Subject |
|---|---|---|---|
| T1 | On training sign-up | Registrant | You're registered: free live training |
| T2 | Day before training | Registrant | Tomorrow: {{training title}} |
| T3 | 1 hour before | Registrant | Starting in an hour (link inside) |
| T4 | 2 hours after training | Registrant | The replay, and seats for {{cohort}} |
| W1 | On waitlist sign-up | Waitlist | You're on the waitlist |
| W2 | When the next cohort opens | Waitlist (consented) | {{cohort}} is open: waitlist first |
| 01 | On purchase | Member | You're in: {{cohort}} |
| 02 | 7 days before Session 1 | Members | Before Session 1: 30 minutes of prep |
| 03 | Day before Session 1 | Members | Tomorrow: Session 1 (what to have ready) |
| 04 | 2 hours before each session | Members | Today at {{time}}: Session {{n}} |
| 05–09 | Within 3 hours after Sessions 1–5 | Members | Session {{n}} recording + homework |
| 10 | Same day as demo day | Member (individual) | Your demo-day result and what's next |
| 11 | 2 days before each support call | Members | Support call on {{date}} |
| 12 | 30 days after demo day | Members | What has your department done? |
| 13 | 10 days before support ends | Members | Your support window ends on {{date}} |
| 14a | 30 days before library ends | Members | Your library access: renew or keep what you have |
| 14b | On library end date | Members | Library access has ended (your files are yours) |

---

## T1 · You're registered: free live training

Hi {{first name}},

You're registered for **{{training title}}** on **{{date}} at {{time}} {{tz}}**.

Join here: {{join link}} (add it to your calendar: {{calendar link}})

In the hour we'll show a real AI department running on a business, how the six-session cohort
works, and how to choose your first department. Bring a question about your own business.

{{Brand}}

## T2 · Tomorrow: {{training title}}

Hi {{first name}}, a reminder that we're live tomorrow at {{time}} {{tz}}. Link: {{join link}}.
If you've taken the free AI audit, have your result open; we'll use a few in the session.

## T3 · Starting in an hour

We start in an hour: {{join link}}. See you there.

## T4 · The replay, and seats for {{cohort}}

Hi {{first name}},

Here's the replay: {{replay link}} (available for {{n}} days).

If you want to build your first department with us, {{cohort}} runs {{dates}}, {{days}},
{{time}} {{tz}}. Seats: {{pricing link}}. Enrollment closes {{close date}} or when the
{{seats}} places are filled. The build guarantee and the 3-day cooling-off are on the refunds page.

Questions? Reply to this email.

*(Only the replay paragraph goes to registrants without marketing consent.)*

## W1 · You're on the waitlist

Thanks for joining the waitlist. We'll email you when the next cohort opens, before seats go on
sale publicly. Nothing else.

## W2 · {{cohort}} is open: waitlist first

You asked to hear first. {{cohort}} runs {{dates}}. Seats open to the waitlist today and to
everyone on {{public date}}: {{pricing link}}.

---

## 01 · You're in: {{cohort}}

*(Sent by the back end with a one-time sign-in link. If you're not using it, send this.)*

Hi {{first name}},

Your {{Founding / VIP}} seat in {{cohort}} is confirmed. Thank you.

**Your member area:** {{member link}}. Session dates and links, the kit download and the setup
checklist are there.

**The sessions** ({{tz}}): {{six dates}}, {{start}} to {{end}}. Add them all to your calendar:
{{calendar link}}.

**Before then:** we'll send 30 minutes of prep a week before Session 1. You don't need to install
anything yet.

{{VIP only: Book your first 1-on-1 build session here: {{booking link}}. The best time is the week
of Session 1.}}

The 3-day cooling-off and the build guarantee: {{refunds link}}.

{{Brand}}

## 02 · Before Session 1: 30 minutes of prep

Hi {{first name}},

Session 1 is on {{date}}. Thirty minutes now makes it smooth (full list: {{pre-work link}}):

1. Check you can install software on your computer (work laptops: ask IT now).
2. Check your Claude plan works (Pro, Max, Team or Enterprise), and put the Claude app on your phone.
3. Download the kit from your member area. Don't install it yet; we do that together.
4. Make a folder called **for-claude** with your website address, a proposal, your prices, a call
   transcript or notes, and three to five things you wrote yourself.
5. Have a first guess at your first department: outreach, content, delivery, admin, or replies
   and support.

The build guarantee needs live attendance at all six sessions. If you know you'll miss one, reply
and tell us now.

## 03 · Tomorrow: Session 1

Tomorrow at {{time}} {{tz}}: {{join link}}. Have your laptop charged, the kit downloaded, and
30 minutes free after the session in case your install needs a hand (TAs stay on).

## 04 · Today at {{time}}: Session {{n}} · {{title}}

Session {{n}}, **{{title}}**, starts at {{time}} {{tz}}: {{join link}}.
Have ready: {{session-specific line, below}}.

| n | Have ready |
|---|---|
| 1 | The kit downloaded, your Claude sign-in, the for-claude folder |
| 2 | Your ten things worksheet; a GitHub (or GitLab) account |
| 3 | The for-claude folder with your documents and writing samples |
| 4 | Sign-ins for the tools your department needs (you'll type them yourself; never share them) |
| 5 | Your phone with the Claude app signed in |
| 6 | Your five-minute demo, tested twice |

## 05–09 · Session {{n}} recording and homework

Hi {{first name}},

The recording of Session {{n}} is up: {{recording link}}. Slides and notes: {{notes link}}.

**Homework before Session {{n+1}}:**
{{homework list from curriculum/session-0n.md}}

**Checkpoint:** by Session {{n+1}} you should have {{checkpoint from the session file}}. If not,
come to the clinic on {{clinic date/time}}: {{clinic link}}.

Stuck? Post in {{community}} or reply to this email.

## 10 · Your demo-day result and what's next

*(Individual. Attach or paste the member's rubric sheet.)*

Hi {{first name}},

Thank you for demo day. Your result: **{{Pass / Not yet / Blocked}}**.

{{Pass: Your {{department}} department is working. The rubric is below.}}
{{Not yet: Here's what's left and the fix we agreed: {{fix}}. Your support slot is {{date}}. We'll
re-check it then, inside the 7-day guarantee window.}}
{{Blocked: {{what}} is outside your control. Here's the alternative we agreed: {{alternative}}.}}

**What happens now**
- Support calls every two weeks for 90 days: {{dates}}. Plus {{support channel}} any time.
- Library updates for 12 months: new releases appear in your member area.
- Your second department: the method from the last 15 minutes of today ({{recording link}}).
- The build guarantee: if your department doesn't work, you can ask for a refund within 7 days
  of today, as the refund terms say: {{refunds link}}.

Two minutes for feedback? {{feedback form}}

## 11 · Support call on {{date}}

The next support call is {{date}} at {{time}} {{tz}}: {{link}}. Bring one thing that's stuck,
and if you can, `bin/wf runs --week` so we can see what your department did.

## 12 · What has your department done?

Hi {{first name}},

It's 30 days since demo day. Would you run `bin/wf outcomes` and reply with the summary (or just
the top three lines: runs, hours saved, what changed)?

It helps us improve the next cohort. With your permission, and only exactly as you say it, it may
also become a result on our site. You can say no to that and still reply.

## 13 · Your support window ends on {{date}}

Your 90 days of cohort support end on {{date}}. The last support call is {{date}}. Your files,
skills and workspace stay yours; library updates continue until {{library date}}.

## 14a · Your library access: renew or keep what you have

Your 12 months of library access and updates end on {{date}}. You keep everything you've
downloaded. To keep getting new releases: {{renewal offer and link}}.

## 14b · Library access has ended

Your library access ended today. Everything on your computer is yours and keeps working. New
releases are no longer available to download. Want them again? {{renewal link}}
