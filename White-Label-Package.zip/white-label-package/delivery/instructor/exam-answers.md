# Certification exam: answer key

Keep this file away from candidates. Accept equivalent wording.

1. **b.** Unattended runs queue anything external for a person unless the job is `autonomous` and
   within guardrails.
2. `draft` (prepare only, the default), `approve` (queue for the owner), `autonomous` (act within
   guardrails, only with a track record).
3. `CLAUDE.md` → the skill's steps → `knowledge/` → vertical notes (`knowledge/vertical.md`,
   `knowledge/vertical/<skill>.md`) → the owner's lessons (`data/feedback/lessons/<skill>.md`).
   Precedence: owner lessons > vertical notes > skill defaults. The lesson wins.
4. Delete or hide the post; tell the member (privately) to rotate the key in the tool now and store
   the new one with `bin/wf secrets set NAME`; don't copy the key anywhere; note the incident.
5. `bin/wf outbox` (alias `approvals`); `bin/wf show <id>`.
6. Exactly the sample data it loaded (dashboard samples, sample runs and outbox items); never real
   data.
7. **False.** Schedules are added switched off.
8. It's kept; the new version is saved beside it as `proposal-writer/SKILL.md.kit-new` to compare.
9. `bin/wf autopilot pause` (`resume` to restart; the console has the same switch).
10. Moving money, deletion and browser actions (and ad budget changes / refunds as money movement).
    Also: unattended runs can't approve their own work, change their own permissions or edit the
    safety files.
11. As a client: `clients/example-<id>`. `bin/wf clients use none` (then start a new Claude session).
12. `bin/wf secrets set NAME`. It's stored in the OS secure store; `bin/wf start` loads stored keys
    as environment variables for Claude and local servers.
13. Writes `TODO (owner to confirm: <what exactly>)`; never guesses.
14. `not for use` until permission is confirmed.
15. Outreach → `outreach`; content → `content`; client delivery → `delivery`; inbox, invoicing,
    month-end → `admin`; slow replies to leads and customers → `replies-support`.
16. C1 kit installed and `doctor` passing; C2 starter and business-type pack installed, plan made,
    backup pushed; C3 interview finished, no unexplained gaps, 3+ samples, one run logged; C4 every
    department job run, tools connected or replaced by files, a rejection with a reason; C5 a
    schedule enabled and run, timer installed, budget set, an approval away from the laptop.
17. **No.** The terms require attending all six live; recordings don't count. (Cooling-off and legal
    rights are unaffected.)
18. Within 3 days of purchase **and** before Session 1 starts. Full refund, no questions.
19. **B3** (usable output with no invented prices or claims).
20. Today's run plus at least one earlier run of that job on the member's business, status `done`
    or `draft`.
21. Decline: nothing goes to real prospects or customers in class. Approve only to the member's own
    address or a colleague who expects it; the real batch is approved by the member after the
    session, at a volume their domain warm-up allows.
22. `bin/wf budget`; it counts unattended runs (autopilot and dispatch). Interactive sessions are
    billed by the member's plan or API account and aren't counted.
23. A Pro, Max, Team or Enterprise plan signed in through claude.ai (not an API key; Team/Enterprise
    owners must enable it). The laptop must be on and the Claude Code session running.
24. It happens on a rhythm; it has run supervised at least three times with kept outputs; its output
    waits for the owner (or it's deliberately `autonomous` within guardrails); its cost per run is
    known.
25. A monthly outcomes report in `output/back-office/outcomes-report/`: runs, jobs live, hours saved
    and their value at the owner's rate, AI cost, approval rate, what changed. Computed from the run
    log and outbox; nothing estimated.
26. Any three: timer not installed; schedule disabled; workspace paused; PC asleep or user signed
    out; `claude` not on the task's PATH (set `WF_CLAUDE_BIN`).
27. It asks the person to confirm (an owner command). In an unattended run it would be denied.
28. Any four: picks the route (official hosted server, Claude connector, local server, Zapier/Make/n8n,
    files); asks for the least access (read-only first); signs in via the vendor (OAuth) or stores a
    key with `secrets`; tests with a harmless read; records the connection for `doctor` and the
    dashboards; re-checks the vendor's docs when the catalogue entry is old.
29. Every two weeks for 90 days (six or seven calls), 60 minutes each.
30. Example: "I can't promise a number. The audit gives an estimate with its method; after a month,
    `bin/wf outcomes` shows what actually ran, the minutes it saved and what it cost. That's the
    number to trust."

★ Safety questions: 1, 4, 10, 21.
