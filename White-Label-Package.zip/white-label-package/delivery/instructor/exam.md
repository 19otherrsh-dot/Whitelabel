# Certification exam (Part 2)

45 minutes. Kit documentation allowed (`README.md`, `docs/`, the curriculum); the answer key is not.
Pass: 80% (24 of 30) **and** every ★ safety question correct. One mark each.

1. ★ A member's job is set to `approve`. During an unattended autopilot run, the job wants to
   send an email. What happens?
   a) It sends, because the job is approved  b) It's queued in the outbox for a person
   c) It's dropped silently  d) It asks the member on their phone

2. Which three autonomy levels exist, and which is the default?

3. Name the order in which an agent reads guidance, and which source wins when the member's own
   lesson disagrees with a vertical note.

4. ★ A member pastes an API key into the community. List what you do, in order.

5. What command shows what's waiting for approval, and which shows a single item in full?

6. What does `bin/wf demo clear` remove, and what does it never touch?

7. True or false: installing a starter turns its schedules on.

8. A member edited `proposal-writer/SKILL.md`. They run `bin/wf update --from new.zip`. What
   happens to their edited file?

9. Which command stops all unattended work at once?

10. ★ Which actions can **never** run without a person, even for a job set to `autonomous`?

11. Where does an example business install, and how do you switch back to the member's own
    business?

12. A connector needs a key. What exact command stores it, and how does Claude get it at run time?

13. What does the onboarding interview do when the owner doesn't know an answer?

14. In `proof.md`, a result has no permission status. How must it be recorded?

15. What are the five Session 1 first-department choices, and which starter goes with each?

16. Name the five guarantee checkpoints (C1–C5) in one line each.

17. A member attended Sessions 1–5 live and watched Session 6's recording. Can they claim the
    build guarantee? Why?

18. What are the cooling-off conditions?

19. On demo day, the member's output quotes a price that isn't in `offers.md`. Which rubric line
    fails?

20. What must be true of B4 (runs logged)?

21. ★ During Session 4 a member wants to approve an outreach batch to 40 real prospects "to see
    it work". What do you say and do?

22. Which command shows AI spend against the budget, and which runs does it count?

23. What does Remote Control need from the member's Claude account, and what has to stay running?

24. The four tests a job must pass before it goes on a schedule.

25. What does `bin/wf outcomes` produce, and where do its numbers come from?

26. A member on Windows says schedules never run. Give three likely causes.

27. What does the approval guard do when Claude, in an interactive session, runs
    `bin/wf library install starter outreach`?

28. Name four things the connector-setup skill does when connecting a tool.

29. How often are support calls held after demo day, and for how long?

30. A member asks: "How much will this save me?" Give an honest answer you'd use in class.
