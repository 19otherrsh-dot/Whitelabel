# Instructor playbook

How to run a cohort from six weeks out to the end of support, without the original team. Read it
with `../curriculum/overview.md`, the six run sheets and `../demo-day-rubric.md`.

## The job

You're not teaching AI. You're helping each member build one department on their own business in
two weeks, safely, and leave able to build the next one alone. Every decision in the room comes
back to three things:

1. **Their business, not the demo.** Pellmark Growth is for showing; their workspace is for building.
2. **Nothing goes out without them.** Drafts and approvals the whole way through.
3. **The checkpoint, not the curriculum.** If the room is behind, cut demo time, never the
   checkpoint. Members can watch a demo later; they can't build later with you.

## Timeline

| When | What | Owner |
|---|---|---|
| **T−6 weeks** | Dates set in the back end (`/admin/cohorts`) and the site config; free training date set; meeting tool, community and email tool ready | Lead |
| T−6 weeks | Book TAs (1 per 12–15 seats) and a producer if over 30 seats. Confirm their certification | Lead |
| T−5 weeks | Free training registration open (T1–T3 emails ready) | Producer |
| T−4 weeks | Latest kit release built (`node build/release.mjs`) and uploaded; tested on a clean Mac **and** a clean Windows machine from download to `bin/wf doctor` | Lead |
| T−3 weeks | Free training delivered (below). Replay and T4 sent | Lead |
| T−2 weeks | Demo laptop prepared (see Session 1 prep). Slides updated with dates | Lead |
| T−1 week | Email 02 (pre-work). Enrollment closes per the config. Member list and seat types exported. In admin → Members, check the **Setup** column (kit downloaded, setup confirmed) and message everyone not ready | Producer |
| T−1 day | Email 03. TA briefing (45 min): run sheet, checkpoints, safety rules, escalation | Lead |
| **Sessions 1–6** | Run sheets. Clinic the day after each. Recordings same day. Attendance every time | All |
| Demo day + 1 | Every Not yet / Blocked reviewed; fix slots booked inside the 7-day window | Lead |
| Demo day + 7 | Guarantee window closes. Refund decisions done (2 working days each) | Lead + 2nd reviewer |
| +2, 4, 6, 8, 10, 12 weeks | Support calls | Lead + TA |
| +30 days | Email 12: outcomes check-in. Collect permissioned proof | Producer |
| +90 days | Support window ends; retrospective written | Lead |

## The free training (60 minutes)

| Minutes | Block |
|---|---|
| 0–5 | Who it's for; what they'll see |
| 5–20 | A department running live (Session 1's Demo A, shorter) |
| 20–35 | How to choose your first department; three audit results from attendees (with permission) |
| 35–45 | How the cohort works: six sessions, the checkpoints, the guarantee and its conditions, the cost of Claude being separate |
| 45–55 | Questions |
| 55–60 | Seats and dates; the waitlist for anyone not ready |

Say the conditions of the guarantee plainly here. Members who know them up front attend live.

## Before each session

- Read the community since the last session. Pick two worked examples (with permission).
- Read the checkpoint sheet. Anyone two checkpoints behind gets a personal message before the session.
- Run the demo once on the demo laptop. Test the meeting tool's screen share and breakout rooms.
- 15-minute TA huddle: who needs help first, which members are on Windows, who's VIP.

## In the room

**Pace.** Demos are timeboxed; build time is protected. If a demo breaks, fix it out loud for at
most two minutes, then move on and finish it in the clinic or the recording notes.

**Help.** Chat first (TAs answer), then a breakout. The lead never debugs one member's install
on the main screen for more than a minute.

**Screens.** When a member shares, ask them to close email and messages first. If a key or a
customer's personal data appears, ask them to stop sharing, and the producer cuts it from the
recording.

**Questions you'll get, and the answer:**

| Question | Answer |
|---|---|
| "Can it just send them?" | Not during the cohort. Autonomy is earned per job after a track record; money, deletion and browser actions never run on their own |
| "Will this replace my assistant / team?" | It takes repeat work off people. Someone still reviews, approves and owns the relationship |
| "How much will Claude cost me?" | Depends on plan and usage; set budgets (`bin/wf budget`) and use the routine model for routine jobs. Don't quote numbers you haven't measured for them |
| "Is my data safe?" | It lives in this folder and the tools they connect, plus Claude itself. Point to the privacy notice and how-we-use-AI page; don't improvise legal answers |
| "Can I use ChatGPT / Gemini / Cursor instead?" | The skills are in the open format and `bin/wf link-skills` lets other agents find them; only Claude Code enforces the approval guard |
| "Can you build it for me?" | We build it **with** you here; a done-for-you service is separate (if the licensee offers one) |

**Never:** promise revenue or hours; show another member's business without permission; run a
real send in class; take a member's key; let a member leave a session without knowing their next
checkpoint.

## Teaching assistants

- Certified at least Associate (`certification.md`).
- Before: troubleshooting guides open, checkpoint sheet open, breakout rooms assigned.
- During: answer chat within two minutes; pull anyone stuck for more than five minutes into a
  breakout; record checkpoints with evidence ("C4: 6/6 jobs run; HubSpot connected read-only").
- After: 15 minutes for stragglers; hand over unresolved problems to the clinic with notes.

## VIP 1-on-1s

Three private build sessions per VIP seat with the lead instructor. Suggested timing: the week of
Session 1 (business mapping and choosing the department), between Sessions 4 and 5 (connectors and
the department end to end), and after demo day (the second department). 60 minutes each, recorded
for the member only. Prepare by reading their knowledge summary and run log (they share their
screen; you don't need their files).

## Demo day

Follow `../curriculum/session-06.md` and the rubric. Room leads must have marked at least one
practice demo with another instructor before their first demo day, so marking is consistent.

## Guarantee decisions

You make them from the rubric sheet, not from memory, and never alone when the answer is no. The
published terms win over anything in this playbook. Members who don't pass deserve the same
energy as those who do: book the fix, help them get there.

## After the cohort: the retrospective (within 2 weeks of +90 days)

Write one page: attendance per session, checkpoint completion rates, demo-day results, refund
requests and reasons, the five most common support tags, members' feedback, what changes in the
curriculum next time. Send kit problems to the release backlog with steps to reproduce.

## Escalation

| Situation | To |
|---|---|
| Something was sent/paid that shouldn't have been | P1 in `../support/sops.md`, immediately |
| A member is abusive or harasses others | Remove from live spaces; the licensee decides on refund per the terms |
| A member asks for legal, tax or financial advice | Decline; suggest a qualified adviser |
| A kit bug that blocks the guarantee | The licensor's support (per the licence) with steps to reproduce; record the member as Blocked if it affects them |
