# Instructor certification

A licensee's instructors and teaching assistants are certified before they teach, so members get
the same programme whoever runs it. Certification is run by the licensor (or by a licensee's
certified Lead Instructor, if the licence allows).

## Levels

| Level | May | Requirements |
|---|---|---|
| **Associate** | Be a TA in sessions; run clinics; answer support | Parts 1–3 |
| **Lead Instructor** | Teach all six sessions; run demo day and mark the rubric; decide guarantee cases (with a second reviewer) | Associate + Parts 4–5 + shadowing |
| **Trainer** (optional) | Certify Associates within their own licensee | Lead + two cohorts taught + licensor approval |

## Part 1 · Build it yourself (practical)

On a clean machine, from the release zip, the candidate:

1. Installs the kit and gets `bin/wf doctor` passing.
2. Encodes a business: either their own, or a fictional one they write (not one of the five
   examples). Knowledge base complete, three writing samples, read-back corrections made.
3. Installs a business-type pack and a starter; makes a department plan from a ten-things list.
4. Connects at least one tool through a sandbox or test account (or uses files, with a reason).
5. Runs every job in the department, rejects at least two outputs with reasons, and shows the
   lessons in use.
6. Puts one job on a schedule with a budget, installs the timer, and receives a notification.
7. Approves an outbox item from a phone (Remote Control), or documents why their plan can't.

**Evidence:** a 10-minute screen recording following the demo-day format, plus `bin/wf runs`,
`bin/wf autopilot list` and the department plan. **Pass:** the candidate's own department passes
the demo-day rubric (B1–B6).

## Part 2 · Knowledge (written exam)

30 multiple-choice and short-answer questions (`exam.md`), 45 minutes, open kit documentation,
closed answer key. **Pass mark: 80%**, and all four safety questions (marked ★) must be correct.

**Online:** with the back end, run it from Admin → Instructors → *Invite to the written exam*. The
candidate gets a private link valid for 14 days; the 45 minutes start when they press Start and are
enforced on the server. Multiple-choice questions are marked automatically; the assessor marks the
short answers beside the key (accept equivalent wording) and the result is emailed. A pass records
Part 2 on the instructor's record. The questions and key come from `exam.md` and `exam-answers.md`
(rebuild with `node scripts/build-course.mjs` in `backend/` after editing either).

## Part 3 · Support and troubleshooting (practical)

The assessor gives five tickets drawn from the macro list and the troubleshooting guides (one P1,
one install, one connector, one skill quality, one refund request). The candidate writes the reply
and the next steps. **Pass:** P1 handled correctly (pause first, no secrets requested), at least
four of five resolved correctly, tone plain and kind.

## Part 4 · Teach-back (Lead Instructor)

The candidate teaches two 20-minute segments chosen by the assessor from different sessions, to the
assessor and at least two others acting as members, including one planned problem (a failed
install, a broken demo, a member who wants to "just send it").

| Criterion | 1 (not yet) | 3 (meets) | 5 (excellent) |
|---|---|---|---|
| Accuracy | Commands or claims wrong | Correct, follows the run sheet | Correct and anticipates the follow-up questions |
| Safety | Skips the approval rule or handles a key carelessly | States and follows the rules | Turns the safety rule into a teaching moment |
| Pace | Over time or rushed through the checkpoint | On time, checkpoint protected | Adapts to the room without losing the checkpoint |
| Handling the problem | Stalls or improvises a risky fix | Fixes it or parks it cleanly | Fixes it out loud so the room learns |
| Clarity | Jargon, unclear steps | Clear steps, plain words | Members could do it without the slides |
| Honesty | Promises results or overstates the product | Says what it does and doesn't do | Uses the outcomes report and the audit method precisely |

**Pass:** at least 3 on every criterion and an average of 3.5 or more.

## Part 5 · Marking (Lead Instructor)

The candidate marks three recorded demo-day demos with the rubric. **Pass:** their results match the
reference marking on all three, with evidence written for each line.

## Shadowing (Lead Instructor)

Assist a full cohort as a TA, then co-teach at least two sessions (one of them demo day) with a
certified Lead Instructor, who signs off.

## Keeping it current

- Certification is tied to the kit's **major version**. When a new major version ships, certified
  instructors complete a short update module (what changed, a practical on the changed parts)
  within 60 days.
- Every 12 months: teach or assist at least one cohort, or repeat Part 1.
- Certification can be suspended for a safety breach (a real send in class, mishandled member
  keys or data) or for teaching material that misrepresents the programme, pending review.

## Records

Keep for each person: level, date, kit version, assessor, the evidence and scores. Licensees list
their certified instructors in the licensee report the licence requires.

Admin → Instructors keeps these records: each part's date, assessor, score and evidence; the level
(it can't be set above what the recorded parts support); the kit major version; and the renewal date
(12 months from certification, renewed with one click when they teach or assist a cohort). It flags
renewals due within 60 days, lapsed certifications, and instructors certified on an older kit major
version who need the update module.
