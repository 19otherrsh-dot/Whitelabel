# Demo-day rubric: what "a working department" means

The refund terms promise a full refund if a member attends all six sessions live, completes the
setup steps, and doesn't leave with a working department. This rubric is the test. It's written so
that two different instructors marking the same demo reach the same answer.

The terms define a working department as: **at least one job in the chosen department runs end to
end on the member's own business and produces output they can use, with its runs logged in their
workspace.** The rubric turns each part of that sentence into something you can check.

## Part A · Eligibility (from the records, before the demo)

| # | Line | Evidence | Pass if |
|---|---|---|---|
| A1 | Attended all six sessions live | Attendance record (back end `/admin/cohorts`, or the sheet) | Six of six. Recordings and the clinic don't count |
| A2 | C1 Kit installed and healthy | Checkpoint sheet; or `bin/wf doctor --problems` now | No failures except optional connectors |
| A3 | C2 Starter installed, plan made | `output/workforce/department-setup/` | The starter's setup plan and the member's plan both exist |
| A4 | C3 Business encoded | `bin/wf status`; `knowledge/examples/` | No unexplained gaps; at least 3 writing samples |
| A5 | C4 Tools connected or replaced | `bin/wf doctor`; the plan's "connect" list | Each tool connected, or a named file used instead |
| A6 | C5 Something on a clock | `bin/wf autopilot list` | At least one schedule enabled that has run |

A2 to A6 are "the setup steps". A line missed because of something outside the member's control
(see "Blocked" below) is recorded as blocked, not failed.

## Part B · The department works (at the demo)

| # | Line | How to check | Pass if |
|---|---|---|---|
| B1 | **Runs end to end** | The member runs one job of their department live, start to finish, with no hand edits to files mid-run | The job completes and writes its output |
| B2 | **On their own business** | Look at the output and the knowledge files it used | It's about the member's real business (not the example, not demo data); `bin/wf clients list` shows no example client active |
| B3 | **Output they can use** | Ask the member: "would you use this as it is, or after a light edit (under five minutes)?" Check it against `voice.md` and `offers.md` | The member says yes, and it contains no invented facts, prices or claims |
| B4 | **Runs logged** | `bin/wf runs --week` | The job has logged runs (plural, as the terms say): today's run plus at least one earlier run on the member's business, with status `done` or `draft` |
| B5 | **Lit on the map** | Console → Workforce Map | The job's node is live or dev |
| B6 | **Safe** | Anything external is in the outbox, not sent; the stress test didn't cause anything to go out | No external action without approval |

**A working department = all of B1 to B6 pass.** Part A decides eligibility for the build
guarantee; Part B decides whether the department works.

## Results

| Result | Means | Next step |
|---|---|---|
| **Pass** | B1–B6 pass | Next-department plan; outcomes check-in in 30 days |
| **Not yet** | One or two B lines fail for a fixable reason | Written fix plan with a date inside the 7-day guarantee window; a support slot booked; re-check in the slot |
| **Fail** | B lines still fail after the fix attempt, and A1–A6 pass | The build guarantee applies: the member may ask for a full refund within 7 days of Session 6 |
| **Blocked** | A line can't be met for a reason outside the member's control (a tool with no way to connect, an admin who refuses access, a platform outage), and it was raised during the cohort | The lead instructor agrees an alternative with the member (files instead of the tool, a different first job). If none works, treat as Fail for guarantee purposes |
| **Not eligible** | A1 fails (a missed live session), or a setup step was skipped without a reason outside the member's control | The department may still work; the build guarantee doesn't apply. The cooling-off and the member's legal rights are unaffected |

## Marking notes

- **Don't mark the demo, mark the department.** Nerves and a slow laptop are not failures; a job
  that only runs when the instructor types is.
- **B3 is the member's judgement, checked by you.** If they say "usable" but it quotes a result
  that isn't in `proof.md` or a price that isn't in `offers.md`, it fails B3: they must not send it.
- **Fixing it live counts.** If something breaks and is fixed in the stress test (a knowledge
  edit, a lesson), mark the line on the state after the fix.
- **Never mark harder than the published terms.** The rubric only makes the refund terms
  checkable; if a line here ever seems stricter than `refunds.html`, the terms win.
- **Write the evidence**, not just ticks: "B4: 5 runs of List Building since Tuesday; today's at
  10:42". The refund decision is made from this sheet.
- A second instructor reviews every Fail and Blocked before the member is told.

## The rubric sheet (copy per member)

```
Member: ______________________   Seat: Founding / VIP   Department: ______________   Room lead: __________

A1 Attended 6/6 live ........ PASS / FAIL       evidence: ____________________________________
A2 C1 healthy ............... PASS / FAIL / BLOCKED  ______________________________________
A3 C2 starter + plan ........ PASS / FAIL / BLOCKED  ______________________________________
A4 C3 encoded ............... PASS / FAIL / BLOCKED  ______________________________________
A5 C4 tools or files ........ PASS / FAIL / BLOCKED  ______________________________________
A6 C5 on a clock ............ PASS / FAIL / BLOCKED  ______________________________________

Job demonstrated: ________________________________

B1 Runs end to end .......... PASS / FAIL       ______________________________________________
B2 Own business ............. PASS / FAIL       ______________________________________________
B3 Usable output ............ PASS / FAIL       ______________________________________________
B4 Runs logged (today + 1)   PASS / FAIL       ______________________________________________
B5 Lit on the map ........... PASS / FAIL       ______________________________________________
B6 Safe ..................... PASS / FAIL       ______________________________________________

Stress test used: ____________________   Outcome: ______________________________________________

RESULT:  PASS  /  NOT YET (fix by ____/____)  /  FAIL  /  BLOCKED  /  NOT ELIGIBLE
Fix plan / notes: ____________________________________________________________________________
Second review (Fail/Blocked): ______________________   Date sent to member: ___________
```
