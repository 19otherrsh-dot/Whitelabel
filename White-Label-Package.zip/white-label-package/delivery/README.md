# Delivering the cohort

Everything a licensee needs to teach, support and certify the programme without the original team.
Nothing in here names a company or a person; every brand slot is "Your Brand".

| Folder | What it is | Who uses it |
|---|---|---|
| `curriculum/` | The six live sessions: outcomes, minute-by-minute run sheets, live-demo scripts, exercises, checkpoints, homework, and a slide deck per session | Lead instructor, teaching assistants |
| `curriculum/troubleshooting-mac.md`, `-windows.md` | Fixes for every install and first-run problem we expect on 50 laptops | Teaching assistants, support |
| `demo-day-rubric.md` | The pass/fail definition of "a working department", with the evidence to check | Instructor, refund decisions |
| `instructor/` | The instructor playbook (a cohort from six weeks out to 90 days after), the certification programme and its exam | Licensee instructors |
| `support/` | Support model, response targets, triage, macros, the 90-day support calls, community and recordings set-up, and staffing maths | Support lead |
| `emails/` | Every member email from purchase to renewal, with timing | Whoever runs the email tool |
| `self-paced/` | The on-demand version of the course: modules, lesson scripts, assignments, quizzes and completion rules | Course builder |

## How the pieces fit

```
 6 weeks out        2 weeks out       Cohort (2 weeks)               90 days after          12 months
 ───────────        ───────────       ────────────────               ─────────────          ─────────
 instructor/        emails/ 01–04     curriculum/session-01…06       support/ calls every   emails/ renewal
 playbook.md        pre-work          run sheets + slides            two weeks              library ends
 (book, prepare)    setup checklist   attendance → back end          support/sops.md
                                      demo-day-rubric.md (S6)        refunds window (7 days)
```

## Ground rules that apply everywhere

1. **Nothing real is sent during a session.** Live demos run on the example business
   (`bin/wf library install example growth-agency`) or on demo data (`bin/wf demo load`).
   Members' jobs stay at autonomy `draft` or `approve` for the whole cohort.
2. **Never ask for a key, password or token.** Not in chat, not in screen share, not in a
   support ticket. Keys go in with `bin/wf secrets set NAME`, typed by the member.
3. **Claims stay honest.** We never promise revenue, hours or headcount. The audit gives an
   estimate with its method; the outcomes report (`bin/wf outcomes`) gives what actually ran.
4. **Attendance is recorded every session.** The build guarantee depends on it. If you use the
   back end, tick it in `/admin/cohorts`; otherwise keep the attendance sheet.
5. **The member owns the files.** We help them build; their workspace stays on their machine.
