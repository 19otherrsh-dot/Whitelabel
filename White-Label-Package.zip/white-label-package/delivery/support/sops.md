# Support: model, targets and procedures

What the site promises, and therefore what support must deliver:

- A private community and a WhatsApp group (or the licensee's chosen chat) throughout the cohort.
- Every session recorded and posted the same day.
- **90 days of support every two weeks after demo day**: a live support call every two weeks
  (six or seven calls), plus written support in between.
- Refund answers within **two working days** (refund terms).
- 12 months of library access and updates.

## Channels

| Channel | For | Who answers | Hours |
|---|---|---|---|
| Community (Circle, Skool, Discord or Slack) | Questions others will have; sharing wins and worksheets | TAs, instructor, members | Business days |
| Member area support form (`/member/support`) or support email | Anything private: account, billing, a stuck install with screenshots | Support lead / TAs | Business days |
| Chat group (WhatsApp Community or similar) | Announcements and quick nudges only | Producer | Posting only; questions go to the community |
| Clinic (during the cohort) | Missed checkpoints | TA | Day after each session, 45 min |
| Support calls (after demo day) | Live help, screen share, the next department | Instructor + TA | Every two weeks for 90 days |
| VIP 1-on-1s | Three private build sessions per VIP seat | Lead instructor | Booked |

Privacy for chat groups: phone numbers are personal data. In WhatsApp, use a **Community's
announcement group**, which hides members' numbers from each other (check WhatsApp's current
settings when you set it up), rather than an ordinary group, and say in the invite who can see
what. Members can opt out of the group
without missing anything; everything posted there is also in the community.

## Response targets

| Priority | Examples | First reply | Resolution target |
|---|---|---|---|
| **P1 Safety** | Something was sent, posted or paid that shouldn't have been; a key exposed; data in the wrong place | **2 business hours** (during the cohort: 1 hour) | Contained same day |
| **P2 Blocked** | Can't install, can't sign in, the department can't run, checkout or access broken | 1 business day (during the cohort: 4 hours) | Before the next session or support call |
| **P3 How-to** | "How do I…", a connector question, a skill output to improve | 1 business day | 3 business days |
| **P4 Idea** | Feature request, new skill idea | 3 business days | Logged and acknowledged |
| **Refund request** | Cooling-off or guarantee | Acknowledge 1 business day | **Decision within 2 working days** |

"Business day" is the licensee's working days in the cohort's time zone. Publish the hours.

## Triage, step by step

1. **Is anything going out or being charged that shouldn't?** → P1. Tell the member to run
   `bin/wf autopilot pause` now (stops all unattended work), then look at `bin/wf runs --days 2`
   and the outbox's `sent/` folder together. If a key may be exposed: rotate it in the tool,
   `bin/wf secrets set NAME` with the new one.
2. **Ask for the two outputs, never the secrets:** `bin/wf doctor --problems` and `bin/wf version`.
   For a skill problem, the output file and the member's prompt.
3. **Match the troubleshooting guides** (`../curriculum/troubleshooting-mac.md`, `-windows.md`).
4. **Reproduce** on the demo workspace if it's a skill or kit behaviour.
5. **Reply with the fix in steps**, and what to check after. Close only when the member confirms
   or after 5 business days without a reply (with a note that they can reopen).
6. **Log it** (tag: install / sign-in / connector / skill / autopilot / console / billing /
   refund). Anything seen three times becomes a macro and an FAQ line; anything that looks like a
   kit bug goes to the release backlog with the steps to reproduce.

## Rules

- **Never ask for or accept a password, key or token.** If a member sends one, tell them to rotate
  it, delete the message, and don't copy it anywhere.
- **No remote control of members' computers** by support staff. Screen share where the member
  drives is fine.
- **Never edit a member's knowledge base or lessons for them.** Tell them what to ask Claude.
- **Don't promise results.** Explain what the department does and what the outcomes report shows.
- **Data:** support tickets can contain business data. Keep them in the support tool only, delete
  attachments after resolution, and follow the privacy notice's retention period.

## Support calls (every two weeks for 90 days)

Format: 60 minutes, recorded for members who can't attend (recordings don't affect anything; the
guarantee window has closed by then).

| Minutes | Block |
|---|---|
| 0–5 | What changed in the latest kit release |
| 5–20 | One member's department on screen (volunteer): what's working, the weekly review |
| 20–55 | Open help, in order of the questions posted in advance |
| 55–60 | What to try before the next call |

Calls 3 and 5 include a short "second department" walkthrough. The last call covers renewal of
library access and what support looks like after the window (community only, if the licensee
offers it).

## Refund requests

Follow the published terms (`refunds.html`) exactly; the rubric (`../demo-day-rubric.md`) and the
member's records are the evidence.

1. Acknowledge within one business day (macro R1).
2. Check which window: **cooling-off** (within 3 days of purchase and before Session 1) or the
   **build guarantee** (attended all six live, setup steps done, no working department, asked
   within 7 days after Session 6). With the back end, `/member/guarantee` has already checked the
   dates and attendance.
3. Cooling-off: approve. No questions.
4. Build guarantee: read the rubric sheet. If B1–B6 failed after the fix attempt and A1–A6 passed
   (or were Blocked for reasons outside the member's control), approve. Otherwise decline with the
   specific reason and the evidence, and offer the fix call anyway.
5. A second person reviews every decline before it's sent.
6. Approve: issue the full refund in Stripe (or admin → Refunds). Access ends when Stripe confirms.
7. Consumer rights (for example the UK/EU 14-day right to cancel online services) apply in
   addition; when the law gives more, the law applies.

## Staffing and cost (plan, then measure)

These are **planning assumptions**, not data. Replace them with your own numbers after the first
cohort (tag every ticket so you can).

| Assumption for a 50-member cohort | Value to start with |
|---|---|
| TAs during the cohort | 1 per 12–15 members (4) in each session, plus the clinic |
| Written tickets during the two weeks | about 1.5 per member |
| Written tickets in the 90 days after | about 1 per member per month, falling over time |
| Average handling time | 15 minutes (installs and connectors take longer; how-tos less) |
| Support calls after demo day | 6–7 × (60 min + 30 min preparation) × instructor and one TA |

Per-cohort support hours ≈ (sessions + clinics × TAs) + (tickets × handling time) + support calls.
Divide by seats to get the support cost per seat, and keep it visible when pricing seats.

## Quality

- Each closed ticket gets a one-question rating ("Did this solve it?").
- Monthly: the top five ticket tags, time to first reply, time to resolution, refunds by reason.
- Each kit release lists which support issues it fixes.
