# Community, recordings and office hours

## Choosing the platform

Any of these works; pick the one your members already use, and one place only.

| Need | What to look for |
|---|---|
| Recordings posted the same day | Upload video, or link from a private video host |
| Private by default | Invite-only spaces; recordings not public |
| Threads, not just chat | Questions stay findable after the cohort |
| Member list per cohort | Spaces or channels per cohort, plus an all-members space |
| Events | Session and support-call calendar with reminders |

Common choices: Circle, Skool, Kajabi or another course platform with community; Slack or Discord
with recordings on a private video host. If you use the included back end, recordings can also be
linked per session in the member area (`/admin/cohorts` → Recording).

## Structure (channels or spaces)

| Space | Purpose |
|---|---|
| **Start here** | Welcome, how support works, the session calendar, code of conduct |
| **Announcements** | Producer and instructor only |
| **{{Cohort}} · Sessions** | One post per session: recording, slides, homework, checkpoint |
| **Help** | Questions. One question per thread, with `doctor` output where relevant |
| **Show your department** | Worksheets, plans, wins, outcomes (members choose what to share) |
| **Departments** | One thread per starter (outreach, content, delivery, admin, replies…) |
| **Releases** | Kit updates and what changed |

## Code of conduct (pin it)

1. Be useful and kind. Everyone here is building on a real business.
2. **Never post passwords, keys, tokens or customers' personal data.** Moderators delete them on
   sight and tell you to rotate the key.
3. What members share about their business stays in the community. Don't screenshot it elsewhere.
4. No selling to other members without being asked.
5. Advice here is not legal, tax or financial advice.

## Same-day recording workflow (producer)

1. Record to the cloud in the meeting tool, with a recording notice at the start of every session
   (it's in the slides) and in the invite.
2. Breakout rooms are **not** recorded. Say so.
3. Within three hours of the end: trim the waiting room, add chapter markers from the run sheet's
   blocks, upload to the private host, and post in the session thread with the slides and homework
   (email 05–09 links to the same post).
4. If a member's screen showed anything private (a customer name, an email address, a key), cut
   it before posting. When in doubt, cut it.
5. Attendance: export the meeting tool's attendance report before closing the meeting, and record
   it (back end `/admin/cohorts` → Attendance, or the sheet). The guarantee depends on it.

## Office hours and clinics

- **During the cohort:** the clinic the day after each session (45 minutes, TA-led) for missed
  checkpoints.
- **After demo day:** the support call every two weeks for 90 days (format in `sops.md`).
- Post the full calendar on day one so members can plan.

## After the support window

Decide before the first cohort whether alumni keep community access after 90 days, and say so on
the pricing page and in email 13. A common choice: keep read access to recordings and the community
while library access lasts (12 months); live support ends at 90 days.
