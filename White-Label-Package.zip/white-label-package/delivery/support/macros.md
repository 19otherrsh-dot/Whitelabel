# Support macros

Saved replies for the most common tickets. Edit `{{placeholders}}`; keep the tone plain and kind.
Never paste a macro without reading the ticket twice.

## S1 · Send me your doctor output

Thanks, {{first name}}. To see what's going on, could you open a terminal in your workspace folder
and run:

    bin/wf doctor --problems        (Windows: bin\wf doctor --problems)

and paste the output here? Please don't include any passwords or keys. `doctor` never prints them,
so if you see something that looks like one, leave it out and tell us.

## S2 · Install blocked on a Mac

macOS is blocking the installer because it was downloaded. Right-click **Install on Mac.command**
→ **Open** → **Open**. If there's no Open button: System Settings → Privacy & Security, scroll down
to the message about the file and click **Open Anyway**. More fixes: {{troubleshooting link}}.

## S3 · Install blocked on Windows

Windows SmartScreen is being cautious about a downloaded file. Click **More info → Run anyway**. If
the window closes immediately, right-click the zip → **Extract All**, then run the installer from
the extracted folder (not from inside the zip). More fixes: {{troubleshooting link}}.

## S4 · `claude` not found

The installer finished, but this terminal window doesn't know about Claude Code yet. Close every
terminal window, open a new one in the workspace folder and try again. Still missing? Reply with the
output of `bin/wf doctor --problems`.

## S5 · You sent us a key

Thanks for trying to help us help you, but please don't send keys or passwords to anyone, us
included. Could you:

1. Create a new key in {{tool}} and delete the one you sent (it's now been in an email/chat, so treat
   it as public).
2. Store the new one with `bin/wf secrets set {{NAME}}`. It goes into your computer's secure
   store, not into any file.

We've deleted your message on our side.

## S6 · Ask your admin (connector needs approval)

Here's a note you can forward to whoever manages {{tool}} at your company:

> I'm connecting {{tool}} to an AI assistant that runs on my own computer. It uses {{tool}}'s
> official sign-in and asks for read-only access at first; nothing is sent, posted or changed
> without my approval, and I can disconnect it at any time from {{tool}}'s settings. Could you
> approve the app "{{app name}}" for my account?

Until then, the department can work from files: export {{what}} to a CSV and put it in
`data/imports/`.

## S7 · Something was sent that shouldn't have been (P1)

Thanks for telling us straight away. First, please run:

    bin/wf autopilot pause

That stops all unattended work immediately. Then send us the output of `bin/wf runs --days 2`
and the file name in `outbox/sent/` for what went out. We'll look at it with you
{{today / within the hour}}. Nothing else will run until you `resume`.

## S8 · Output sounds generic

That usually means the knowledge base or the voice samples are thin for this job. Try:

1. *"show me what you read for that"*: check `offers.md`, `customers.md` and `voice.md` say what
   you'd say.
2. Add two or three real examples of this exact kind of writing: *"add these to my voice examples"*.
3. Reject the next draft with a specific reason ("too formal; we never say 'leverage'"). Reasons
   become lessons the skill reads every time.

## S9 · Schedule didn't run

`bin/wf autopilot list` shows the likely reason at the top: the timer isn't installed, the
schedule is switched off, the workspace is paused, or the computer was asleep. Missed runs catch up
once when the computer wakes, up to a day late. Reply with that output if it's none of these.

## S10 · Updating the kit

A new release is in your member area. To install it without touching your work:

    bin/wf update --from ~/Downloads/workforce-kit-{{version}}.zip --dry-run
    bin/wf update --from ~/Downloads/workforce-kit-{{version}}.zip

Your knowledge, data, outputs, runs, outbox, schedules and settings are never changed. Any kit
file you edited is kept, with the new version beside it as `.kit-new` to compare.

## R1 · Refund request received

Thanks, {{first name}}, we've got your refund request. We'll confirm within two working days.
{{Cooling-off: Your request is within the cooling-off period, so it's approved; the refund is
on its way to your original payment method.}}

## R2 · Refund approved

We've refunded {{amount}} to your original payment method. Depending on your bank it can take 5 to
10 working days to appear. Your access to sessions, recordings, the community and library updates
has ended. Anything you created about your own business is yours to keep. Thank you for building
with us.

## R3 · Refund declined (needs a second reviewer)

Thanks for your patience, {{first name}}. We've looked carefully at your request against the build
guarantee terms ({{refunds link}}) and your records:

{{The specific line(s) and the evidence: e.g. "Our attendance records show you joined Sessions 1,
2, 3, 5 and 6 live; the guarantee needs all six."}}

So we can't approve a refund under the guarantee. This doesn't affect your legal rights. We'd still
like your department working: {{offer: a support slot on {{date}}}}. If you think we've got
something wrong, reply and a different person will review it.
