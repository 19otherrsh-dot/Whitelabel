# White-label package: start here

**Confidential.** For you, your team and investors. Nothing in this package has been published, hosted or
uploaded anywhere. Every part is brand-free ("Your Brand") so it can be licensed to another company.

## What's in it

| Folder | What it is | Start with |
|---|---|---|
| `reports/` | The competitor report, the gap audit (96 tasks) and the **gap closure report** (where each task stands, including what the last round added) | `White-Label-Gap-Closure.docx` |
| `website/` | The marketing site, free audit, map and dashboard demos (static files; design unchanged) | `README.txt`, then `assets/config.js` |
| `workspace-kit/` | The product buyers install: the workspace kit release (90 skills, each with job playbooks; department leads; approvals, also enforced in Cursor, Codex, Gemini CLI and Antigravity; autopilot; dashboards with live data feeds; skill tests; "Check my computer"; the optional hosted runtime, installable as a phone app) | unzip, then its `README.md` |
| `backend/` | Checkout, renewals, member area with the self-paced course and certificates, online instructor exam, and admin (Next.js + Supabase + Stripe), plus a no-code route | `README.md` or `NO-CODE.md` |
| `delivery/` | Curriculum (six sessions with decks), demo-day rubric, instructor playbook and certification, support, emails, self-paced course content | `README.md` |
| `business/` | Licence agreement and pricing, compliance pack, launch kit, sales collateral (decks, one-pagers, ads, demo video) | `README.md` |
| `licensor/` | Running many licensees: automated set-up of a new licensee (`provision.mjs`, plans only until `--apply`), a fleet console for their quarterly reports with a live local view, and release signing | `README.md` |
| `plugin-marketplace/` | The skills as a Claude Code plugin in a private marketplace, for licensees who want it | `README.md` inside the plugin |

## What only you can finish

Seventeen items are built but need something that can't be invented for you: your accounts (Stripe,
Supabase, Vercel, email, webinar, community, the tools you connect), your real dates, brand and
instructors, real testimonials and Cohort 01 results, a lawyer's review of the legal drafts, and a first
run of the skill tests with your own Claude account (`node bin/wf.mjs eval --all --dry-run` shows the
most it can cost before anything is spent). They're listed in section 2 of the gap closure report, and
turned into dated steps in `business/launch-kit/launch-checklist.md`.

## Checked before packaging

Kit 158 tests, hosted runtime 28, back end 134 plus 70 database checks with clean types, licensor tools 9;
every skill passes the security review; every website page, both embedded apps, the 29 member and admin
pages and the 22 console views checked at desktop and phone width and against WCAG 2.2 AA; the plugin and
marketplace validate. Live third-party accounts, a real run of the skill tests and a real cohort are not
tested here; each has a test-mode step in the launch checklist.
